GS.dataCache['03B299305051E7484A3ABC5489EB98D2606B'] = {
    "uid": "03B299305051E7484A3ABC5489EB98D2606B",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C12-7 Queen Munie's truth",
        "type": "vn.scene",
        "parentId": "0DA051010899144EF2189765D0B2BF2E5564",
        "chapterUid": "6050980F4DA8824E656AEA34864FAEA22853",
        "order": 9,
        "localizableStrings": {
            "22DFC2331F78874B098ACFE3AF6BE8C72975": {
                "t": "Ahhhh...{W:300} Ahhhh...{W:300}\nWell done...",
                "d": {
                    "cid": "314B7C2C33CDC44BF73B2888D2C21ACABDBB",
                    "eid": "48AB0E3F5F0BB34A48492D27C6ED694A1F97"
                }
            },
            "60AB49062F00E642005913117605CC3665A8": {
                "t": "It was a challenging battle.{W:300} I expected no less from my foster mother.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "E36448F432B85642B20827E414C04923B36A"
                }
            },
            "798948DF8F2CD64576193C025CA00D7907DD": {
                "t": "Though perhaps... this look is more... appropriate.",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "4BEC99FC69EA794F8D3A44E2F2F800AEF768"
                }
            },
            "6B702E803067C94A0319052684CD6E185D72": {
                "t": "Who are you really, Queen Munie?",
                "d": {
                    "eid": "DDBF8ECB6233C542C6687EA36C39B7594D9C"
                }
            },
            "B8D96B5470ADC945B57AF032D912DFC5316F": {
                "t": "Tell us about me and Shiori.",
                "d": {
                    "eid": "6214A2EA056E064B282B00400F19FE1352F4"
                }
            },
            "01125D1F7895E147505826C77F2F826D7198": {
                "t": "What do you know about Elias Lehmann?",
                "d": {
                    "eid": "E212B6517C5AC6444C1A15170329A7E33564"
                }
            },
            "0E8AA82A8ACCD348221AAD016E6D7377C18A": {
                "t": "It's a little strange to ask your mother a question like that, don't you think?",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "5F0C01891C4AF74FA03A58088447118F6A13"
                }
            },
            "58E3BBE03A330744C45AD266DBD9495E85EE": {
                "t": "I know you were a general of Hoikade. But before then?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "A2E9D69F888456494F9BD143272D686F16A8"
                }
            },
            "BDE79975549DA84FFA390D33E86C332C7B5A": {
                "t": "One last question, now...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "3F2727775C57D542EF3986872E081E71F9A6"
                }
            },
            "0C56B8EE8B69F94F3D4A17853BE17555B232": {
                "t": "These revelations are hard to swallow, but... I need to ask her a few more things.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "CA9CE5DC5A37934CD30BEA38CAB49E126E37"
                }
            },
            "AD42A70064C7A8488089DB26BEAEB6D727F5": {
                "t": "I hope you can adequately compensate us for our efforts now.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "87DF1F2D7941414416687D84CB18C465A0EC"
                }
            },
            "CDDD1AFD6B6F4745964A18F9759BAF973FDA": {
                "t": "Heh.{W:300} Harsh but fair, as always.",
                "d": {
                    "cid": "314B7C2C33CDC44BF73B2888D2C21ACABDBB",
                    "eid": "E781295F9068A7492F497214209B3BCD3B29"
                }
            },
            "E3081490724BA84BAB3A09834D2B61AB9730": {
                "t": "Don't worry.{W:300} I plan to honor my promise...{W:300} before I leave.",
                "d": {
                    "cid": "314B7C2C33CDC44BF73B2888D2C21ACABDBB",
                    "eid": "EB4EC26F62D33643747894951FDFB1D1C273"
                }
            },
            "6E22A85780E7B84DFF480421CEC83DE47C29": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "DD86152A2CF4C84F15696A653D34D7F986CA"
                }
            },
            "A6EE5EBF3E91334BAD3BA5E1064F9B29AA2F": {
                "t": "Not even Magnolia has any in-depth information about your past, Queen Munie.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "1B27415F40DF87466C68EFE2D95488F21B7C"
                }
            },
            "0B81288F956019449E0B65A1FE0AE5BC9DE6": {
                "t": "And of course, insisting would have caused diplomatic incidents.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "09278DB1896EE44D277A2768CAE7EB355335"
                }
            },
            "3FC4D69445793340854822B70DB01EF5D7BA": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "E6E2B0F638176342CE8A5D95E5EA04EC1526"
                }
            },
            "E591C9B27D270944553ADD97F931BD7FB9BA": {
                "t": "Hah, I thought I was going to die carrying this secret around with me.\nCough! Cough!",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "CCDA43072BBFA549332AA5C62441E6CB4581"
                }
            },
            "70ED1DBF1932B84A215A16C514CEC3FE2C8E": {
                "t": "I... was a {SP:1}{C:1}spy{C:0} for the Church of Pylum.",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "2CCF435F581EE642DF19133499087C7BE069"
                }
            },
            "9AC5F4939BBB0149FC8BED826D50F7EB2857": {
                "t": "Say... what!?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "CD7A29F233EAB440E89A7E84AF0942CCEDC0"
                }
            },
            "E96CD6156A57E34CB81830573F6CCDF7B732": {
                "t": "A spy... from the Church?",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "15F9860C269C984314293484961100EB6085"
                }
            },
            "5CBD086A59F8C04EC50A3547409E496B7BFF": {
                "t": "I find that hard to believe. Why would you infiltrate Hoikade?",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "D416824C17BA59415538DCF33AFF962B3761"
                }
            },
            "F6CCA9408B64D845728AD8806F246CD103E0": {
                "t": "The Church has always kept an eye on the research of Elias Lehmann and Saito Pascal.",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "13C7F027295EB94AFA5BE583BF82B99F38A4"
                }
            },
            "508E237D50AFB9435B2A8BF35AD2C122E6E9": {
                "t": "We wanted to avoid any disasters that would shake the entirety of Arvium... Cough!",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "BB4A9CCE2FFEC9427508572725B9B6C11317"
                }
            },
            "F7300D062BF2584C522840F650F60EA826A3": {
                "t": "It hasn't worked out very well, so far.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "97A32A2C76B39248A19B41B75E5764862EC4"
                }
            },
            "14EA48DC03B77644302B4FE905F69B88EE8B": {
                "t": "Heh... it wasn't easy to keep an eye on the ramifications of that wicked research...",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "1545717660A499431F2AC5971BDFF13BC238"
                }
            },
            "4CCEA3D2325D6742485BB1C5A6A73D83DD71": {
                "t": "Amaranth's Manacrest on one side... and the Vassals of the Demon King on the other.",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "311D9B0851A365417E58D9C8BF1004917EEC"
                }
            },
            "B87B94EF3E23B84EAE0BE686961ED941695C": {
                "t": "I, for one, was in charge of making sure the Vassals in Hoikade didn't get out of control.",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "831191918D2B3746B3193E9763EB46186F7B"
                }
            },
            "D43E69AD35EB5940DA9A8A913E83D3E1E2B0": {
                "t": "Mother... I had no idea...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "F7780E464B28804F16497755B29B8C96A6CB"
                }
            },
            "A691067347C1044AFB2AEE97231F78661BD8": {
                "t": "And the fact she kept an eye on me all this time now takes on a whole new meaning...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "49575ECF3CF05848646BEB76FF34B2241B09"
                }
            },
            "ABA8CB0655DAB646430A67817C16C74368B6": {
                "t": "If your role was simply that of a spy, why did you become queen?",
                "d": {
                    "cid": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "eid": "7ECFA0713CB3E3406B0BAD68F3270190374C"
                }
            },
            "4995FF51692AF64482396A6181B8A2D7FBEB": {
                "t": "It wasn't planned... initially...",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "B5F9414C765F5144C88AACE5ABB10C0A5B7F"
                }
            },
            "583A287C573E734918597952D5EFDA939A1A": {
                "t": "But living in Hoikade for so many years... I became attached to the people... and vice versa...",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "BCDB65A124727748BF1BDBB9C2A0536E7C36"
                }
            },
            "BC6BC26E1AFAF34EFA2B3549908D5531E0DD": {
                "t": "When the previous rulers passed away, it was the people who elected you, a general, as their ruler.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "9FDAE71D62D2244FFA68AE878FC20A67FCBD"
                }
            },
            "0E76BFC78113834D0D2B3A6842F37B358943": {
                "t": "... ... ...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "048228EA2EE6464C586A3AA352A315EA55F1"
                }
            },
            "058CCC8432432844717AF6F8AE02621170C2": {
                "t": "Yes, it was a popular choice. All in all... you made the people of Hoikade love you.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "96A64F377DAEA840C42BD3F3F72D58E0ACC5"
                }
            },
            "430E48C069F91346768AE8397E61E00300E7": {
                "t": "Fa...",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "8E36D5D050E797404C4A3A98020DDC92462F"
                }
            },
            "412923447F6C2441743905B40A982B61B479": {
                "t": "Maybe I should have... believed you, that fateful day. But...",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "E02ACB5289EA714AB978EC814D8C5C58BD1B"
                }
            },
            "D5247BDE1EC2624BD468AC38E3AF60EA5A4B": {
                "t": "I... I think I understand it now.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "AD6FA6F62BF6C1425678D1D28A06E83E6624"
                }
            },
            "AE6198E138F8C4472099358675C8291BBA7C": {
                "t": "Having to represent both Hoikade and Pylum's interests... You couldn't risk throwing away a lifetime's worth of effort...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "30C286E41B65B3467A682FE6B9DFB4D08EFF"
                }
            },
            "A911BB496DF977434F59D86421286DD98DD1": {
                "t": "You just chose your duty and your people over your daughter.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "8078D9038E2E73499F28B2611FB9C7489245"
                }
            },
            "61AE3BD85B37E846C77967246174B45C21E9": {
                "t": "Hehe... At the end of the day... Cough!",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "F734C8655FA3C44F2F1B935442D6EAB7650C"
                }
            },
            "609690EF732774481D8B972700AEEBADDA46": {
                "t": "That makes us quite similar... don't you think?",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "1D940DB62AAD8641B3399F88F4295AAD8637"
                }
            },
            "7B3D5ABE1849F34066799BE95CB47239FF6B": {
                "t": "Yes...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "7360D3CD8A315547D94B9754C6E8C2BE5C50"
                }
            },
            "E7FD274C22B6C145FE797C582019FAE9EB1A": {
                "t": "I also acted by putting the good of the people first... sealing away my own feelings.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "610FA5682C9B0444551983A9B63142C9B4C5"
                }
            },
            "7033F1DA91D59245835838A5A81878EC37A7": {
                "t": "Mother... If only we could have understood each other better...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "0F9D599616A8B8431B9991A8538187635E59"
                }
            },
            "07E696FB2F19574F6C984BA765B51CCEB9D7": {
                "t": "... ... ...",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "324640D05FA7B2493B4915784F4380EC9338"
                }
            },
            "D33978050F49D74D7889C475ACD3E193C15B": {
                "t": "Please, Queen Munie.{W:300} If you know anything about our past...{W:300} Anything at all...",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "C2318FEB8AB033496F5B6CC5DFDF4CE9E616"
                }
            },
            "C308BC735E76994F037B63075C6BDEABBC87": {
                "t": "I was there when you two were born.",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "81E50B5E64241448EE38E5A00897E8E1278D"
                }
            },
            "440437227E932742625A21B1FA91E1D0D283": {
                "t": "When...{W:300} \"we\" were born?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "FD4AAECF43CBC74DFC998E37BC9F25162371"
                }
            },
            "44150C0C2E61B643AE6ADCB60F345D854034": {
                "t": "Cough cough!",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "9F0A30F67849A241D1690B91B28F9E020A11"
                }
            },
            "18AB1FD20D61024F3A5AFEC5FBFF28FFBE51": {
                "t": "Explain yourself!{W:300} Does that mean you know something about our real parents!?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "EBEE0D2762FB58437689AE12919C8F0DA72D"
                }
            },
            "7AE80F4D0396B649D788EA4607DD12631B83": {
                "t": "It was a delicate situation.{W:300} The former Vassal was losing control.{W:300} We had to transfer the Demon King's soul...",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "B3A656772CFAC94C793A5FF575DC8005DF65"
                }
            },
            "0AC1E05A23DD13462179A628C276A27EE406": {
                "t": "But the only compatible person...{W:300} was the child in the queen's {SP:2}{C:1}womb{C:0}, who was pregnant at the time.",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "2618F27B3739C5431A48DD498F4768A04D69"
                }
            },
            "5C4BF9157926654BCF581CF9DB3A209411E5": {
                "t": "You...{W:300} transferred the Demon King's soul into the pregnant queen's womb!?",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "9B556E2D4BC32841288AF5D2BDB247333239"
                }
            },
            "10B17E877457444BD98ADAA39728C5623993": {
                "t": "Yes...",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "6C2038D77571A145DF2B01A338306FA9AD58"
                }
            },
            "D72AB6386F58004361195FC7F473DD18EE7C": {
                "t": "I knew that the Demon King's soul had been passed to me as soon as I was born, but...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "C49052013B75984AAD3951F81C26C7BB0B68"
                }
            },
            "F3FC080927B6B14E6F3AC4A8FC7079C2CF23": {
                "t": "It never crossed my mind it could've happened even BEFORE that...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "7C6CCE7056519142EB99E9D6221411190C77"
                }
            },
            "859EEA87520B0549F48B1293FDAB088D42DB": {
                "t": "That's insane.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "FD1292D25BCD04491A39F9120967A9A2C129"
                }
            },
            "BEF6866E0EC4E140C539AAA635A601746163": {
                "t": "But it was the only solution.{W:300} Cough! Cough!",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "43CA30CC7A85524F8B98A110E4C2D596BA23"
                }
            },
            "0EBF8D942A2137448B1A7353E4EC743F56DD": {
                "t": "Who performed the rite of Vassalage?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "0A4968FA4B8A2248C44954B0D9942DCB15C6"
                }
            },
            "514AF9139A2B95455E0A1E91A9DD9A002DCE": {
                "t": "Her Holiness Soraya, herself...",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "2E262FCC755D784EF2580020387E3FECEA93"
                }
            },
            "E9E026AE1A8841490B3847217AA760A0519C": {
                "t": "The Matriarch...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "6833D7FA15FC27415D395FD29D0DCE827C37"
                }
            },
            "72CC5C6746E0704BBD3A0584DAAA366B748C": {
                "t": "Cough! Cough!",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "BB972A2374395044D68B47B6B64F1B74DF94"
                }
            },
            "4B36D13E38C8994FB17B96B1AE33DF899A6D": {
                "t": "Mother...{W:300} Please hold on.{W:300} We need to know the truth.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "61FE80915BDF1543AF1875A07E1DA01F3862"
                }
            },
            "E0073C3F6CDD2344152B1C413E521D823249": {
                "t": "Heh...{W:300} Let me show you...",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "6A52FA7A542E354AA56AA022C3AAB7885854"
                }
            },
            "85D348DE17B80547D59914F9268335BA614C": {
                "t": "It's easier than...{W:300} just talking...",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "6F8C872911D9D64B5D58BF82553125F8A67E"
                }
            },
            "2071EFE44AEB824FDC5A51E4A82A80297F36": {
                "t": "Hah!{W:300} Something appeared in my mind...",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "D4AC34B02520D845788AE260C1BF491F9E63"
                }
            },
            "145EE4D94923B1422B292D378F1BBF5E016F": {
                "t": "So, you can see it too?",
                "d": {
                    "cid": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "eid": "3573F2403A3D324C9D381A2855FDF49C761A"
                }
            },
            "3DEB44F58B33A34C665B6D283FE86B89943B": {
                "t": "What's this vision?{W:300} Who are these people?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "BA8A59202D4BC2433B2B4C063D4134EB04E0"
                }
            },
            "3C52D3807CF9B545DC3BA55632A16EC5F4CA": {
                "t": "Your...{W:300} parents...",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "0C384E132F54A4456D6B5DB32AE4E75A77FA"
                }
            },
            "4377A0169633504EF8296FB13825CC20B2BB": {
                "t": "... ... ...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "4B8D8DD192BC8145601BA534030C3BAA3571"
                }
            },
            "7168D0679146A94E83198061FBE868F8E55F": {
                "t": "That day, when you were about to be delivered...{W:300} something went wrong.",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "926674972C21254D6068CDD21911EA787904"
                }
            },
            "855333C91144924C13197707ABB1980287EE": {
                "t": "There was a magical explosion...{W:300} and everyone in that room...{W:300} died...",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "430F89F64F95D446C878A6E5F15B218C1F83"
                }
            },
            "1A7BCB2A1E83184D3638E288A75B7BBE3150": {
                "t": "Mom...{W:300} Dad...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "9E2AAB9B86BCB34B562BB42486D0455AA1A4"
                }
            },
            "136F2BC33C94C04F918BBA082F4F6C14EEE8": {
                "t": "Next to the body of King Alfhrìd...{W:300} Soraya and I found a baby...",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "22BBBCD55DAE054EF32A73965E9548095FC2"
                }
            },
            "DCB6FB8C9E9F0247696B27D7917C47BA1736": {
                "t": "She was crying out loud, almost as if she sensed that her parents just passed away in an attempt to save her life...",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "56BFD2382509204EA91BC072050FDAAD964B"
                }
            },
            "3F3CD0F743C6D24DF90BAC88C87337D44491": {
                "t": "No...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "25AE32DA586188413B19A3E27AACDF1B8D78"
                }
            },
            "C1C498E833D7334B2D2BB852C9788BB7DB90": {
                "t": "The king must've protected her with his own body.{W:300} Yes, that child...",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "E7CD3844340BF740F23B8873FC2AC2020EB9"
                }
            },
            "BB6D9F49770F914693595F680BF08AF360A6": {
                "t": "It was you, Fa.",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "AE6B7EBF6A5DC344841B409936A167ECAA16"
                }
            },
            "F99A555D130AD54EDA6A258581F69D5C9162": {
                "t": "But you weren't alone.",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "6ECEA0A88611A649AC38B562AF0189D5D169"
                }
            },
            "180EA1AF420142403D799699763E395CC81F": {
                "t": "That...{W:300} can't be.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "5AE3F5034C1E3948511B0188856A332F52A2"
                }
            },
            "13E9B28782571141BB6BBF26112131689182": {
                "t": "That's...{W:300} me...?",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "6A802FD46CD4C64468297FE0AFB7DA33EF32"
                }
            },
            "050CA7772987B74AA02AFE6366A05C2906AE": {
                "t": "Yes...{W:300} You two were beautiful {SP:1}{C:1}twins{C:0}.",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "1EA2CCA73EA8D6486749734156ABF1018934"
                }
            },
            "AE1EC1D677D9F548BD68B9E3FF6E914DDB1B": {
                "t": "So it is true...{W:300} Faratras and I are...",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "35001CB65FE554428A48F3438B3BD6BEFADA"
                }
            },
            "20F4C58587C559411698EBB21D542E03FDD5": {
                "t": "Twin...{W:300} sisters.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "E905642C4E57C941DD99A774F81CE65278B2"
                }
            },
            "CCF472A55A80F4427009ACE3D8B8CAB50B2D": {
                "t": "Cough! Cough!",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "69FA64153261E240521B45122A9DF5C3BC35"
                }
            },
            "57C07DD9385297487E38A8E7E2C27BAF9E01": {
                "t": "Faratras...{W:300} had inherited the absurd magic of her grandmother, Farilde...",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "24CC84277A11D249836A30D4B17544773254"
                }
            },
            "336E83213A50F44FD5786BA1DB974F5E1265": {
                "t": "And you, Shiori...{W:300} you had the seal of Vassalage...{W:300} the power to seal away evil.",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "C80C942A127E584CAC68FEB12D41338BC674"
                }
            },
            "58ECE2754FAAF6499A7A2217661E457D1526": {
                "t": "I don't know how to feel about this. It seems too surreal...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "B1AA72767A0301460B8992F48891F2349FE3"
                }
            },
            "6167BFDC0B3AD94D4D3A1AA043818559C90E": {
                "t": "Unfortunately, we noticed that Shiori's seal had reacted with Elias's soul...",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "E342A8A8793E9145FA592E26AA5B69B37315"
                }
            },
            "9C63A73C6FA1E44C3B0878413724AE4E5848": {
                "t": "However, lacking the necessary magic, it had an adverse 'reaction'.",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "10E83A1F3BF6B748AC2A34350F42EB32389B"
                }
            },
            "3483FDEA2153234E006851057B88E547837A": {
                "t": "So that's when I lost my sight and we exchanged powers?",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "4CE50E2E4CF0444C723B351824C5A7F14464"
                }
            },
            "F3DCB6EB692478409D88C418E290DB1B78E0": {
                "t": "Yes...{W:300} you took from Elias the power to sense malice.{W:300} And from the stress of the reaction... Cough!",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "48C3F49329DF9541F87A05A27B7BDFA5626C"
                }
            },
            "54B5B543115F564B116BF429EE2D0729C3BF": {
                "t": "Your hair turned silver...",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "0FFF87F25D0E184BC3987CB44A92E903A2A5"
                }
            },
            "0D8E8C394EAFC145F58BB05167313910EED8": {
                "t": "... ... ...",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "AD0ED5E32087A2439588AAB56AB33B0E7A3B"
                }
            },
            "8D432A308F5E8741B4185A8686861641B6B9": {
                "t": "Her Holiness Soraya was appalled.{W:300} There was the distinct possibility...{W:300} that Elias had already corrupted you.",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "B56A14198FAEB84E4B1BCFD1FEAC7D12C2D9"
                }
            },
            "8AA4D8945BFD6345C60B4DA945086066B1FE": {
                "t": "So she took you with her to Pylum...{W:300} and we hid your origins...{W:300} to prevent the people from panicking...",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "9914913C230F974C217A251375ECC4CE92AF"
                }
            },
            "A3EA891B48AF554B5A9BA8D345DC169DC70D": {
                "t": "I'm at a loss for words.{W:300} Do you have any idea how much suffering you've caused to these sisters?",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "5E82BA348C87124F0128D6680453C127DBB2"
                }
            },
            "D0C5624C5D1F74453D0BBD53B38C67842C82": {
                "t": "Yes, but...{W:300} Cough!{W:300} What else could we do?",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "C5A7031086B18446E1393D65719836D88962"
                }
            },
            "F22073EF99FA834E3D29F0B3D43D327D9399": {
                "t": "They were both unstable, and...{W:300} destined to fail.",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "44BA956D2F76054F002B7CE4E336E40F16C4"
                }
            },
            "3695388F2E697944A4381F28820B644CBC9D": {
                "t": "Faratras was missing most of the seal, which allowed Elias' power to leak out over the next twenty-one years, creating the Hellios you knew.",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "EDEDC3D192E2544D5A8A5FD743592BDEC616"
                }
            },
            "9D03993D4B0DA645CA8B79C546CCBC710CD8": {
                "t": "Ha...{W:300} hahaha!{W:300} Are you trying to say that no matter how hard I tried...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "E64B8A1882767343962B1A1233762561AC72"
                }
            },
            "4121C9736F68554AE3198175B35C20B0FEAF": {
                "t": "...I had...{W:300} already failed as a Vassal...{W:300} from the day I was born?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "C2FC8CEA4072714B503989A6A3F677B7761D"
                }
            },
            "DD6F859319FC48402129470091B8E4A5F46B": {
                "t": "Yes.",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "ADFC0A268B5DB149425BF441D03BCAE4951C"
                }
            },
            "DC6A186A6F6CC84C1B0A31D11080CDBE17FD": {
                "t": "You know the rest of the story.",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "F2C87E8D7541B84CCB59105550CE760D89BE"
                }
            },
            "8C612CD71AD1364910892917990E29C68C0A": {
                "t": "I... was an incomplete Vassal...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "9F164EB98A2376488E2816A7D6372609B12A"
                }
            },
            "A0E6DA574A6F0243AF1B16D134007C2F4411": {
                "t": "And Shiori, my twin sister, was the missing piece of the puzzle... all along...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "CCE595658B85384B4A3BE944C11079850FE6"
                }
            },
            "241B48BD606D34445728DE6744ACA076BFAB": {
                "t": "... ... ...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "088974BA53A961468B383665027010F6DFF3"
                }
            },
            "87AA843C6DF8A746FA881B53BA46AB45EF69": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "9149D6DB52EF4944456B37A133A7FB8FEB1F"
                }
            },
            "477F8732223A2447768A507488D613DC97A9": {
                "t": "I'm afraid I don't know much more than you do... Cough!",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "EDB242C33DBCB24E0088ADE14D86EE892171"
                }
            },
            "90EA3ECC43295348A24950B5A7C466B2CB55": {
                "t": "He was a brilliant researcher... but he got overwhelmed by his feelings...",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "0BD5648164B9B14A484A41C72F9BFB39DA2E"
                }
            },
            "1FCB4BF571732043515AF7916473AB9946F7": {
                "t": "Did he have an affair with Farilde II Hoikade?",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "5E58FFA665B918481B8ABF116E683F6ED16C"
                }
            },
            "2580C3636487E34ECA5B80279FD561B532AF": {
                "t": "Rya... Do you really think that...?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "1FE08DDC4FDEB24C1D0B0CA7939929050810"
                }
            },
            "CAC33E858CF9E6477E48F36495FC1EDAA68D": {
                "t": "If I recall the records correctly, Farilde was already in an arranged marriage by that time. She'd already given birth to Alfhrìd in fact. However...",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "4B7F67C709F621432359100138ECE1CB173F"
                }
            },
            "F1BA9DA17F59054EA13AF8D0A597B3DCC06F": {
                "t": "The evidence we found in the underground laboratory leads us to the hypothesis that Elias had strong feelings for her.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "6B419A126B7D87410C4AE8F5B6C9DD523DAB"
                }
            },
            "316C5B466153414B373A5E14C4A3DCFDBE7A": {
                "t": "It was never made official... but it was clear that Elias was willing to take his research into unsafe territory... all for her sake.",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "1481CD966C90784B4C4B0E815AE2D76F5645"
                }
            },
            "C859324F4F1E83425D4AF0C60A250648B37B": {
                "t": "If I'm not mistaken, Saito Pascal's research was much safer but it'd have taken at least 50 years to fully develop...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "FCAF826142F9E14E9A9B243362220CE7F13E"
                }
            },
            "FF120AC37483274AB50AE57740C13CFE696A": {
                "t": "Elias Lehmann couldn't wait. He wanted to save Farilde from her illness because he was in love with her.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "EFA0DB526DB86845F56A9DB43C73D522CDEC"
                }
            },
            "8BCF36E689097142494838A68EEEEB415852": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "0B4C7B21923F43436338578705608019D8C3"
                }
            },
            "E1084EA40F69E24A0E29C7F6D6445A725267": {
                "t": "Yes, that's right... Cough! Ironic, isn't it?",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "FE54189033720841C92AF9D360CE08CEE503"
                }
            },
            "B89B27CA438870438858EBA30305B9AA8FD1": {
                "t": "Sixty years later, he posed as the brother of the granddaughter of the woman he'd loved...",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "F062D4C79176E649582A55C55EAD6E436E42"
                }
            },
            "152C5A68951C4243591B2DB816C89E3C27DE": {
                "t": "... ... ...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "9CDD214940E9C64DDD0BFA95EB2BC5425394"
                }
            },
            "4C62402F04377345B0789E114B7BA48DB719": {
                "t": "Why?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "F73C5AD78D95E448597B44362114BC790293"
                }
            },
            "B0481E08261E404F4F0A150061378DB6183E": {
                "t": "Why did Elias turn into Hellios? Into... the Demon King?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "6A43DDA9235406460C496B911B4E40E9B0E2"
                }
            },
            "5136BA5F8C9AD64F7549A16713274B620D77": {
                "t": "I don't know... But judging by his fury... The fury that I can also feel through this power of his I possess...",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "F0939DA59FEAE44F8B89B53565A32F83A4BF"
                }
            },
            "ED47AB8C152BD447277A5DA0FBB9A172B2CE": {
                "t": "Something must have happened to Farilde... Something that made him make drastic decisions...",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "F806EEC1669181462059A273580CFA48AE51"
                }
            },
            "97912C8748EB65492E3A30185378A9FC1002": {
                "t": "\"They will pay\".",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "978501EE89C90945146A40B7656853C985D5"
                }
            },
            "C177BECC8F6A6748349B51E373A2F178BBEE": {
                "t": "... Right.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "F99ED00414A9A5462B4BC795A8911DF614B4"
                }
            },
            "463072DE387F634E637A5A07A5AF9E70A983": {
                "t": "But I wonder who he was angry at... and what happened to my grandmother.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "DFD09F9D941FC244B51B48A1E9729A79B00A"
                }
            }
        },
        "commands": [
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            20,
                            1,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "ED5FEC7075D698463618AB6217633658A14E"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "FEAEB6DD2243514BDD8AA13134F5C2CB83C9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "4AFB18644E9F1541AB7BF912BF3013A47092"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "D71400347744034C5B0ABBB6D9FA3495F53B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "F4D01DE8672FA949891B7BE8F65F59F49827",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ED393FA87509954A997A7A256022B30434E2"
            },
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 0,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 240,
                        "y": 240
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "397FFCC724B3724AC8583627666EDDE0CAC8"
            },
            {
                "id": "gs.PanScreen",
                "params": {
                    "duration": 0,
                    "waitForCompletion": 0,
                    "position": {
                        "x": -5,
                        "y": 100
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "3D63FC499D610841034B76197EF1B0D818AA"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "EEFBAB4B88633546EA3B79A3011C51C3BE0F",
                        "name": "19 - Queen Munie"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "74BD92A968B824420C7833E55CC4BE767C97"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "2D020C1916A3814359783A811324EF00AF65",
                        "name": "92 - Shiori Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "DA7872C95286B3456888CEA7EDA724A76D5D"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "0FCC16EC8F14214F211BD711C5EF156BDE65",
                        "name": "95 - Rya Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "310561EA0CCB844F4F3B1E34407DF91125CE"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "567F1E3489D91446CF4A0ED6AF508D6BB339",
                        "name": "96 - Cristoph Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "D7A49ED814BA7145B31B4832AB912ED29C35"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "73FF2C2B2558A541171A3D65A72D2412C128"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 54,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "3BE816239CF1424CC35889617F84A3BEC616"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "8A56D341769E50467119331944B99FFC8687"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "807B4DD16E67274BA23B4CD559898E3B5FEC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B609288F2E2D834ABE1889F71EF59B198F86"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "ui"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "314B7C2C33CDC44BF73B2888D2C21ACABDBB",
                    "model": {
                        "name": "Nefertiti.model.live2d",
                        "folderPath": "Live2D/Z1 - Enemies",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 4999,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": -1900,
                        "y": 454,
                        "zoom": {
                            "x": 1.8,
                            "y": 1.8,
                            "d": 1.8
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 0
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "4DEA87825CA9664D9F796734C3F690C8CE21",
                "expanded": false
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "314B7C2C33CDC44BF73B2888D2C21ACABDBB",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.2,
                    "idleIntensity": 0.2,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 1
                    }
                },
                "indent": 0,
                "uid": "CF0DD8DD844AA943F27A6D50A2DCACC0CD78"
            },
            {
                "id": "vn.L2DMove",
                "params": {
                    "predefinedPositionId": 0,
                    "characterId": "314B7C2C33CDC44BF73B2888D2C21ACABDBB",
                    "model": {
                        "name": "Nefertiti.model.live2d",
                        "folderPath": "Live2D/Z1 - Enemies",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": -880,
                        "y": 454,
                        "zoom": {
                            "x": 1,
                            "y": 1,
                            "d": 1
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 18,
                    "waitForCompletion": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0641D15434783242FD4BD9D5FB378FED9E0D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "314B7C2C33CDC44BF73B2888D2C21ACABDBB",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C25B6CB07460014EE6284643061464F96940"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "22DFC2331F78874B098ACFE3AF6BE8C72975",
                        "defaultText": "아아아...{W:300} 아아아...{W:300}\n잘했다..."
                    },
                    "position": 0,
                    "characterId": "314B7C2C33CDC44BF73B2888D2C21ACABDBB",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "48AB0E3F5F0BB34A48492D27C6ED694A1F97",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E465F1EF4116B749E639E53757E68DE135C6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "21A407A619C46346452BA6C7C8BE890E81BF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "60AB49062F00E642005913117605CC3665A8",
                        "defaultText": "힘든 전투였어.{W:300} 내 수양어머니라면 이 정도는 될 줄 알았지."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C12-7_line2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "E36448F432B85642B20827E414C04923B36A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5F6766362743354EA2291FE37F9C7E71AA81"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AD42A70064C7A8488089DB26BEAEB6D727F5",
                        "defaultText": "이제 우리 노력에 합당한 보상을 해 주시겠지요."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C12-7_line3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "87DF1F2D7941414416687D84CB18C465A0EC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "75EA02259DC0F24A823A0C2030B737A0FF2E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "314B7C2C33CDC44BF73B2888D2C21ACABDBB",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C9A88C6D5DF2E4446F4B37023D1BB323AFAD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CDDD1AFD6B6F4745964A18F9759BAF973FDA",
                        "defaultText": "후후.{W:300} 언제나처럼 가혹하지만 공정하군."
                    },
                    "position": 0,
                    "characterId": "314B7C2C33CDC44BF73B2888D2C21ACABDBB",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line4.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "E781295F9068A7492F497214209B3BCD3B29",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4D0B7AD852EDB146588B9DB1C15CA1FF14D4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E3081490724BA84BAB3A09834D2B61AB9730",
                        "defaultText": "걱정하지 마.{W:300} 떠나기 전에...{W:300} 약속을 지킬 생각이니."
                    },
                    "position": 0,
                    "characterId": "314B7C2C33CDC44BF73B2888D2C21ACABDBB",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line5.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "EB4EC26F62D33643747894951FDFB1D1C273",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "B42743B73FE3B6490F1A38B1A469E3C85D17"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "B81EBC6C1F4BE7455B59423632DD185B8E0A"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Battle Animation sounds/Spell sounds",
                        "name": "Candelabra.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "722FD22433EE674E993910B495351FF5E523"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "314B7C2C33CDC44BF73B2888D2C21ACABDBB",
                    "duration": 15,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "50ECF0F076224048F97A67810D7A81D11743"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "577D4C6E2D68654FF2883C59BF0F9D33436D",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            250,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "2A7484D164F0234CBA7A8188F13F4FF04FA2"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "2F48DF85542ED746646ACDD5151703A85572"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EE4F2492791CB74F284B47699AE0E06B4438"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "D18997D11F8590426E4AF1C9B38854E77F4C"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "(she transforms back to her human appearence)"
                },
                "indent": 0,
                "uid": "833CB7B05F924645C6382639C436F0217669",
                "expanded": true
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Battle Animation sounds/Buffs Sounds",
                        "name": "DEBUFF.ogg",
                        "volume": 100,
                        "playbackRate": 140
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2EA4EF31622B224B7A7B2A3363D2D14B7040"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "577D4C6E2D68654FF2883C59BF0F9D33436D",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            450,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "13D48CAF829EF84FE83B6926FC7C9DD5175A"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "model": {
                        "name": "QueenMunie.model.live2d",
                        "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 800,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 882,
                        "y": 628,
                        "zoom": {
                            "x": 0.2,
                            "y": 0.2,
                            "d": 0.2
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 27,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "8825465C67645640511A92C7EA799F783567",
                "expanded": false
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -30,
                        "green": -30,
                        "blue": -20,
                        "grey": 100
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "69E44EF532C26241C44BEEA2122EB86473B6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "BCF8C23085B7324602693066E56A36B6D283"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "230EB8EA21A1544CCD382458CBC68D6F65CD"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 42
                },
                "indent": 0,
                "uid": "476810101D86B544603AC4F5D0E6429F4527"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "98F0F9AD68DC624959483AB397759ADE7761"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "88E94C1F9710F3443E3986E4030D1AF550BE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "0D0AC7261E377140114AAE49DA42943F9399"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E824A6A15A09534F0129C538242E319136B7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6E22A85780E7B84DFF480421CEC83DE47C29",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "E3-Munie_line13_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "DD86152A2CF4C84F15696A653D34D7F986CA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "07E450FD98D1C24671693066D2A549BF6170"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A31815FB134C2241F009F8051764F3AF0A6D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "798948DF8F2CD64576193C025CA00D7907DD",
                        "defaultText": "하지만 어쩌면... 이 모습이 더... 적절하겠구나."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4BEC99FC69EA794F8D3A44E2F2F800AEF768",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "3D8E5A8A5182154CD62ADC656E2A77754247"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "6B702E803067C94A0319052684CD6E185D72",
                        "defaultText": "무니 여왕님, 대체 누구시죠?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DDBF8ECB6233C542C6687EA36C39B7594D9C",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "B8D96B5470ADC945B57AF032D912DFC5316F",
                        "defaultText": "나와 시오리에 대해 말해 주세요."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6214A2EA056E064B282B00400F19FE1352F4",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "01125D1F7895E147505826C77F2F826D7198",
                        "defaultText": "엘리아스 레만에 대해 아는 게 있나요?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E212B6517C5AC6444C1A15170329A7E33564",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "munie",
                            "sisters",
                            "elias",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "A95B979070F0644F155B83D08C5F6009B75E"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "Loop Start"
                },
                "indent": 0,
                "uid": "EE5B34E069F74445F38BF8C117F6531E7FBD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "F4E9ECCB7A15C749373BA6F870A709D100EF",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "295F619A83A71147F58B23051BD172BE0D93"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "munie"
                },
                "indent": 0,
                "uid": "D8FD8BE521757540F35A6C385AC55CF12A9D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EB9F84974B2ED74A1E7BF726E6F6E3B1C519"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FEFE4C909B4BB84E537BAE89B0DE7EF37732"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0E8AA82A8ACCD348221AAD016E6D7377C18A",
                        "defaultText": "어머니에게 그런 질문을 하는 건 조금 이상하지 않니?"
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5F0C01891C4AF74FA03A58088447118F6A13",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4E73DA4B68037040B98AC53475445A9AF7D0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FF9B5B5474C2734FC5588090E4559475655A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "58E3BBE03A330744C45AD266DBD9495E85EE",
                        "defaultText": "당신이 호이카데의 장군이었다는 건 알아. 하지만 그전에는?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A2E9D69F888456494F9BD143272D686F16A8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D5B90FBF36998947B07BACC9F472E81B7036"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "292AF08F6B4F824EF12A1B85C16E48D7543B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "59AAEE7481943446F56B9538E83D749017F2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A6EE5EBF3E91334BAD3BA5E1064F9B29AA2F",
                        "defaultText": "마그놀리아조차 당신의 과거를 자세히 알지 못해요, 무니 여왕님."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1B27415F40DF87466C68EFE2D95488F21B7C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EA48E6955F531547DC583602F548D68D797F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0B81288F956019449E0B65A1FE0AE5BC9DE6",
                        "defaultText": "물론 계속 캐물었다면 외교 문제로 이어졌겠지."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "09278DB1896EE44D277A2768CAE7EB355335",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "58FFF9432CD2694A9788F6560653EF10DAB3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "899898034F83A24BED6AE1C27FD9E849E5C0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A85A8E983300B84526084A15641CC46ECF58"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3FC4D69445793340854822B70DB01EF5D7BA",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "E3-Munie_line15_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "E6E2B0F638176342CE8A5D95E5EA04EC1526",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1CCC5D0B486C614D6B2BB3D325FDDC21A778"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4CBB726629A8614EAA989FA692E83E478ADD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E591C9B27D270944553ADD97F931BD7FB9BA",
                        "defaultText": "하, 이 비밀을 품은 채 죽는 줄 알았어.\n콜록! 콜록!"
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CCDA43072BBFA549332AA5C62441E6CB4581",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B3FFC8728625964BE44970558B5D16B24BB2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D6EBF4D266A1F1438748167610D5808B7192"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "70ED1DBF1932B84A215A16C514CEC3FE2C8E",
                        "defaultText": "나는... 파일럼 교단의 {SP:1}{C:1}첩자{C:0}였다."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2CCF435F581EE642DF19133499087C7BE069",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E33028B938DDF445BD390553348C2CAC5927"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "038D85988B79194B52682660338BE0739429"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9AC5F4939BBB0149FC8BED826D50F7EB2857",
                        "defaultText": "뭐... 뭐라고!?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CD7A29F233EAB440E89A7E84AF0942CCEDC0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0F7F0D0600D3C542202999E2620AD01996C2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C8CB013835DE954F39395873EDEB602B9062"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "78EE860939B86740DD78FDF4E57303ACC9AF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            8
                        ]
                    }
                },
                "indent": 0,
                "uid": "FF8571A704099749B169E9D461D91153DEE0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "30B65443330ED84A4F1983E1B06078815E93"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E96CD6156A57E34CB81830573F6CCDF7B732",
                        "defaultText": "교단에서 보낸... 첩자라고?"
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "15F9860C269C984314293484961100EB6085",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C9E0C2ED7B03A542D73B6311B9A1ADEE3020"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7B7F7D0543A6F24BC63AC91884553D15B60D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5CBD086A59F8C04EC50A3547409E496B7BFF",
                        "defaultText": "믿기 어렵군요. 왜 호이카데에 잠입했습니까?"
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D416824C17BA59415538DCF33AFF962B3761",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2EC9618D0AB09344569AEEE60AACC7D8D399"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9CC71BEC3753654AF979FDB138FA17481008"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F6CCA9408B64D845728AD8806F246CD103E0",
                        "defaultText": "교단은 늘 엘리아스 레만과 사이토 파스칼의 연구를 감시했다."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "13C7F027295EB94AFA5BE583BF82B99F38A4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "37E736588D28B343C5592017C614BF09B10E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "508E237D50AFB9435B2A8BF35AD2C122E6E9",
                        "defaultText": "아르비움 전체를 뒤흔들 재앙을 막고 싶었지... 콜록!"
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BB4A9CCE2FFEC9427508572725B9B6C11317",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CD282676107A09420D298AF77FB79DA9EE74"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "A2F551D708EFE84CB31AF6A1CE13C16002C0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "329FBD92967BB04FEC0B1B112EE6A94CC65E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F7300D062BF2584C522840F650F60EA826A3",
                        "defaultText": "지금까지는 별로 잘되지 않은 것 같네."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "97A32A2C76B39248A19B41B75E5764862EC4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C1A60DB38408024D53390B153968873EC378"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8B6F443B85BFF0466358F4963EBFF1733D24"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "14EA48DC03B77644302B4FE905F69B88EE8B",
                        "defaultText": "후후... 그 사악한 연구의 파급 효과를 감시하는 건 쉽지 않았어..."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1545717660A499431F2AC5971BDFF13BC238",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DC5BF9456006954BF788F660C6B5506E396A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4CCEA3D2325D6742485BB1C5A6A73D83DD71",
                        "defaultText": "한쪽에는 아마란스의 마나크레스트... 다른 쪽에는 마왕의 그릇들."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "311D9B0851A365417E58D9C8BF1004917EEC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2B68A9775C23174A1F7A2197C59969C14C32"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B87B94EF3E23B84EAE0BE686961ED941695C",
                        "defaultText": "나는 호이카데의 그릇들이 통제를 잃지 않도록 감시하는 책임을 맡았지."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "831191918D2B3746B3193E9763EB46186F7B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F4317E4E4F01E84B8F49520685EBDA818D89"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C1E4F9FA85DFD64B5E9B08255D9CEA59F437"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D43E69AD35EB5940DA9A8A913E83D3E1E2B0",
                        "defaultText": "어머니... 전혀 몰랐어요..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F7780E464B28804F16497755B29B8C96A6CB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F482EC8D0E99D7499D6BA101160D532073B9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2C306BD69A50B5433689E40289CFDB00F194"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A691067347C1044AFB2AEE97231F78661BD8",
                        "defaultText": "지금 생각하니 그동안 나를 감시했던 일도 완전히 다른 의미로 다가와..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "49575ECF3CF05848646BEB76FF34B2241B09",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "88207FB790F4884DBE7B4A454F1393ECE3E4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5AD94DB83FF654444C1928E497FD7FBF900E"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "29CA1B8513192843EF4A3462645BD92F0258"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C7A0E8605B43294F621B80613A1EEF86440B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "4E7473BA29CED14EA65BFA34F4E36F2C0D72"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D48277F805BAD944A059481505F2C0800132"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "ABA8CB0655DAB646430A67817C16C74368B6",
                        "defaultText": "단순한 첩자였다면 왜 여왕이 된 겁니까?"
                    },
                    "position": 0,
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7ECFA0713CB3E3406B0BAD68F3270190374C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CCE18B417272834AFD5A6C53454FC1AE01D2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FC3526A03C7288485F8A8619890B425F71F5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4995FF51692AF64482396A6181B8A2D7FBEB",
                        "defaultText": "처음부터... 계획한 일은 아니었어..."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B5F9414C765F5144C88AACE5ABB10C0A5B7F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "94A6F57C0BD7564C15582EA6010864A79CAF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "583A287C573E734918597952D5EFDA939A1A",
                        "defaultText": "하지만 호이카데에서 오랫동안 살다 보니...\n백성에게 정이 들었고... 백성도 그랬지..."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BCDB65A124727748BF1BDBB9C2A0536E7C36",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "885BEBBA42AF114C634B1EA33281AB588CB7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "37B4A2F01AC9B2495A9AE74287DD112C518F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BC6BC26E1AFAF34EFA2B3549908D5531E0DD",
                        "defaultText": "이전 통치자들이 세상을 떠나자 백성이 장군이던 당신을 통치자로 선출했군요."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9FDAE71D62D2244FFA68AE878FC20A67FCBD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0E2CD539309AC74CF12B55D75A321FB39D4C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8F9993B81114D94A62795D85AA90F10D8D0A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0E76BFC78113834D0D2B3A6842F37B358943",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "048228EA2EE6464C586A3AA352A315EA55F1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A4D73356448837498E895748F5F261B954CC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "058CCC8432432844717AF6F8AE02621170C2",
                        "defaultText": "그래, 백성의 선택이었어. 결국... 넌 호이카데 백성의 사랑을 얻은 거야."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "96A64F377DAEA840C42BD3F3F72D58E0ACC5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "941D8A790DC3454F8B794D895DF81F80727C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "6AA96EAC6D1F7849F84B5A31E8EE41B578B6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0DC0EB857CA3C540D63A26520CC211DF1A9C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "430E48C069F91346768AE8397E61E00300E7",
                        "defaultText": "파..."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8E36D5D050E797404C4A3A98020DDC92462F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9F5CCD1874BFA343BD195651E42F1CF47E9C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7D028E7B9130C04CF48BA5A71EB2DDBA6528"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B4E26EC05ED679441E1BC669DA80345C5084"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "412923447F6C2441743905B40A982B61B479",
                        "defaultText": "그 운명의 날에... 네 말을 믿었어야 했는지도 모르겠구나. 하지만..."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E02ACB5289EA714AB978EC814D8C5C58BD1B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4DFE67993B5D674893280EF3488AEB8CCC6C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3D1AC4E83396624F04683816BB2DF75AD952"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D5247BDE1EC2624BD468AC38E3AF60EA5A4B",
                        "defaultText": "나... 이제 이해할 수 있을 것 같아요."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AD6FA6F62BF6C1425678D1D28A06E83E6624",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "98CB7D604297C84E2139D45768EF3C2DE850"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AE6198E138F8C4472099358675C8291BBA7C",
                        "defaultText": "호이카데와 파일럼의 이익을 모두 대변해야 했으니...\n평생의 노력을 버릴 위험을 감수할 수 없었겠죠..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "30C286E41B65B3467A682FE6B9DFB4D08EFF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "655F00167D52B54C782AE3F749F9A8497555"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A911BB496DF977434F59D86421286DD98DD1",
                        "defaultText": "그저 딸보다 의무와 백성을 선택한 거예요."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8078D9038E2E73499F28B2611FB9C7489245",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "107E83445E89A848E57836317B2083E2C884"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "7F98C36F6F6B714C131B3731DAA5150091BC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "15A9461135845546FB9BF06802B5F1761236"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "61AE3BD85B37E846C77967246174B45C21E9",
                        "defaultText": "헤헤... 결국에는... 콜록!"
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F734C8655FA3C44F2F1B935442D6EAB7650C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FF8909421C7E6244631B0FB750995FF2ACD5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "609690EF732774481D8B972700AEEBADDA46",
                        "defaultText": "우리는 꽤 닮은 셈이구나... 그렇지?"
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1D940DB62AAD8641B3399F88F4295AAD8637",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "218BD8CA1EEC0342DD3918B564FFC1CAC742"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D9F7F09E9E907940B35973E2AD068BA8E0F0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7B3D5ABE1849F34066799BE95CB47239FF6B",
                        "defaultText": "네..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7360D3CD8A315547D94B9754C6E8C2BE5C50",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "475B937D07145049736A8EE1C13A52D8D960"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C74B15FA335E6348C6397B7321D72D7B3B87"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4F46D15D5241444CC01ACE02DFAB64E1DCD9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E7FD274C22B6C145FE797C582019FAE9EB1A",
                        "defaultText": "나도 백성의 안녕을 먼저 생각해 행동했고... 내 감정을 봉인했어요."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "610FA5682C9B0444551983A9B63142C9B4C5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "942D987616A40541F159FCF572685EDC3DB6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6BE319CC8AE86942B8482577ABF585BDC18F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7033F1DA91D59245835838A5A81878EC37A7",
                        "defaultText": "어머니... 서로를 조금만 더 이해할 수 있었다면..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0F9D599616A8B8431B9991A8538187635E59",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            8
                        ]
                    }
                },
                "indent": 0,
                "uid": "3DE12D612DB50445D938FFD7E53F81511926"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "verify loop",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "244101B92BFFB343C06A04420D29A3518538"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "sisters"
                },
                "indent": 0,
                "uid": "FA9490062FFC524DC1895543CA8DD563F1A6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "433A12354BF505420B2B343769C77DFD1472"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6F0CDD5D18403443C1483B4675DDB56CB546"
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 1,
                    "idleIntensity": 1,
                    "lipSyncSensitivity": 0,
                    "fieldFlags": {
                        "breathIntensity": 1,
                        "idleIntensity": 1,
                        "lipSyncSensitivity": 0
                    }
                },
                "indent": 0,
                "uid": "E186D1BF48B5A846321B3810F634B114925E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "07E696FB2F19574F6C984BA765B51CCEB9D7",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line43.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "324640D05FA7B2493B4915784F4380EC9338",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0C8778086442134F395BE3617C0E0B2DEEB2"
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 1,
                    "idleIntensity": 1,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 1,
                        "idleIntensity": 1,
                        "lipSyncSensitivity": 0
                    }
                },
                "indent": 0,
                "uid": "30FFA8F96149C9427868C2F1FD076ED9F7C8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D344717685453749288ADE38DD8821D245B0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "E096873A5DA506428D3B9002EBEB246F6BF4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "16E1F3894C538845DF8A3142D2679B9481F5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D33978050F49D74D7889C475ACD3E193C15B",
                        "defaultText": "부탁합니다, 무니 여왕님.{W:300} 우리의 과거를 아신다면...{W:300} 무엇이든..."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C12-6_line44.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "C2318FEB8AB033496F5B6CC5DFDF4CE9E616",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3D8BE89D1E7358448A9947A1311D09A66F93"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "FAD74E1663CD614F604B8B00042A3FEFB3D5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "258F51AE2181A244FB4BF7F47DEA34D1938B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C308BC735E76994F037B63075C6BDEABBC87",
                        "defaultText": "너희 둘이 태어날 때 내가 그 자리에 있었어."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line45.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "81E50B5E64241448EE38E5A00897E8E1278D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BC86614208A41141ED2901C19FE7DDC5A1E4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "43DBB5A2537516468009464602483FBA18D7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "440437227E932742625A21B1FA91E1D0D283",
                        "defaultText": "\"우리\"가...{W:300} 태어날 때라고요?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C12-7_line46.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "FD4AAECF43CBC74DFC998E37BC9F25162371",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "61A5E2283D74C2402E3A1CE3B77665648F6A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "ACAD2EDF1436D1448E3A59373983CB6C2E68"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6237E5E36C6098468F0924887965661BCD59"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "44150C0C2E61B643AE6ADCB60F345D854034",
                        "defaultText": "콜록, 콜록!"
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line47.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "9F0A30F67849A241D1690B91B28F9E020A11",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "89EECF4158FE0745EE1B42E1E9F5EC52A76D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A4C2488D6637164DC26ABB55D0BA823DD0B9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "18AB1FD20D61024F3A5AFEC5FBFF28FFBE51",
                        "defaultText": "설명해!{W:300} 그렇다면 우리 친부모에 관해서도 안다는 뜻이야!?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C12-7_line48.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "EBEE0D2762FB58437689AE12919C8F0DA72D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "65F3D0926B48A243B749047414ED65A91BE8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FBA8C5CE3425B94D2B8B94431AF944066FF0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "20BFF0C19CDF234BBE28B3E70B5A8FF9F223"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7AE80F4D0396B649D788EA4607DD12631B83",
                        "defaultText": "위태로운 상황이었어.{W:300} 이전 그릇이 통제력을 잃고 있었지.{W:300}\n마왕의 영혼을 옮겨야 했다..."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line49.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "B3A656772CFAC94C793A5FF575DC8005DF65",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A0EE07B23421A44BBE2A62881B5F3CBB357F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0AC1E05A23DD13462179A628C276A27EE406",
                        "defaultText": "하지만 유일하게 적합한 사람은...{W:300} 당시 임신 중이던 여왕의 {SP:2}{C:1}태중 아이{C:0}뿐이었어."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line50-glued.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "2618F27B3739C5431A48DD498F4768A04D69",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5CA9D0714742874B211BEE3743CF872F5D2D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            8
                        ]
                    }
                },
                "indent": 0,
                "uid": "5171322A2A07C447CF7A4305A8F7F9549244"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "635004B919D80648244969B074364DE8D734"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5C4BF9157926654BCF581CF9DB3A209411E5",
                        "defaultText": "마왕의 영혼을...{W:300} 임신한 여왕의 자궁으로 옮겼다고!?"
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C12-6_line51.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "9B556E2D4BC32841288AF5D2BDB247333239",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B915A53B75EB8843826A3578DF08377BD311"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "36409D536319A74CCB6A0415EB4835637019"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "10B17E877457444BD98ADAA39728C5623993",
                        "defaultText": "그래..."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line52.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "6C2038D77571A145DF2B01A338306FA9AD58",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A370E05A42081643BF5A81103271B1EA3296"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CB7CD5181FB2814B326A3B26475B757DA0D3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D72AB6386F58004361195FC7F473DD18EE7C",
                        "defaultText": "태어나자마자 마왕의 영혼이 내게 계승됐다는 건 알고 있었지만..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C49052013B75984AAD3951F81C26C7BB0B68",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "35C40128198C6546558863C7597EBC321575"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F3FC080927B6B14E6F3AC4A8FC7079C2CF23",
                        "defaultText": "그보다 전부터 시작됐을 거라고는 생각도 못 했어..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7C6CCE7056519142EB99E9D6221411190C77",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CA113D4F353ED848EC2800D89903BC773231"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4A35C1B70604074835483FC195C3E12EA586"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "F6E6BD2B9384A348524B343387A0801648B2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9FC9CB4D135E3440736922B9A69730EDC37C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "859EEA87520B0549F48B1293FDAB088D42DB",
                        "defaultText": "미친 짓이야."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Rya",
                        "name": "C12-7_line55.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "FD1292D25BCD04491A39F9120967A9A2C129",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0CD0BB002987A842187B13526BA064D51F0A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7A24BC147606D64CF4790440A5C879A14580"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BEF6866E0EC4E140C539AAA635A601746163",
                        "defaultText": "하지만 유일한 해결책이었어.{W:300} 콜록! 콜록!"
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line56.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "43CA30CC7A85524F8B98A110E4C2D596BA23",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E6E597F6630672407C2B53A996906C9220DA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F8E6C12A0E3D634BE669BF13D62173C6C3FE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0EBF8D942A2137448B1A7353E4EC743F56DD",
                        "defaultText": "그릇 계승 의식은 누가 진행했지?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C12-7_line57.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "0A4968FA4B8A2248C44954B0D9942DCB15C6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "16333EE84C53294CED5A45889017D0F71912"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F3D7A2BE260DC142B37A9BC6147935F5B350"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "514AF9139A2B95455E0A1E91A9DD9A002DCE",
                        "defaultText": "소라야 성하가 직접..."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line58.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "2E262FCC755D784EF2580020387E3FECEA93",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "45DA04E47FF18445147A89185004EEC86E67"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E6AA06BC8347944EF66986641D26E81072A4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E9E026AE1A8841490B3847217AA760A0519C",
                        "defaultText": "대모가..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6833D7FA15FC27415D395FD29D0DCE827C37",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "91B6C01039FB9048B429A2964749E4C8E08F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "421CF12A8F35354D853AA4D4CD7A84799B3D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "72CC5C6746E0704BBD3A0584DAAA366B748C",
                        "defaultText": "콜록! 콜록!"
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line60.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "BB972A2374395044D68B47B6B64F1B74DF94",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "7B94B2E513468244D178EC63ED331225DB6B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EF7190811F632141298BD4C2E1F6E3239D2E"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 72
                },
                "indent": 0,
                "uid": "F48086F8037F46418A2AE57823A5F95729D3"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "close;reopen"
                },
                "indent": 0,
                "uid": "A3CB877071AC614A6A1BC356B0C4558E4984",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6B49622391BF18460799F29421EB0ABFAB69"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FEEB4C4F8A3E044FC49802823DEB25E5A9BD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4B36D13E38C8994FB17B96B1AE33DF899A6D",
                        "defaultText": "어머니...{W:300} 조금만 버티세요.{W:300} 진실을 알아야 해요."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C12-7_line61.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "61FE80915BDF1543AF1875A07E1DA01F3862",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "73953C0D8DD8384C3D59EEC5BD3F563F57A9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BA796E410705A640205B9C86C95D57F87656"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E0073C3F6CDD2344152B1C413E521D823249",
                        "defaultText": "후후...{W:300} 직접 보여 주마..."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line62.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "6A52FA7A542E354AA56AA022C3AAB7885854",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1B36FBCB24CB2642DA1B6B85976ADD0024DE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "85D348DE17B80547D59914F9268335BA614C",
                        "defaultText": "말로만 하는 것보다...{W:300} 쉬우니까..."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line63.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "6F8C872911D9D64B5D58BF82553125F8A67E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "4C1D8EE27CB466470F4B8E2388F19219C037"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A484F64713E8374BB93A56E68FCCFA156388"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 72
                },
                "indent": 0,
                "uid": "0973349031718448BE6B4DA3D87456931261"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Battle Animation sounds/Spell sounds",
                        "name": "Candelabra.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D4C66A9F1738084AAE6A3478D3E02613B6DD"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 9,
                    "blendMode": 0,
                    "zOrder": 999,
                    "duration": 60,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "white bg.png",
                        "folderPath": "Graphics/Pictures/CG Gallery",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "4A1ACE9483D0F44AA769C772DEFDA46EEC08",
                "expanded": false
            },
            {
                "id": "gs.TintPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 9,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -20,
                        "green": -20,
                        "blue": -20,
                        "grey": 155
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BBA81E246F29F641DF39C8919C351EB92865"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 132
                },
                "indent": 0,
                "uid": "5E49D9DB0414F24FB68A3968861C0EF20DAD"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 10,
                    "blendMode": 0,
                    "zOrder": 1000,
                    "duration": 60,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "sfondo nero.png",
                        "folderPath": "Graphics/Pictures/CG Gallery",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "7E40BB9D42E0944ACF1961D441B97665E4CD",
                "expanded": false
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 11,
                    "blendMode": 0,
                    "zOrder": 1001,
                    "duration": 60,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "alfhrid_1.png",
                        "folderPath": "Graphics/Pictures/Memories",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "2FDD29EC2F0976407348FE628598A7A453B8",
                "expanded": false
            },
            {
                "id": "gs.PictureEffect",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 11,
                    "duration": 0,
                    "pixelate": {
                        "enabled": false,
                        "size": {
                            "width": 10,
                            "height": 10
                        }
                    },
                    "blur": {
                        "enabled": false,
                        "power": 0
                    },
                    "wobble": {
                        "power": 8,
                        "speed": 15,
                        "orientation": 1
                    },
                    "waitForCompletion": 0,
                    "type": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "D6EDDAC32F1F2840244B68708F1CBF7A7E67"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 12,
                    "blendMode": 0,
                    "zOrder": 1002,
                    "duration": 60,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "alfhrid_2.png",
                        "folderPath": "Graphics/Pictures/Memories",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "6B403D7C2C2DC3467D7ADCD6C2B7ABE8639F",
                "expanded": false
            },
            {
                "id": "gs.PictureEffect",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 12,
                    "duration": 0,
                    "pixelate": {
                        "enabled": false,
                        "size": {
                            "width": 10,
                            "height": 10
                        }
                    },
                    "blur": {
                        "enabled": false,
                        "power": 0
                    },
                    "wobble": {
                        "power": 5,
                        "speed": 10,
                        "orientation": 2
                    },
                    "waitForCompletion": 0,
                    "type": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "5FC0537F5B48384B441A5B62F6291B3E4860"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 120
                },
                "indent": 0,
                "uid": "BD49D7E95203F8452F380DE298E6EBDD333C"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "vision appears"
                },
                "indent": 0,
                "uid": "422D99EF57823644FE3ABA44CB44027637BB",
                "expanded": true
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 9,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "26E3C5FA7829374D1108AD81C98E69F066AB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BD9A767B61C7564A5E189A42E361D288FC56"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2B82ED4325A3394C8A986FF5072AEF436757"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2071EFE44AEB824FDC5A51E4A82A80297F36",
                        "defaultText": "하!{W:300} 머릿속에 무언가 나타났어..."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C12-6_line64.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "D4AC34B02520D845788AE260C1BF491F9E63",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8F619BA47954634E6F8A9EE290BF89BCEB94"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "30E5E5AB70A65942057B9D323A32A6D07964"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "145EE4D94923B1422B292D378F1BBF5E016F",
                        "defaultText": "그럼 너도 보이는 거야?"
                    },
                    "position": 0,
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cristoph",
                        "name": "C12-7_line65.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "3573F2403A3D324C9D381A2855FDF49C761A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2CB0518631B2864C9D3B2EB6D6E2FDA7E281"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0BB532668EC8E442872971B4FA6A6E08B0DA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3DEB44F58B33A34C665B6D283FE86B89943B",
                        "defaultText": "이 환상은 뭐지?{W:300} 이 사람들은 누구야?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C12-7_line66.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "BA8A59202D4BC2433B2B4C063D4134EB04E0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "44254AA77EBE794F7A3B66885486D4F34316"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4108C01E84A304497B48155636C5CE675959"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3C52D3807CF9B545DC3BA55632A16EC5F4CA",
                        "defaultText": "너희의...{W:300} 부모..."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line67.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "0C384E132F54A4456D6B5DB32AE4E75A77FA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FB89E56C6B15124A1209A75000D3696D0E75"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "48E99F7C018CF342DB4A6177877471FA6997"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4377A0169633504EF8296FB13825CC20B2BB",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C12-7_line68.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "4B8D8DD192BC8145601BA534030C3BAA3571",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8129D68E8DAE4745815B0B01C63720C4D1A6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1B6F51D31F16B94866397096837EB01ACF40"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7168D0679146A94E83198061FBE868F8E55F",
                        "defaultText": "그날, 네가 태어나려던 순간...{W:300} 문제가 생겼어."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line69.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "926674972C21254D6068CDD21911EA787904",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AC00B81E8EFC2748BD49F593852CE7A39762"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "855333C91144924C13197707ABB1980287EE",
                        "defaultText": "마법 폭발이 일어났고...{W:300} 그 방에 있던 모두가...{W:300} 죽었지..."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line70.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "430F89F64F95D446C878A6E5F15B218C1F83",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F738E6758FF61142F57B82E0479C7A6BF4D4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8CDFBD9B28DBB24FF00B099625F350A0EF2B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1A7BCB2A1E83184D3638E288A75B7BBE3150",
                        "defaultText": "엄마...{W:300} 아빠..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C12-7_line71.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "9E2AAB9B86BCB34B562BB42486D0455AA1A4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "86DAF1E11BA7974319892555A1712E92B77F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "218A676D214166423C1858213613C482AF4D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "136F2BC33C94C04F918BBA082F4F6C14EEE8",
                        "defaultText": "알프리드 왕의 시신 곁에서...{W:300} 소라야와 나는 아기 하나를 발견했어..."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line72.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "22BBBCD55DAE054EF32A73965E9548095FC2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A86151AF6C4DD64A84398F1507874DDC9A25"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DCB6FB8C9E9F0247696B27D7917C47BA1736",
                        "defaultText": "부모가 자기 목숨을 구하려다 죽었다는 걸 느낀 듯 큰 소리로 울고 있었지..."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line73.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "56BFD2382509204EA91BC072050FDAAD964B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FBA286C638C2A04B5528364408B25C5A0EC9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "839667A77871734C087BE58812F0AB12DBAD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3F3CD0F743C6D24DF90BAC88C87337D44491",
                        "defaultText": "안 돼..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C12-7_line74.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "25AE32DA586188413B19A3E27AACDF1B8D78",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "912048D78DC86746304929388E6E17D3BDD5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D8F2E34D2740744AE429F7F0332633B9995B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C1C498E833D7334B2D2BB852C9788BB7DB90",
                        "defaultText": "왕이 자기 몸으로 아이를 지킨 게 분명해.{W:300} 그래, 그 아이는..."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line75.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "E7CD3844340BF740F23B8873FC2AC2020EB9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4F4A4D733C5DD24FAD49199446166440D889"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 14,
                    "blendMode": 0,
                    "zOrder": 1005,
                    "duration": 30,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "shifa_1.png",
                        "folderPath": "Graphics/Pictures/Memories",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "064BB18C8EE1F24D3E38B2A4CED7D3C2A680",
                "expanded": false
            },
            {
                "id": "gs.PictureEffect",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 14,
                    "duration": 0,
                    "pixelate": {
                        "enabled": false,
                        "size": {
                            "width": 10,
                            "height": 10
                        }
                    },
                    "blur": {
                        "enabled": false,
                        "power": 0
                    },
                    "wobble": {
                        "power": 8,
                        "speed": 15,
                        "orientation": 1
                    },
                    "waitForCompletion": 0,
                    "type": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "fieldFlags": {
                        "easing.type": 1
                    }
                },
                "indent": 0,
                "uid": "E803AEC18DFFE041BB7A04E7BD4A69B51F45",
                "expanded": false
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 15,
                    "blendMode": 0,
                    "zOrder": 1006,
                    "duration": 30,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "shifa_2.png",
                        "folderPath": "Graphics/Pictures/Memories",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "00EFD8B77BE3E445976816E6DA2044935515",
                "expanded": false
            },
            {
                "id": "gs.PictureEffect",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 15,
                    "duration": 0,
                    "pixelate": {
                        "enabled": false,
                        "size": {
                            "width": 10,
                            "height": 10
                        }
                    },
                    "blur": {
                        "enabled": false,
                        "power": 0
                    },
                    "wobble": {
                        "power": 5,
                        "speed": 10,
                        "orientation": 2
                    },
                    "waitForCompletion": 0,
                    "type": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "6DA1D68F354FD84B5E18F72586B6881848AC"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 31.200000000000003
                },
                "indent": 0,
                "uid": "EC2A6D3470FFE64E482A4A18E1CE69559932"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 11,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "162A78120896864F778B9C4713396B565A7B"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 12,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "37CA210E5B91C946287BCF041538629C1921"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BB6D9F49770F914693595F680BF08AF360A6",
                        "defaultText": "바로 너였어, 파."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line76.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "AE6B7EBF6A5DC344841B409936A167ECAA16",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EBC9E420715AE6402789FB62B868E67A773C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F99A555D130AD54EDA6A258581F69D5C9162",
                        "defaultText": "하지만 혼자는 아니었지."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line77.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "6ECEA0A88611A649AC38B562AF0189D5D169",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E99D84D00C23D3400A4854E3D1D8BFE9EF0D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A252BED53321A745DE3A62C32B18DA41A32B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "180EA1AF420142403D799699763E395CC81F",
                        "defaultText": "그럴...{W:300} 리 없어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C12-7_line78.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "5AE3F5034C1E3948511B0188856A332F52A2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D533221E13AE45462D5995C4531F13F22F3B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D5D9F6D76C0F5142D22896E07F21E7408380"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "13E9B28782571141BB6BBF26112131689182",
                        "defaultText": "저게...{W:300} 나라고...?"
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C12-6_line79.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "6A802FD46CD4C64468297FE0AFB7DA33EF32",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D453C4FE8809E54C80888CF36CDAE8ACAD2E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0DE98F4B5456674F427B77632032C79CD813"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "050CA7772987B74AA02AFE6366A05C2906AE",
                        "defaultText": "그래...{W:300} 너희 둘은 아름다운 {SP:1}{C:1}쌍둥이{C:0}였어."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line80.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "1EA2CCA73EA8D6486749734156ABF1018934",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "79CC621A9247834114689482E02A017C3C3E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7C54391C3DC956429B1BFD699DD84CB98FE5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AE1EC1D677D9F548BD68B9E3FF6E914DDB1B",
                        "defaultText": "그럼 사실이었어...{W:300} 파라트라스와 나는..."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C12-6_line81.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "35001CB65FE554428A48F3438B3BD6BEFADA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AC4F6DCA3CE3054BF15826E2833AAEDB391C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1902EBA05BACA54C94485370CF9620AA5312"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "20F4C58587C559411698EBB21D542E03FDD5",
                        "defaultText": "쌍둥이...{W:300} 자매야."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C12-7_line82.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "E905642C4E57C941DD99A774F81CE65278B2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "30AD686419A267421B9BEBC6A1400FEC945C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BBE1C4AF2E4B28488F88C09623E6853C032B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CCF472A55A80F4427009ACE3D8B8CAB50B2D",
                        "defaultText": "콜록! 콜록!"
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line83.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "69FA64153261E240521B45122A9DF5C3BC35",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7F5440E618325349B849EBE9C33158554825"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "57C07DD9385297487E38A8E7E2C27BAF9E01",
                        "defaultText": "파라트라스는...{W:300} 할머니 파릴데의 터무니없는 마력을 물려받았어..."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line84.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "24CC84277A11D249836A30D4B17544773254",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FFF1F2706F32654777783DE6BF465C2F069F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "336E83213A50F44FD5786BA1DB974F5E1265",
                        "defaultText": "그리고 시오리, 너는...{W:300} 그릇 계승 의식의 봉인...{W:300}\n악을 봉인하는 힘을 지녔지."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line85.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "C80C942A127E584CAC68FEB12D41338BC674",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "07C9131010C4B145868B33F80D6F267FA87A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "07ED0A9D5F3C40429E381CD860831AECCC10"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "480600C1757FE541913A9C43F1641FC1757A"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Battle Animation sounds/Buffs Sounds",
                        "name": "DEBUFF.ogg",
                        "volume": 100,
                        "playbackRate": 124
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0894D79B58033940F58A6AC17C5D005C91A8"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 10,
                    "duration": 48,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "489C9ED8044D464322089F01BB9E8F3BEA7B"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 14,
                    "duration": 48,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "65BAC23994E74847118BEDD142B7436F4607"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 15,
                    "duration": 48,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "C166819387BE784EA85BF8E75A0446DD170F"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 84
                },
                "indent": 0,
                "uid": "D6A4939E8B55284A6C98E89604753F273986"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "vision ends"
                },
                "indent": 0,
                "uid": "35EFBFE8802532478A39BB955DEF5EB936CA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C0DE364B1CE9E449B89847B7DB314E6066AE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5FC224F82746B94A462838B30D1F130378D0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "58ECE2754FAAF6499A7A2217661E457D1526",
                        "defaultText": "어떻게 받아들여야 할지 모르겠어. 너무 비현실적이야..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B1AA72767A0301460B8992F48891F2349FE3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "49B9CECD3F06C447036BE226DBF11851E27E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F02F6BEA2CAC544F4B482F535420729E3952"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6167BFDC0B3AD94D4D3A1AA043818559C90E",
                        "defaultText": "안타깝게도 시오리의 봉인이 엘리아스의 영혼과 반응한다는 걸 발견했어..."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line87.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "E342A8A8793E9145FA592E26AA5B69B37315",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CC9EC4F42E79E54DF04B7A33B3DF334189B6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9C63A73C6FA1E44C3B0878413724AE4E5848",
                        "defaultText": "하지만 필요한 마력이 부족해 부정적인 \"반응\"을 일으켰지."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line88.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "10E83A1F3BF6B748AC2A34350F42EB32389B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "271DD6E830B6A74E47394C6464E5AA8FFA77"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1B1E566B0D37534B085804E20503F4C515F1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "8B37273B4947404E6E1B31336BEC107E878A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "934ACB302A33844A38686F485C4B35221969"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3483FDEA2153234E006851057B88E547837A",
                        "defaultText": "그럼 그때 내가 시력을 잃고 두 사람의 힘이 뒤바뀐 거야?"
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C12-6_line89.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "4CE50E2E4CF0444C723B351824C5A7F14464",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "54E552588CC817454F88DBD0E3D1682AB3AA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8DBFF7422C2044473C6908044F565DE60A44"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F3DCB6EB692478409D88C418E290DB1B78E0",
                        "defaultText": "그래...{W:300} 넌 엘리아스에게서 악의를 감지하는 힘을 빼앗았어.{W:300}\n그리고 반응의 충격으로... 콜록!"
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line90.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "48C3F49329DF9541F87A05A27B7BDFA5626C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "633863918E233143AD2BB15369E1A636821F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "54B5B543115F564B116BF429EE2D0729C3BF",
                        "defaultText": "네 머리카락이 은빛으로 변했지..."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line91.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "0FFF87F25D0E184BC3987CB44A92E903A2A5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A21A8F2512AFC94FE9282DD1276D9274C9CD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CAE9423F64A09141473B0342DA207DBCF559"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0D8E8C394EAFC145F58BB05167313910EED8",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C12-6_line92.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "AD0ED5E32087A2439588AAB56AB33B0E7A3B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "36E85BDD26D2E34F072AEFA4F1ADE6AC72D9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F26DA52A97B44446F21865475A9BED482A1F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8D432A308F5E8741B4185A8686861641B6B9",
                        "defaultText": "소라야 성하는 경악했어.{W:300} 가능성은 명백했지...{W:300}\n엘리아스가 이미 너를 타락시켰을 가능성."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line93.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "B56A14198FAEB84E4B1BCFD1FEAC7D12C2D9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DF59DA748D54824BA45B52D7002AC4B82EEC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8AA4D8945BFD6345C60B4DA945086066B1FE",
                        "defaultText": "그래서 너를 파일럼으로 데려갔고...{W:300}\n백성이 동요하지 않도록...{W:300} 출신을 숨겼어..."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line94.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "9914913C230F974C217A251375ECC4CE92AF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E4B6EB3058DE9146B16808737221553C50BA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E3D2687B4AA3B44592490F87E1A120CD77A3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "8191B46E4A8B484B8D1AB3F267360F29B73C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "64418CE51E38654DC04ACD9867D32E64D704"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A3EA891B48AF554B5A9BA8D345DC169DC70D",
                        "defaultText": "할 말을 잃었군요.{W:300} 두 자매에게 얼마나 큰 고통을 줬는지 압니까?"
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Rya",
                        "name": "C12-7_line95.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "5E82BA348C87124F0128D6680453C127DBB2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D1257C8C37AE114F8799C8C23A058B1FFE47"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "C7DABC81269E754BE68A11282E37C9229FB5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1BA81AAC1D9B9545C06B43A56C36277490E5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D0C5624C5D1F74453D0BBD53B38C67842C82",
                        "defaultText": "알아, 하지만...{W:300} 콜록!{W:300} 달리 어떻게 할 수 있었겠니?"
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line96.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "C5A7031086B18446E1393D65719836D88962",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A689AF977F045741A7484F12BAD2876B66B6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F22073EF99FA834E3D29F0B3D43D327D9399",
                        "defaultText": "둘 다 불안정했고...{W:300} 실패할 운명이었어."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line97.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "44BA956D2F76054F002B7CE4E336E40F16C4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B877167A5BA16644524888F1038C2D4AA7C8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B623138F52A0B6400E298158762DFC8349DD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3695388F2E697944A4381F28820B644CBC9D",
                        "defaultText": "파라트라스에게는 봉인의 대부분이 없었어.\n그 탓에 21년에 걸쳐 엘리아스의 힘이 새어 나왔고,\n너희가 아는 헬리오스가 만들어졌지."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line98.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "EDEDC3D192E2544D5A8A5FD743592BDEC616",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3F853BA744D1424A318B7BD3340DE9CA0848"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AACFD7198F0DE44D085A82563FC5490B4169"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9D03993D4B0DA645CA8B79C546CCBC710CD8",
                        "defaultText": "하...{W:300} 하하하!{W:300} 그럼 내가 아무리 노력했어도..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C12-7_line99.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "E64B8A1882767343962B1A1233762561AC72",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2233774A7601324B8E68FA632AA3D0ECF845"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4121C9736F68554AE3198175B35C20B0FEAF",
                        "defaultText": "난 태어난 날부터...{W:300} 이미 그릇으로서...{W:300} 실패했던 거야?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C12-7_line100.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "C2FC8CEA4072714B503989A6A3F677B7761D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "208034A81A6331486038FE44F9AF7691ED74"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            8
                        ]
                    }
                },
                "indent": 0,
                "uid": "FE43C0A438AA264F741A19124A4040E22914"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A357AE1F8D27E241DD89752598A9742964CE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DD6F859319FC48402129470091B8E4A5F46B",
                        "defaultText": "그래."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line101.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "ADFC0A268B5DB149425BF441D03BCAE4951C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D31BCBCC5D26C644F48B665728A399AC7F1B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DC6A186A6F6CC84C1B0A31D11080CDBE17FD",
                        "defaultText": "나머지 이야기는 너도 알고 있지."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-7_line102.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "F2C87E8D7541B84CCB59105550CE760D89BE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4ECAD383769E974EF079F7F3DEFC67179DBF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "717DE5F24F2776435048EB47B2A539C57469"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8C612CD71AD1364910892917990E29C68C0A",
                        "defaultText": "나는... 불완전한 그릇이었어..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9F164EB98A2376488E2816A7D6372609B12A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D7A1C4B15476B44CAC7BD4254B6311FA99C7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A0E6DA574A6F0243AF1B16D134007C2F4411",
                        "defaultText": "그리고 쌍둥이 자매 시오리가 처음부터... 빠진 퍼즐 조각이었고..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CCE595658B85384B4A3BE944C11079850FE6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "028BE18373E5D543BF4B0D9307E4CBD311BE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "241B48BD606D34445728DE6744ACA076BFAB",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "088974BA53A961468B383665027010F6DFF3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7B563B8109896045548BFFE818CA9EDCFCD1"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "verify loop",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "15FC0C4B7040644C838B4C52CC127BD58B2C"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "elias"
                },
                "indent": 0,
                "uid": "F077040F3BD8804D20889E78628BC2E486CA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C9D874DC2F41E349B979D3753ACB1E0FBAFD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "87AA843C6DF8A746FA881B53BA46AB45EF69",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "E3-Munie_line15_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "9149D6DB52EF4944456B37A133A7FB8FEB1F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "FDC09E3331D6B84B1F2AD310849A19DADA89"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0359DDC44D77B84CE0182EC153655D1A0DAB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "477F8732223A2447768A507488D613DC97A9",
                        "defaultText": "유감이지만 나도 너희보다 더 많이 알지는 못해... 콜록!"
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EDB242C33DBCB24E0088ADE14D86EE892171",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2ACD913327DDC441E3893A18A1199BD2C1B7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "90EA3ECC43295348A24950B5A7C466B2CB55",
                        "defaultText": "그는 뛰어난 연구원이었지만... 감정에 압도되고 말았지..."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0BD5648164B9B14A484A41C72F9BFB39DA2E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DD2AE0D76EBB40491808EDB155487C3FFBEE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "66745CA42D976043546A76D39103DAA9FEBA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D60A83B1574C914D8F4BBC613103B1EB9F54"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1FCB4BF571732043515AF7916473AB9946F7",
                        "defaultText": "파릴데 2세 호이카데와 불륜 관계였습니까?"
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5E58FFA665B918481B8ABF116E683F6ED16C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FA1AF71521D2114BE92AE397B60BFC80C39C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "59F053732E52B843599B6FA5AA1127DCE15B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2580C3636487E34ECA5B80279FD561B532AF",
                        "defaultText": "리아... 정말 그런 관계였을 것 같아...?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1FE08DDC4FDEB24C1D0B0CA7939929050810",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8BFBA68F7B6026429378CD64C71AF7317572"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B155B11A9DB1A04B058836672A5EBF57F184"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CAC33E858CF9E6477E48F36495FC1EDAA68D",
                        "defaultText": "기록이 맞다면 파릴데는 당시 이미 정략결혼을 한 상태였어.\n알프리드도 낳은 뒤였지. 하지만..."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4B7F67C709F621432359100138ECE1CB173F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B3FB033F8F72B547051AEFE5CA0D9FBEA547"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F1BA9DA17F59054EA13AF8D0A597B3DCC06F",
                        "defaultText": "지하 연구실에서 찾은 증거로 보면\n엘리아스가 그녀에게 강한 감정을 품었던 것 같아."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6B419A126B7D87410C4AE8F5B6C9DD523DAB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CAD1FF0B4F0DE34F0119BBE0AD27CE4D20C1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "74E53FB650D5C34B6E5ACBC032CE6B5AF795"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ED27A16B170DB14B976ADFA0AC8AA525CFCF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "316C5B466153414B373A5E14C4A3DCFDBE7A",
                        "defaultText": "공식적인 관계는 아니었지만...\n그녀를 위해서라면 위험한 연구도 감수하려 한 게 분명해."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1481CD966C90784B4C4B0E815AE2D76F5645",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "700761334643F14C8B1881A58C9CCAE23072"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3596F1FC6EFDD2470C2AF724F987A66E5FD8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C859324F4F1E83425D4AF0C60A250648B37B",
                        "defaultText": "내 기억이 맞다면 사이토 파스칼의 연구는 훨씬 안전했지만\n완성에 최소 50년이 걸렸을 거야..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FCAF826142F9E14E9A9B243362220CE7F13E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C872406C7CC515411A1AE4B1978123F3920A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "052C71F122C83744F43AA6720BB06CE02472"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FF120AC37483274AB50AE57740C13CFE696A",
                        "defaultText": "엘리아스 레만은 기다릴 수 없었어.\n파릴데를 사랑했기에 그녀의 병을 고치고 싶었던 거야."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EFA0DB526DB86845F56A9DB43C73D522CDEC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7598207A3D8EB449B65A9827FF987C699F90"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "D5800FC94C08B548EA498110C7EF4FD1CBA2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8BCF36E689097142494838A68EEEEB415852",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "E3-Munie_line12_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "0B4C7B21923F43436338578705608019D8C3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "BC9C529913E6C5421D8A6958C57772B27453"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1F7FAC9E3268E645700AF24942D9DA830644"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E1084EA40F69E24A0E29C7F6D6445A725267",
                        "defaultText": "그래, 맞아... 콜록! 아이러니하지 않니?"
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FE54189033720841C92AF9D360CE08CEE503",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B124721E2059104692898A53AE60A4691E20"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B89B27CA438870438858EBA30305B9AA8FD1",
                        "defaultText": "60년 뒤, 자신이 사랑했던 여인의 손녀 앞에 오빠로 나타났으니..."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F062D4C79176E649582A55C55EAD6E436E42",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AAF6F5EA1841354A9C6A80A635424BE90D7B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F3D105FB8E876842B3092DD3D5E1ABF6F407"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "152C5A68951C4243591B2DB816C89E3C27DE",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9CDD214940E9C64DDD0BFA95EB2BC5425394",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F8AC55CC803F91469E5B2FE6A30B428E50B4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C16BE27C3364264C959AE176453E2EB1873C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4C62402F04377345B0789E114B7BA48DB719",
                        "defaultText": "왜?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F73C5AD78D95E448597B44362114BC790293",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "054268FD1D5CC14FF968ED84176392AA65D3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B0481E08261E404F4F0A150061378DB6183E",
                        "defaultText": "엘리아스는 왜 헬리오스가 됐지? 왜... 마왕이 된 거야?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6A43DDA9235406460C496B911B4E40E9B0E2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7BDA2D467F5A744BC17ACEC56F917D54AE6E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "890EE1948B5A2748151A738591D23390F4DE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3DD785B606F831431A8813A582EC17EE87FD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5136BA5F8C9AD64F7549A16713274B620D77",
                        "defaultText": "몰라... 하지만 그의 분노를 보면...\n내가 지닌 그의 힘을 통해서도 느껴지는 그 분노를 보면..."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F0939DA59FEAE44F8B89B53565A32F83A4BF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EAF4B49640523342B2684A23750692C3EF7D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "ED47AB8C152BD447277A5DA0FBB9A172B2CE",
                        "defaultText": "파릴데에게 무슨 일이 있었던 게 분명해...\n그가 극단적인 결정을 내릴 만한 일이..."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F806EEC1669181462059A273580CFA48AE51",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BD77E80E5D03324AC679B1522E454B408FA6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DA582EA372DA844832482F48D5F0C5D1C820"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "9C72F71543CA65462F1A78E36D49C2434987"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "96659F8F31C1A846B72BFEC2A007DB5699DD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "97912C8748EB65492E3A30185378A9FC1002",
                        "defaultText": "\"놈들은 대가를 치를 것이다.\""
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "978501EE89C90945146A40B7656853C985D5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "88BDDBF994E37244BE6B1327797FCB5BDA24"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3021372147DF9540121BADC2796E1CE754F2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C177BECC8F6A6748349B51E373A2F178BBEE",
                        "defaultText": "...맞아."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F99ED00414A9A5462B4BC795A8911DF614B4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FF21023A7E640647722AB77404DD9EECC2E0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F5FB5A351D9A6647AB694C93C13425E0FB8D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "463072DE387F634E637A5A07A5AF9E70A983",
                        "defaultText": "하지만 누구에게 분노한 건지... 내 할머니에게 무슨 일이 있었는지 궁금해."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DFD09F9D941FC244B51B48A1E9729A79B00A",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "verify loop"
                },
                "indent": 0,
                "uid": "3820189455939749426BEA373BCFA56D3BA5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "278FF9AA5DA69544FA499F79B0FC4C4D0CA0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5BE6E6B0005F5344912A5E27D853057690C0"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Numero Risposte Choices",
                        "index": 258,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 1,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "725902B03F4534404E69F89213F041C5AA01"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 1,
                "uid": "B84F22EB816DC54C649A2370E23EF399DFA3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "6CACE66A7E86A24CBE08F1E59EB31383B684"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "727FAB8C2ED5D443BE8AD7115A840E373BBD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BDE79975549DA84FFA390D33E86C332C7B5A",
                        "defaultText": "이제 마지막 질문이야..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "3F2727775C57D542EF3986872E081E71F9A6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "8814194632A7084E9938EAA4C8F8DCF5118F"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "Loop Start",
                    "target": "activeScene"
                },
                "indent": 1,
                "uid": "3CFF5427026FD545C26BE2A97339588F685F"
            },
            {
                "id": "gs.ConditionElseIf",
                "params": {
                    "variable": {
                        "name": "Numero Risposte Choices",
                        "index": 258,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 2,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "129593C292841445FF5BF5941739DBFAFEDC"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 1,
                "uid": "5AF72AE77A076244F14BC0D6B3C8E73195CA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "760AB23E644431422A28C7694E5258848754"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "5DE16A0497C88742B929DBE8CDB3791B25B6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0C56B8EE8B69F94F3D4A17853BE17555B232",
                        "defaultText": "이 진실들을 받아들이기 어렵지만... 그 여자에게 몇 가지 더 물어봐야 해."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "CA9CE5DC5A37934CD30BEA38CAB49E126E37",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "F4062DE552E0354AA5593E28A4291FFC3283"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "Loop Start",
                    "target": "activeScene"
                },
                "indent": 1,
                "uid": "F2F713981F9F63416B2A047652C053A0E0A5"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after all choices"
                },
                "indent": 0,
                "uid": "FF4AB89292170145620B60F40BCE24AC5B74"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "84B36B000E28E74822583BF433014DBFF23B",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "7E49C5B08DDE414084582C81FF75FC54EB8F"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "365DD92A15620541083B0BF0FDD8C40CA758",
                        "name": "C12-8 Conclusion"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "228CEBFF13E6B64CB199542679A6025207F8"
            }
        ],
        "livePreviewDisabled": true,
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}