GS.dataCache['5402FF4A7FC89648F3296AF957DED1E85043'] = {
    "uid": "5402FF4A7FC89648F3296AF957DED1E85043",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C10-01 Introduction (VN)",
        "type": "vn.scene",
        "parentId": "880444DA01A75341EC3B21A00BDB761DDCAD",
        "chapterUid": "75EF9E6F85E3E84744787D615C2743CE32CF",
        "order": 0,
        "livePreviewDisabled": true,
        "commands": [
            {
                "id": "gs.Comment",
                "params": {
                    "text": ""
                },
                "indent": 0,
                "uid": "9FE8F7753A36C84B394A6687391F66488B15",
                "expanded": true
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "1CA9AEC835B767428F093A52DAEEDB67C08C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "92722EE6693CD1493E7A82F34D2CF160BB6A"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "2D020C1916A3814359783A811324EF00AF65",
                        "name": "92 - Shiori Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "6F49AE9C2F37C54DD20A1A14BBBEFBC0A311"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "51FE568238DE384B4F8A0356581EC6A54FA8",
                        "name": "94 - Hellios Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "A4411A9C56D666497F482CD90D22EF98FC2A"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "0FCC16EC8F14214F211BD711C5EF156BDE65",
                        "name": "95 - Rya Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "F264A5B373634149978BE814E09BB2218BD5"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "567F1E3489D91446CF4A0ED6AF508D6BB339",
                        "name": "96 - Cristoph Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "7D285DFF0809874A7A4929B46C0C11C79DFE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "7A52F8DE55D159434B499B596439193E987E",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1329EC1A7CB1014ECC198758767AC8F2A8D2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AA53A3133140C74BB979A0645E51B4BE7E40",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E"
                        ]
                    }
                },
                "indent": 0,
                "uid": "078407E34DA3724F813B83149F9E5C5D0AB1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "942D16A85E0B3342745815540D0D511A07B0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "92D57AC61878454F822889C5F7202376DAB3"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "91621DB8625F70441E69CEF57C08228C3107"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            20,
                            1,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "191EEE936764A74AA8391C62883340D875BB"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "D567806C3F89B4425428F3B2699F96651900"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "76693676909AF64256785DC7A142A0FBAAC4"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "7EBBD6D4558C03457B28CE98CE696CF5B4A4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "DE0B2B767D47F149BB498527FD744F29E061",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E5A070F557C8B84F8D2A19B67FE8CCBB8183"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "DC5BBD146ACCE24BA97A75C7F20ACEB95C49",
                    "parameters": {
                        "values": [
                            0,
                            1,
                            0,
                            0,
                            0,
                            0,
                            800,
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8DB37F373581B744016ACC84F24008704545"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "F954C67490E9C54CE94BDF245FE8220EE2CA",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1C004ECE0F9A09437C7A0C24F8C2982443F2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            6,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B463AB7F61845343B118BEF6466B8150A09A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "03DEA4954ABD5648B72A16630CB12FEB0C7F",
                    "parameters": {
                        "values": [
                            5,
                            200,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "84223E9C569523402C6AD9671CE6224ECCDB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "DB2CDEC354069646936B3126CD5DE8C8245C"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "511432882830D746612A66F50F5A7E971684"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "E428A3E40C08B44F795AA1A43F88B2D3CD28"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 54,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "F6FC376E9AAD95454028A234D3EBAC07577D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "E1FA34F614B4B241021B5382B6EE2ED0EAFB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A6E7ADE3572E6449B148AE305FD76E0A8F51"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4D400A6629A88447C77B53F8895BEF4F326B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CBA3D13B837F4148291BD2F1B3ACD2F85AEC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "77FF9C907D82E147BF39A704ADE2FE59E524",
                        "defaultText": "근처에 다른 괴물들이 있는 게 확실해, 시오리?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {}
                },
                "indent": 0,
                "uid": "7967981D3861A740D439FDA25D25E30F8C3F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C267EEE44B61C146FA08DA47DE18AAF874B7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            5,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "622ED17B42F42546B839C8470BEDBF3D378A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "D13B0AAF2D3485412C8A3B03EAB2EA48ECEB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "231CDE634656D8407E0881C20539A5891C95",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "E3-Shiori_line31_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C02C60526A8379447799009412AD6148DFEA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "508CB9E9535A72405B4A30C75EC3D23277F1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E12B48823928C246C16B8122537FA7C4FAED"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3E78E7898DF15345536B39328E70BF4D4D3F",
                        "defaultText": "그런 것 같아... 아까 그중 하나에게 공격당했어.\n전혀 감지하지 못했으니 만일을 대비해 서로의 뒤를 지켜야 해."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "457FFB554B02F44FB4588278489DDF94D57C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C1B01CA8211D144FA878349558E1CFC148AE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EF249663257FB145741930B8149E7DB8CAD4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3BB9E37964E6D143EE29F4148378386B740A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AA85DE777D29624A4F68A2D7E0DD7AF8EDAF",
                        "defaultText": "위에서 단서를 찾았어, 슈바르츠?"
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1AEB5DF15ADD6647FA4B2502571270470D50",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F309ECB61288E04D0C68677651392E93D9A2"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "model": {
                        "name": "schwarz.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 800,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 1164,
                        "y": 146,
                        "zoom": {
                            "x": 1,
                            "y": 1,
                            "d": 1
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 42,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "1AA6F8A15B4CC140C9480E9250A8BB4511BC",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "F954C67490E9C54CE94BDF245FE8220EE2CA",
                    "parameters": {
                        "values": [
                            "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "012F593F3F7F384A7428BE870F0E691F4ACE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                            6
                        ]
                    }
                },
                "indent": 0,
                "uid": "795830B15CB4454BE808E9B5859E88AA1932"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "F57A54E8327BC9431629F9E498B137593E3C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1304390525D8C84C1D598B940BD4F2675030"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "84B13DEC7D2BC249769936067DF3A83FCC51",
                        "defaultText": "지금으로서는 이 주변에 다른 괴물은 없는 것 같아."
                    },
                    "position": 0,
                    "characterId": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8174AAA86DF0D9450F48CE35DF21E6B6A35D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1437F00216F243408E8AD271123A053D9636"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "47161FDA6E52B6428E8A5A190BC67D611BF6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B0EBBD079DB65343412B6F54C8DDDE1CD5F3",
                        "defaultText": "그래도 야영지에서 보급품을 좀 가져왔어.\n무슨 일이 생길지 모르니까."
                    },
                    "position": 0,
                    "characterId": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3C6B2CDB37C8324EF529DC985BA03B945E48",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "BC576B342058E148AB3945E4DBF5042552DC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8D37575D0C88F8431B9A32C57C77E347169D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "E0352BE557D2944B565A65B6CC403C2D5288"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0311BE5092E2034F93688BB62C6E859C7032",
                    "parameters": {
                        "values": [
                            "D099EDDA3E2B3446FD2835580A8561A44551",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "C0FA74CD17C86741E46A27286C18E2CB4A0D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EEC637476CA0C44DB639DD3814A41B3AF9DE",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "CC1A6EA5509D34445928D1C139BAE9CB1C17"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "24EA83E247CF864F612AB3342F76B65353CC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0311BE5092E2034F93688BB62C6E859C7032",
                    "parameters": {
                        "values": [
                            "3A6470303809F6402069BCA779DE051805FA",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "83F106A432DF91457948C0244CBB74417C78"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EEC637476CA0C44DB639DD3814A41B3AF9DE",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "CDF0B0DC174645452A0B0AD3542E9EBCAA4B"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "3F82C66C3784824D88492DF65B4DF0209FBD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0311BE5092E2034F93688BB62C6E859C7032",
                    "parameters": {
                        "values": [
                            "7BAEC95A702D664CF74AB71248751A8C1B8F",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "10CABAF332BE634415290011192E3B9514A6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EEC637476CA0C44DB639DD3814A41B3AF9DE",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E753933D9731F546DC39213349084EA0C1F3"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 33
                },
                "indent": 0,
                "uid": "1DCB8D1F663D254BC419BAE89E9615868758"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "138896F45682074E1F3A8A98EE5FCD2326A6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "077FE9717F9C9543AB283F59847B750CF7EA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8E0B995B49898142DD9A43228ED45E5AF626"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9EE85EA461CE7243B1986F832D565B74E0CA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "691AEF7E0AF431494049E47500914851A475",
                        "defaultText": "고맙군. 너를 훈련한 지난 세월이 헛되지는 않았어."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0A19A1576DBED94D323A0655A9D5EE92C990",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DA2E78BB7489764A942B5CB8A9B56C09E397"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CF2580D99CF596449F4AD0643770E806259B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7E357B3F6E527849477B77D5BBA31AA2F8E9",
                        "defaultText": "흥! 나는 처음부터 뛰어났어."
                    },
                    "position": 0,
                    "characterId": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6D85F91B3C31334DEA5973D8CC5A70E06188",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D22358BE274C3141FD7BD9E6125D57D6188B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8486C20D7CED62497E798F355C9F81DC54A1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A22E8D1B88A6744D441A8E50D4DEBC6B6E17",
                        "defaultText": "그런데 이상해... 아까 그 진동은 뭐였지?\n그 뒤로 내 안에서 점점 커지는 이... 기묘한 느낌은 뭐고?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DC10F98656089241167B4DB0202885525BD0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BE3E88F66406214DFE88DF52AFAE531586F9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F2749D3357E9F441E749F2D8CE5B506B5514"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "087D1DB23BC5C3405A695DD187224E05A8DF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1FBC46AA8E2BA14A56880C01F6A9E102F4DF",
                        "defaultText": "시오리! 모두들!"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F65F6CFA3C174740D92944C38AC8A5077CC1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "CB04BA474F3D1240291BCDC62B70795D04E5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C79E31C60BCB07473E6B2AC4B1812E834328"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 33
                },
                "indent": 0,
                "uid": "01C6274D796B9542C55965373403C1EAD3A6"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "2D5931CB5A39A74BB74A5806FA0EF5557143"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "5AF509B61104194D954A6E403F7091A3CD2D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "FD71621A728EC344B76BA9413EB058FB15AB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6EACFE6390D701404449A2B2D4A723380C6F",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0,
                            0,
                            600,
                            0,
                            800,
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FDF2A2928B22B5423A8AB959F75DBC233EB9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "F954C67490E9C54CE94BDF245FE8220EE2CA",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "27FE7B236805E540913AEBD362059BEDFB59"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            5,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "80CD527573B1C74F1C1A8EB2589DE09F5A71"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 39
                },
                "indent": 0,
                "uid": "79281E608A18C54269691254D2C1B8779D74"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Hellios appears"
                },
                "indent": 0,
                "uid": "1905D1B2394BE3449788E9F099C9B6B725BD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "6205916A1818054E608942B05A80ADF66CB6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B1E4AE7F607E11465169493357C4422BC834"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AA8D56230A3B504F141BAA12A28A6744F3AD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "831851A594B88248BA998643FC6471DFD51F",
                        "defaultText": "헬리오스! 여기서 뭘 하는 겁니까?\n파라트라스 님과 함께 있지 않았습니까?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FA979E305BF968410C6A1B73042B92D3E769",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4DB7883F6305A2484D9BAC42662F399142FE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "944A729B2E3AD344945BF2606A10C56E7FE6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5D5A75067526C045C738CB924F82638BB96D",
                        "defaultText": "파라트라스가... 그 아이가..."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FA52FF6332F6994DD32B67D6885400E2AE81",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9D361AA168CF504A89689687C04C4A19D760"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9D121B952B801947804BEE26AB0A0132F28A",
                        "defaultText": "...젠장!\n사이 사령관이 그릇 계승 의식을 방해하려 하고 있어!"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B579FDF68EC89747607ACF748E00475109C3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "CEC96907159F0348CC7B0B6973F3AA46476A"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "4F7C11C45308A5446E4BCB91BD09A7631B61",
                        "defaultText": "서둘러야 해!"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F700F3E0514FC44105290E719C37C2012D57",
                "expanded": true
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "if sarcastic enough"
                },
                "indent": 0,
                "uid": "CAEBDABE90CBA141C348CE33C2BCCA4B3CA0",
                "expanded": true
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "Sarcasm",
                        "type": 0,
                        "value": 50
                    },
                    "targetVariable": {
                        "name": "nini",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "34499CBE5BAA054700292672A857278103C4"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "nini",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 55,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 3,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D3A7127A4D3B0143D7794C378E076F22B5E7"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "AAEEA3F331A538498B5BF0C5AB5921E9B140",
                        "defaultText": "참 예상도 못 했네, 그렇지?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "7354ED5B49E3C643540B7115EAD70ABF3609",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "not sarcasm",
                            "sarcasm",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 1,
                "uid": "A53A77749FE0664AD5495DE20A72467DF2D0"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "D99B84622B3B684393880EC89F8DEE42045C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "not sarcasm",
                            "",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 1,
                "uid": "2C6C1DF61FFD174F962AF3819CB4683B21F1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "15909A9383E444455D29C380E25A5826F620"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "sarcasm"
                },
                "indent": 0,
                "uid": "B66552FB62FF17494F9A94828063E07F27F5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0,
                            5,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "676134C43371B946C979543450C7DA97E9E3"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "not sarcasm"
                },
                "indent": 0,
                "uid": "17072FB047C228477B58AB231C82DD1D0213"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            7,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8E7B042E0DD4B24A7E0A3D78F8E1139E4196"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            2,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "75AE5B107AEC6442864809C2F1D63E90654F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "4BB0B99B15EFD14A062A9CE7D7E98E1B4E28"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B6D4E33C8D93704DB84AD2172A12C780F6C9",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "E3-Hellios_line27_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B3AB2FB76AA0344EAC3AF4D92D8C25B03232",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "CFDA988E1FD0C5443D5A614536A0A68AF1CE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8BB624DC2BFA584A4C58E239B5574B7FE0BE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8176AA807076D840674B4A8447617CF165BD",
                        "defaultText": "그래...\n미안해. 그를 막지 못했어."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "492A8C2E677F854EBF29B7F75507311C0022",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "652EC4871B90784390681138AFD79DCC9609"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "78E328A7740ED04EC81B36B641D6AD9133C8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "DD78AF895026514BDC489D3150D14BA780A8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D6F85F7523E29140224B8FB64BEB11E4A1C1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0B40C23C552B434A0609FB696F5A89BB2C9B",
                        "defaultText": "지금은 사과할 때가 아니다! 즉시 성소로 돌아간다!"
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D300F71534901543491AD51256AB93A058B5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "20E38E635CC40543797887C4F77E98819ECB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "958F4CB3139E154587681E74F3D4384F83CF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "EAB4CDE890FDF644D2092BE4F5336ABEB0D4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "93408F748BC871472268EFB76091F221964A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C4AD96C231010241778A41504E677D7D3EAE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CA7E05AC0A398241BC18CAC344E50F32400D",
                        "defaultText": "맞아, 리아! 파라트라스에게 가자! 서둘러!"
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D10EC65161E4F54EDB3B2039D59FB9380C28",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "2C1762446FF2D24D2D18D6184F8FBC57897C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A3034AD918A8584236994628E9850C9237B5"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "REMEMBRANCE SHORT.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E06748DA7AD37646A84867B1CFF12E9D4CCE"
            },
            {
                "id": "gs.ScreenEffect",
                "params": {
                    "type": 1,
                    "pixelate": {
                        "enabled": false,
                        "size": {
                            "width": 10,
                            "height": 10
                        }
                    },
                    "blur": {
                        "enabled": false,
                        "power": 100
                    },
                    "wobble": {
                        "power": 10,
                        "speed": 10,
                        "orientation": 0
                    },
                    "duration": 24,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "zOrder": 830,
                    "fieldFlags": {
                        "zOrder": 0,
                        "easing.type": 1
                    }
                },
                "indent": 0,
                "uid": "6F2332514DE2764E0C6AC813ACCB13B095CE",
                "expanded": true
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 15
                },
                "indent": 0,
                "uid": "FDF32DC12FCB4448718885D229542FA3B8B2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            250,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8C3F7EC374BE114DA839EE032244F44A6496"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "B90347EC11597648D36A3C99408EF32359A4"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "ornières has a vision"
                },
                "indent": 0,
                "uid": "B0659A93706745432C8B2AD11AA5F92CD3F3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "0E975E1839C3E6419449E282D3A30C065931"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "649243DF4879C6493529838771C6DC09431D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "20C0FB5290F42141CD9B31546916D5A3D73C",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "179C4AEA7DB2654B7E8A0D57894427D7D5A9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B858A2AF513C424BC86AC9883DD021618F14",
                        "defaultText": "때가 왔다! 네가 친구들을 학살할 때가 거의 다 됐다!"
                    },
                    "position": 0,
                    "characterId": "20C0FB5290F42141CD9B31546916D5A3D73C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C3F20AA8308D8747BB097533B246F300DC08",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E885951C9DD9224E557A2F48961869C948F9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "9B0B082405404240696A1420DD5DECF5BDC2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0CD86AE323A7824659588218575BC51925E3",
                        "defaultText": "나의 부름에서 벗어날 수 없다. 오너라!"
                    },
                    "position": 0,
                    "characterId": "20C0FB5290F42141CD9B31546916D5A3D73C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9B402C19588D074F6E5BF0A614F468B4A561",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "0AC4A262594AF040327BE117CFCFB5336827"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "241AD5C78B5B014FF549F1113BFD25CDC79A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "5CA3FDDF6553D749BE7B8632DBBDD71C2568"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 15,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "C8D943EA95DE95485B8961C3E1BA54B202CB"
            },
            {
                "id": "gs.ScreenEffect",
                "params": {
                    "type": 1,
                    "pixelate": {
                        "enabled": false,
                        "size": {
                            "width": 10,
                            "height": 10
                        }
                    },
                    "blur": {
                        "enabled": false,
                        "power": 0
                    },
                    "wobble": {
                        "power": 10,
                        "speed": 10,
                        "orientation": 0
                    },
                    "duration": 24,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "zOrder": 830,
                    "fieldFlags": {
                        "zOrder": 0,
                        "easing.type": 1
                    }
                },
                "indent": 0,
                "uid": "770653136206D0420568FEC4391117D67D1F",
                "expanded": true
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "CAA0C4282AAEA44942289F7066AED51AB686"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "after the vision"
                },
                "indent": 0,
                "uid": "FF28FB4B2348574DE17A2E44F466DD9A36F2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "18560A3C9B241545138A8F577CDBC23606A9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B5F0992319A344499738CB750472B4E9CC3F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2F2624286FF6D74EC16922A53A8070FD58F9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "24FB7EC087B07348A478DC71DA90F2CC9975",
                        "defaultText": "으으으으윽...!!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B15FE6502A99844A0E4AFB61B5658335F995",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D65D4A7658C26241142B60C4F8194C5C4D2B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "161BB8584EBE05429D9A178487F5301553F0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BB11422817B7F748498B16C25C59C94C4A74"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6CA184879FBEE24D0D78B8D3DA0FD43E1668",
                        "defaultText": "또 편두통이야?"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "28B43FD75183B64B483B91B34863361FA8B0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C087DDCF2478C44A5D884B0183D03C53C313"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C6FFC8B57696B24A783A6A14C41E1468976C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "CB60E6A16C1EC84CF14BF6E1C42F4E4D3B79"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "EF16A7142DE4C248A01A0AF286249238C0CD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A5B7760731FF7743EE99FD2332C6BE89E5F7",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C01-01_line31.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "30C5FF046743224F6B5AEAD3A0B810F0CEDB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "069963A586208844541B13877BC990A7D555"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D77FCF9982C8E149E329C31087D4A4B4E365"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8F637AFB612F8846BB2A48A755D47AC9AADB",
                        "defaultText": "니니!? 괜찮아?"
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "44185D50344B724D167AE4B6E11CAF39AAED",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "218ED83914E2774B602802F9F9B9FA979C24"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "62089B2F7026524BEA595374126FC44001E7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1802C411119881436D1BDB81CF96181999D7",
                        "defaultText": "으, 응... 아무것도 아니야... 헉..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "59EF280B6CD02345FF2869C2008A0E0E7A87",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C8EC9105455FC84F7A691799D5D7A7E097FE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "68783AA55C1E254574196EF7105AD5468C44"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "01222F8E19B3E941874B4EB581B3A43E7A66",
                        "defaultText": "이번에는 기억이 아니야... 그 불길한 목소리뿐이었어..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AE1D43953CED254FA25A01813D079EDC62EA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "27B9A28654A1B1428B7B34044534D55B9955"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2BCC101A39D0774EFA981092D620D6BCDCB1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FA9A9BFF81269044337BBEA6ECB15ABAE1AF",
                        "defaultText": "하지만--!"
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F26384ED5EC59748885ABB51ECD63B1426B1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2872EC6D8E60E24E884B1C4794BD3B41FDA8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C37ACA07429AE442AA498C3046214A29D62E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F6919EF535E629412E2ABE64878E8E0F5C67"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "57D60BB160A13248EF6B4D804EC018FF6242",
                        "defaultText": "파라트라스 님에게 우리가 필요해...\n괜찮다고 했잖아. 가자..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5B914C6B75D7144D01497F09CC8B24C28E7C",
                "expanded": true
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "if affection is high"
                },
                "indent": 0,
                "uid": "2ECA865B136E254F032A6D43BC5EC9D0717E",
                "expanded": true
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5483A015854DF843C179B7221499FB63BBA5"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Ornières x Faratras",
                        "index": 401,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 70,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 3,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "35C211265D2731476A695C8576067F5528D3"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "8AC9C88447990741783BA54119C18E7FAD7E"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Fa interested in Orni",
                        "index": 193,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "76DD6A55892BD8427B99E2514D81757EDEC0"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "0DD9A22863E8F34FA9890A946F098F2A5DE7"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A92FFF7899C85240BA2A4A845DB029CA6A1E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "769A82CA448DF048A64981B63DA015622B0C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "CC663FB36BE0354DBF1A7475DFDFB2EDB2B9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "147022646BD157469F282721F7FA225142F4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3C3E709B4B11F24AA5681A856D6EEBB8F43B",
                        "defaultText": "그동안 함께 겪은 모든 일 끝에 그분을 잃는다고\n생각하기만 해도... 가슴이 아파..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "902070ED82BAB749AD8948B577A9E9D8A24C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "1D574B7F45497846BD587634F221EFB97E6B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            6
                        ]
                    }
                },
                "indent": 0,
                "uid": "7B8AF0F04BB45447453BF422E2CA76DE4EB4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BDAE4B6C81E69946C86BBAE1CD9973347368"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "51BEF1B1108C344B96691116F1EFDE7D2996"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "92C8A7271BDE7246CD7A3E44885A847CCB4B",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4BB301C984393141233A0BB27C3A74B72EA3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "4B8E9FF0167D914046390F75687D84636674",
                    "parameters": {
                        "values": [
                            5,
                            1400,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "CE83F1B80026B742D6592BE9532774D9DE4B"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 114
                },
                "indent": 0,
                "uid": "9C76A692331D084DA418DB72A4B0F6F939EF"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "F344C5E9328EB4454C4AEB4359F220B1C82E"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 2,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "15DE7D207DCB224A520BA6A1D60FDA4F1FB0"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 3,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "CE1227D66352D84D29488A55391B302E042A"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 4,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "D4175CDB878671484D68FF87ACD1C8078B78"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 5,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "E66C0FDA21750341A97BA9377EEE84226205"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 10,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "52D83BC2383AE4438658B63610A12DFA0931"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "9DF738344E3F0140A91B24B6BD04D0067FC5"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "414D363A57C0144EB85A8736783625D1A71C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "DE0B2B767D47F149BB498527FD744F29E061",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D69712AA06E8A6408D48FF77B05FBC1B4B2D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "92C8A7271BDE7246CD7A3E44885A847CCB4B",
                    "parameters": {
                        "values": [
                            0,
                            1,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "948DB2B408C9E741461A9B0598A6B811153C"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "(they move on the map to Faratras' place)\n  (Alfred's note) I'm coding this part in advance."
                },
                "indent": 0,
                "uid": "4DA4B53E5F6F754FF15942950AFEDA99591B",
                "expanded": true
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 45
                },
                "indent": 0,
                "uid": "37B671F92B065643082A8868A3A58BBFFE68"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1B4E257C92FB7442C36A8B74234B5A017E25"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B819296F5F7629433C2BAEF47E4578E91CD7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "244CF5107A2C194AB90856C026CBB74ACE29"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "DB52B5E583763645D868FC65737AB5058878"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "94474E2F355FA2414368C3414B159DBF189F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "050309A87C42524DE798CB55342B1585B4CC",
                        "defaultText": "파라트라스! 어디 있어!?"
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4B35E0AB8055604EA22B462042E1B7046FA6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3D2AC92971DD3146804A32D411C9742B860A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D5EE9F1C5A26C54B904883F28B284F26239F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "8A4012CC13901146A4487232F4ABA43BCEDD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "51B2E6739723084FF5888C961AC9D181C12F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8D20B1EE2A82F0456D696668860E073B102C",
                        "defaultText": "잠깐... 뭔가 확실히 이상해, 친구.\n저 사람 사령관 아니야!?"
                    },
                    "position": 0,
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "02A646BE6107B94612892741634AD0B489A3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2781F77A6C04454AA77B9828CA64D8EC7825"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1B8E7A1449CA244D750ADE94E97D27814371"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "22B689D215A3794643293AC1AD533D715F6A",
                        "defaultText": "맞아... 그리고 죽었어."
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CF94D90B8A63C140D82B6990D9C23446C7E8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F4DAACDC1F528346740A7BD362ADAA65B6E1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "810556461E88C14BAB3B8FB51585E0D932E6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3D311CA029E4A9425909FAF80E2B3471EB32",
                        "defaultText": "대체 여기서 무슨 일이 있었던 거야!?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8FDA7A46714F2945275B0FB68DB6CCD76C34",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ACFD68FB07055341555818F49AD24521D594"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FD010FBB1F7CC34DA25BBA575CCA7F670EEB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "616548C687709846664B2CD11C592FCAF628"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CFEE7BED323F1843B268EA03722E0156F475",
                        "defaultText": "아무것도 보이지 않아! 마나 재앙이 너무 강해!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A97D5E431D6FB845C71808470BDF107DB98E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FF1944992602664AC4094F91199C913612A7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5D4D9C765251774FB088FC301350B058DFE7"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 108
                },
                "indent": 0,
                "uid": "B089D6623506664BA72B86753318A88D9B3D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1DAE910917F0454B7F9B6628586D12F8E71B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "32EC82E07B296341F62B81D581F7CA809663"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8C07D0054959E54D9A384254807D2604E8F4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "04FBC2379BBE3640EA7976938F1652622FD5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8BA344B82461A14D6B5871C7A11C3AF3B854"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "549017808459F145279AFA391E66E20664CA",
                        "defaultText": "파라트라아아스! 제발 대답해 줘!"
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F0980C1B1F7BC34CD2394C05610D7BABCA78",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "30DC7FE407F4074A9C196AE4CC266E52F0C9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1C2862AF448D3147D19BF4D530FD50683507"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E654BEDC85A040492D49AB7308206E1B54BC",
                        "defaultText": "파라트라스 님! 들리십니까!?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E579909C28429347306AD324563B22E30AF8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "61E474F6495F274E9F1BBCA5B047F33500B0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "73BED9FC54A2414B0B2BBF888DAABEE16B7E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FA97B8B67751394D1609D417014A934D7210"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "CA278C02547931494D9836C0E44E9528C649"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "676C4568768CD34262191749B92D6B3A0D7C",
                        "defaultText": "잠깐! 아주 희미하지만 누군가...\n우리에게 다가오는 게 느껴져..."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "960739354D936841F75BF62763A65A264C5E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5C2A6EFE7B97C447133B52D3475CA8606CD5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A1893D314E3A134C7A2B4A8499426F274490"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 78
                },
                "indent": 0,
                "uid": "6BDE4CEA5C72E1455A4A97E067EAEDB9D0A4"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "58551AE6186D954129888B02279955DE46BB",
                        "defaultText": "파라트라스 님...?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CBDBA00F8B87C44F2A9B7981AB86C175EB7B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "only choice",
                            "",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "09339C9650CD1548A08A1C37639C2BC30F8D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E43CFD4E7CAD214A994AA4B6816283D52982"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "only choice"
                },
                "indent": 0,
                "uid": "FB92A7301374E241D82BBEF989AAF5EC664D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "3BFD649F29CC0943664A4532530B03D1BDEC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4CCA748A24A75341CC69DA231D2FFC9BC565"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "E82E07414D83364C4F4A7917961725FCF2DD",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FEF7B6747C35F3408A59B64853C521FC6826"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E55943A44FCB2345F37A0D3139C9D95D2162",
                        "defaultText": "파라트라스를 찾나? 지금은 집에 없다."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2D324D313811D8406D5A231300855F9CC307",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CFA90E2D20BC3348D95A0191623FD5E8D47C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "80E2532277B89140BD0947A2C1B57E9723B7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "90233BD00A71914A092AC5175F7DE852962F",
                        "defaultText": "하지만 필요한 게 있다면..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "55E0056947EDD24C11889F72527C14B3A7E4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F50A91FF4CCB9646A82A70248D1AD82F429A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "781BEF7698B8444C681B43373D09796D41DD"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9C327132470DA747B84B9916D516853634EC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3D44B8FE9E7FA24BF52ABB650691D5E45507"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "DK!Fa appears"
                },
                "indent": 0,
                "uid": "9C4D2F594608E1403098A4632C2B96E2C794",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "71A50C5884CC654A72297CF412478F6CE71E",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            4,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "01E173AB170F984C7E69AB4788C9E4D15A5A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "452971AC57A9E1405C6AB92902730EA270A0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2DD5316C39C075430379F595F45E468286C0",
                    "parameters": {
                        "values": [
                            9,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4B3BC27B765AE744A94A6DD38A058CAD6B8F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "12F680C17B13584F516BB80161A157ADE973",
                    "parameters": {
                        "values": [
                            9,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "38D596A41F4CD546B45AC0858A43B62BFEA0"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "625AC1C377D5354C836AE8C83C178D1404D2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8319221052E2994A002BCCF3E3EE5345B869"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "972239E4224FD34FE33839B8D5E68A79CFC0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B6651AED6C9EA74FA158C979EFCA5E327A44",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "E3-Faratras_line38_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "47995914566E3444F58AFF31FB76927684CA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "068B2FA52564F5402F79F1E280E5319F5352"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "E82E07414D83364C4F4A7917961725FCF2DD",
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "2165A2B497AB08456A4A7D636A6083B31135"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "32F57BD587FA5943E7694F91D7F80341C58A",
                        "defaultText": "나에게 물어봐라."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C225160178E8F144D698FE381B6368640D8F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AB50538B128EC74CB29B0723E0B9534ABD60"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7C97692F3DB42548AC1AF6F73A23DD9C05E2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A8F1D97E3CEEE24AE2282C74BBDDA520982D",
                        "defaultText": "너, 너는...!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9B1D29696E560140181B2AD3D5EA07DC75D9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3F2DD1629E7F9648A5696D55C2843C60C9C0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0EB6E04481A178414938A8661B47A345D4CB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EDA8ED6D9A5B5141717B6043BB6D903F8434",
                        "defaultText": "말도 안 돼..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8C25EAF07A5664437D288545083387CBFE75",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DA8D590C5764784A0A29C783320E7DD35E46"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Fa's name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "360ADFC961C60742814BF8F53210EC708E06",
                        "defaultText": "Demon King"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "599C51A227AEE84561390ED66847522CA347",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "E82E07414D83364C4F4A7917961725FCF2DD",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Faratras"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Fa's name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3E122AEA5AECA246AF28066779230E677BFB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "E82E07414D83364C4F4A7917961725FCF2DD",
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "4C8FEBCB74FEE84ECD9BE7A6E8C02DC0118D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "173420495696784972181E20AEE9C11B0F54",
                        "defaultText": "그래, 나다. 마침내 자유의 몸이 됐다! 하하하!"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E3511CB177741441E96AC8783A508F932CC0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "552864C97F9448477D297DB7BD0B04568E8E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2DD5316C39C075430379F595F45E468286C0",
                    "parameters": {
                        "values": [
                            11,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DE0FD3871CA78740917B0DD77BCEDB4561B2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "12F680C17B13584F516BB80161A157ADE973",
                    "parameters": {
                        "values": [
                            12,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "993BDD8F313DC24B485ABC33B0605D1BF3C7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BD98027054B3224915688107F4DE88282414",
                        "defaultText": "너희 머저리들이 이렇게 쉽게 내 함정에 걸려들다니...\n인간은 참으로 가련한 종족이야."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "80D2EFA31FF3F5446C5A84D206011BA5AF5E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4542364F557C134EEF29BF16144C92818E33"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0F35C00542B8F246711A87851F4027720322"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "12C38FCC5AAED8441A1AA192BE63302F9BE1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8716FDF5868F5442885980C2E679C0E44DD0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A928F8C04D1B0948CC885F31E70234FA8C13",
                        "defaultText": "그 아이의 몸에서 나와! 당장!"
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "86CC5ECC868D044BE689DAF81EAA3964EADF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "46C7AC4589A0B6480B683353F343C87608D3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "E82E07414D83364C4F4A7917961725FCF2DD",
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "95FC6B39150D1946BC3BB56796E83464980A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6158CB852F0AD3443D387428C97A96BA0B89",
                        "defaultText": "상당히 초조한 모양이군? 하지만 그렇게 할 수는 없다.\n적어도 아직은 말이지."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "92949FAE366F3047706805160E5E2BA9929E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "38C5B58E38FA644ED728556878866D9E0688"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A707ECE46418384C392B69B23A46F87CBB03"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "148E9AFB0D2F984B18092AF5854A5E52DE7D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C38E70484232B246E36B32C7195E420CF48C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4DBE455455801042B02AE64210FDFFD7F14F",
                        "defaultText": "무슨 뜻이지?"
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "165F85F6686600449E4834458E48532885F5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "86700BD68895D24FF56943280997EAC8B81B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "12F680C17B13584F516BB80161A157ADE973",
                    "parameters": {
                        "values": [
                            7,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D02E2B4F66FB8748DB39CF045C923964ABA3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "60268C52474B2149DA19ED545007F9830121"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "696FC7F96F08044C4E5939F4341EF0C24E28",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "E3-Faratras_line41.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C2C82C8B53C3434B4E5ABC67C0D0599E43B2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "3CC1C6897C84894B855BBCA73531DE2460DB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "E82E07414D83364C4F4A7917961725FCF2DD",
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "54E1D1EE583DF64B0C6B97439C075C7ACFBE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B6EAF6E17CE00544401A19D2E4303C08AE8B",
                        "defaultText": "이미 알고 있을 텐데.\n머리 빈 꼭두각시들아, 마지막으로 한 번 더 너희를 이용하겠다."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D4A445F933658540FF480FB6DF46B4606EA1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9F19C26416589847AF78C1976ACC6406530D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "30419B1B1C991042125B13623FB21023403A",
                        "defaultText": "자, 덤벼라... 나를 막아 봐라... 뛰어넘어 봐라..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7B86D7147CDB214643884026FDCCD7D06202",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B5D6D787836C58468E6B0174E7F18472923D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "99A0FF31625FA842DE4A02E86FDF5BBE432C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FE7270CB810E564FEB1B96B9DA7F8C46334B",
                        "defaultText": "왕의 힘을!"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "196A761486500542CC5AEB7286955323863D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B8223E3A51C36446F5380A57B04F51E89992"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4BB7C6F0378E67420C980D58809E0E67D90D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "96E8865C46A6744AF298785563F5D69BB4F3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "7CC273F24EF3C84EB83B5926DC507D476C56"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8F0D279321A7D1491288F3361046DBAC18A5"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "67B99B4A72EF7545DA3A6A2604A323360168"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Battle Animation sounds/Spell sounds",
                        "name": "Hell_Teleport.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2111017A1491834C514AAED173FE50693707"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "duration": 9.6,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "0AEE3DD47B26744DAF2BD91836E58AA6E70F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "577D4C6E2D68654FF2883C59BF0F9D33436D",
                    "parameters": {
                        "values": [
                            0,
                            1,
                            180,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "D6BB67627156A3464528A12550220DF8AE61"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "BB44D70E3E211845D33B2C04C8A4B4B4962D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6191D9F08F78F446264ACBC01D8C2DBC5CED"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "DF3474E318AF5443006B8DD39C7FA742A22C"
            },
            {
                "id": "gs.FreezeScreen",
                "params": {},
                "indent": 0,
                "uid": "24D6C9B22D98704AD789EE7068AAB6C69626"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "1FB8201E1FBB0548014AD8221F2942AD9589"
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "4EB93F0E6E07B046F95AA30861649B05875B",
                        "name": "C10-02 MAP (Midnight Shrine day)"
                    },
                    "savePrevious": 0,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "FEEB05112FA1214CD77AA992F2738CFD6B62",
                "expanded": false
            }
        ],
        "localizableStrings": {
            "77FF9C907D82E147BF39A704ADE2FE59E524": {
                "t": "Are you sure there are other monsters nearby, Shiori?",
                "d": {
                    "cid": 0,
                    "eid": "7967981D3861A740D439FDA25D25E30F8C3F"
                }
            },
            "3E78E7898DF15345536B39328E70BF4D4D3F": {
                "t": "So it seems... I was attacked by one of them earlier. I couldn't even sense it, which is why we should cover each other's back just in case.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "457FFB554B02F44FB4588278489DDF94D57C"
                }
            },
            "A22E8D1B88A6744D441A8E50D4DEBC6B6E17": {
                "t": "It's strange though... What was that quake from before? And what's this... weird feeling that's been growing inside me ever since?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "DC10F98656089241167B4DB0202885525BD0"
                }
            },
            "1FBC46AA8E2BA14A56880C01F6A9E102F4DF": {
                "t": "Shiori! Everyone!",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "F65F6CFA3C174740D92944C38AC8A5077CC1"
                }
            },
            "831851A594B88248BA998643FC6471DFD51F": {
                "t": "Hellios! What are you doing here? Weren't you with Lady Faratras?",
                "d": {
                    "cid": 0,
                    "eid": "FA979E305BF968410C6A1B73042B92D3E769"
                }
            },
            "5D5A75067526C045C738CB924F82638BB96D": {
                "t": "Faratras... She is...",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "FA52FF6332F6994DD32B67D6885400E2AE81"
                }
            },
            "4F7C11C45308A5446E4BCB91BD09A7631B61": {
                "t": "We have to hurry!",
                "d": {
                    "eid": "F700F3E0514FC44105290E719C37C2012D57"
                }
            },
            "AAEEA3F331A538498B5BF0C5AB5921E9B140": {
                "t": "Who would've seen that coming, huh.",
                "d": {
                    "eid": "7354ED5B49E3C643540B7115EAD70ABF3609"
                }
            },
            "8176AA807076D840674B4A8447617CF165BD": {
                "t": "Yes...\nI'm sorry. I wasn't able to stop him.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "492A8C2E677F854EBF29B7F75507311C0022"
                }
            },
            "0B40C23C552B434A0609FB696F5A89BB2C9B": {
                "t": "This is no time to apologize! We shall get back to the Shrine immediately!",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "D300F71534901543491AD51256AB93A058B5"
                }
            },
            "CA7E05AC0A398241BC18CAC344E50F32400D": {
                "t": "Exactly, Rya! Let's get to Faratras! Quickly!",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "D10EC65161E4F54EDB3B2039D59FB9380C28"
                }
            },
            "B858A2AF513C424BC86AC9883DD021618F14": {
                "t": "IT'S TIME! IT'S ALMOST TIME FOR YOU TO SLAUGHTER YOUR FRIENDS!",
                "d": {
                    "cid": "20C0FB5290F42141CD9B31546916D5A3D73C",
                    "eid": "C3F20AA8308D8747BB097533B246F300DC08"
                }
            },
            "0CD86AE323A7824659588218575BC51925E3": {
                "t": "YOU CANNOT ESCAPE MY CALL. COME!",
                "d": {
                    "cid": "20C0FB5290F42141CD9B31546916D5A3D73C",
                    "eid": "9B402C19588D074F6E5BF0A614F468B4A561"
                }
            },
            "24FB7EC087B07348A478DC71DA90F2CC9975": {
                "t": "Uuuuuuuurgh...!!",
                "d": {
                    "cid": 0,
                    "eid": "B15FE6502A99844A0E4AFB61B5658335F995"
                }
            },
            "8F637AFB612F8846BB2A48A755D47AC9AADB": {
                "t": "Nini!? Are you alright?",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "44185D50344B724D167AE4B6E11CAF39AAED"
                }
            },
            "1802C411119881436D1BDB81CF96181999D7": {
                "t": "Y-Yes... It's nothing... Pant...",
                "d": {
                    "cid": 0,
                    "eid": "59EF280B6CD02345FF2869C2008A0E0E7A87"
                }
            },
            "FA9A9BFF81269044337BBEA6ECB15ABAE1AF": {
                "t": "But--!",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "F26384ED5EC59748885ABB51ECD63B1426B1"
                }
            },
            "57D60BB160A13248EF6B4D804EC018FF6242": {
                "t": "Lady Faratras needs us... I said I'm fine. Let's go...",
                "d": {
                    "cid": 0,
                    "eid": "5B914C6B75D7144D01497F09CC8B24C28E7C"
                }
            },
            "3C3E709B4B11F24AA5681A856D6EEBB8F43B": {
                "t": "Just the thought of losing her, after all we've been through together... It hurts...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "902070ED82BAB749AD8948B577A9E9D8A24C"
                }
            },
            "050309A87C42524DE798CB55342B1585B4CC": {
                "t": "Faratras! Where are you!?",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "4B35E0AB8055604EA22B462042E1B7046FA6"
                }
            },
            "8D20B1EE2A82F0456D696668860E073B102C": {
                "t": "Wait... something's definitely off, man.\nIsn't that the Commander!?",
                "d": {
                    "cid": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "eid": "02A646BE6107B94612892741634AD0B489A3"
                }
            },
            "22B689D215A3794643293AC1AD533D715F6A": {
                "t": "It... is. And he's dead.",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "CF94D90B8A63C140D82B6990D9C23446C7E8"
                }
            },
            "3D311CA029E4A9425909FAF80E2B3471EB32": {
                "t": "Just what in the world happened here!?",
                "d": {
                    "cid": 0,
                    "eid": "8FDA7A46714F2945275B0FB68DB6CCD76C34"
                }
            },
            "CFEE7BED323F1843B268EA03722E0156F475": {
                "t": "I can't see anything! The Mana Scourge is just too intense!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "A97D5E431D6FB845C71808470BDF107DB98E"
                }
            },
            "549017808459F145279AFA391E66E20664CA": {
                "t": "Faratraaaaas! Please, answer us!",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "F0980C1B1F7BC34CD2394C05610D7BABCA78"
                }
            },
            "E654BEDC85A040492D49AB7308206E1B54BC": {
                "t": "Lady Faratras! Can you hear us!?",
                "d": {
                    "cid": 0,
                    "eid": "E579909C28429347306AD324563B22E30AF8"
                }
            },
            "676C4568768CD34262191749B92D6B3A0D7C": {
                "t": "Wait! It's very faint but I can sense someone... approaching us...",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "960739354D936841F75BF62763A65A264C5E"
                }
            },
            "58551AE6186D954129888B02279955DE46BB": {
                "t": "Lady... Faratras?",
                "d": {
                    "eid": "CBDBA00F8B87C44F2A9B7981AB86C175EB7B"
                }
            },
            "E55943A44FCB2345F37A0D3139C9D95D2162": {
                "t": "Faratras, you say? She isn't at home now.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "2D324D313811D8406D5A231300855F9CC307"
                }
            },
            "90233BD00A71914A092AC5175F7DE852962F": {
                "t": "But if you need anything...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "55E0056947EDD24C11889F72527C14B3A7E4"
                }
            },
            "32F57BD587FA5943E7694F91D7F80341C58A": {
                "t": "You can ask ME.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "C225160178E8F144D698FE381B6368640D8F"
                }
            },
            "A8F1D97E3CEEE24AE2282C74BBDDA520982D": {
                "t": "Y-You! You are...!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "9B1D29696E560140181B2AD3D5EA07DC75D9"
                }
            },
            "EDA8ED6D9A5B5141717B6043BB6D903F8434": {
                "t": "It can't be...",
                "d": {
                    "cid": 0,
                    "eid": "8C25EAF07A5664437D288545083387CBFE75"
                }
            },
            "360ADFC961C60742814BF8F53210EC708E06": {
                "t": "Demon King",
                "d": {
                    "eid": "599C51A227AEE84561390ED66847522CA347"
                }
            },
            "173420495696784972181E20AEE9C11B0F54": {
                "t": "Yes, it's me. At last, I'm finally free! HAHAHA!",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "E3511CB177741441E96AC8783A508F932CC0"
                }
            },
            "BD98027054B3224915688107F4DE88282414": {
                "t": "To think that you fools would have fallen for my trap that easily... Humans are such a pitiful race.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "80D2EFA31FF3F5446C5A84D206011BA5AF5E"
                }
            },
            "A928F8C04D1B0948CC885F31E70234FA8C13": {
                "t": "Leave her body! NOW!",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "86CC5ECC868D044BE689DAF81EAA3964EADF"
                }
            },
            "6158CB852F0AD3443D387428C97A96BA0B89": {
                "t": "Quite nervous, aren't you? But I'm afraid I can't do that. Not yet, at least.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "92949FAE366F3047706805160E5E2BA9929E"
                }
            },
            "4DBE455455801042B02AE64210FDFFD7F14F": {
                "t": "What do you mean?",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "165F85F6686600449E4834458E48532885F5"
                }
            },
            "B6EAF6E17CE00544401A19D2E4303C08AE8B": {
                "t": "Oh, I think you know that already.\nI will use you for one last time, you brainless puppets.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "D4A445F933658540FF480FB6DF46B4606EA1"
                }
            },
            "30419B1B1C991042125B13623FB21023403A": {
                "t": "Now come... try to stop me... Try to overcome...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "7B86D7147CDB214643884026FDCCD7D06202"
                }
            },
            "FE7270CB810E564FEB1B96B9DA7F8C46334B": {
                "t": "THE POWER OF A KING!",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "196A761486500542CC5AEB7286955323863D"
                }
            },
            "231CDE634656D8407E0881C20539A5891C95": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "C02C60526A8379447799009412AD6148DFEA"
                }
            },
            "AA85DE777D29624A4F68A2D7E0DD7AF8EDAF": {
                "t": "Did you find any clues from above, Schwarz?",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "1AEB5DF15ADD6647FA4B2502571270470D50"
                }
            },
            "84B13DEC7D2BC249769936067DF3A83FCC51": {
                "t": "It doesn't seem there are any other monsters around here, for now.",
                "d": {
                    "cid": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "eid": "8174AAA86DF0D9450F48CE35DF21E6B6A35D"
                }
            },
            "B0EBBD079DB65343412B6F54C8DDDE1CD5F3": {
                "t": "I brought some provisions from the camp, though. We may never know.",
                "d": {
                    "cid": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "eid": "3C6B2CDB37C8324EF529DC985BA03B945E48"
                }
            },
            "691AEF7E0AF431494049E47500914851A475": {
                "t": "Appreciated. All these years spent training you weren't a waste of time after all.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "0A19A1576DBED94D323A0655A9D5EE92C990"
                }
            },
            "7E357B3F6E527849477B77D5BBA31AA2F8E9": {
                "t": "Pfui! I was already good to begin with.",
                "d": {
                    "cid": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "eid": "6D85F91B3C31334DEA5973D8CC5A70E06188"
                }
            },
            "9D121B952B801947804BEE26AB0A0132F28A": {
                "t": "...Damn!\nCommander Saai is trying to disrupt the Vassalage!",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "B579FDF68EC89747607ACF748E00475109C3"
                }
            },
            "B6D4E33C8D93704DB84AD2172A12C780F6C9": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "B3AB2FB76AA0344EAC3AF4D92D8C25B03232"
                }
            },
            "6CA184879FBEE24D0D78B8D3DA0FD43E1668": {
                "t": "Another migraine, huh?",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "28B43FD75183B64B483B91B34863361FA8B0"
                }
            },
            "A5B7760731FF7743EE99FD2332C6BE89E5F7": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "30C5FF046743224F6B5AEAD3A0B810F0CEDB"
                }
            },
            "01222F8E19B3E941874B4EB581B3A43E7A66": {
                "t": "No memories this time... Only that ominous voice...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "AE1D43953CED254FA25A01813D079EDC62EA"
                }
            },
            "B6651AED6C9EA74FA158C979EFCA5E327A44": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "47995914566E3444F58AFF31FB76927684CA"
                }
            },
            "696FC7F96F08044C4E5939F4341EF0C24E28": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "C2C82C8B53C3434B4E5ABC67C0D0599E43B2"
                }
            }
        },
        "stringVariables": [
            {
                "name": "Fa's name",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "numberVariables": [
            {
                "name": "nini",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}