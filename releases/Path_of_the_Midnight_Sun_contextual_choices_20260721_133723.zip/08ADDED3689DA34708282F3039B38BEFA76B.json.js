GS.dataCache['08ADDED3689DA34708282F3039B38BEFA76B'] = {
    "uid": "08ADDED3689DA34708282F3039B38BEFA76B",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C8-08d P2 Chic lady",
        "type": "vn.scene",
        "parentId": "FF47CDDE604592431E7A81A35165A3966CB8",
        "chapterUid": "823DFD145789F24D466B6858151B6EA2F9AB",
        "order": 1,
        "localizableStrings": {
            "D0615F5B100CE643101A46E86199D8E76DD8": {
                "t": "Greetings, young lady. Pardon the intrusion, but I heard you already met my companions yesterday.",
                "d": {
                    "cid": 0,
                    "eid": "7ABFC0F59B49A945F588B2D41465BD939ACD"
                }
            },
            "7F09B25E6ABB8840417913E0D9DC21350E4B": {
                "t": "OHOHOH, what a hunk! You really are my type, you know?",
                "d": {
                    "cid": "F96DF25013A4B64C0D297691393A879B2668",
                    "eid": "7B5931785768C1432B38A4B1D95AD71EB496"
                }
            },
            "F0D9514E15F7924DDE29834318A50551AD44": {
                "t": "Why, thanks. You're a fine specimen too.",
                "d": {
                    "eid": "E50C3BC487EBD841224B75E8A6D76D44EE0B"
                }
            },
            "692D759D1706844AD888D37354D84B1CCA1D": {
                "t": "I'm not interested, apologies.",
                "d": {
                    "eid": "DBD366DF729F38419E9AB305182C9407B563"
                }
            },
            "878955EF7F0E15444358B882B734465F968F": {
                "t": "You've got good taste in women, too. I might enjoy spending some time with you.",
                "d": {
                    "cid": "F96DF25013A4B64C0D297691393A879B2668",
                    "eid": "77F5E6A4866BF841277AED23DCB6B29EA725"
                }
            },
            "7D97C454142DB64412284B84F9DCCF11DCB0": {
                "t": "I was actually being sarcastic...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "CEFFE617891755409028A8505334A41D5431"
                }
            },
            "740813C134CA2340FE195DF9D453C22816E8": {
                "t": "Too bad. Such a handsome man, but with no taste at all.",
                "d": {
                    "cid": "F96DF25013A4B64C0D297691393A879B2668",
                    "eid": "D5CE65F650F8144C5F1B5F4456167DE90253"
                }
            },
            "F4970B0A24833348568B4E936011966B5D19": {
                "t": "I get that she has a high opinion of herself...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "6DAA10B91FD1564C8E79C7C0947FCEABF708"
                }
            },
            "712A67C23F69B648336AE8C4F2048A959E15": {
                "t": "Anyway, such a refined gentleman surely wouldn't refuse the request of a beautiful maiden, would he? OHOH!",
                "d": {
                    "cid": "F96DF25013A4B64C0D297691393A879B2668",
                    "eid": "262CA9C7752E93488F9A4A764FD4D53B1129"
                }
            },
            "953A26DD9FA96347D1689748253982D8EFA6": {
                "t": "You surely aren't like THAT DAMNED HUGO-- I mean, my sweet, kind husband.",
                "d": {
                    "cid": "F96DF25013A4B64C0D297691393A879B2668",
                    "eid": "7501DC0A4C35E149A43BA402E7D0D6F82C96"
                }
            },
            "9AEB3744481A4741A40BCD77D47D704C47A0": {
                "t": "What a kind, absolutely-not-crazy maiden.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "3F9F6561305284435649EC426742DA990604"
                }
            },
            "F8D777CE33FAD1457E581F82C04BABE34EDE": {
                "t": "It depends on the request, I suppose...",
                "d": {
                    "cid": 0,
                    "eid": "504307C61D73C24732682E92F8EE968B40E2"
                }
            },
            "95DC3C6173479342252BA943B82820E069ED": {
                "t": "Read here!! OHOHOH!!",
                "d": {
                    "cid": "F96DF25013A4B64C0D297691393A879B2668",
                    "eid": "E82CA4A845A7424C5E08E3B753911FE62302"
                }
            },
            "A386BA683BA0B54EF68A67219CB741F5CC64": {
                "t": "That's a very... straightforward request... and what's with that signature?",
                "d": {
                    "cid": 0,
                    "eid": "4FF951B580C31745A219A8F5559340F4B865"
                }
            },
            "49AF8BA36F45674462495E37DF7215C72BAA": {
                "t": "I know, you can't help but feel mesmerized by my incredible writing!",
                "d": {
                    "cid": "F96DF25013A4B64C0D297691393A879B2668",
                    "eid": "8E56F8057431B145D38B9C73516BB5228436"
                }
            },
            "2BF743703E63F549C768DF17F9F1ECAECDB9": {
                "t": "Pssst... I sense a very threatening aura coming from this lady, Nini!",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "26E2D9F7384C8849A71A33E65EFF9F41B68A"
                }
            },
            "77A1EC956261E54B320807B651BFEA15D394": {
                "t": "Whelp! We better not let her down then. I wouldn't want her to get in our way during our stay in Ferasew.",
                "d": {
                    "cid": 0,
                    "eid": "18AC37AA8AC9C849C2187486BBBECF51EF12"
                }
            },
            "DA4D242E523B384184982CA3FA274A874A70": {
                "t": "I'm expecting great things from you, handsome knight!",
                "d": {
                    "cid": "F96DF25013A4B64C0D297691393A879B2668",
                    "eid": "629A42C08C0C994B75794371E7FC6174FB5A"
                }
            },
            "4DA787474154854FDF49B519D6150CD41ECC": {
                "t": "What do you think you're doing, you fool?",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "8CAAC4A56512B74DBC7B70A1786272173267"
                }
            },
            "A98153797AD8784AD46BC5F0EF736B90FC92": {
                "t": "Nini...?",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "5BAC7870297BA14FDB1A0566B79B1864224C"
                }
            },
            "BFA242E67A260642697B3F0695D6891F2B7B": {
                "t": "\"Bring me 2 bottles of poison.\nOHOHOHOH!!\"\n- your matching star xoxo",
                "d": {
                    "eid": "5EF09E7318F3A74DF13971D42C49DB5B9655"
                }
            },
            "13A5DDC5625C8440E468C3068A67BB7E22DE": {
                "t": "AND DON'T KEEP ME WAITING! OHOHOH!",
                "d": {
                    "cid": "F96DF25013A4B64C0D297691393A879B2668",
                    "eid": "4FB435BD0295484DFF9A9C91AFD670A5CC91"
                }
            }
        },
        "commands": [
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Flag locale 8",
                        "index": 167,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "EBE37F6177EE33442B48D99776CC62F7DE56"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "DD58EC664312A6461A3BC21753EC7205917B",
                        "name": "C8-08d P2 Chich lady (quest completed)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "708FDF87589F0441596BEF3027619A7DDEF5"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of chic",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "E05ED0738E306241FE39044526A58229ED9A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "685CBD223DCE8345E94B960302B7D43550B4"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "read",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F42034B35D13D642917A7BD71206CAC75889"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "A934766645E85046586A16F472AE4F1C25D1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "EDE8FC8968C7A3486089492166A3A4C29A91"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "second time",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "8EA762C8170C234C829980A7C26FFCC935EE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "970840ED1627F44E5099D3457AB38CD6F9A5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D0615F5B100CE643101A46E86199D8E76DD8",
                        "defaultText": "안녕하십니까, 아가씨. 실례를 용서해 주십시오.\n어제 제 동료들과 이미 만나셨다고 들었습니다."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7ABFC0F59B49A945F588B2D41465BD939ACD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9D6E30C191B52549538A997537665AF9DE98"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "39F1E2AE6A55B44224894179AB0078D7B398"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "6792B7583C29E54B5A984FA51140F9A62666"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": null,
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-ChicLadyLazulis_line6.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C049F9FE7644B1437008C9525D08375C4563",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "9EB2339D7320B6445B388351A4228AB6783C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "77D6BDA39E51D542C928001065AADE148C0C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7F09B25E6ABB8840417913E0D9DC21350E4B",
                        "defaultText": "오호호호, 정말 멋진 남자네!\n정말 내 취향인 거 알아?"
                    },
                    "position": 0,
                    "characterId": "F96DF25013A4B64C0D297691393A879B2668",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7B5931785768C1432B38A4B1D95AD71EB496",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "DBB2759305F21145A41A0E362D872DCFE4B5"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "F0D9514E15F7924DDE29834318A50551AD44",
                        "defaultText": "고마워요. 그쪽도 꽤 근사하네요."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E50C3BC487EBD841224B75E8A6D76D44EE0B",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "692D759D1706844AD888D37354D84B1CCA1D",
                        "defaultText": "관심 없습니다. 죄송합니다."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DBD366DF729F38419E9AB305182C9407B563",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "sarcastic flirt",
                            "nope",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "4FA7CD52378CD64C877B64D17D76E80CA8A4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "0626B3687E46A3497A89C243849CAFC86C89"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "sarcastic flirt"
                },
                "indent": 0,
                "uid": "74D196B370B5374C4B3922D8B4EA823CAC58"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "+sarc"
                },
                "indent": 0,
                "uid": "FE7EEF722DC878495F5BA8534A944BC388D9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            8,
                            5,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DAE6C70625FDC144681AE5B1B59969AE12C5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "920F0F80795E844F062B92F0565A89A57398"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A7ABB9A6139F3040064B5190211A8B1A8559"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": null,
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-ChicLadyLazulis_line7.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "02B830403C25A54BE3494B532B492C01063C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "32EA40DC849E2348B4397C186F83EBE373C2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7A78595E7916A148AC3B0330506A3CBB1558"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "878955EF7F0E15444358B882B734465F968F",
                        "defaultText": "여자를 보는 눈도 좋군요.\n당신과 함께 시간을 보내면 즐거울지도 모르겠네요."
                    },
                    "position": 0,
                    "characterId": "F96DF25013A4B64C0D297691393A879B2668",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "77F5E6A4866BF841277AED23DCB6B29EA725",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9BD02C931577244884392B44923ECFA3CF5D"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Ornières x Faratras",
                        "index": 401,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 60,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 3,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5B99E643849A004DC358138329A0EF35A394"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            0,
                            6,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            1,
                            4
                        ]
                    }
                },
                "indent": 1,
                "uid": "8FC87E1066D7634A937A7CB7881039A20C9F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "8B4DA5C07486B74D0368ECB44144AE3CBD10"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            4
                        ]
                    }
                },
                "indent": 1,
                "uid": "F1BEEF1B5E1E3846B64AAB0717F8812B758E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "A8AF0AA28721844E1528BB53F352ED371AB1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4DA787474154854FDF49B519D6150CD41ECC",
                        "defaultText": "뭐 하는 거야, 이 바보야?"
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "8CAAC4A56512B74DBC7B70A1786272173267",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "224330C49468784B0F4929A89BE2A28B403C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "BAE24FB461C06445954B9946973D80D9D668"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 1,
                "uid": "03D2102F11D5B540B23A7783AACEE6CBA98F"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Ornières x Shiori",
                        "index": 400,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "numberValue": 60,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 3,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "95FF649E3F05A643F6585446714A315C6BA4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            0,
                            1,
                            0,
                            6,
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            1,
                            8
                        ]
                    }
                },
                "indent": 1,
                "uid": "6C7B7FF711D6A64676186E8412E2433EAFB5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "7A9FFC572B69A5450769A447443D528A8A13"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            2
                        ]
                    }
                },
                "indent": 1,
                "uid": "6AA34F130165F74D2E4B8AD6A8E18809280B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "D2C0B1BE11FBF9497D1A65F1BA10B6A9A9B6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A98153797AD8784AD46BC5F0EF736B90FC92",
                        "defaultText": "니니...?"
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "5BAC7870297BA14FDB1A0566B79B1864224C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "4B4A7C82746105402B1A9FA1E2BDED3E4DE0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "195EAC10774B004697094913B02D61E8358A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 1,
                "uid": "9199EE0A61CCD2461C2AFEB2B8A1011091BD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DE2E50EE7A9CD44E442A6C48A2D94F98F5BA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7D97C454142DB64412284B84F9DCCF11DCB0",
                        "defaultText": "사실 비꼬는 말이었는데..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CEFFE617891755409028A8505334A41D5431",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after choice",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "B12F75DC321AC340B0492D06312C136DA300"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "nope"
                },
                "indent": 0,
                "uid": "52B8DE195BEF4846D2581858153ABBBAF20C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "3AF1D0471AF569426B693056258544DE42CC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "DFB7C51A4FF5C442AD1A8C73C14317891865"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": null,
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-ChicLadyLazulis_line12_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "11A2B8B79F6CC647413960794D3D69BF05C8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "7BC621995168044D553BD9F93A32D5C9688D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4D7C3A003337E0487C5AB271388973CF5C4C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "740813C134CA2340FE195DF9D453C22816E8",
                        "defaultText": "아쉽네. 이렇게 잘생긴 남자가 취향은 형편없다니."
                    },
                    "position": 0,
                    "characterId": "F96DF25013A4B64C0D297691393A879B2668",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D5CE65F650F8144C5F1B5F4456167DE90253",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6E743B7D1E55C0455C2BE07591BE54AD7748"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F1639AB43DB968450E296BA07BF192739836"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F4970B0A24833348568B4E936011966B5D19",
                        "defaultText": "자신을 굉장히 높이 평가한다는 건 알겠네..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6DAA10B91FD1564C8E79C7C0947FCEABF708",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D7AC36688128D640A66B30818FD7CB7E7314"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after choice"
                },
                "indent": 0,
                "uid": "F1C168EB2032014BE47A3BB4CAE8C2EBA0E3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "039A48336842B24D4469D2E91A191D1C2A53"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "646EE4E076094242263BAE89819BD462A1D7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "712A67C23F69B648336AE8C4F2048A959E15",
                        "defaultText": "아무튼 이렇게 세련된 신사라면\n아름다운 아가씨의 부탁을 거절하지 않겠죠? 오호호!"
                    },
                    "position": 0,
                    "characterId": "F96DF25013A4B64C0D297691393A879B2668",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "262CA9C7752E93488F9A4A764FD4D53B1129",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "390AD8D786CCE049F24A1F835675879FC744"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "E1354933026B184FB478DE61B0A1DDA0397B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "953A26DD9FA96347D1689748253982D8EFA6",
                        "defaultText": "설마 그 망할 후고처럼 굴지는 않겠지--\n그러니까, 내 다정하고 착한 남편 말이에요."
                    },
                    "position": 0,
                    "characterId": "F96DF25013A4B64C0D297691393A879B2668",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7501DC0A4C35E149A43BA402E7D0D6F82C96",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C32B5C19371A4749E3985B05E3D850EC8B13"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "93B666733FF2714F1F2A30B4519DD4ED8C68"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9AEB3744481A4741A40BCD77D47D704C47A0",
                        "defaultText": "정말 친절하고, 전혀 미치지 않은 아가씨로군."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3F9F6561305284435649EC426742DA990604",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "25A425737FADF2448F98DA14573AEEC481C2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "02B4299637C8024E839B90F39AA973F34E93"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F8D777CE33FAD1457E581F82C04BABE34EDE",
                        "defaultText": "부탁이 무엇인지에 따라 다르겠지요..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "504307C61D73C24732682E92F8EE968B40E2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BD267A30715660480B2B64E51A60D5DAA101"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C495D58A6AD9D4412898DBB2904456EC4947"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "93FDC29C0C273742F56AA0B15FBCC5267D2B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "95DC3C6173479342252BA943B82820E069ED",
                        "defaultText": "여기 읽어 봐요!! 오호호호!!"
                    },
                    "position": 0,
                    "characterId": "F96DF25013A4B64C0D297691393A879B2668",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E82CA4A845A7424C5E08E3B753911FE62302",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "37A58F883C640840CF4B08A63D5F4291F831"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BF03C6677F89D244502800481837877C6224"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "155959F51F7D464F357A7B945C731B1137CB"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo Multiuso 1",
                        "index": 1,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "BFA242E67A260642697B3F0695D6891F2B7B",
                        "defaultText": "\"독 2병을 가져오세요. 오오오오오!!\"- 당신과 어울리는 스타 xoxo"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5EF09E7318F3A74DF13971D42C49DB5B9655",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EA3235C38988B64A6019D6B33077DC66B0C0",
                    "parameters": {
                        "values": [
                            3,
                            "I LOVE YOU",
                            {
                                "name": "Testo Multiuso 1",
                                "index": 1,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            5000,
                            9000,
                            "3B0CC1DC3A5686405B19B414D254FE0FB1D1"
                        ]
                    }
                },
                "indent": 0,
                "uid": "CEBACAD86E4B1449A72B7034B8C4B0CF2EBB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0C219E9C37417042B158B2D8826E7BA5D6FF",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "8ACB2F696B70974B885A7ED3C8326F147D8D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "1C324D004043274C02190F29CE2AD2EC3641"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EF22C5317868C44A3E882D28A90E6006B800"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A2437605278FB44F412B315556DD290E4488"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A386BA683BA0B54EF68A67219CB741F5CC64",
                        "defaultText": "정말... 직설적인 의뢰로군요...\n그런데 이 서명은 뭡니까?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4FF951B580C31745A219A8F5559340F4B865",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A0C228C81A53E945BC392034A59DD45B53CB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "407897E38D9EF84C543BADF4CC0A2420E44C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "49B81A724675C4498A7800A7A698928A575B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CC75FB1D694AB8464C4BAF25802C3061B8F8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "49AF8BA36F45674462495E37DF7215C72BAA",
                        "defaultText": "알아요. 내 놀라운 필체에\n넋을 잃고 빠져들 수밖에 없겠죠!"
                    },
                    "position": 0,
                    "characterId": "F96DF25013A4B64C0D297691393A879B2668",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8E56F8057431B145D38B9C73516BB5228436",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0320263014A02048EF882F8746BEEEA82E26"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AA93DBA44D6F874A4A1B6E217CD51A69D912"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "A02946A56940754C793912C1F3F411727185"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8D9E51B07BD4D64C261AB8F62163A7A44816"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2BF743703E63F549C768DF17F9F1ECAECDB9",
                        "defaultText": "쉿... 이 여자에게서 아주 위협적인 기운이 느껴져, 니니!"
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "26E2D9F7384C8849A71A33E65EFF9F41B68A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7ECA31E8039D2348FC8BE3F788CB9A1B41FA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4CE9E9618C5CC843115A7326C303BD47D4CC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "77A1EC956261E54B320807B651BFEA15D394",
                        "defaultText": "이런! 그럼 실망시키지 않는 게 좋겠어.\n페라세우에 머무는 동안 방해받고 싶지는 않으니까."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "18AC37AA8AC9C849C2187486BBBECF51EF12",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4DA514DD7B50D745B54AF7D54BDFC5E83508"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "second time"
                },
                "indent": 0,
                "uid": "0662A56A34A7574C9C39D2E14B1CD72D058E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7388BDE76F3333411E684BA67A9BCF837E62"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DA4D242E523B384184982CA3FA274A874A70",
                        "defaultText": "기대하고 있을게요, 잘생긴 기사님!"
                    },
                    "position": 0,
                    "characterId": "F96DF25013A4B64C0D297691393A879B2668",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "629A42C08C0C994B75794371E7FC6174FB5A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "956F13B0221AB04D1D088622C9C9CCDC0CB2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "3BA849DA3D8871460088D5B3061CD0AEA174"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E9BACE26777DB84EA86B06416096457F2A9C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": null,
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-ChicLadyLazulis_line9_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EBB96FBD58B5184D527914F8DE6700349035",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F402B0C76A60C7486368C7F51962569AB22A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D5AB3F8D3C01544C2228BBD7A34A3F0D73F7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "13A5DDC5625C8440E468C3068A67BB7E22DE",
                        "defaultText": "그리고 기다리게 하지 말아요! 오호호호!"
                    },
                    "position": 0,
                    "characterId": "F96DF25013A4B64C0D297691393A879B2668",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4FB435BD0295484DFF9A9C91AFD670A5CC91",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "A43ED6CB5DF6B04B035837E6BCE912154A63"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F3DFA7867E69A548244B86415DBE7ABBDF27"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "read",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1873B8CF1A37F44AA23A6F48A425CC559823"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "end of chic"
                },
                "indent": 0,
                "uid": "1E1B7D8C329B374BAC4BF1752FFF5E5193FC"
            }
        ],
        "livePreviewDisabled": true,
        "stringVariables": [
            {
                "name": "quest",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "read",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}