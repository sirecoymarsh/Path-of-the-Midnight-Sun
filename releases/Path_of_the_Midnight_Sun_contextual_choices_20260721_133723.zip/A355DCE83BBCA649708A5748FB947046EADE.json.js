GS.dataCache['A355DCE83BBCA649708A5748FB947046EADE'] = {
    "uid": "A355DCE83BBCA649708A5748FB947046EADE",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C5-01c Post Manacrest tutorial",
        "type": "vn.scene",
        "parentId": "555C26067448B148177A8258764AD85D121F",
        "chapterUid": "27B6E8FB2921364C12682182E915B49DA958",
        "order": 2,
        "localizableStrings": {
            "86E1E7AE59F8F142500877F372E08E84A243": {
                "t": "What was that just now?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "BE854BE29495664B296A05D7917CB6FCD3F5"
                }
            },
            "C851ACC91166D64ED23B765476D39B53B1DA": {
                "t": "Usually, when I finish fighting, my Mana gets dispersed. Shiori said it's the 'nature of Mana' to leave your body after situations of peril.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "305B4EF27F199643B45A0DF11EB0F591FFE8"
                }
            },
            "CEDEF6838FA8114B1869F5B605FD0B9DFA64": {
                "t": "But this time...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "57BBBD307B153643DA5ADC143EB551BA4840"
                }
            },
            "B87DC153368BB34B69581BD24B4698D0A460": {
                "t": "Our Mana's been {SP:2}{C:1}stored inside the Manacrest{C:0}, instead of disappearing.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "3301B5D551822648846A6A081AB831922299"
                }
            },
            "0D10F2558F784147021A6D48AE7A811590B9": {
                "t": "Well, this changes everything.",
                "d": {
                    "eid": "98FCD92C4FB5C449B53AA419B1BE0E1CEC82"
                }
            },
            "63DF99DB5ACA6743032A5099989D72B155D4": {
                "t": "It should've been called Manabank.",
                "d": {
                    "eid": "5F0E598F0B1C534710985A6849C1301DF2C2"
                }
            },
            "70BB244332E58740DE2BBD96609FD4B7C2D4": {
                "t": "Indeed. The whole foundation of our world is the ephemeral nature of Mana.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "F3206E7C760DF1490A28B9F558AE7C053463"
                }
            },
            "AE07D9604BE2C2449819BE84D7C0C8FE064D": {
                "t": "Be serious for a while, and listen to me. This is important.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "0AE215D3722DD2444F8BC94403D8F22BD97E"
                }
            },
            "C238145844C9724EBC88CDD28B20E9543EB1": {
                "t": "If you could use magic at any time, rather than just in battle... could you imagine the possibilities?",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "311F8A0D780693434A6B7811B74304D12F77"
                }
            },
            "E0D7BB1119C58741DD2BD4B3F30998E38341": {
                "t": "We could treat people's injuries at any time....",
                "d": {
                    "cid": 0,
                    "eid": "92FC0DE92FD8A14B6B794503672B9BEBDED2"
                }
            },
            "C87E65364DD66541D84A73B11F50D0EF426D": {
                "t": "Yes, and much more.\nBy the way, did you notice it absorbed my Mana as well?",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "FBD4BD89488A744CE2399BB139C5AAC026FE"
                }
            },
            "5134EB8A77C0424D5889DE82011713F059D2": {
                "t": "It's true... it seems like Rya's energy is in here now, too.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "AC21AD527D99874E18197E177C15DEC019F0"
                }
            },
            "2D094F3F67BA0741BA09C508F8CA1B358D7F": {
                "t": "Too bad that I can't remember any spells.",
                "d": {
                    "cid": 0,
                    "eid": "C98905656C9F794D5F6A56072F6ECCB7B4E8"
                }
            },
            "AE07B5736C51D849C12A2FF97B5E2A9C85C3": {
                "t": "Too bad indeed. Especially because it seems you're the only one compatible with that Manacrest.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "A6CB0EEB7D67C84273393D135D60A73765E1"
                }
            },
            "5D7D88F804AA17469888CEB107E87CD19910": {
                "t": "All that Mana, and it cannot be used. Ironic.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "8D4EC30B01DB874379881643554B7AB2BA0C"
                }
            },
            "5495AA19392CA243F928563401608A77DEAC": {
                "t": "Well, let's keep storing more and more Mana in here. Who knows, I might remember something in the meantime!",
                "d": {
                    "cid": 0,
                    "eid": "B53CBF8E7F3D024FA87906D46D60A5E9B7A3"
                }
            },
            "260159843D13D14D6B69E1B58973C595ABE4": {
                "t": "Agreed.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "9F9902BC52ABD14B7C2AFF1346B78BDC7665"
                }
            },
            "8A66BC8421CEF1408688A723B5A33911C83C": {
                "t": "With that being said... let's return to the encampment. Our little experiment was a success.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "A2E91C99143580474E4BD5C18E529F5D761A"
                }
            },
            "EFF78469256C0844D8392A86BB3FE57DE96A": {
                "t": "Sure thing--",
                "d": {
                    "cid": 0,
                    "eid": "FF28ADA8571EE049573A3578BB82E3730427"
                }
            },
            "2366FA84207519469988363180F7BA4B8978": {
                "t": "No wasted words or movement, always in a rush... She's just the epitome of efficiency.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "5EAAE5DB887B9041092AF7C2B0E51944BA08"
                }
            },
            "F9B3EA18832C3146E8683E68651366F1FC68": {
                "t": "Rodrigue",
                "d": {
                    "eid": "95E5386435B2B544562B54C6982B68A9FF89"
                }
            },
            "1DB90A7242A7C844C019F813E9BC6A07A0CE": {
                "t": "Pietro",
                "d": {
                    "eid": "9913531D53AC734A868BAE83E74C0D89B72F"
                }
            },
            "82467D8F49E719437F19081594384184D967": {
                "t": "Yes, there's no doubt about it.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "762D5BFD21CD624E6F4A124735C28F73026A"
                }
            },
            "437D4DF82AE8A448981A3F158CF1AC44803F": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "F6E1AA46204BC6424B5831A6670C523C056E"
                }
            },
            "A48FA8F340FA434F9079AD84826E93AB6437": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "277DCA8F410F6044896B1F60A85E79339B6B"
                }
            },
            "D7A155E277083444CB3981488545D4492A64": {
                "t": "Hey, Rya! Wait for me!",
                "d": {
                    "cid": 0,
                    "eid": "252FA00A6F3E924DE22A98F74444EA3093D4"
                }
            }
        },
        "commands": [
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            20,
                            1,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "1A40C9511178974F2F7BF2630C5D35415ECA"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "0C5993BC79C1D442FA7AF8D99C91F0866F13"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A81A04CA618804412A8A51E1D0B221245888"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "E1CA2893771F814DE9790B607D72EE360FEC"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "7285F1B9214BF643D3982457FE50A883F047",
                        "name": "Music - Forest day"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 7,
                "uid": "A73A0743252A724F088A26B971DA103E79DA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "9B60A3CF3630E44D8158477328729312F194",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7A0336EC7655F64FFB583976172503A128AC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF3CB6A82BA3F543FE7A3C88D43FBE81ABE4",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3EA8C8B61DD8A8470C6988A52BFFD6057218"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "9EDA648F2CD68948927BDA65DA7F9CA9F71A"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 54,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "0B2738BA29CA144A872A05071AE866CB9497"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "9B45618F45B05540B41808D560A6091C7CF5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "9CC23B982A28F742804BCDB739E6DAB6590B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B96896CC3D12E747FC0994188CF8709302B6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8E13903C6911644A1E5A6458844C73FE0D78"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "86E1E7AE59F8F142500877F372E08E84A243",
                        "defaultText": "방금 그건 뭐였지?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "BE854BE29495664B296A05D7917CB6FCD3F5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "83EA4F31148AE94E0D89710052382B95D983"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C851ACC91166D64ED23B765476D39B53B1DA",
                        "defaultText": "보통 전투가 끝나면 내 마나는 흩어져.\n시오리는 위험이 지나면 몸을 떠나는 게 ‘마나의 본성’이라고 했어."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "305B4EF27F199643B45A0DF11EB0F591FFE8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E0AC5C8B4FD029433C3875F5442A43D17C09"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CEDEF6838FA8114B1869F5B605FD0B9DFA64",
                        "defaultText": "하지만 이번에는..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "57BBBD307B153643DA5ADC143EB551BA4840",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "4320ECAD7219C44F6D6A1451C6B09EE125CE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "98B92070405BB64FB098E105B8E7FD55C3A9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "793A54B47E075242AC297991C2D390C49937"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 45
                },
                "indent": 0,
                "uid": "0B6AC3F32D223946236A1E34BB6056194FE8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D7C7F3438586724F858B044271FE73C04142"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "823DA012331B384C64298CD5B9DA44F8E29C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "82467D8F49E719437F19081594384184D967",
                        "defaultText": "그래, 틀림없어."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "762D5BFD21CD624E6F4A124735C28F73026A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CF7278B46E4C614C2E68E313BF3DFA6D54EE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "EFF7C0F1645CF849AA2B1B4142A42C29178C"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B27CCE2E1E7B22488E6B6C79233BBAA8B5E8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B3BCAC950A91A148FB1B6D7681842F512F1D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            5,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EF447037824538431A7B9241690175C75F2D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "D7D6BF09356CD242CC5B674331DE118E301A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "437D4DF82AE8A448981A3F158CF1AC44803F",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Rya",
                        "name": "E3-Rya_line6.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F6E1AA46204BC6424B5831A6670C523C056E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "08210B5A4B64C44C0D88B1777DB26005C70F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "56A27CCB27EEF5447D5BAF6508587C5BB731"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B87DC153368BB34B69581BD24B4698D0A460",
                        "defaultText": "우리 마나는 사라지지 않고\n{SP:2}{C:1}마나크레스트 안에 저장됐어{C:0}."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3301B5D551822648846A6A081AB831922299",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "F1A08DF753EBD3432C4A7D448D80990F668D"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "0D10F2558F784147021A6D48AE7A811590B9",
                        "defaultText": "이거라면 모든 게 달라지겠어."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "98FCD92C4FB5C449B53AA419B1BE0E1CEC82",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "63DF99DB5ACA6743032A5099989D72B155D4",
                        "defaultText": "마나은행이라고 부르지 그랬어."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5F0E598F0B1C534710985A6849C1301DF2C2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "changes",
                            "manabank",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "1278DAE28B3EA54F4369ECA8358A6137D8F2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C7B8707509B6604F743B2F35F1F83659CAD7"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "changes"
                },
                "indent": 0,
                "uid": "8AC898AD6BDBB442D788D14926948109B890"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "- sarcasm"
                },
                "indent": 0,
                "uid": "C61D4784802655432F18C6E9550F65B0F6D0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            1,
                            8,
                            3,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "566F04B03391B446285950A58CF271383CE2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0389899C3D27394B3B78D2F5C86126943F49"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "417F5AFC02F7634B8E5BE81234B485C9472B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "70BB244332E58740DE2BBD96609FD4B7C2D4",
                        "defaultText": "그래. 우리 세계의 근간은 마나가 덧없이 사라진다는 성질이야."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F3206E7C760DF1490A28B9F558AE7C053463",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of choice",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "B8F7D1522C506843F24ADFB4AC45F96D8109"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "manabank"
                },
                "indent": 0,
                "uid": "ADE7811563B22343E48A46E8315E74C81ED3"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "+ sarcasm"
                },
                "indent": 0,
                "uid": "CB2544766013084DAA8A65825F6004B15932",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            8,
                            5,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C33B5B3340E3684E2C5802C5CA1F6FF4F804"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            5,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7B38EAFE4D47394C3E0A76337C5346A46D4E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "998C93065CEEB343D52B50A6C80B8DD37764"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AE07D9604BE2C2449819BE84D7C0C8FE064D",
                        "defaultText": "잠깐이라도 진지하게 내 말을 들어. 중요한 얘기야."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0AE215D3722DD2444F8BC94403D8F22BD97E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "88645F443E684448B32BCC088AE9E1BAC32A"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "end of choice"
                },
                "indent": 0,
                "uid": "E523B3677184914B47797BF7519060FFA678"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CBF2CDBA211892476A6B1D12FDE64AE1EFE2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A8EAEB2014B13540590B6601DBBBB225747A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "577251B46F4F464683886666986D6E0DF65E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C238145844C9724EBC88CDD28B20E9543EB1",
                        "defaultText": "전투 중이 아니어도 언제든 마법을 쓸 수 있다면...\n그 가능성이 얼마나 클지 상상해 봐."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "311F8A0D780693434A6B7811B74304D12F77",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "F0B8999A30077441F45A1B292A0647DFC1B4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0CC3126029D5B24E004B5532C29A4D6C00BC"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "FC4E81587B20B2483D3BB762E6387E0F61BA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B83CFF621197A3453C2ACD80C648B42D81AE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D14BC1C21019514FB18BE8E6948EFDEC955A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E0D7BB1119C58741DD2BD4B3F30998E38341",
                        "defaultText": "언제든 사람들의 부상을 치료할 수 있겠네..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "92FC0DE92FD8A14B6B794503672B9BEBDED2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "84CA9AC390CE714BE85B3E07CEFCE593DC23"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "848D001A927B54423209F33566C9F70DA591"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C87E65364DD66541D84A73B11F50D0EF426D",
                        "defaultText": "그래, 그 밖에도 훨씬 많지.\n그런데 내 마나까지 흡수한 거 알아챘어?"
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FBD4BD89488A744CE2399BB139C5AAC026FE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7384A7DD4369F34A214B4028C8CBC7E9EC53"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D57C53A74C25A1451148DF375F821BA0F661"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5134EB8A77C0424D5889DE82011713F059D2",
                        "defaultText": "정말이네... 이제 이 안에 리아의 기운도 느껴지는 것 같아."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AC21AD527D99874E18197E177C15DEC019F0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "A9D40D672F3D224E8F692504F1BE903556E4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "58A2089530B122464D88F8995B1F370571C9"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 27
                },
                "indent": 0,
                "uid": "0077FC995834C849069BEE35A220F97B53DA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "96E8865C46A6744AF298785563F5D69BB4F3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "142C21E4027AB0403D1B35C6238061483B8D"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "C58FAD2E15F1624ADA68FD30270846D96089",
                        "name": "Manacrest tutorial prompt"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5AEE9BCA21DF034CCA6909C62015F0023023"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A1EAD5135E53B84AB688212328A4B1F45C4A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 27
                },
                "indent": 0,
                "uid": "BCE728641F68D8433A4B3455E6C7473A1FDE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A7684BA92EB73440868977A42B647FFA3CDD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "97B8DB349DBD6143047B2C94F7FE006221FA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2D094F3F67BA0741BA09C508F8CA1B358D7F",
                        "defaultText": "어떤 주문도 기억나지 않는 게 아쉽네."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C98905656C9F794D5F6A56072F6ECCB7B4E8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9578C639487E344F125B5BA7BA3D3A62AE1A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "93FEB2133ED5674DED18713784B5D7FD6E2F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5FFB1C409592784D189976E03F614E1C2BA7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AE07B5736C51D849C12A2FF97B5E2A9C85C3",
                        "defaultText": "정말 아쉽지. 특히 이 마나크레스트와 호환되는 사람이\n너뿐인 것 같으니까."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A6CB0EEB7D67C84273393D135D60A73765E1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5516339830F6D2424D8819186CF37DFF50E3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5D7D88F804AA17469888CEB107E87CD19910",
                        "defaultText": "그 많은 마나를 쓸 수 없다니. 아이러니하네."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8D4EC30B01DB874379881643554B7AB2BA0C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "75BFBC22318EF7464F2BDD547AF161718BD2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "148D73BF3046234CD63B64568AD21114D30C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A48FA8F340FA434F9079AD84826E93AB6437",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E3-Ornieres_line23_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "277DCA8F410F6044896B1F60A85E79339B6B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "6136D9E66F2F8349FB79F5461F12CEBB580E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0B8E559B723B584F9C5A6AB0B713B14001FF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5495AA19392CA243F928563401608A77DEAC",
                        "defaultText": "그럼 여기에 마나를 계속 쌓아 두자.\n그러다 뭔가 기억날지도 모르잖아!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B53CBF8E7F3D024FA87906D46D60A5E9B7A3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "66761C0D4BAE494B7368F7A304DF5060C149"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "964EB3AE17B735488A089EB47553E8C574BC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5D221DEC3F2A4643E949D5A254112B2F9CB0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "260159843D13D14D6B69E1B58973C595ABE4",
                        "defaultText": "동의해."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9F9902BC52ABD14B7C2AFF1346B78BDC7665",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EA89005D4A53A942611AA7D3642A1439BF39"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8A66BC8421CEF1408688A723B5A33911C83C",
                        "defaultText": "그럼... 야영지로 돌아가자. 작은 실험은 성공했으니까."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A2E91C99143580474E4BD5C18E529F5D761A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D33F01385A3EB0496E9A5EF8E30455C25270"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BB1A48C333C1F746073929077159A0051C79"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EFF78469256C0844D8392A86BB3FE57DE96A",
                        "defaultText": "좋아--"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FF28ADA8571EE049573A3578BB82E3730427",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "40972AE530A157444C99186786BC980B881D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "C6342A0895B04346520BD69627A44AD092D3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8F16F74762D84642D31904D5451C71272277"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "BDCCA1724724D549B0799EC0CDC8A71A931B"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "3B11637683ADD5454689CDF7F6181C0407F7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "75BDEF3A7F7BD747F629D4A1F982ED318382"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "16C3686687681344D638F445E3B7ACA48F37"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D7A155E277083444CB3981488545D4492A64",
                        "defaultText": "리아! 기다려!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "252FA00A6F3E924DE22A98F74444EA3093D4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "34CE45077789F244EC8898C2D2FCE1FD571B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "13F2412859D5D748407BCE15D235BB38C59B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2366FA84207519469988363180F7BA4B8978",
                        "defaultText": "쓸데없는 말도 움직임도 없이 늘 바쁘네...\n효율 그 자체야."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5EAAE5DB887B9041092AF7C2B0E51944BA08",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "49E38225751F7146081A6A58EE6F085C595C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5F4EC25B6413B34FF92A1279C9A54046C189"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "92C8A7271BDE7246CD7A3E44885A847CCB4B",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9DBE1CCF392454494A2A69141864C14727F5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "4B8E9FF0167D914046390F75687D84636674",
                    "parameters": {
                        "values": [
                            5,
                            1400,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "A035DDBC76E00341BC8BAE941C03C005CE6A"
            },
            {
                "id": "gs.FreezeScreen",
                "params": {},
                "indent": 0,
                "uid": "1E3ED85978247044614ACD26848E5C3FC95D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 2.4
                },
                "indent": 0,
                "uid": "0A4D2B1C4254C64EBC4AFE25F4D84B78783F"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Rodrigue's name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "F9B3EA18832C3146E8683E68651366F1FC68",
                        "defaultText": "로드리그"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "95E5386435B2B544562B54C6982B68A9FF89",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "9B7379F6740A984CA12860D34E8DA1457AFE",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Blacksmith"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Rodrigue's name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "586270F713EDD344CC184C95CA515E98F7B8"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Pietro's name",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "1DB90A7242A7C844C019F813E9BC6A07A0CE",
                        "defaultText": "피에트로"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9913531D53AC734A868BAE83E74C0D89B72F",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "3D54C18956C7454847398E01C4535C66BABA",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Blacksmith"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Pietro's name",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "57B3ECC574482244F448F7F6A1756C37C1B3"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "Numero Identificativo Suono",
                        "index": 159,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 0,
                    "source": 0,
                    "sourceValue": 0,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "08A0485A52CE464A234B3658FDD3A987F657"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "Tempo d'attesa",
                        "index": 32,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 0,
                    "source": 0,
                    "sourceValue": 45,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D3330A526120C7402E2AD887196A405F65DE"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Spend time (during travel?)",
                        "index": 96,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "ECA4220F32B0424FEA4A50E0CBB7D54303B7"
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "BBA9AB897A85D344FD782BD01FE902FC14EF",
                        "name": "C5-02 Encampment (Exploration)"
                    },
                    "savePrevious": 0,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8FA6C28D4707D440C598C04773DD164B8A89",
                "expanded": false
            }
        ],
        "livePreviewDisabled": true,
        "stringVariables": [
            {
                "name": "Rodrigue's name",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "Pietro's name",
                "index": 1,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}