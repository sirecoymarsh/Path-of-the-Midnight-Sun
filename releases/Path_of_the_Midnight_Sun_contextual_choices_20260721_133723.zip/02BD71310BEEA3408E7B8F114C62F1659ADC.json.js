GS.dataCache['02BD71310BEEA3408E7B8F114C62F1659ADC'] = {
    "uid": "02BD71310BEEA3408E7B8F114C62F1659ADC",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C8-03c P1 Chic lady",
        "type": "vn.scene",
        "parentId": "9194FBA83E8C9447D14A2BE899DC6EFF9641",
        "chapterUid": "823DFD145789F24D466B6858151B6EA2F9AB",
        "order": 0,
        "livePreviewDisabled": true,
        "commands": [
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6D7D42F3445266442B6B2C33E741087B6FEE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4D28A83F5D26B544F10A2266B9BF692B70FA"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Flag locale 8",
                        "index": 167,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C82EFCE77D48034B1139CE15431DC322B16B"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "second time",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "3E8CEAF519F4E2468E083520EC94F7A1DF1C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "DD17E2265E8217416E6BA80980352043B1CB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9C255A4E32F7334C1F4BE307CE0E3A07758C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CFC9C75D49E90240B40AF5E288FFD1064DE7",
                        "defaultText": "오호호호호! 당신인가요?"
                    },
                    "position": 0,
                    "characterId": "F96DF25013A4B64C0D297691393A879B2668",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "E1410F9C2DA6154B757A40D35F4319A6F9D8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3C0A1633121A3641206AC0086465D49A502F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0943FB8415BBA447C539CF36FDCF13A56583"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7003D6206F4670442E5BE7077D8EBE24EDF7",
                        "defaultText": "내가... 뭐라고?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FAAFFD0237D7F545761B6954963B68CEA5F0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8B231E3B39AE1946A46A2D25E9AE139FE883"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "389CBC7B32662445265A84C5A509329BC6B6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": null,
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-ChicLadyLazulis_line2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "952EF98D389BD3476358F0325029096E904E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "BDECF14353437349144B5C505AEDA65D292A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9F0ED57C3BA7654A5F79FF64476CBEB0196C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1AA9990C0DBD22462328D7B81BF43F714FEF",
                        "defaultText": "내 결혼 생활을 구해 줄 사람이 당신인가요?"
                    },
                    "position": 0,
                    "characterId": "F96DF25013A4B64C0D297691393A879B2668",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5E32E4090B204441F6782637FAC7344DD9C9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "1E53AEE93199654A1E7B79A707ACC18DF352"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "581692654E1E6142C4790D964AFB4A869676",
                        "defaultText": "더 중요한 일이 있어."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6F147A113970E64AFF28EAB52706708428BF",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "A047882845C1264506790C030269AAA8C7F5",
                        "defaultText": "그 결혼은 이미 가망이 없어."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BD7887B859FE0442D0498A983011AE643CE5",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "7AC7E5201CBE4648F22B8D03A877142E8B4D",
                        "defaultText": "혹시... 괜찮으신가요?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "091CB3A33D2FA84A1088D7D596E0B44FF7B6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "better",
                            "cruel",
                            "kind",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "8BF1C2029753B54A755961922AB8CA61C15D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "3304BC0E621E904F145B8701A27D4BF9B1C6"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "cruel"
                },
                "indent": 0,
                "uid": "40BF87E64B0F9640492B4E894145F4285C7C"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "+ cruelty"
                },
                "indent": 0,
                "uid": "F2FAE2834D5BF74209199911DB163D5D73B4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            8,
                            3,
                            "",
                            "",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E68BE8C934705348EA59D482834DB317C77E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0,
                            3,
                            "45918E0E12BBF148635A9360998958409EFE",
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "38FACE8D657CE8418A38AC13DCC2FE35DDB7"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "better",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "BA9AE23073BA914EA2994BE6D6C361DA7FEB"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "kind"
                },
                "indent": 0,
                "uid": "7868EDF86AE8C64B125893A51F71B5D4DDFE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            8,
                            3,
                            "",
                            "",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F886791072D17748BB4BCA0596D5F3C4F917"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "- cruelty"
                },
                "indent": 0,
                "uid": "683797F131DEB043DB089172638039607A84",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "better"
                },
                "indent": 0,
                "uid": "3EAD11EB3174D648856A2BF736C7C394DC60"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "E0A5FFBC5B52E249181A1216DA74A1C9D0BC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "108D0C3F2F35A14E46593FB6DAD0B6DCB7CD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": null,
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-ChicLadyLazulis_line3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4148F6D66F47B448FD3B9D7980B795809300",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C54B06275EFE2248126A47061C27C8AB43D1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "086D7FB96B5DC8485A2B9954D35FD67BBCEE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E2CBAAED40B1884A519AE5880AA8286F5787",
                        "defaultText": "아니, 아니, 아니에요! 틀린 답이군요.\n당신은 내가 꿈꾸던 사람이 아니에요."
                    },
                    "position": 0,
                    "characterId": "F96DF25013A4B64C0D297691393A879B2668",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0F178415657FC140524B62838864BA68E0F3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "95E2E70C5366094A9F79D686C39DF26516FB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EB75A00B2D8AE745AC1A6F25C1F47AC8A565"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DB30205644584743865A8CA4CC8477E9C3B9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9FF6A02C82BEA843E17B6A172AB4CBB966B4",
                        "defaultText": "그건 모르겠지만 남의 시간을 계속 무시하면\n우리가 당신의 생생한 악몽이 될 거야."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5D348AFA174E964BA518BBA137A84B2CE421",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "944866F3779639465A48F2E53ECE39643888"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4080406A6EB3E244D01A7587B0C9D7BB30F2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0142C58644665745A4598311560FAA634730",
                        "defaultText": "잘 말했어, 리아! 잠입 중이라 실제로 그러지는 못하겠지만...\n옛 버릇은 버리기 어렵군."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "03759A5C597AF3435A68D5B10925A19F0E9B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "99B89F7A22876847085BC53639AC63193615"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D9E4C58A6487E44C53196E6215B23EE6B3FE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "90772CA7791202425F6BBDA6DD852A74A7CF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8C1631F41ACD71432088C172CF06FAA359DC",
                        "defaultText": "생생한 악몽이라... 웃겨요! 정말 웃기는군요!\n오호호호! 난 이미 악몽 속에 살고 있어요!"
                    },
                    "position": 0,
                    "characterId": "F96DF25013A4B64C0D297691393A879B2668",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D11299D1213A21412E09D1557BAD33E2F363",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "22F0D55E5BB8D841357B70E6135006504666"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D50F5A3464FA22474539D2F497DF54BACDB0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3D537284405DC746734B67B03449977ADE01",
                        "defaultText": "그... 개. 그 터무니없고 음탕한 짐승."
                    },
                    "position": 0,
                    "characterId": "F96DF25013A4B64C0D297691393A879B2668",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9C308AB61D336543518912B80110DB1F41F2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "8D212D24017F2546DA28EF2196F92ADF0EB6"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "5F4C59782AB5F345FE8ABD428F33E84DAB17",
                        "defaultText": "반려동물에게 무슨 문제라도 있나요?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7C5F13DB2C14B8425008BA42EB6D66638CCA",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "C5D10A0F222B044386191BE1CE6D53662DB5",
                        "defaultText": "동물도 존중받을 자격이 있어요."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "28FB34C68A25084EFE992D96B645400F21E6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "fake choice",
                            "fake choice",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "AE904A4E614E304D8349C7133042BE165D61"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "6BB63A9579DC384D9B4B6FB2294C324FE227"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "fake choice"
                },
                "indent": 0,
                "uid": "018FC568902646468D9BB9D998AA6FA24F49"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0811F3DC6C21B143C39AE3383D883AAAD356"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7639BC2E7B0F324644987D14E4B16120BC5D",
                        "defaultText": "진짜 동물을 말하는 게 아니에요!"
                    },
                    "position": 0,
                    "characterId": "F96DF25013A4B64C0D297691393A879B2668",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DE6CA2DF2C0D2549318BF6482DF2D4F75DDB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9929E509759243489109F974D417E61C4AF5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "10D6EA4D3AE2D646B358B250201BAAD83EFD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "09DDA9A50540474B830A531509F41604137C",
                        "defaultText": "내 남편 말이에요! 그 끔찍한 짐승!"
                    },
                    "position": 0,
                    "characterId": "F96DF25013A4B64C0D297691393A879B2668",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "09B9E84E33ED334DAD6BC453157D3F5241CF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "06B8D1A3470012448B2B2763EF719C28A4B4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "8EB9507C852FC74A5B1955599D8D12DD9C5F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": null,
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-ChicLadyLazulis_line5.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8306E92D26D7B3484B1A65312CB5E15F100E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E667942117E43543E67B6563F1BC14B591D0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8E20DB0403DE684D4369A21824AA228DA178"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3B9607F2642A354962591B926C5F69CF20C6",
                        "defaultText": "내 말 들려요, 후고!? 당장 집으로 와요!\n이번만은 그 쓸모없는 일도 잊어버려요!"
                    },
                    "position": 0,
                    "characterId": "F96DF25013A4B64C0D297691393A879B2668",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0E90F767107C194DA929F9E2854A26CE064B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6290FF604C105744094B3D8541305359D790"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "971DB62C22A481422539FE18BEA6FAEA45FE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2ADC8B4249425244734BA5F1AF5A847E7E2D",
                        "defaultText": "대체 여기서 무슨 일이 벌어지는 거지?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3C9230A04E58454CA0680474C39BD7410309",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "10A034448E5C9246465B4754EBD82ECE4F89"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "1CF40F8C935699451C3986F6695C62826B71"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9FD2F502535858457489B53523FB26915D1C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8400A9BE63B356409D495FC9DC21FEBB4686",
                        "defaultText": "이만 가보는 게 좋겠군요.\n하지만 당신의... 꿈속 짝을 찾으면 알려 드리죠."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6E22FB490BE74340B18AB7C124D0B5BCD43A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5D12C90D8EFFB644F16801C319BC7B6B7DF0"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "second time"
                },
                "indent": 0,
                "uid": "0FE5456264E5584E3F283751B7FBC0EC845F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "75CD1329416CB84E3B6BC2E37A6CFD3AF829"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "F96DF25013A4B64C0D297691393A879B2668",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5D8E56514C7F5946D4789A880EA133D508EC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A550205448BB7345337A1098E76BA0BB4580",
                        "defaultText": "그런 사람은 없어요... 이제는 확신해요. 어디에도 없어요."
                    },
                    "position": 0,
                    "characterId": "F96DF25013A4B64C0D297691393A879B2668",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "98E8E25B1FB3F14C9A89A0166DAAD830EDBA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "496B1B257B49F343951B099494286D45D40B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "13DEF48C74C54846802831C2F52D43858D0C",
                        "defaultText": "낯선 사람을 아무리 많이 초대해도 진정한 사랑은 보이지 않아요..."
                    },
                    "position": 0,
                    "characterId": "F96DF25013A4B64C0D297691393A879B2668",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E42E80DD2BC686406D28CE4878B64FB9617C",
                "expanded": true
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Flag locale 8",
                        "index": 167,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F25D4FB37B0DA84CC48ABE62AF42E16872F6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "76765B4E14B214455C3B29763EEBBBE5B96A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "8DCCE66B4C12514FFA084FF98F134E23C54E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "71BF6EFF1E1456430B69ACD28E19E84C1666"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "434A0F74713C124F9C48F02266AF3392572A",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "240A152F192B61434A8B5F82B03FCE3CC012",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "9BC3D95C3861A04C527AA062DA5B43C708A8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "8701575B5C656448591A76C13811C96E7C2C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "231FB6FE6796C34D472B1D89C8BE608CAC47",
                        "defaultText": "아, 알겠어, 리아. 여기서 단 1초도 더 머물면 안 되겠군."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "498363E80635324FFC5B1A259E2E13CC043F",
                "expanded": true
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Flag locale 8",
                        "index": 167,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "B79C6FA53BC552461A4AE1C92ADE1AEC72B8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "AB93650E0698D84FE7881802BB89A615DEBD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "99D4EADD414B8044B27934950A86D3FEAD5D"
            }
        ],
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "localizableStrings": {
            "CFC9C75D49E90240B40AF5E288FFD1064DE7": {
                "t": "Ohohohohoh! Is it you?",
                "d": {
                    "cid": "F96DF25013A4B64C0D297691393A879B2668",
                    "eid": "E1410F9C2DA6154B757A40D35F4319A6F9D8"
                }
            },
            "7003D6206F4670442E5BE7077D8EBE24EDF7": {
                "t": "Me... what?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "FAAFFD0237D7F545761B6954963B68CEA5F0"
                }
            },
            "1AA9990C0DBD22462328D7B81BF43F714FEF": {
                "t": "Are you the one who's going to save my marriage?",
                "d": {
                    "cid": "F96DF25013A4B64C0D297691393A879B2668",
                    "eid": "5E32E4090B204441F6782637FAC7344DD9C9"
                }
            },
            "581692654E1E6142C4790D964AFB4A869676": {
                "t": "I have better things to do.",
                "d": {
                    "eid": "6F147A113970E64AFF28EAB52706708428BF"
                }
            },
            "A047882845C1264506790C030269AAA8C7F5": {
                "t": "Your marriage is beyond saving.",
                "d": {
                    "eid": "BD7887B859FE0442D0498A983011AE643CE5"
                }
            },
            "7AC7E5201CBE4648F22B8D03A877142E8B4D": {
                "t": "Are you... feeling well?",
                "d": {
                    "eid": "091CB3A33D2FA84A1088D7D596E0B44FF7B6"
                }
            },
            "E2CBAAED40B1884A519AE5880AA8286F5787": {
                "t": "No, no, no! Wrong answer. You aren't the person I dreamed of.",
                "d": {
                    "cid": "F96DF25013A4B64C0D297691393A879B2668",
                    "eid": "0F178415657FC140524B62838864BA68E0F3"
                }
            },
            "9FF6A02C82BEA843E17B6A172AB4CBB966B4": {
                "t": "I don't know about that, but we're sure to become your living nightmare if you don't stop disrespecting other people's time.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "5D348AFA174E964BA518BBA137A84B2CE421"
                }
            },
            "0142C58644665745A4598311560FAA634730": {
                "t": "Well spoken, Rya! Except that we probably can't do that, we're undercover... Old habits are hard to kill, I guess.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "03759A5C597AF3435A68D5B10925A19F0E9B"
                }
            },
            "8C1631F41ACD71432088C172CF06FAA359DC": {
                "t": "A living nightmare... Funny! You're extremely funny! Ohohohoh! I'm already living in a nightmare!",
                "d": {
                    "cid": "F96DF25013A4B64C0D297691393A879B2668",
                    "eid": "D11299D1213A21412E09D1557BAD33E2F363"
                }
            },
            "3D537284405DC746734B67B03449977ADE01": {
                "t": "That... DOG. THAT PREPOSTEROUS, PERVERTED ANIMAL.",
                "d": {
                    "cid": "F96DF25013A4B64C0D297691393A879B2668",
                    "eid": "9C308AB61D336543518912B80110DB1F41F2"
                }
            },
            "5F4C59782AB5F345FE8ABD428F33E84DAB17": {
                "t": "Do you have any problems with your pet?",
                "d": {
                    "eid": "7C5F13DB2C14B8425008BA42EB6D66638CCA"
                }
            },
            "C5D10A0F222B044386191BE1CE6D53662DB5": {
                "t": "Animals deserve more respect.",
                "d": {
                    "eid": "28FB34C68A25084EFE992D96B645400F21E6"
                }
            },
            "7639BC2E7B0F324644987D14E4B16120BC5D": {
                "t": "I'm not talking about literal animals!",
                "d": {
                    "cid": "F96DF25013A4B64C0D297691393A879B2668",
                    "eid": "DE6CA2DF2C0D2549318BF6482DF2D4F75DDB"
                }
            },
            "3B9607F2642A354962591B926C5F69CF20C6": {
                "t": "CAN YOU HEAR ME, HUGO!? COME HOME IMMEDIATELY! FORGET THAT USELESS JOB, FOR ONCE!",
                "d": {
                    "cid": "F96DF25013A4B64C0D297691393A879B2668",
                    "eid": "0E90F767107C194DA929F9E2854A26CE064B"
                }
            },
            "2ADC8B4249425244734BA5F1AF5A847E7E2D": {
                "t": "What in the world is going on here?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "3C9230A04E58454CA0680474C39BD7410309"
                }
            },
            "8400A9BE63B356409D495FC9DC21FEBB4686": {
                "t": "We'd better be off, young lady. But we'll let you know if we find your... dream partner.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "6E22FB490BE74340B18AB7C124D0B5BCD43A"
                }
            },
            "A550205448BB7345337A1098E76BA0BB4580": {
                "t": "It doesn't exist... oh, there's no such person, I'm sure of it at this point.",
                "d": {
                    "cid": "F96DF25013A4B64C0D297691393A879B2668",
                    "eid": "98E8E25B1FB3F14C9A89A0166DAAD830EDBA"
                }
            },
            "231FB6FE6796C34D472B1D89C8BE608CAC47": {
                "t": "Huh, I get it, Rya. We shouldn't stay here one second longer.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "498363E80635324FFC5B1A259E2E13CC043F"
                }
            },
            "09DDA9A50540474B830A531509F41604137C": {
                "t": "IT'S MY HUSBAND! THAT HORRIBLE BEAST!",
                "d": {
                    "cid": "F96DF25013A4B64C0D297691393A879B2668",
                    "eid": "09B9E84E33ED334DAD6BC453157D3F5241CF"
                }
            },
            "13DEF48C74C54846802831C2F52D43858D0C": {
                "t": "No matter how many strangers I invite in, my true love is never in sight...",
                "d": {
                    "cid": "F96DF25013A4B64C0D297691393A879B2668",
                    "eid": "E42E80DD2BC686406D28CE4878B64FB9617C"
                }
            },
            "434A0F74713C124F9C48F02266AF3392572A": {
                "t": "... ... ...",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "240A152F192B61434A8B5F82B03FCE3CC012"
                }
            }
        },
        "booleanVariables": [
            {
                "name": "read?",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}