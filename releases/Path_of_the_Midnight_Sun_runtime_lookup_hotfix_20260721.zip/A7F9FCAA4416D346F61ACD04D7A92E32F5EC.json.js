GS.dataCache['A7F9FCAA4416D346F61ACD04D7A92E32F5EC'] = {
    "uid": "A7F9FCAA4416D346F61ACD04D7A92E32F5EC",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "Order food",
        "type": "vn.scene",
        "parentId": "2EFF267B41FA84405E4A70A330F772345E6D",
        "chapterUid": "CF7E3CE62FB82749AB7B39C1990AC623D042",
        "order": 0,
        "localizableStrings": {
            "D28A6B476A8D064A096A80B5578EC1098B62": {
                "t": "Done, Nini?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "8E016FB037F55849D20ABAF033288652BE1B"
                }
            },
            "7ECC66959A0F5048CF8BB6B4B19E8AAD5991": {
                "t": "I'm... {W:150}er, still choosing.",
                "d": {
                    "cid": 0,
                    "eid": "024892C25F8D654A6C7A87436D1D813E0972"
                }
            },
            "1725028D04E8204A2E189A04824007E69113": {
                "t": "You seem pretty indecisive.{W:200} Don't worry, take your time.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "3640EF8C20ACF0477179DA646C4F5A869B0A"
                }
            },
            "119ADC182DB3394C4A3BAB971A0DAE13F708": {
                "t": "It seems you're done. {W:150}Hehe, I'm curious to see what you've chosen for me!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "C022AAC97BA0834DAA2877E7762651F9C460"
                }
            },
            "D5106BA2436B2146918B093932F6ACF4071B": {
                "t": "I hope I didn't make any mistakes...",
                "d": {
                    "cid": 0,
                    "eid": "E397F4E92F42764DB2583A245ACB3394AF35"
                }
            },
            "E892F1A06574574B9488B15465F11FD4B86A": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "BA27DE3645AD4642811B1CD45A4F240805DC"
                }
            },
            "B80395E8540D72415D3BD774FF4B12DF5B9F": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "D7E870DA4086554CDA29B2146CED9B3361FA"
                }
            }
        },
        "commands": [
            {
                "id": "gs.Comment",
                "params": {
                    "text": "SHOP"
                },
                "indent": 0,
                "uid": "0BD2EAEE683D1840E39859C75B050DDC022F",
                "expanded": true
            },
            {
                "id": "gs.ListLength",
                "params": {
                    "listVariable": {
                        "name": "Lista Cibo",
                        "index": 310,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "949A075F24CA21412458F8A54C7FF870EDE1"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Numero Multiuso 1",
                        "scope": 1,
                        "index": 0,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A609AD997DEC9640DA38C5448F3708389A64"
            },
            {
                "id": "gs.ListCopy",
                "params": {
                    "listVariable": {
                        "name": "Lista Cibo",
                        "index": 310,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Lista eventi speciali 2",
                        "index": 537,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "892DD77730D2554D01990878580395DA47BE"
            },
            {
                "id": "gs.ListClear",
                "params": {
                    "listVariable": {
                        "name": "Lista Cibo",
                        "index": 310,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "49E4A81B6B22A54AC98BACD957C8077270FD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "422B49CA8A63A04CB338ADD9E56A9BFB25A0",
                    "parameters": {
                        "values": [
                            "",
                            {
                                "lcId": null,
                                "defaultText": "Any food you had will be unavailable during dinner."
                            },
                            "",
                            2
                        ]
                    }
                },
                "indent": 1,
                "uid": "0E0A2EDB2E77834F7F7B3B555DCB370DD8B7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6FE3C1466BE6D749E93B1A1763C2A8DE2900",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "0B48891A300352483C09A6362A8F046325CE"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 1,
                "uid": "DDDD099E80D9D3441F883B3561448D48D061"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "Open Shop"
                },
                "indent": 0,
                "uid": "CC1B4B6685BA784B0279DFD26ECA75DA6701"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8C6A213E7AF5E746C31937045FBD07B15D7D",
                    "parameters": {
                        "values": [
                            "F93B23EE2C30854DCC5B1C70CDBAA49A2A9A",
                            "A61006745779B54F95583F031E23AAF3B85A",
                            "9CD432E8076BF34ECA4887B30B4A24F40A7A",
                            "4BE0921B0375824E39486375D29E6D610E31",
                            "",
                            "",
                            "",
                            "",
                            "",
                            150,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "89FE17515A5FA743313A5BF8F82C1658D1EE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "48504D765D9B054F023B0B558BB866C0CF69",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "BE8DAC273658B44CB73A6632E337E8186CCB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "5C11C618154A624C74695842A76E24FD1F8B",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "80E5D8E195931946126AD5D9FDB7E7B1CABF"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "Confirmation"
                },
                "indent": 0,
                "uid": "0C1CC1BA4F046342D319A718FE4C5B5FF167"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "Confirmation event",
                    "target": "activeScene"
                },
                "indent": 0,
                "uid": "3355467D1D57F7407C89A716D45385123518"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "Cancel anything else"
                },
                "indent": 0,
                "uid": "7C89BF0E0DF85744894A09536BCA4F9DE112"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "Cancel anything else event",
                    "target": "activeScene"
                },
                "indent": 0,
                "uid": "FB88DFCF1BAEA44DD73ACC930402499C4A02"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "Thank anything else"
                },
                "indent": 0,
                "uid": "31DFC05A1498D340A609B436E4372628C180"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "Thank anything else event",
                    "target": "activeScene"
                },
                "indent": 0,
                "uid": "4BDB72D641F0D2461A8BF3214F82840C35A6"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "Not enough money"
                },
                "indent": 0,
                "uid": "1795AA79118710403C5A92432E9260C30708"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "Not enough money event",
                    "target": "activeScene"
                },
                "indent": 0,
                "uid": "223129A58815524EA92912B6DAE903155ECB"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "Close Shop"
                },
                "indent": 0,
                "uid": "62254C655666324D3729E4C0037E0AE7FABB"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Annulla tempo chiusura Shop",
                        "index": 142,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "09B154710EDA154625285D0515B06B828434"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "Close Shop event",
                    "target": "activeScene"
                },
                "indent": 0,
                "uid": "D35E9A8958F13748F8282CD7B3C4E693E6BD"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "Closing Event"
                },
                "indent": 0,
                "uid": "E40A67F85610524F484AA486899B61E5BFA3"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "verify if you have enough food"
                },
                "indent": 0,
                "uid": "1C2E39A2169A8147B84A43161C9262E3C400",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B4EF623468E667476929C1E798417D418D96"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "7AAD022E3E58B64F007A2CE9B11F3392B406"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E892F1A06574574B9488B15465F11FD4B86A",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C0.1-01_line16.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BA27DE3645AD4642811B1CD45A4F240805DC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "AF6A063C3C5DA148E92890D83C7104C4B79A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CC9414CB1E46534FA92B12D647DA51F867F6"
            },
            {
                "id": "gs.ListLength",
                "params": {
                    "listVariable": {
                        "name": "Lista Cibo",
                        "index": 310,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D71CBE3D55CBE2404018F39774D7E0051288"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0
                },
                "indent": 0,
                "uid": "9CDF96640E19D148DF4806F22E3B7D727496"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "Rifai scelta",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "2F49287E2516434AC749D1E10C37DC3DDB21"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 1,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0
                },
                "indent": 0,
                "uid": "EF0CF594638E4247CF7833E3B0D7EF9AB27D"
            },
            {
                "id": "gs.ListValueAt",
                "params": {
                    "valueType": 2,
                    "index": 0,
                    "listVariable": {
                        "name": "Lista Cibo",
                        "index": 310,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo Multiuso 1",
                        "index": 1,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "3F6A301B53DFF64C5879DDC9F62A67F8D0BC"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": {
                        "name": "Testo Multiuso 1",
                        "index": 1,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "param": {
                        "name": "Quantità",
                        "type": 0,
                        "value": 0
                    },
                    "targetVariable": {
                        "name": "Numero Multiuso 2",
                        "scope": 1,
                        "index": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "08B982771B28C8417029F284BCE70C8CAA5D"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Numero Multiuso 2",
                        "scope": 1,
                        "index": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "numberValue": 2,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 4,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "B38034238AA7314D988AC85246B966CF19BF"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "Rifai scelta",
                    "target": "activeContext"
                },
                "indent": 2,
                "uid": "71BB4F96332AA6478B281C58D697DFCAF673"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "Prosegui storia",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "BE6DA74D7EB2284BFC589722BD4E1B1E2827"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "Rifai scelta"
                },
                "indent": 0,
                "uid": "8AA01C548B21084DB93A7C6650ED645DC075"
            },
            {
                "id": "gs.MessageSettings",
                "params": {
                    "useCharacterColor": 0,
                    "paragraphSpacing": 0,
                    "backlog": 0,
                    "bold": 0,
                    "italic": 0,
                    "linePadding": 6,
                    "lineHeight": 0,
                    "lineSpacing": 0,
                    "smallCaps": 0,
                    "underline": 0,
                    "strikeThrough": 0,
                    "autoErase": 1,
                    "waitAtEnd": 1,
                    "font": "Verdana",
                    "size": 40,
                    "outline": 0,
                    "outlineSize": 4,
                    "shadow": 0,
                    "shadowOffsetX": 1,
                    "shadowOffsetY": 1,
                    "color": {
                        "red": 255,
                        "green": 255,
                        "blue": 255,
                        "alpha": 255
                    },
                    "outlineColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255
                    },
                    "shadowColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255
                    },
                    "fieldFlags": {
                        "autoErase": 1,
                        "waitAtEnd": 1,
                        "backlog": 0,
                        "font": 1,
                        "size": 1
                    }
                },
                "indent": 0,
                "uid": "71AAD2BC2EA708468B381C71012AC45FEB7E"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "read?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8AF5DF3A81E2474A716B93B2BA96A7A5693E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            8,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "A6C75F073A33B643181A1CC69184095712B9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D28A6B476A8D064A096A80B5578EC1098B62",
                        "defaultText": "다 골랐니, 니니?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "8E016FB037F55849D20ABAF033288652BE1B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "B1EEE5901427C84EFD792AB2E6B4B68D07A0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "4981D9B37BC5A441171B9053FE78C545F18D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B80395E8540D72415D3BD774FF4B12DF5B9F",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E3-Ornieres_line28_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "D7E870DA4086554CDA29B2146CED9B3361FA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "2FA6117B29C8B14A963B15F223354E28C384"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "EAA26FDD0119044C287AE3C598A2FE0B2A76"
            },
            {
                "id": "gs.MessageSettings",
                "params": {
                    "useCharacterColor": 0,
                    "paragraphSpacing": 0,
                    "backlog": 0,
                    "bold": 0,
                    "italic": 0,
                    "linePadding": 6,
                    "lineHeight": 0,
                    "lineSpacing": 0,
                    "smallCaps": 0,
                    "underline": 0,
                    "strikeThrough": 0,
                    "autoErase": 1,
                    "waitAtEnd": 1,
                    "font": "Verdana",
                    "size": 40,
                    "outline": 0,
                    "outlineSize": 4,
                    "shadow": 0,
                    "shadowOffsetX": 1,
                    "shadowOffsetY": 1,
                    "color": {
                        "red": 255,
                        "green": 255,
                        "blue": 255,
                        "alpha": 255
                    },
                    "outlineColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255
                    },
                    "shadowColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255
                    },
                    "fieldFlags": {
                        "autoErase": 1,
                        "waitAtEnd": 1,
                        "backlog": 0,
                        "font": 1,
                        "size": 1
                    }
                },
                "indent": 1,
                "uid": "D00637810B6E6542FF09AFF23A456A8084BB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7ECC66959A0F5048CF8BB6B4B19E8AAD5991",
                        "defaultText": "나는... {W:150}어, 아직 고르는 중이야."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "024892C25F8D654A6C7A87436D1D813E0972",
                "expanded": true
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "A825A2AE6330B94BFA3ACE15C743267BF6BD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            12,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "B9788D9F36AD81469928DA24762050D4219E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1725028D04E8204A2E189A04824007E69113",
                        "defaultText": "꽤 망설이는 것 같네.{W:200} 걱정 말고 천천히 골라."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "3640EF8C20ACF0477179DA646C4F5A869B0A",
                "expanded": true
            },
            {
                "id": "gs.MessageSettings",
                "params": {
                    "useCharacterColor": 0,
                    "paragraphSpacing": 0,
                    "backlog": 1,
                    "bold": 0,
                    "italic": 0,
                    "linePadding": 6,
                    "lineHeight": 0,
                    "lineSpacing": 0,
                    "smallCaps": 0,
                    "underline": 0,
                    "strikeThrough": 0,
                    "autoErase": 1,
                    "waitAtEnd": 1,
                    "font": "Verdana",
                    "size": 40,
                    "outline": 0,
                    "outlineSize": 4,
                    "shadow": 0,
                    "shadowOffsetX": 1,
                    "shadowOffsetY": 1,
                    "color": {
                        "red": 255,
                        "green": 255,
                        "blue": 255,
                        "alpha": 255
                    },
                    "outlineColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255
                    },
                    "shadowColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255
                    },
                    "fieldFlags": {
                        "autoErase": 1,
                        "waitAtEnd": 1,
                        "backlog": 0,
                        "font": 1,
                        "size": 1
                    }
                },
                "indent": 0,
                "uid": "32429CCA301AC142D14AE5E34D4E5E53076D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CC941F3E3E24B34FC9496AF7AF20E7D4D6E2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D1F9FB892A2CD143F78B4E972BE364F1D37F"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "read?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "FE9894850EB8904C8F6AB7D32EF7B477149B"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "Open Shop",
                    "target": "activeScene"
                },
                "indent": 0,
                "uid": "E579027A60ED8341FB8A52F9EACDE3D816C1"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "Prosegui storia"
                },
                "indent": 0,
                "uid": "A56BE8D82E92A24CA788BE132196802F48AD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            14,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E74A292F4F4A11400B89BD8710A6011A1A9D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8288C3B64FB5224DAF5BC401225A6158AEE4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "119ADC182DB3394C4A3BAB971A0DAE13F708",
                        "defaultText": "다 고른 것 같네. {W:150}헤헤, 뭘 골랐는지 궁금해!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C022AAC97BA0834DAA2877E7762651F9C460",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6201EB826CD2A44F08690C770A892E14552F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B3809F4E24706543B66905330D7E4E712333"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D5106BA2436B2146918B093932F6ACF4071B",
                        "defaultText": "실수한 게 없으면 좋겠는데..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E397F4E92F42764DB2583A245ACB3394AF35",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "356742A59180A343DA593AA2FE43031B76F1"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "hide chosen food"
                },
                "indent": 0,
                "uid": "91104F87384DA64E5B4ABCC8BFBFA6F15B10",
                "expanded": true
            },
            {
                "id": "gs.ListCopy",
                "params": {
                    "listVariable": {
                        "name": "Lista Cibo",
                        "index": 310,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Lista per eventi speciali",
                        "index": 539,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "18B7935B53CB824294497F79825C8FDFA6D1"
            },
            {
                "id": "gs.ListClear",
                "params": {
                    "listVariable": {
                        "name": "Lista Cibo",
                        "index": 310,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B0F561AB1FBD574FAE5AE062E8C84A2A513D"
            }
        ],
        "livePreviewDisabled": true,
        "booleanVariables": [
            {
                "name": "read?",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "listVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}