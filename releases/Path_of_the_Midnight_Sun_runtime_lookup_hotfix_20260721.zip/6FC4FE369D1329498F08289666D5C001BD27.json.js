GS.dataCache['6FC4FE369D1329498F08289666D5C001BD27'] = {
    "uid": "6FC4FE369D1329498F08289666D5C001BD27",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C11A-2b P2 Finn",
        "type": "vn.scene",
        "parentId": "96E6D4851B65E542343B4F677C5CBE962889",
        "chapterUid": "EF3BAE1B50D8764F0D184715C435B627D64E",
        "order": 1,
        "localizableStrings": {
            "2364C7653C9427417D1955B78D6091A123AD": {
                "t": "... ... ...",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "E7526DD33243944B91499865EAEDAF6DBD68"
                }
            },
            "A68379A7424FA940070B5A48B894C2DD2469": {
                "t": "... ... ...",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "A8B8504A4A912640C4184EE41794B0991EA5"
                }
            },
            "753459E7305D484962587A8393D1F89B1372": {
                "t": "He seems very pensive...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "50F94E3C038A3847467B061649C19AC7EA30"
                }
            },
            "EDE088641E27994C4348ACE24345D9FE3F6C": {
                "t": "... Hmh?",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "17C8CB9690CF3940CC8884D600B695E95190"
                }
            },
            "1D3C206555BE56429C897E37C628208D5718": {
                "t": "Oh, umh... My apologies, I didn't intend to disturb you.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "44AA6FBC66D0A540A28AC71867CF246D5F78"
                }
            },
            "E4368EDE235E8546488ADF07FEE0AAD60D45": {
                "t": "This is one of those people for whom my old power would have been VERY useful!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "BF8B2333316B524FAE299AB94B8EA57A8693"
                }
            },
            "9B80384D2A38A84D766AAD028ADB6A6DC21A": {
                "t": "He really is him! He looks younger than I expected.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "11C1AF85472E4744507B6990E9CB0AD7ACE4"
                }
            },
            "25A4BDBE81DA9748CC6B7921E64988DD8537": {
                "t": "Umh... excuse me buddy, could you.... y'know, participate in this conversation? Properly?",
                "d": {
                    "cid": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "eid": "4F0B4239281EC4486459CA645A96B6308886"
                }
            },
            "2E94CA97882C5844092B7464B0103F3245E8": {
                "t": "Forgive me, Sir Valinor. You're one of the Holy Swords like me, right? I believe Her Holiness must've informed you about our situation.",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "91BD9DBE0B5F9749134A824606C2B7409254"
                }
            },
            "8C6C1B855A33384D00284B014B5B0C7E8E59": {
                "t": "... Captain Ornières, long time no see.",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "0C938CB164FCB2479E3A0461B7DE5261C454"
                }
            },
            "7221A60B32A61049954B9C34FE4AC3C74396": {
                "t": "I... er-- Okay, this is awkward.",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "D0B30AA108AAF74A5B48F1C65552A2E4D686"
                }
            },
            "124B82691FD63643545878579B728FEAFCE8": {
                "t": "You see, his memories--",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "5CE444498D13954FA98B312421F99A575C85"
                }
            },
            "C4987BF3284C404C495A7C825D0156F5280F": {
                "t": "Hah, just kidding. No need to explain. I was already informed by the Matriarch about his... amnesia.",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "9DB136B48FCC3347D338ED862C21B2DE7832"
                }
            },
            "4BBD88AF5E9EA349F3595DD3BB5615F772E9": {
                "t": "I just hoped he would at least remember my name. We used to train together...",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "5D19F6325529F7444E795D77438EC3FA24D8"
                }
            },
            "1AAF66EF6B892143B82BB808B9E0776CEE2C": {
                "t": "Really? That's awesome! And where is it?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "83D0E5A81B55294F0719E39533D073EBAA92"
                }
            },
            "EC9C182C10810148239AB7E6EA7EB488B2FF": {
                "t": "I don't know.",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "DD6888C52DBDB147740B83A4873288DC4F18"
                }
            },
            "77197E63763D86448619CE72EC8FFD311D0E": {
                "t": "Well, that's underwhelming.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "65D4F5101A6904494A290A12E92BFE8A9D61"
                }
            },
            "2E86CF0160A5B5417C586BB1AC172A3B452E": {
                "t": "Let me finish...",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "B36865C974EA0746F37A61338A750DEC5696"
                }
            },
            "EE4C506A2486F541239BEC7872133830A904": {
                "t": "There's a... man with {SP:2}{C:1}certain talents{C:0} who lives in the nearby forest. I've heard he might know where that weapon you mentioned is.",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "36B1407E55C98241468A7D7548BBAA8AC41D"
                }
            },
            "696ADF9534D4094E8749A9D141FC294D60DD": {
                "t": "That's still vague, but... way better.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "4151EBB14DCB024CCF293DA69D24AD893207"
                }
            },
            "CF4218C467E13340E29A7959D052C00A52D4": {
                "t": "Get off your high horse Orni, you seldom do anything useful.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "F5AFC7A57DFEF0440E98A0030207C481D614"
                }
            },
            "6F858A357BB27740406B0DA3F077D244B0A2": {
                "t": "Hehe! They're at it again... I think I'm starting to understand how their relationship plays out.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "CF2129A76DBA194D27481BD2AF066E0EFBAA"
                }
            },
            "FF907BA35E8EF848F04A5047651C1DB6DD1B": {
                "t": "Let me guess, Royce. You don't know where this informant is exactly.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "FBB53E9D0733F14112790BC7AC2D701AA6D7"
                }
            },
            "73656BE12A5F804EC53AD6F1477EB90F90DF": {
                "t": "Correct. And given the current situation with the monsters, it's too dangerous for me alone to search for them.",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "3803A4D22B509248088B8948F7BBCD31EA58"
                }
            },
            "78DECD5D3024784BFB884E86E19F396DBDC4": {
                "t": "That's what we're here for, buddy! Just leave the hard lifting to us.",
                "d": {
                    "cid": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "eid": "D7C052675581534E955874A682B2494940E7"
                }
            },
            "B0C9005834D7B7407878B6023D3FD0B91FE1": {
                "t": "I can lift my own weight, don't worry. You'll see.",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "352111EF34A684442049BBA4C221EAA3E9FB"
                }
            },
            "6EE2314A87AC11479C1B5FD4AD9092E6F5BE": {
                "t": "What a curious person. There's something about him that bothers me, but I still don't understand what...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "B92DD7F32F07B74CD939ACD76FB37817D719"
                }
            },
            "E6BF0DB43F8493414639B1F380495A1F5270": {
                "t": "Hah, what am I talking about? Judging people based on some sort of 'sixth sense'... Force of habit!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "F5C463A674329845CB693EC3F8FB29A03612"
                }
            },
            "6D49857C2CB73443365B7C4197B26544856C": {
                "t": "I'm probably overthinking. Let's go into the forest and see if we can find some clues.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "3FD6BD664454B24EB32B7714BB54CC6FCA7A"
                }
            },
            "A634B82E1A0A574BA16813D37455324ECFFE": {
                "t": "He gives off a familiar vibe, somehow. Have I met him somewhere before?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "4EA0B70512104341511BCA5461367646D62C"
                }
            },
            "2308B4C416BF17487479BBE05EB6916CC48A": {
                "t": "What a curious individual... He doesn't seem evil, but there's something about him that doesn't sit right with me.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "F48E91E348336444DE3A96D247F174B9943D"
                }
            },
            "231C685581FEB3459F59A3317BC7F0306BA0": {
                "t": "Huh...",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "C3C96F594E45C94EC5180A4160719BE9A1BE"
                }
            },
            "3E2C05E42287D24D6F997734B494A26F26FF": {
                "t": "So he knows Nini...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "CC4B04AF6CD43643E789CF81CD6BBADACDE3"
                }
            },
            "00ADBB0D240A564975683594D5097F81CBCE": {
                "t": "What's with the \"Sir Valinor\"? You weren't the type to joke around when we met in Sacrépilier.",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "4EA966BB8E6F9741A04BC822E162720A2FFE"
                }
            },
            "3A3C40A437B8D646A00AFDB69C63EBEB67F6": {
                "t": "I'm truly sorry. And I'd be happy to talk about our past experiences... later.",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "59A0A6B35E4D5440B17853779A5DDEFFB3C2"
                }
            },
            "DABB1F81274DF647E98A67B27E03A59AEEC0": {
                "t": "\"Later\"... Certainly.\nWe have more pressing matters to attend to now.",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "F076FEEF567761408038579440D2459AAF6E"
                }
            },
            "74CCF6E85A4FF9401E8A1CD81449A537DADC": {
                "t": "You're searching for the Archdemons, right? Well, I know for sure that one of them is hiding here.",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "4DEE19D46581E64A9B589B76369C45664219"
                }
            },
            "880EB86980D6104784885A2707F5E1E9B89F": {
                "t": "As expected from a fellow Holy Sword! You truly are reliable.",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "7A78A3528E673145CC199D6799A6FF3D44DD"
                }
            },
            "189510EE0CF5404FD8282FB4FFCED8B69B7F": {
                "t": "You aren't getting any Mana from me if you keep teasing.",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "FDB9D28659A6E4498A39A443197B4B13ED3F"
                }
            },
            "3003AB9577A8854AC69889A6882D7308208F": {
                "t": "In any case...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "9A7BD4F89EEDD54F7489CF479B4ED418DE2F"
                }
            },
            "BE7DB88041512841EF59C6590EA1F5641134": {
                "t": "It's alright.",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "47DD18274642424EC64A20618190EDFED520"
                }
            },
            "EF9D1C7288855440922B59B5713A9A69F465": {
                "t": "... ... ...",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "727A08E679F1A844C808B451E8CBA9E720D7"
                }
            },
            "7A1C707475BC004FE60A79213AA1C616A124": {
                "t": "Excuse me, Sir...?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "85490E949B88044723390B6542BFF8047BE0"
                }
            },
            "CA0E684C6241334979786A5342F660BA1EBF": {
                "t": "Royce",
                "d": {
                    "eid": "4ACE45F47AF1E34925687A840292B14B1F6F"
                }
            },
            "63B17F15401E024AC64BAAE22A8EDE9767A7": {
                "t": "Sir Royce Valinor. How may I help you?",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "1EB7E5936661A64C77196BB4190FCD183D1E"
                }
            },
            "C2E4C7249792E445DC29E6192377F02EC1D3": {
                "t": "I've heard of your valiant deeds, Sir Valinor.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "54084389321FE14EF418C9B57EFBD0BA4067"
                }
            },
            "D638879A575CC646D9484A9324813853B8C4": {
                "t": "And according to our intel, a Holy Knight in town could help us to find a weapon to fight the demonic forces.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "1CE0795B9FF78545A64A7A67D4CE0A7AE96D"
                }
            },
            "90BED7CB6F05B445FA5B2A1249881692DE79": {
                "t": "That'd be me, yes.",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "05D559DA9432844F9E4B4774B5BE83C28361"
                }
            },
            "F6C68D1D8541F34FFE393DD2C34AFAA02EC9": {
                "t": "... ... ...",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "1FB2AD5729530747092875E7CD3DA2023365"
                }
            },
            "CD50690D7A75454F2299F9F6C5C004FEF1E0": {
                "t": "Sure, you can count on me, I guess.",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "1818272F4D37C348EA892811B34C655DBD14"
                }
            }
        },
        "commands": [
            {
                "id": "gs.Comment",
                "params": {
                    "text": "If you still haven't talked to Arlene"
                },
                "indent": 0,
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "38B299732B09B343095909D667921FF86E94"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DE02C6593186734A622B0793B383D00AEC89"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F9533BDB376B954CAF6B29F6A8CD802528A2"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Flag locale 8",
                        "index": 167,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3C2DFF804CA1B64DC35BD061085D6DA79F28"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2364C7653C9427417D1955B78D6091A123AD",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "E7526DD33243944B91499865EAEDAF6DBD68",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "86AF9E972F1AA74DE28B9FB1FFE987B08148"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "C2D461BD9B88F4499028B83929E86EC3A9CF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A68379A7424FA940070B5A48B894C2DD2469",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "A8B8504A4A912640C4184EE41794B0991EA5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "B7B2712413F7B646A58B08D41C59E345DA0D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "01A1F4BD7E68594FD518AD66E92D1222A9F1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "753459E7305D484962587A8393D1F89B1372",
                        "defaultText": "생각에 깊이 잠긴 것 같아..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "50F94E3C038A3847467B061649C19AC7EA30",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "9354D4A1255BD640B11A25C317619C21EE1E"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "read",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "16B24A2436A2D24FCF2803711FCA45E56C18"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 2,
                "uid": "FCEC64CE1C39D4460F6A95F8E3550D1B23DC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "78A3B4926F9D4040AA6BD1D0A6A62FCBDB9B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EDE088641E27994C4348ACE24345D9FE3F6C",
                        "defaultText": "...흠?"
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Finn",
                        "name": "C11A-2b_line4.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 2,
                "uid": "17C8CB9690CF3940CC8884D600B695E95190",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "7B5D56567FF3D7403C6B05468152A9A998BA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "6A1256A78A840144C00BC946A77981BFC379"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1D3C206555BE56429C897E37C628208D5718",
                        "defaultText": "아, 음... 죄송해요. 방해할 생각은 없었어요."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C11A-2b_line5.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 2,
                "uid": "44AA6FBC66D0A540A28AC71867CF246D5F78",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "CFD5F9BB12FAF34301088154E27ED5397995"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "8F3AE5476C4982415C6A3AE6576AE5549944"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BE7DB88041512841EF59C6590EA1F5641134",
                        "defaultText": "괜찮습니다."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Finn",
                        "name": "C11A-2b_line6.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 2,
                "uid": "47DD18274642424EC64A20618190EDFED520",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "6F0DD89403BE244D8E797E260671A4E7252D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "2136AF4F2F65C644D4698E940257A0BAC6D3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "F409625B2B622742489858696B11D6D6AA32"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 1,
                "uid": "33EE573A6A2D5748D93850015D81DEB5D3B7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "C1D58218868B9846B3294B42ADA142E2CB33"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E4368EDE235E8546488ADF07FEE0AAD60D45",
                        "defaultText": "이런 사람에게는 예전 능력이 정말로 유용했을 텐데!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "BF8B2333316B524FAE299AB94B8EA57A8693",
                "expanded": true
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "read",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "CCA7AA3853B0B843FF4A4B00A0B86E189C0C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1148036754E2994C210B6749EEFEAC16E090",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "8238744768DC3649154B00349EAA8853147B"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "C407A6331B14534A906B77210DB81D71E8A6"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "If you have already talked to Arlene"
                },
                "indent": 1,
                "expanded": true,
                "uid": "8A568E19210BB440644B40B12E472B24FF5A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "BECA2B4E1D6FD345BB491205BDBDDBDD09EB"
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 1,
                    "idleIntensity": 1,
                    "lipSyncSensitivity": 0,
                    "fieldFlags": {
                        "breathIntensity": 1,
                        "idleIntensity": 1,
                        "lipSyncSensitivity": 0
                    }
                },
                "indent": 1,
                "uid": "0B98CB765E5B3041E0295F63C2DCC1FD82DC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EF9D1C7288855440922B59B5713A9A69F465",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Finn",
                        "name": "C11A-2b_line8.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "727A08E679F1A844C808B451E8CBA9E720D7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "0225A7EE3E53C240CF7ACD47C1379ECFDD37"
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 1,
                    "idleIntensity": 1,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 1,
                        "idleIntensity": 1,
                        "lipSyncSensitivity": 0
                    }
                },
                "indent": 1,
                "uid": "10C824087DAD5844D209A5F9A9174315F364"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "149D413E798D8842125A369260BD72449196"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7A1C707475BC004FE60A79213AA1C616A124",
                        "defaultText": "실례합니다, 기사님...?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C11A-2b_line9.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "85490E949B88044723390B6542BFF8047BE0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "C0D018551DEF084F351B9024AC3CB55E6053"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "D529B1ED8AE6394F0768E177F84D35F53FD0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A634B82E1A0A574BA16813D37455324ECFFE",
                        "defaultText": "어쩐지 익숙한 느낌이 들어.\n예전에 어디선가 만났던 사람일까?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "4EA0B70512104341511BCA5461367646D62C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "F2A87727375FC34FFA88FA57333A9FD10B0F"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "CA0E684C6241334979786A5342F660BA1EBF",
                        "defaultText": "로이스"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "4ACE45F47AF1E34925687A840292B14B1F6F",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Finn"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "F8F174EB7694314ED63A4012B18FC585D6BB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "EC44C32576DDC549CA9A38E6739EBA8D6489"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "63B17F15401E024AC64BAAE22A8EDE9767A7",
                        "defaultText": "로이스 발리노르 경입니다.\n무엇을 도와드릴까요?"
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Finn",
                        "name": "C11A-2b_line11.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "1EB7E5936661A64C77196BB4190FCD183D1E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "AEA7646C5354D348478821A3272A935FF9A4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "9E3B9F855742404B6F0AAB78133FE58A7D22"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9B80384D2A38A84D766AAD028ADB6A6DC21A",
                        "defaultText": "정말 그 사람이야!\n생각보다 훨씬 젊어 보이네."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "11C1AF85472E4744507B6990E9CB0AD7ACE4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "CB134D045C8FC348EF383DD18D0AA856CEB1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "ED35696B17EDC841848B7F24B0D460A2F660"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C2E4C7249792E445DC29E6192377F02EC1D3",
                        "defaultText": "발리노르 경의 용맹한 활약은 들었습니다."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C11A-2b_line13.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "54084389321FE14EF418C9B57EFBD0BA4067",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "83D51F9B848598471088AB51D76EE2636E8F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D638879A575CC646D9484A9324813853B8C4",
                        "defaultText": "저희 정보에 따르면 이 마을의 성기사가 악마의 세력에\n맞설 무기를 찾도록 도와줄 수 있다고 했어요."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C11A-2b_line14.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "1CE0795B9FF78545A64A7A67D4CE0A7AE96D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "AB02E2ED7AD3C34634899BB40975DDC2BF2F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "C6A7A7BF4B54A44D0C9B2841A68ABFE616D9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "90BED7CB6F05B445FA5B2A1249881692DE79",
                        "defaultText": "그게 접니다. 맞아요."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Finn",
                        "name": "C11A-2b_line15.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "05D559DA9432844F9E4B4774B5BE83C28361",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "6AF573988DC8E841721BAC51673794EB598F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "D8B5C6F343F315451C59A845A282A1E874CE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            2
                        ]
                    }
                },
                "indent": 1,
                "uid": "9B779AC840D0794EFA5BA227936FCBD97470"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "02AE68F41F4B804FC70B9525BB6F25E064BA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "25A4BDBE81DA9748CC6B7921E64988DD8537",
                        "defaultText": "음... 이봐, 친구. 그게... 대화에 좀 제대로\n참여해 주면 안 될까?"
                    },
                    "position": 0,
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cristoph",
                        "name": "C11A-2b_line16.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "4F0B4239281EC4486459CA645A96B6308886",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "7AE33B859E94C84C146B1C870AA973F24984"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "4C69A2F358A8D841F46A4F37BAB5512D0DE9"
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 1,
                    "idleIntensity": 1,
                    "lipSyncSensitivity": 0,
                    "fieldFlags": {
                        "breathIntensity": 1,
                        "idleIntensity": 1,
                        "lipSyncSensitivity": 0
                    }
                },
                "indent": 1,
                "uid": "500E731D6ADAD347333A6914099DCA2E69CB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F6C68D1D8541F34FFE393DD2C34AFAA02EC9",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Finn",
                        "name": "C11A-2b_line17.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "1FB2AD5729530747092875E7CD3DA2023365",
                "expanded": true
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 1,
                    "idleIntensity": 1,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 1,
                        "idleIntensity": 1,
                        "lipSyncSensitivity": 0
                    }
                },
                "indent": 1,
                "uid": "7489C3CF5A98374388194EF285CD7A3188F8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "951C28917F367444D08B919319DDD1114DE5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CD50690D7A75454F2299F9F6C5C004FEF1E0",
                        "defaultText": "물론이죠. 아마 저를 믿으셔도 될 겁니다."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Finn",
                        "name": "C11A-2b_line18.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "1818272F4D37C348EA892811B34C655DBD14",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "ED89EAE16E92054A754AF711CC635CAB1EB8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "EB2219117BFCB44E4E5B20C2C526C3279489"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "A145F84C1A37F840FA9850932E54F58CB7D4"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 42
                },
                "indent": 1,
                "uid": "6EA7A553775CF6491338981182E4EEC62280"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "model": {
                        "name": "Finn.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 800,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 350,
                        "y": 30,
                        "zoom": {
                            "x": 1.5,
                            "y": 1.5,
                            "d": 1.5
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 36,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 1,
                "uid": "82750A9E3B0E944D4348C565DDDB01D2B098",
                "expanded": false
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.7,
                    "idleIntensity": 0.75,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 1
                    }
                },
                "indent": 1,
                "uid": "5D33D64A3C60334A3648C623AC5AD21E9405"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 78
                },
                "indent": 1,
                "uid": "FB62E55D604A9245FE8B0894997B3480969F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "AC62EF094CB22542BE493D14071EB57CA2FA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "9A54D0EB8E93A84511680AE3AA9AB78A46D0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2308B4C416BF17487479BBE05EB6916CC48A",
                        "defaultText": "참 특이한 사람이네... 사악해 보이진 않지만\n어딘가 마음에 걸리는 점이 있어."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "F48E91E348336444DE3A96D247F174B9943D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "9D1468E15E498744B6681F98ADF74205F8E0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "A64B41FC6F82E342225BEA15A10105609621"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "56A6D3D28204304F444B3231450F77D391F0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2E94CA97882C5844092B7464B0103F3245E8",
                        "defaultText": "용서하십시오, 발리노르 경. 저처럼 성검단 소속이시죠?\n성하께서 저희 상황을 알려 주셨을 거라 생각합니다."
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "91BD9DBE0B5F9749134A824606C2B7409254",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "1E699A4929A03441D55AD124BD8AF4924025"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "C023D06147E4B54E4A3B30070E124FB0907F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": null,
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Finn",
                        "name": "E3-Finn_line12_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "6BE44B5791BDC8428F19AD9804151D76C994",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "115FC34D843874472D3AF6F76EB79F389AD5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "6525A2DF93CEC14E00791DA86797AB48FBC2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8C6C1B855A33384D00284B014B5B0C7E8E59",
                        "defaultText": "...오르니에르 단장님, 오랜만입니다."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "0C938CB164FCB2479E3A0461B7DE5261C454",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "431A42F46B70B14AC71889B1BD9702D20751"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            2
                        ]
                    }
                },
                "indent": 1,
                "uid": "6DE09FE5723AD24EC66896747DA7B8AE4C3D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "98EA1CA8795E53492C1B6BE366FFAB51A406"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "231C685581FEB3459F59A3317BC7F0306BA0",
                        "defaultText": "흐음..."
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "C3C96F594E45C94EC5180A4160719BE9A1BE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "00C660CF49D66741694B77F1F13D79AF30E8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "47B6BF3E96455447417AF484B128CE97338E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3E2C05E42287D24D6F997734B494A26F26FF",
                        "defaultText": "니니와 아는 사이구나..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "CC4B04AF6CD43643E789CF81CD6BBADACDE3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "BD598CB916ABC2423159F1328C27FD37A9E8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            4
                        ]
                    }
                },
                "indent": 1,
                "uid": "39B77C4364C5E347F46A2A88A9E6027D2B93"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "76BCA61538FAA941BA2ADF9330196EF66994"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "00ADBB0D240A564975683594D5097F81CBCE",
                        "defaultText": "“발리노르 경”이라니 무슨 소리야?\n사크레필리에에서 만났을 땐 농담할 사람이 아니었잖아."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "4EA966BB8E6F9741A04BC822E162720A2FFE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "B4993457833614425A5AF1D81ADA7B8821BD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "BC01C7FA1E1A1449132866A7F6AAEE439E4E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7221A60B32A61049954B9C34FE4AC3C74396",
                        "defaultText": "저... 어-- 좋아, 이거 어색하네."
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "D0B30AA108AAF74A5B48F1C65552A2E4D686",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "C96B74C779CB5841907A14B58BE7D0B49B1F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "ECE84A889D2D544DEF1AEBD640D0E4053CCD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "124B82691FD63643545878579B728FEAFCE8",
                        "defaultText": "그게, 이 사람의 기억은--"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "5CE444498D13954FA98B312421F99A575C85",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "32FC50C669C6B847B5192799D5BA2C9F7499"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            4
                        ]
                    }
                },
                "indent": 1,
                "uid": "7F45892376A614466A2817F6ABC9A944F7F7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "9D30AA5F0E800343224A70013F4EFB99D191"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "EF2268492932774A07390097C0C652626AE8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 19.2,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C4987BF3284C404C495A7C825D0156F5280F",
                        "defaultText": "하, 농담이야. 설명할 필요 없어.\n대모님께 그자의... 기억상실에 관해 이미 들었으니까."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "9DB136B48FCC3347D338ED862C21B2DE7832",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "57B351357893A344F088E5F4C6625FBCA5BD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "75533EF581548845EA4B6D030F045EBE33C1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": null,
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Finn",
                        "name": "E3-Finn_line4.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "B4A7407E6159C143E4281C33605A560DDC15",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "F947F9389859B24AC6494CF87B34C55E1390"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "26F5E9559A455249352B05B0BEF8E223CD3C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 19.2,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4BBD88AF5E9EA349F3595DD3BB5615F772E9",
                        "defaultText": "적어도 내 이름만큼은 기억하길 바랐어.\n예전에는 함께 훈련했거든..."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "5D19F6325529F7444E795D77438EC3FA24D8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "1F65994A18F4A842215A8560ED1F7F8B2281"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "153645F967A6554E2D7922399F3D125E6E19"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 19.2,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3A3C40A437B8D646A00AFDB69C63EBEB67F6",
                        "defaultText": "정말 죄송합니다. 예전 일에 관해 기꺼이\n이야기를 듣고 싶습니다... 나중에요."
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "59A0A6B35E4D5440B17853779A5DDEFFB3C2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "6E2184582C48B34B52787CD030E92E315B2C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "C4AFDBF4885C8440CC483B33CBB9E4611987"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 19.2,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DABB1F81274DF647E98A67B27E03A59AEEC0",
                        "defaultText": "“나중에”라... 물론이지.\n지금은 더 급한 일이 있으니까."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "F076FEEF567761408038579440D2459AAF6E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E59A303A3D8C3844A22BF8F271079A0CACE8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "BF1AC4BF73F6344E6F68F7D231733F6F948C"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "C6BEBBFD3AAD894D048B35B2496030695BFC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "74CCF6E85A4FF9401E8A1CD81449A537DADC",
                        "defaultText": "대악마들을 찾고 있지? 그중 하나가\n이곳에 숨어 있다는 건 확실히 알아."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "4DEE19D46581E64A9B589B76369C45664219",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "918616C62A241545638B3970303C56C69674"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "69158E8A1EAA284F707950534A701CEF278E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1AAF66EF6B892143B82BB808B9E0776CEE2C",
                        "defaultText": "정말? 굉장한데! 어디에 있어?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "83D0E5A81B55294F0719E39533D073EBAA92",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "6F69B0A58ACE9445AA7AA4987FFA48E49174"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            4
                        ]
                    }
                },
                "indent": 1,
                "uid": "CFDAC5CC2013B54E2A3BCA93E4187634C909"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "BBE8D2A37BE47446FC5A74C57F6CD5F3E87A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EC9C182C10810148239AB7E6EA7EB488B2FF",
                        "defaultText": "몰라."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "DD6888C52DBDB147740B83A4873288DC4F18",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "B01C3D1C560CA2481B798FB104CB127E64D9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E8E5629C1FB4B34D817A0668646D14156866"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 1,
                "uid": "2C834ADF71793343813AD0D4E088D21BD1E0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "0A2ECBF2674E3545951B6BD9D99CB8FDC9D5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            4
                        ]
                    }
                },
                "indent": 1,
                "uid": "4D5628C14EEFD34C725B3DF33F2A0ADBB0DD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "BF4FFCBF8E66024373085392F20EBC0759A3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": null,
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Rya",
                        "name": "E3-Rya_line18.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "038E9585559F654E2C3AC9C269DF99805CBF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "517C0F6C1B23F341AE287A73B60154BEE485"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "F2A62AB08941084D7B488931C70F3A932DE9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "77197E63763D86448619CE72EC8FFD311D0E",
                        "defaultText": "뭐야, 기대 이하잖아."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "65D4F5101A6904494A290A12E92BFE8A9D61",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "5764D7835EF6514B408A09D2567309224337"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "7D5C61254FA27244FC58F5F7F77E0412F980"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2E86CF0160A5B5417C586BB1AC172A3B452E",
                        "defaultText": "말을 끝까지 들어..."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "B36865C974EA0746F37A61338A750DEC5696",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E266CB5B3670E84DDF7B1FE4DB9CEFECC934"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "EF2D29E31649F14AFF7A2E9918CDA8805F66"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EE4C506A2486F541239BEC7872133830A904",
                        "defaultText": "근처 숲에는 {SP:2}{C:1}특별한 재능{C:0}을 지닌... 남자가 살아.\n네가 말한 무기의 위치를 알지도 모른다고 들었어."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "36B1407E55C98241468A7D7548BBAA8AC41D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "3A02B08E72198546053AD7A8649D5F38F0B7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "3CF4CD1326902544141886573EA3E689AD44"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "AC12C6E26175E7476C8829461CCFE77F2C50"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "696ADF9534D4094E8749A9D141FC294D60DD",
                        "defaultText": "여전히 모호하지만... 아까보다는 훨씬 낫네."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "4151EBB14DCB024CCF293DA69D24AD893207",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "981306089CA4F641CD39BD38D708BDE46F9B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "CB2935AF6050424030582F90563E7BBAD033"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 1,
                "uid": "F1E0056C1B955841687A771343D7446CA59D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "741A525C3454704A7788E216EACCC66E32D8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "88933EA860524542C36880996FEF4A0B2689"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "68D5E77A3CBC86489F4BE0E53E9AD892F469"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "880EB86980D6104784885A2707F5E1E9B89F",
                        "defaultText": "역시 같은 성검단 기사답군!\n정말 믿음직해."
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "7A78A3528E673145CC199D6799A6FF3D44DD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "5EC21D295D207942C329CC017C849CD31D89"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "A8BA37368578554EE37A1773C4051E8F8A69"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            4
                        ]
                    }
                },
                "indent": 1,
                "uid": "F0BA25F63B03A242A0694BA58E1C8593F57E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E3C7447F62C7A54FCD887E351F31F20CE385"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CF4218C467E13340E29A7959D052C00A52D4",
                        "defaultText": "잘난 척 좀 그만해, 오르니.\n넌 도움 되는 일을 거의 안 하잖아."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "F5AFC7A57DFEF0440E98A0030207C481D614",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "530B26291A81F74AEC081C775305D5210603"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            4
                        ]
                    }
                },
                "indent": 1,
                "uid": "C6ECCA5C265C04437F6A95A2BA17AE0F6DBF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E654D0957CC5F84C9A982E464D4EA8A68380"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "189510EE0CF5404FD8282FB4FFCED8B69B7F",
                        "defaultText": "계속 놀리면 내게서 마나는 한 방울도 못 받을 줄 알아."
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "FDB9D28659A6E4498A39A443197B4B13ED3F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "6DDF3BD515AB22426E9943404E91DDFDB911"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "AE34566E79E845465D485336E9B1C6C2FA8F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6F858A357BB27740406B0DA3F077D244B0A2",
                        "defaultText": "헤헤! 또 저러기 시작했네...\n둘이 어떻게 지내는지 조금씩 알 것 같아."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "CF2129A76DBA194D27481BD2AF066E0EFBAA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "C97D220C676CC146A54B8925EFF58C674296"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3003AB9577A8854AC69889A6882D7308208F",
                        "defaultText": "어쨌든..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "9A7BD4F89EEDD54F7489CF479B4ED418DE2F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "5133A76F2220E74F0D8B0826387ACAD1C492"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "D5FB5BF786C30247897A65B79CED9583DFAE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "1A2DC6340D9C0740988B359832550BF99748"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "04FC62BA4AA6D74A5299340475819F546C9C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": null,
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "E3-Shiori_line31_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "23CA66EB8CCAF54FDD6A7615EC85CAEEA63D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "A2A9CE7C26E0784E685BDD28862A245535D0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "619405752743F74C461ACBC27045FEB21D7C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FF907BA35E8EF848F04A5047651C1DB6DD1B",
                        "defaultText": "내가 맞혀 볼게, 로이스.\n그 정보원이 정확히 어디 있는지는 모르지."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "FBB53E9D0733F14112790BC7AC2D701AA6D7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "574BC1B000D8B349B95BA51654B4FD7A5C73"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "23783FB458823144C0696A82EF3FB6CB5124"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "73656BE12A5F804EC53AD6F1477EB90F90DF",
                        "defaultText": "맞아. 게다가 지금은 괴물 때문에\n혼자 그자를 찾기에는 너무 위험해."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "3803A4D22B509248088B8948F7BBCD31EA58",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "CDDAF4FF914474439C3AECF3E3940E8DDB8F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "8ABD98F26128F443564BBB729379DE9B50C0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "BD4A54A18B4AB74E8B8AD65345BCFD2C4149"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "78DECD5D3024784BFB884E86E19F396DBDC4",
                        "defaultText": "그래서 우리가 온 거잖아, 친구!\n힘든 일은 우리한테 맡겨."
                    },
                    "position": 0,
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "D7C052675581534E955874A682B2494940E7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "F45F91A408E6C64B6A4A7A86A79D6C1D0241"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "CF396A695EAC264BF6697DD34C7460029EB2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": null,
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Finn",
                        "name": "E3-Finn_line2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "59BBB53A4EEF184BDC2856920064A5C2EBEA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "F81ADB84914DF4412F399F24A58773BD8E11"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E650A7A68CC206447A7920934C15BEB5AAB0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B0C9005834D7B7407878B6023D3FD0B91FE1",
                        "defaultText": "내 몫은 내가 할 수 있으니 걱정하지 마.\n직접 보게 될 거야."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "352111EF34A684442049BBA4C221EAA3E9FB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "FB5863441059C545094B5576F9D7AF201C89"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "58256D803AF512413C38C906D2BA504000AE"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 33
                },
                "indent": 1,
                "uid": "93DBFEF6419133453D699C14044722C20D6B"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "C32114CB201FE34F845AEC640078768F4C47"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 33
                },
                "indent": 1,
                "uid": "B7B56D081168494CC54907724B65DFABDF4F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "422B49CA8A63A04CB338ADD9E56A9BFB25A0",
                    "parameters": {
                        "values": [
                            "",
                            {
                                "lcId": null,
                                "defaultText": "{C:1}Royce{C:0} joins as an {C:2}Adjutant{C:0}."
                            },
                            "",
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "CC376B1F80B391480769B3E5EA15A94328C6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6FE3C1466BE6D749E93B1A1763C2A8DE2900",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "28E3C0C32DBA314BC75810E7D4647DACE79D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "7DEFA4E056B0424037680879F6D7F754DF58",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "C8F3251E83DC09441438B507BA6F9FC12CB4"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "C43B456369B5D740BC8A3F24EEEE8CB68114"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D86A0B755C3931407F0ABD74F73B1E1241A9",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "EF5FB65011420248E34A79516F0080BF3723"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 1,
                "uid": "C0DB942434DD834E48091106D36488CA5868"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "DA048C7E6697C7481188AF30A50BC2CCAA55",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9"
                        ]
                    }
                },
                "indent": 2,
                "uid": "E8EC645D848DE14BBD5BD14874BED42BF1E9"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "\"Royce\" joins the party!"
                },
                "indent": 1,
                "uid": "715C1C245B10414D6F48502555926FFBF7B2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            5
                        ]
                    }
                },
                "indent": 1,
                "uid": "3725B2B95F49544B10380B952B29C2FBC2D8"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 1,
                "uid": "7A29C8F05D142942527B8FF2821EEA0999B9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "2CBAFA5A4B29A140CD4A1CA7D187004D33CA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "FAF9FB614CBFD24BA319C447B6CCCDFF4089"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6EE2314A87AC11479C1B5FD4AD9092E6F5BE",
                        "defaultText": "참 특이한 사람이야. 뭔가 마음에 걸리는데\n아직 그게 뭔지는 모르겠어..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "B92DD7F32F07B74CD939ACD76FB37817D719",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "1479830E021C324A79183D252A768146D44F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E6BF0DB43F8493414639B1F380495A1F5270",
                        "defaultText": "하, 내가 무슨 생각을 하는 거람?\n무슨 “육감”만으로 사람을 판단하다니... 습관은 무섭네!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "F5C463A674329845CB693EC3F8FB29A03612",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "1016385D4DF29140C46B4C30D16380BA7FE7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6D49857C2CB73443365B7C4197B26544856C",
                        "defaultText": "내가 너무 깊이 생각하는 것 같아.\n숲으로 가서 단서를 찾아보자."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "3FD6BD664454B24EB32B7714BB54CC6FCA7A",
                "expanded": true
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Royce disappears from overworld\nYou can now go to the Encampment"
                },
                "indent": 1,
                "uid": "1B0F655221EF8146C86BC172324AA48EB412",
                "expanded": true
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "r2",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "DD44563C79A4E842CB593097017E1AACE4B8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "86E321048192F44CF38A6C544924A03B2A07"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "081E1EAD334EA74AA10A00548EBCCDCABE7B"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "r2",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "780F9E7A7B1EB44B1A2BF745F77F41CDBCC5"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Flag locale 6",
                        "index": 165,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "0D37CEA65C260847533BBF437EE803F2EEBA"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Flag locale 6",
                        "index": 165,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "BDC70CD74611D34E3F4AEDE48CBF2D0BB516"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 2,
                "uid": "117691FA4890D840DF0A353799B4FFEDAE94"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1BD8725E0D9E344CE22BA0F8C56A41689C28",
                    "parameters": {
                        "values": [
                            "Encampment"
                        ]
                    }
                },
                "indent": 2,
                "uid": "5FF8A37A199AB345DB1A4CD1C513522488E1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D1D322CB2E2602402C88D2428C77C01E35E6",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 2,
                "uid": "21F2FA537278C341EE78AFB4613877ED306D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "DDCBE3494B66564B7A79781394738F395645"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "B8FC62C375AE6144F33820A16771A2ED3A53"
            }
        ],
        "livePreviewDisabled": true,
        "booleanVariables": [
            {
                "name": "read",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "r2",
                "index": 1,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "stringVariables": [
            {
                "name": "name",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}