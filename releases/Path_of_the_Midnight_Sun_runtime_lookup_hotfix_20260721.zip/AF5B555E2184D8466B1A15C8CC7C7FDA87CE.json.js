GS.dataCache['AF5B555E2184D8466B1A15C8CC7C7FDA87CE'] = {
    "uid": "AF5B555E2184D8466B1A15C8CC7C7FDA87CE",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C6-06c S1 Chest",
        "type": "vn.scene",
        "parentId": "C7AE323A747A524EA36A5A08731F448A3599",
        "chapterUid": "6C9C582F416E10408F5A6150A01276B7C148",
        "order": 0,
        "localizableStrings": {
            "010EBA15372F95418989E85792A96E330558": {
                "t": "There's a chest here, and it doesn't seem to be locked. However...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "4AB366732B6AD441EF18C5754DB8077807CD"
                }
            },
            "3F82B1370E7C4741126B0E743F444C8A75A0": {
                "t": "Woot! Woot woot woot!!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "F5EF1E081A1818451A19FB75A76232526A75"
                }
            },
            "BDBCE67E24D5E04B3E1BBA86313FDC621194": {
                "t": "I'm getting a nasty sense of deja-vu regarding it... Have I seen a similar chest before?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "4AC4B7EA10FBA043E46BDCC9C4A001D7A334"
                }
            },
            "7B9696A5347DD74C916AD28335AE8F37E9F2": {
                "t": "(Let's open it.)",
                "d": {
                    "eid": "81744B563500D44B85382AE3480D863D3CCD"
                }
            },
            "1984F9599799044DFF5BF3323FFA4A99925B": {
                "t": "(Maybe later...)",
                "d": {
                    "eid": "6C1591B1677192456F7994D0F6EA0DFC787C"
                }
            },
            "986326A8048D3540444A79F721BC277CF86C": {
                "t": "Woot?",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "79DD1BB75D0B2441FB5B7FA820231AEC7053"
                }
            },
            "EC739FF929E2124D0F283661BA1740C354A8": {
                "t": "Woot.",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "137F522852A1F74FC79BFED71661E6A21920"
                }
            },
            "95C56B485769774AEE59F796CDF4E8BFCBF6": {
                "t": "Yeah, don't judge me. I don't have a good feeling about this.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "611A4D918B72A14AFC397672FBD3B15C821C"
                }
            },
            "66B8142664FE68440C6979E445FDAC439815": {
                "t": "There could be a whole world inside chests like these, but you won't know until you open them.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "340AB9B015B1D94B7A088E572F4709DA7DCC"
                }
            },
            "EEB024EA78AC834576999EB1D550669E8B15": {
                "t": "Woot! Woot woot woot!!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "7A0854DD3A81314600395DC102D78CA2F391"
                }
            },
            "936EF41054D4F747CE4B42B95244A7BE2AD9": {
                "t": "Oh, gods! This is...!",
                "d": {
                    "cid": 0,
                    "eid": "B20AF12D1AD7D54EDC2895F5C4759388F2E0"
                }
            },
            "68D57B2E83FE65497C7A66E3F5214BEA8B78": {
                "t": "... ... ...",
                "d": {
                    "cid": 0,
                    "eid": "7E73325B579F224A9039342448A259AB1D9E"
                }
            },
            "25337B334A33A24F851835261FD73FC05D4D": {
                "t": "...an actually useful piece of equipment? And Gold?",
                "d": {
                    "cid": 0,
                    "eid": "ACCE2E81836726486C3BDD972713114B37F7"
                }
            }
        },
        "commands": [
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Flag locale 4",
                        "index": 163,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B53DD2E964FAD54FE10B34220C711688BF83"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "second time",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "58D38C77716F354C5B1B34C1731646055B5C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2E95B2031F00F34856090B562ADD83E009CA"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "read?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F893071B0665674B2E380E598430225574D5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E35A637F2F9DA44AC928DEA082B0BBC27F24"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "010EBA15372F95418989E85792A96E330558",
                        "defaultText": "여기 상자가 있는데 잠겨 있지는 않은 것 같아. 하지만..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "expanded": true,
                "uid": "4AB366732B6AD441EF18C5754DB8077807CD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "7BBEE5D041782540FB7B7271A490CC23068D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "7FDA90D2465598404A19B9E7EFD50EB60C98"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "AA42384482DD12417D789BA7A11D7045EBD8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "BEB4609A201DA64B427B77C4C5A31783216A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3F82B1370E7C4741126B0E743F444C8A75A0",
                        "defaultText": "우웃! 우웃 우웃 우웃!!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "F5EF1E081A1818451A19FB75A76232526A75",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "73DE514848BFB140AC892AC3B7CD834E8B20"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1BF70BCB35B5C74477585AC497BECCF8F5AF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BDBCE67E24D5E04B3E1BBA86313FDC621194",
                        "defaultText": "불길한 기시감이 드는데...\n전에도 비슷한 상자를 본 적이 있었나?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "4AC4B7EA10FBA043E46BDCC9C4A001D7A334"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "507091BD5A00F44B2E386F74B250BF600F21"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "7B9696A5347DD74C916AD28335AE8F37E9F2",
                        "defaultText": "(열어보자.)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "81744B563500D44B85382AE3480D863D3CCD",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "1984F9599799044DFF5BF3323FFA4A99925B",
                        "defaultText": "(아마도 나중에...)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6C1591B1677192456F7994D0F6EA0DFC787C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "open",
                            "not now",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "05EEE8C464857344F05BC8492FA7D78E0204"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C0543D8D3E6AD64B3419CAC475B110685172"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "open"
                },
                "indent": 0,
                "uid": "8FB37B542138294BB82A78F60B365BB9A564"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Exploration",
                        "name": "Chest_FARATRAS.ogg",
                        "volume": 100,
                        "playbackRate": "100"
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "457147F5256C02487D5820F63D0954BF15DE"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "scene"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 8,
                    "blendMode": 0,
                    "zOrder": 0,
                    "duration": 0,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 1,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "8) open chest.png",
                        "folderPath": "Graphics/Backgrounds/MAGNOLIA/Fort Corridors",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "429C7D6E7A50F84C41689494A6EB531D4603",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "3357D07718671548B9991D01EB86E321C5CE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "1C7F27594ED8D54002791BE80053EC96D827"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3677ADBB3340D24B9879C367276D67E055C6"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 114
                },
                "indent": 0,
                "uid": "7D21D6698E785148448A8C34F599C97676B9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "A5CD3C3B352843410338B9731325131A7FD8"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3EE1AEE27CC72842200AC625DDF4EF524EA3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "500A588217C377421D28C5A211D9C118D4A4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B24755E54AF5624A2C5857265A8B0D853521"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "F83202AA56BA7549D02B209316E37C0E790D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "942A570254DE71466A49C2625C465181FD84"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EEB024EA78AC834576999EB1D550669E8B15",
                        "defaultText": "우웃! 우웃 우웃 우웃!!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7A0854DD3A81314600395DC102D78CA2F391",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1E9C0C6D5708904A639B155148D6EC218643"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3A6B164B35D96646B18A0983818A2174A52B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "936EF41054D4F747CE4B42B95244A7BE2AD9",
                        "defaultText": "신들이시여! 이건...!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B20AF12D1AD7D54EDC2895F5C4759388F2E0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "757117088F43C340F67958E9E7D42817B3B6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "68D57B2E83FE65497C7A66E3F5214BEA8B78",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7E73325B579F224A9039342448A259AB1D9E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "60BDBFCC1C7F734FDD79B7616A1C0C0D7E47"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            5
                        ]
                    }
                },
                "indent": 0,
                "uid": "857A4651734BE44B66385D89F935E6D594A0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A15FDC457504D84B4D1957673002367738D4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "986326A8048D3540444A79F721BC277CF86C",
                        "defaultText": "우웃?"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "79DD1BB75D0B2441FB5B7FA820231AEC7053",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "254C127B822C5347C48A34E8E18E715939F2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "77BBA11A70CB4948377838D9648CE77ACFC8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F8D4D5682FFAC146AC8B7A600FDF91F9CDBB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "25337B334A33A24F851835261FD73FC05D4D",
                        "defaultText": "...정말 쓸 만한 장비라고? 골드도 있잖아?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "ACCE2E81836726486C3BDD972713114B37F7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "B8CCDCE441BCB447BD6BD564CF47A8630F2E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FE8209DA18DA9246CC58D39390F0166F87B7"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "ACE8627A37D1964484996218BF75431E93D0"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "reward"
                },
                "indent": 0,
                "uid": "43C57AE732A34044E61A4529186F91760FF5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0311BE5092E2034F93688BB62C6E859C7032",
                    "parameters": {
                        "values": [
                            "9E11144D9E18A146655B993045B86ADBC430",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "8A0EF277650B124BC419AA12B03EE7BC5A89"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EEC637476CA0C44DB639DD3814A41B3AF9DE",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "65FFD9F58D0FD442AA1ADA885129314FDA1B"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "6879F1BD459562493E0A61B7E130BB4B6FD3"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "SOLDI ATTUALI",
                        "index": 247,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 1,
                    "source": 0,
                    "sourceValue": 2500,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C1C03CD2150BB14BAF19D783943396E6AED7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "422B49CA8A63A04CB338ADD9E56A9BFB25A0",
                    "parameters": {
                        "values": [
                            "",
                            {
                                "lcId": null,
                                "defaultText": "You found {C:3}2500 G{C:0}."
                            },
                            "",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "816E61ED5D94D5405B8A1701E3A6A5A42EAF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6FE3C1466BE6D749E93B1A1763C2A8DE2900",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "BBEEC5B95FD2684F104BC58104F77A779B5A"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Flag locale 4",
                        "index": 163,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7B8A06D54F94614BAA0A71641E6C0D8B1340"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "AA131493965B7148FF4A0CB8B3778F813EC1"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0561EEEC3178A74D489ACB0990B20E0E8BFD"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "second time",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "E38F830640D5864E6338A1541D0903E68FA3"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "not now"
                },
                "indent": 0,
                "uid": "A378CA28315A0145E0487334CD73B2ED33AE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "EA9D28B62572C445AE2B2FE1D0214F7FB628"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "66DAC64777121644294A5DA4D05C890799B1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EC739FF929E2124D0F283661BA1740C354A8",
                        "defaultText": "우웃."
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "137F522852A1F74FC79BFED71661E6A21920",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A9F54CE24B75F34F319BE0F5446C1343DFD4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "412458C11D08714E023824E563A2ED129DD6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "95C56B485769774AEE59F796CDF4E8BFCBF6",
                        "defaultText": "그래, 그렇게 보지 마. 왠지 불길해서 그래."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "611A4D918B72A14AFC397672FBD3B15C821C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1148036754E2994C210B6749EEFEAC16E090",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "DD211CF32AD6924AA81A87F9BBAF788534BB"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of event",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "9D5EBCA617CE334A4419E5C73F07A552F773"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "second time"
                },
                "indent": 0,
                "uid": "6641E68462F2F44C3648D477F9781AD06852"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BC37FF3D7FCEA14190182357010C15153316"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "63C24FC13E97A740551BC5E1FBCA68755E2B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "66B8142664FE68440C6979E445FDAC439815",
                        "defaultText": "이런 상자 안에는 온 세상이 들어 있을 수도 있어.\n열기 전에는 알 수 없지만."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "340AB9B015B1D94B7A088E572F4709DA7DCC",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "end of event"
                },
                "indent": 0,
                "uid": "B98334459BA54247867B990178166EA1D5C3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "B0A102BF63DE984A311BDC74961083CF0FE0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "67ACC1A65B2CC9451F79CB929077F08CB610"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "read?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7FE1106740F0A442942BCA067ACC58FC43A2"
            }
        ],
        "livePreviewDisabled": true,
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "read?",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "opened?",
                "index": 1,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}