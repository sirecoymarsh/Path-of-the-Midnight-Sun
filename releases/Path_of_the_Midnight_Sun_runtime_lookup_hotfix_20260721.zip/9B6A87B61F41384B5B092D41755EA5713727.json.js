GS.dataCache['9B6A87B61F41384B5B092D41755EA5713727'] = {
    "uid": "9B6A87B61F41384B5B092D41755EA5713727",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C8-03 S6 Barrels",
        "type": "vn.scene",
        "parentId": "9EB64CFC7728714424485C47734682ADAFE5",
        "chapterUid": "823DFD145789F24D466B6858151B6EA2F9AB",
        "order": 8,
        "localizableStrings": {
            "3B21BDF86F9CB74C1D2B9A75124B162CBF30": {
                "t": "I don't know why, but I feel the urge to check these barrels.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "A01F7094300959429A28A8655A682B7312B0"
                }
            },
            "9D7A56C41569574F81881805BB7A380CE3D8": {
                "t": "Hey! What do you think you're doing!?",
                "d": {
                    "cid": "FD0D221037AC2447211BD16590951D3E4743",
                    "eid": "59F15A596788D84DDB6A5001E3AE03BBEE58"
                }
            },
            "39B776225DE1654EFB8B9141632FDED0DF25": {
                "t": "We're checking those barrels, sir.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "4588D9022B42F64080698277FFB314143A3D"
                }
            },
            "D402D53E41E5C340B6981BE39476F5D790B6": {
                "t": "As if any honest citizen would ever do anything that pointless!",
                "d": {
                    "cid": "FD0D221037AC2447211BD16590951D3E4743",
                    "eid": "8DE838E951CBA6410B190624D5C55AA486A5"
                }
            },
            "D62440F37A76F94D751BE19529E361BC1A7D": {
                "t": "Forgive us. As travelling artisans, we were... impressed by the craftsmanship of these objects. It won't happen again.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "C3BA1B19816C784F8B2A9EF84CBC761D7BEC"
                }
            },
            "5354E2938B5BF8449008DD28CEEF91A1B393": {
                "t": "You aren't getting away! CATCH THE INTRUDERS!!",
                "d": {
                    "cid": "FD0D221037AC2447211BD16590951D3E4743",
                    "eid": "141DC5743C61A843883BA054466A5DDC81A0"
                }
            },
            "3BD8BB63355FE7451F4BC4A5BBFCE0AE7365": {
                "t": "Tch! People nowadays sure are crazy.",
                "d": {
                    "cid": "FD0D221037AC2447211BD16590951D3E4743",
                    "eid": "B0BE4DD11734C24C85386DF5B72E04663BA4"
                }
            },
            "6EDCBD647DD0654A8398EF121E039EECB2CC": {
                "t": "Wait, is that... the toy that child, Scott, was searching for?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "D383FBCD3B5182460939C474D139E974671B"
                }
            },
            "62EF598D12EA464F93190522420ACC4C4C4D": {
                "t": "Why do you seem that interested in it?",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "B708E3A29C5FD1440A7A3B001F174D7786DB"
                }
            },
            "0D77CAC66136C747520B036412C7C884A3D2": {
                "t": "Let's get Scott his toy back, quick! This is a matter of utmost importance!",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "CE3ED45353BC1744DF783245FCCFB876AC53"
                }
            },
            "BC20CD038306614450885E27F76BCC183FBE": {
                "t": "Er... Lady Faratras, are you... okay?",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "1234AFE62A8D334A245A8EF41F8E9DB2733B"
                }
            },
            "6A4C00F06B87524DC25BB8B203F30A351597": {
                "t": "Scott's toy was here.\n... It's not like I liked it or anything!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "46F055765A99354A15998C2506F127EB762C"
                }
            },
            "E03F88A68859644A62897E36712FAF64ED1A": {
                "t": "This hair, this outfit... I think I know this character!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "6DABE6AC409B88439978DF75CFB3A543C1F8"
                }
            },
            "ECF26B394DAE8544AD489164CBD0F72D7886": {
                "t": "The guard is gone, so I can take a look at these barrels.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "3EBAF09764D7514F8B7A2C75D2ADC9B737C2"
                }
            },
            "0F57405971441748C3299F266CB6199F33F9": {
                "t": "... ... ...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "1E8B434A3E5541479018A92631FF19D3FBE3"
                }
            },
            "2B1406FC0D34A14D031A334731CEBA3BB910": {
                "t": "They look... quite normal.\nWhy did they even catch my attention to begin with?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "3C773B6751B514471E097426E7322D8D4ABA"
                }
            },
            "CF4555B83F9BC549708B39A0BBB1D9AB142D": {
                "t": "There might be something interesting inside, but I prefer not to check unless it is strictly necessary.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "B6054CBF63BAA84C5538F774B90D58658DF4"
                }
            }
        },
        "commands": [
            {
                "id": "gs.Comment",
                "params": {
                    "text": "has Scott's toy in it"
                },
                "indent": 0,
                "expanded": true,
                "uid": "16F6C865408E614083387E15BC0052D28D52"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BC37117636EEA240601B8AB2428AE164DF9A"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Flag locale 8",
                        "index": 167,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6FA1334A11B7A14C3E4BB4F01F892DD11621"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "if the guard still is next to the barrels"
                },
                "indent": 1,
                "uid": "DAEBBE16397EE547F13AAEF5AED79428DB15",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "5769900A08FDC2478519F3727100C13DA165"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3B21BDF86F9CB74C1D2B9A75124B162CBF30",
                        "defaultText": "왜인지는 모르겠지만 이 통들을 확인하고 싶어."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "A01F7094300959429A28A8655A682B7312B0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "97026B0561E9F24EF53A0C63C28006F35DF6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "F9C3EDF926C31146E2194CA77E3158DBC27F"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "BC537AB42A9324400D8908376DB3C35E8E06",
                        "name": "C8-03 Search confirmation"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "7DF4C9F048E4204A6178CFC17DCC036147E7"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "3FD0717481F9514F403ADEF30D95EE648FF1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1148036754E2994C210B6749EEFEAC16E090",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 2,
                "uid": "0B3ED3994AD795491519D1E9DEA2285E64A3"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of event",
                    "target": "activeContext"
                },
                "indent": 2,
                "uid": "8F00C4CD8C426842D658C8C4C43271D5DDC2"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "FD0D221037AC2447211BD16590951D3E4743",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "CD21B4FE4957784485180E679D7B534015D7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "14CEFE6947F1334CBD5B82886CA8710B18AD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "FD0D221037AC2447211BD16590951D3E4743",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "69DF73D42362244A0F6A4DB700695C6D62C8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "FD0D221037AC2447211BD16590951D3E4743",
                            4
                        ]
                    }
                },
                "indent": 1,
                "uid": "3BB565F4133807419128B273DCA0E3DB08C0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "FD0D221037AC2447211BD16590951D3E4743",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "F907F6BA86DC91453C4A60B66715AA62F47C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9D7A56C41569574F81881805BB7A380CE3D8",
                        "defaultText": "이봐! 지금 뭘 하는 거지!?"
                    },
                    "position": 0,
                    "characterId": "FD0D221037AC2447211BD16590951D3E4743",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "59F15A596788D84DDB6A5001E3AE03BBEE58",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "B326172F37EE384F662AB718E6FC8D041ADC"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "read?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "9CA525D98E7F194CA85B741328CF674CBF92"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "read?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "17B0393E55BA4746A44A5AF649088E65916B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "AF0E5AC47BEF1749837A2304B8768BFF9730"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "39B776225DE1654EFB8B9141632FDED0DF25",
                        "defaultText": "저 통들을 살펴보고 있습니다."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "4588D9022B42F64080698277FFB314143A3D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "513017670F436044AB8BBAA69AB1CBCD34FF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "FD0D221037AC2447211BD16590951D3E4743",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "A90A346B3DB0A5492748E329360B6969A698"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D402D53E41E5C340B6981BE39476F5D790B6",
                        "defaultText": "정직한 시민이라면 그런 쓸데없는 짓을 할 리가 없지!"
                    },
                    "position": 0,
                    "characterId": "FD0D221037AC2447211BD16590951D3E4743",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "8DE838E951CBA6410B190624D5C55AA486A5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "C5401BB71CC0794D158B6942E4F9B4B628B6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "65F2282F810E3949A309284384A5311BBC9E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "0B48C19C8F7E054AB74A5D42581955E3C804"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D62440F37A76F94D751BE19529E361BC1A7D",
                        "defaultText": "용서해 주십시오. 여행하는 장인으로서 이 물건의 솜씨에...\n감탄했을 뿐입니다. 다시는 그러지 않겠습니다."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "C3BA1B19816C784F8B2A9EF84CBC761D7BEC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "A2F3EA7D2A4F1442782A86501B915A23A944"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "FD0D221037AC2447211BD16590951D3E4743",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "9E435B1863F8864FE45AB76127C9FBD63650"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "Number of warnings (Lazulis)",
                        "index": 359,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 1,
                    "source": 0,
                    "sourceValue": 1,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "4D6ACE7B0D89894FCF2AA5455F59046ABA8A"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Number of warnings (Lazulis)",
                        "index": 359,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "numberValue": 3,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 3,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "FF3F21303F2F57438F485CA1571B6BCAC33D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5354E2938B5BF8449008DD28CEEF91A1B393",
                        "defaultText": "도망치지 못한다! 침입자를 잡아라!!"
                    },
                    "position": 0,
                    "characterId": "FD0D221037AC2447211BD16590951D3E4743",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "141DC5743C61A843883BA054466A5DDC81A0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 2,
                "uid": "6AAFF6333C78034C125AA92503348B8B0EE3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "25D6F1008AA18343503A84D349C4AC65AF42"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "242B2B8D338743409148DDA3F0798B9DB0EC",
                        "name": "C8-03e You get caught! (Game over)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "16CEE9D686E28242D06BA153F29F8B8BFF8C"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 1,
                "uid": "51AE024F74EB424C564BABE839C74DDA0C59"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3BD8BB63355FE7451F4BC4A5BBFCE0AE7365",
                        "defaultText": "쳇! 요즘 사람들은 정말 미쳤군."
                    },
                    "position": 0,
                    "characterId": "FD0D221037AC2447211BD16590951D3E4743",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "B0BE4DD11734C24C85386DF5B72E04663BA4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 2,
                "uid": "0A9C8F685261E343D239AF52101781C72F05"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "150544AA710A624F7E5A1421DAC4273067A9"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "FD0D221037AC2447211BD16590951D3E4743",
                    "model": {
                        "name": "LazulisSoldierMale.model.live2d",
                        "folderPath": "Live2D/Z2 - NPCs/Lazulis",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 720,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 1410,
                        "y": 558,
                        "zoom": {
                            "x": 0.17,
                            "y": 0.17,
                            "d": 0.17
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 30,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 2,
                "uid": "8D1669D813F5C54CD97903770CA9821F4AB1",
                "expanded": false
            },
            {
                "id": "vn.SetObjectData",
                "params": {
                    "objectType": 4,
                    "number": 0,
                    "numberDomain": "com.degica.vnm.default",
                    "layer": 0,
                    "characterId": "FD0D221037AC2447211BD16590951D3E4743",
                    "field": 6,
                    "numberValue": -20,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0
                },
                "indent": 2,
                "uid": "CC60595E811E964C6D8A60F82980E70BE51E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "FD0D221037AC2447211BD16590951D3E4743",
                            6
                        ]
                    }
                },
                "indent": 2,
                "uid": "9CA10B1E8C4DE74FFB18D944D18386A584BB"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 2,
                "uid": "D8AF7F4F60B1C24EC83A1E34475731187387"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1148036754E2994C210B6749EEFEAC16E090",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 2,
                "uid": "2584A6BB8CA6F3465F7BD178CF3A733599DC"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "80144B9977EC354F8A8B55A0B0E6CD95DE48",
                        "name": "C8-03e Whoopsie (Warning)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "76C5772F2A70454B173A7A06E7955F197CAE"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "C7BDDF9E41B9924FF85857F6EB840AF23E79"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "if the guard isn't there anymore"
                },
                "indent": 1,
                "uid": "978F13D33768624AFA891488C0759FDD0549",
                "expanded": true
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "BBC7ABE825206248D0391D1235EC89FAC591",
                    "param": {
                        "name": "Legame",
                        "type": 0,
                        "value": 0
                    },
                    "targetVariable": {
                        "name": "legame",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "867A50697830244FA989BD65318DFB9E4F59"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "legame",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 1,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "A21EA8CB25330347F37A61D375ABB3B94581"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "r2",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "0E3CF0FF72AAE9440A697F95AA3EA7B4E967"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "if you've never read"
                },
                "indent": 3,
                "uid": "4BEE491D96D7F341B82A67561271003E15B7",
                "expanded": true
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "r2",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 3,
                "uid": "CC0885002AD5784A2F3AFB86C318AE8552E0"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Flag locale 5",
                        "index": 164,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 3,
                "uid": "F04DFC117EDC864C0E4BD770E7E112AC6DE6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 3,
                "uid": "0B1D92DC7BAFB74F6628E840A6BD65EB2369"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6EDCBD647DD0654A8398EF121E039EECB2CC",
                        "defaultText": "잠깐, 저건... 스콧이라는 아이가 찾던 장난감 아닌가?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 3,
                "uid": "D383FBCD3B5182460939C474D139E974671B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 3,
                "uid": "DE0023248A9D5749C48BF2741B5F0A9A949E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 3,
                "uid": "1ADF944A075A3746296B80E3727FC5D63134"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 3,
                "uid": "E4B3FA887657354D4C8B5294411E17E1E7D9"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 20,
                    "duration": 36,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 3,
                "uid": "95C563AF46B0B0467F18D7E7E696044AEFEB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "422B49CA8A63A04CB338ADD9E56A9BFB25A0",
                    "parameters": {
                        "values": [
                            "",
                            {
                                "lcId": null,
                                "defaultText": "You collect {C:1}Scott's toy{C:0} from the barrel."
                            },
                            "",
                            1
                        ]
                    }
                },
                "indent": 3,
                "uid": "5A219CEB70D81249F60A3E218A0C18330776"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6FE3C1466BE6D749E93B1A1763C2A8DE2900",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 3,
                "uid": "990A9DB52E5EC14D391A292455DDFE62B19B"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 3,
                "uid": "F0DFBAA178A0E042BE9B128499078FE6EAFE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 3,
                "uid": "E2364E2A25381740502B3180A403132C2A5A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 3,
                "uid": "7E9A7874298F824EC08BDE2261EA3A169937"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E03F88A68859644A62897E36712FAF64ED1A",
                        "defaultText": "이 머리카락, 이 옷... 이 캐릭터를 아는 것 같아!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 3,
                "uid": "6DABE6AC409B88439978DF75CFB3A543C1F8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 3,
                "uid": "8922D7DA83D3B247005ABDB67C0FB74A8C54"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 3,
                "uid": "3D0B23C52796934F2D881702B288EC58EBD3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 3,
                "uid": "BED1A5CC4707824F5B68A6E7AF92F238F9B0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "62EF598D12EA464F93190522420ACC4C4C4D",
                        "defaultText": "왜 그렇게 관심을 보이는 거야?"
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 3,
                "uid": "B708E3A29C5FD1440A7A3B001F174D7786DB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 3,
                "uid": "238328D361CC26463E7AF42475DA41034B44"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 3,
                "uid": "5A1D8AFF1DAF57497E59434008AB39D21BC9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0D77CAC66136C747520B036412C7C884A3D2",
                        "defaultText": "어서 스콧에게 장난감을 돌려주자! 무엇보다 중요한 일이야!"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 3,
                "uid": "CE3ED45353BC1744DF783245FCCFB876AC53",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 3,
                "uid": "1CB2961213FB774E207A62710FA1C432FCE3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            2
                        ]
                    }
                },
                "indent": 3,
                "uid": "7085EACD2E6BC346B7390312F2D2A22AA434"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 3,
                "uid": "887D42D37B76044C7B5B5713F1528F2E4A6E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BC20CD038306614450885E27F76BCC183FBE",
                        "defaultText": "저... 파라트라스 님, 괜찮으세요?"
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 3,
                "uid": "1234AFE62A8D334A245A8EF41F8E9DB2733B",
                "expanded": true
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 2,
                "uid": "7399E19B12AD9646BE5B51772C9FB183E4F9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 3,
                "uid": "A1B9CAA98532D64F4C583C0291E4B7549DF3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6A4C00F06B87524DC25BB8B203F30A351597",
                        "defaultText": "스콧의 장난감이 여기 있었어.\n...내가 마음에 들어서 그런 건 아니야!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 3,
                "uid": "46F055765A99354A15998C2506F127EB762C",
                "expanded": true
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 1,
                "uid": "F6FBE8F676FCF846D18992947E8B97F8EE11"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "17BB63E4401B164EA67BEB18DC9D567F6090"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "ECF26B394DAE8544AD489164CBD0F72D7886",
                        "defaultText": "경비병이 사라졌으니 이 통들을 살펴볼 수 있겠어."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "3EBAF09764D7514F8B7A2C75D2ADC9B737C2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "641F5DC022CE684A8D580F67E36D9118BEA8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0F57405971441748C3299F266CB6199F33F9",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "1E8B434A3E5541479018A92631FF19D3FBE3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "DDDE127C844F954AB5580498DE298F45F45B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2B1406FC0D34A14D031A334731CEBA3BB910",
                        "defaultText": "아주... 평범해 보여.\n처음엔 왜 눈길이 갔던 거지?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "3C773B6751B514471E097426E7322D8D4ABA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "83B545AB7D0AC44AF68887A26B79C937E06B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CF4555B83F9BC549708B39A0BBB1D9AB142D",
                        "defaultText": "안에 흥미로운 게 있을지도 모르지만 꼭 필요한 게 아니라면\n확인하지 않는 편이 낫겠어."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "B6054CBF63BAA84C5538F774B90D58658DF4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1148036754E2994C210B6749EEFEAC16E090",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 2,
                "uid": "C0DAD16A46F43847A64A6CD7171F26119B2A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "62FD1C5B975DF646440953649C357ACAE44C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "F30C6BB8255BA8440C5B7FD8F34FCC69AAA5"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "end of event"
                },
                "indent": 0,
                "uid": "7E0B116B8A2F6645F25B3246EC0C4D3EF715"
            }
        ],
        "livePreviewDisabled": true,
        "numberVariables": [
            {
                "name": "legame",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "booleanVariables": [
            {
                "name": "read?",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "r2",
                "index": 1,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}