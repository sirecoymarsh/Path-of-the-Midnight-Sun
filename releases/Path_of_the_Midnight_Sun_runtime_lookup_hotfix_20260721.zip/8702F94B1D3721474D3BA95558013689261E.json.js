GS.dataCache['8702F94B1D3721474D3BA95558013689261E'] = {
    "uid": "8702F94B1D3721474D3BA95558013689261E",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "Names of all System Messages {to GT:315}",
        "type": "data_record",
        "order": 8,
        "category": "commonEvents",
        "id": "8702F94B1D3721474D3BA95558013689261E",
        "isFolder": false,
        "data": {
            "name": "Names of all System Messages {to GT:315}",
            "startCondition": 0,
            "conditionEnabled": false,
            "parallel": false,
            "autoPreload": false,
            "singleInstance": false,
            "inline": false,
            "parameters": [
                {
                    "label": "input",
                    "type": 3,
                    "stringVariable": {
                        "name": "input",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "stringValueType": "text",
                    "stringValueLocalizable": false
                }
            ],
            "commands": [
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 1,
                        "target": 0,
                        "sourceVariable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": "",
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "You can now access your {C:1}Inventory{C:0}.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "AEC2414017E2484172785D05F430F7E07739",
                            "defaultText": "이제 귀하의{C:1}인벤토리{C:0}."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "5ADDE9A458946747D979C5B7C79305120A48",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "doggo1",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9057FB9F5D09734BEB8B2D36FFAD85105004"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "B0042F20786A934E2E4BAFA8FA33DE9B6BF2",
                            "defaultText": "분명히 당신은 지금 개를 키우고 있습니다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "F7F6481943E3F541F448DE6270CB46E9EF9C",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "Any food you had will be unavailable during dinner.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5CDC457A53661645C09BD65171641DC71A2A"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "E45A2C128AF3804F2E793B5883B5AC48F7CD",
                            "defaultText": "당신이 먹은 음식은 저녁 식사 중에 이용할 수 없습니다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "9C98F1EB641B304D670B20F7C175665CD421",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "{C:1}Suzaku{C:0} can now use {C:2}Stella Triplet{C:0}.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "DE08EF7A2FCE944FA84A04B53742D6B9EA01"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "4FD29D7728DFD34F418BB088CD0B437A846B",
                            "defaultText": "{C:1}스자쿠{C:0}이제 사용할 수 있습니다{C:2}스텔라 삼중항{C:0}."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "F0AE7C36440FC9473C7A7788EB39532A252C",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "doggo2",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E3430D0F8A50174F0B5B7DF768FFF6DDD10F"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "26D6661150342849441AB213D1A0286CE9F0",
                            "defaultText": "확인되었습니다. 이제 개가 있습니다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "5A6FC7EE6B29674EB66A0245A128919C14D6",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "New party member: {C:1}Hooded man{C:0}.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "61EEAF9444B84448766A5273DD7050ED35AE"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "C69BC3D82DDF0647902BC3A4955624979754",
                            "defaultText": "새로운 파티원:{C:1}후드맨{C:0}."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "46709ED38921674D9508A9069463624ACEC7",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "You also obtain {C:3}3000 G{C:0}.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E0E17882603E464F1559E045509816FD2206"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "44BD30DF8F3C234BF91B7463921D85DF5826",
                            "defaultText": "당신은 또한 얻습니다{C:3}3000G{C:0}."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "E2348C065721204F802843019CE4E47D8596",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "New party member: {C:1}Useless knight{C:0}.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "BFCD58C61677084FCB4A099132DD5806183A"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "2A9882333070564DD5489852F6225149965F",
                            "defaultText": "새로운 파티원:{C:1}쓸모없는 기사{C:0}."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "4A7463BB819D414FB149BDA2742750E99E3E",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "New party member: {C:1}Royal chestnut{C:0}.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "24DE5391070AB4402C699E62A791376830A6"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "460EA46605825544E52803D53C4386BDED65",
                            "defaultText": "새로운 파티원:{C:1}로얄체스트넛{C:0}."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "23F2D7F63E05E247BC19845076867F427A05",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "New party member: {C:1}Stupid hunk{C:0}.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F4C5FE1C5BF5D34F323AE58109590820956F"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "87B7AE963031204E77897959F56A6484002F",
                            "defaultText": "새로운 파티원:{C:1}멍청한 놈{C:0}."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "EC8DE1C15E34424F168817F92317E127C1F1",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "You delivered: {C:1}Potato x1{C:0}.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "828C83F0996B0248401BA1285AEDF7CE42D6"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "720136A72D90214FC95B68B9A2B539C5FCE0",
                            "defaultText": "귀하는 다음을 전달했습니다:{C:1}감자 1개{C:0}."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "6FAC4C0121473242E409EC90B24AAA8C0EFB",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "{C:1}Andre{C:0} and {C:1}Poledro{C:0} join as {C:2}Adjutants{C:0}.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D45FE89E01AA3749325A198461BCC645486D"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "61BC62BB9AEFC540380BE795241C4C101402",
                            "defaultText": "{C:1}안드레{C:0}그리고{C:1}폴레드로{C:0}다음으로 가입{C:2}부관{C:0}."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "846958F92A29F145FE8A46485955151BC421",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "Your allies prepared for combat and learnt {C:2}new skills{C:0}.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9228A3383C8F584B9D298BF8B3492C3BC742"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "94D4CE03017EA848D239D710E45FB26223D4",
                            "defaultText": "동맹국은 전투를 준비하고 학습했습니다.{C:2}새로운 기술{C:0}."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "972C929A6B7917492C58DD922F30BB668141",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "{C:1}Menmus{C:0} joins as an {C:2}Adjutant{C:0}.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "6405B4832E189743F66B0FD69FADDEA4DD34"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "CD14152C918F7343291ADD162193C022E5DA",
                            "defaultText": "{C:1}멘무스{C:0}로 합류{C:2}부관{C:0}."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "B65A2F507ABFD249C7787FA5D2B4EDE15C85",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "{C:1}Cattleya{C:0} joins as an {C:2}Adjutant{C:0}.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "986B9BC843EB4249D48BAF3532C1982EA459"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "909637E28150674C9989CD461E55DBEEBEA1",
                            "defaultText": "{C:1}카틀레야{C:0}로 합류{C:2}부관{C:0}."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "2F2DAB161FC9074BCA8B72F4C6079CB13F03",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "The {C:1}Skill Trees{C:0} are now available in the Inventory.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4E3083F471B9F7442B3B8EF0CE23ADD6055E"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "D632D6A22437594B0E1AFE04A5DB49398071",
                            "defaultText": "그만큼{C:1}스킬 트리{C:0}이제 인벤토리에서 사용할 수 있습니다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "AACA81CD38B2B44A515BB3479E8104854552",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "You're joined by your allies and Adjutants.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F23BB6CF230145444429CB477AE5BA1ABFFC"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "E3122FC3926C5341FE0B2F5417C46F5AE50D",
                            "defaultText": "당신은 동맹국과 부관와 합류했습니다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "F699D18645F2834FF73A8690CEA583AF7493",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "You're joined by your allies.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "CC7B48C7431072462F4AEB30573F3964FE0C"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "03DE85DD8D8A104C148AA315B61C4D2B21AE",
                            "defaultText": "당신은 동맹국과 합류했습니다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "11DB6191802C784CEC9A3C07544C775E399B",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "garionarrives",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5E0775537CD0E845516A18223252C73B06E0"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "6D28B2C6943CA24CDA18A4B49CF90CDAB925",
                            "defaultText": "주요 목표가 업데이트되었습니다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "14F1BAB930A1E240B01A37584D98985C3864",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "You found {C:3}2500 G{C:0}.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0517761E4844234DAF18F5981956DF1B7D16"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "665DDF318735D849B279DEE47CCD84AA143D",
                            "defaultText": "당신이 찾았습니다{C:3}2500G{C:0}."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "23CA85A3208F604C47396993606FB68FB6F3",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "{C:1}Kalevala{C:0} joins as an {C:2}Adjutant{C:0}.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "91A0E2475E31D7451C9AC466984DEE41B1A6"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "801C7DDB7258474CAA393697C5B85188133A",
                            "defaultText": "{C:1}칼레발라{C:0}로 합류{C:2}부관{C:0}."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "61E0B4701699B34AD218F78878A5BAA348AA",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "{C:1}Garion{C:0} & {C:1}Djambo{C:0} join as {C:2}Adjutants{C:0}.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "975286EA7F26934679387C556B1037BCE572"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "74FCAB00271CF641796824B28EF8C4799863",
                            "defaultText": "{C:1}가리온{C:0}&{C:1}잠보{C:0}다음으로 가입{C:2}부관{C:0}."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "F86134175D12194E5978BE73E3CBF0CBBF6A",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "You collect {C:1}Scott's toy{C:0} from the barrel.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "7F27BC383C62D344832956D60B31A5458C60"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "2565243217C8154FF88A3B48EAFB85896BC1",
                            "defaultText": "당신은 수집{C:1}스콧의 장난감{C:0}배럴에서."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "0EFBE1BA29EA444A0F494383B3DF100FB458",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "{C:1}Schwarz{C:0} joins as an {C:2}Adjutant{C:0}.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D27007904A11834ACE696B8804354C464ADD"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "2D16371C17BAF141103B1E52DFD461633274",
                            "defaultText": "{C:1}슈바르츠{C:0}로 합류{C:2}부관{C:0}."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "5016689866C0D8404A38B082AFF76665BA0E",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "You received your entry permit.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "705399CD8692414D812B391955D593179E9D"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "901E697E11FD92400358D8D457BB12EACCB1",
                            "defaultText": "입국 허가를 받으셨습니다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "C184C2882FC37143AB69DF41E10DBC8F4C78",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "You handed the girls their visas.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B2B1874914D43043A848841060252241D01C"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "3501AF907E8A234CDA19CF913BC4D91F69F2",
                            "defaultText": "당신은 그 소녀들에게 비자를 건네주었습니다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "2ED0A95F0F44A044B87A174372D75132CC47",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "You can now cook {C:1}Fa's Special{C:0} at the camp.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "18AF097450B748450528CA52DFF79F86FABD"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "1606C3A92B2CC145463B7A934E349814313E",
                            "defaultText": "이제 요리를 할 수 있습니다{C:1}파의 스페셜{C:0}캠프에서."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "F40F9FC357246743E63931340C8C3C842F74",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "{C:1}Azurite{C:0} joins as a {C:2}Temp. Adjutant{C:0} for this chapter.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9D76BB029ABF84496E7A5081E17E6EB51FA7"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "DD0D3B7E8724C048202942E43C1405C38FB6",
                            "defaultText": "{C:1}아주라이트{C:0}로 합류{C:2}온도부관{C:0}이 장에서는."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "AB95DB9F6C98D24AC68AC8D70EEFA4AE897B",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "{C:1}Azurite{C:0} leaves the party.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "6AEE8CBC9645E74EB2498C342AE2C1F171B0"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "524016890730C3422D5A768083F77BCB5367",
                            "defaultText": "{C:1}아주라이트{C:0}파티를 떠납니다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "93BD3C1072CFF54721389E7193B551270C3C",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "Pietro'll make {C:1}Pixie Incense{C:0} at the camp from now on.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5F42835478EF394F6B4906B340F765A017AE"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "25DC67A55CDAA64E085A0A57D13D51B9ED9D",
                            "defaultText": "피에트로가 만들어줄게{C:1}픽시 향{C:0}지금부터 캠프에서."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "D65304B98C180545697A77A54783250260F8",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "{C:1}Ceapana{C:0} joins as an Adjutant.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C5BB735D59055740803A89131C6987D5872A"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "BA61C0AE74F0804C20182E77A04F17002164",
                            "defaultText": "{C:1}체아파나{C:0}로 합류{C:2}부관{C:0}."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "D27D2EB0553105453789A088C1AA10B90115",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "Woot woot woot! Woooot.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "095BFCB823B485431858FE0366C74BDCC1FA"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "A0854E0A2D25C3478F1BF984CDDAF9215CA9",
                            "defaultText": "우우우우우우우!우와."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "E96153B72FDDD14F632AA0471D81BEE051BD",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "{C:1}Saai{C:0} joins as a {C:2}Temp. Adjutant{C:0} for this chapter.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "EDFB607611CBB54D073A4229C70308C57F80"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "B104732F0253574AB779C9742836DABA56EC",
                            "defaultText": "{C:1}사이{C:0}로 합류{C:2}온도부관{C:0}이 장에서는."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "45111DAE57D407441D7985F30B7F3B5F83FF",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "You found some beautiful lilies.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "BF14D8881502F241BB282D587DF21B3F5AC4"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "3D5DFB9088F5A74D771B55F7797D01F4BD0A",
                            "defaultText": "당신은 아름다운 백합을 발견했습니다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "C38A25CF701D0847307A1036374F18AC9573",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "{C:1}Shiori{C:0} unlocked her full potential.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "79B23D1D1EC10841E87B90B561490F4666A6"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "B34B95D78386D740027B69011DAE194C32A0",
                            "defaultText": "{C:1}시오리{C:0}그녀의 잠재력을 최대한 발휘했습니다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "464E5A159DD78443BF291A6703A23C0B9983",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "{C:1}Royce{C:0} joins as an {C:2}Adjutant{C:0}.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "946108E36393654E9A2838524CB88B580367"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "55FFDA5225CDB44934782F87334775463449",
                            "defaultText": "{C:1}로이스{C:0}로 합류{C:2}부관{C:0}."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "41DBDF4F263DE341D83B7D146B4CE2676465",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "{C:1}Lepto{C:0} joins as a {C:2}Temp. Adjutant{C:0} for this chapter.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "EC92E2827E8746437F5AAB33B068E7FC4164"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "877672F810D02145748B9BD7563019990FC8",
                            "defaultText": "{C:1}렙토{C:0}로 합류{C:2}온도부관{C:0}이 장에서는."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "91E0F8971B564745AA081BC1537DBDE68689",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "The Manacrest obtained {C:7}1200 MP{C:0}.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "EFDC4767345C2247A908CB2200C8BD79F7BF"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "FFF8B7727E3969424A193344C431E213408A",
                            "defaultText": "마나크레스트 획득{C:7}1200MP{C:0}."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "2B46431900B81346F84BB5A273FCD0CFCCEC",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "{C:1}Lepto{C:0} joins as an {C:2}Adjutant{C:0}.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "883ACD81818FD54EF43AB7D62FE0DF4795FB"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "85ED9A7B4D7ED5432A3AA1C4EB444E68ED49",
                            "defaultText": "{C:1}렙토{C:0}로 합류{C:2}부관{C:0}."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "9A1E95CE5628C74D7F29A633713C7493A7F9",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "{C:1}Azurite{C:0} joins as an {C:2}Adjutant{C:0}.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "523F536789FF2946936911866F9CF4E19CF5"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "D637C8C847FBE4401E0AAFD830034F7F2CBA",
                            "defaultText": "{C:1}아주라이트{C:0}로 합류{C:2}부관{C:0}."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "9C17F5D5150D98498638DEA36975900424BB",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "{C:1}Sae'rah{C:0} joins as a {C:2}Temp. Adjutant{C:0} for this chapter.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E1C15E6B9D40114BB6881689D7BD6CD8ED3D"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "925D2108778760486618997438CA8A2A8EE9",
                            "defaultText": "{C:1}사에라{C:0}로 합류{C:2}온도부관{C:0}이 장에서는."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "A3CA633834456546EF2B6EE1B4ACE8820037",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "You receive a {C:1}broken Manacrest{C:0}.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "7DFF91CA4162484533998FE0F0F53BEC55DB"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "80AAFEB87D9D04438269351391938752D852",
                            "defaultText": "당신은{C:1}고장난 마나크레스트{C:0}."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "A0D617D0836D184D761801608286058483F2",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "Sae'rah joins as an {C:1}Adjutant{C:0}.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "220CE9484D90C2434D1AB925CA50D2C75EF4"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "B74B44E77CBCC94B6309582867AE3687D156",
                            "defaultText": "{C:1}사에라{C:0}로 합류{C:2}부관{C:0}."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "7F118C9B6B73A541E3891167073075B5D969",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "The Manacrest obtained {C:7}1500 MP{C:0}.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "EEDD2F6229BB7345A26845B7EF423988D6FC"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "2526045D1700074A536A6E72DBDDDEC43EE1",
                            "defaultText": "마나크레스트 획득{C:7}1500MP{C:0}."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "8C5B91622983F8415A780E953B989F1B5E0D",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "{C:1}Phoebe{C:0} joins as a {C:2}Temp. Adjutant{C:0} for this chapter!",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4804C6045666A740326AAF83242367CD33A2"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "B045E14A1EA088458C1BF5586679877FB436",
                            "defaultText": "{C:1}피비{C:0}로 합류{C:2}온도부관{C:0}이번 장을 위해!"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "16DF64351721104A70680B23A525A0C62D05",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "Shiori and Faratras learned {C:1}new spells{C:0}!",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "BB64FD593B94A748126A70E4031873CED633"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "5CDE38F017F9B4481B6A3E93D31AA1206C51",
                            "defaultText": "시오리 및 파라트라스 학습{C:1}새로운 주문{C:0}!"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "9390FF8A1415D947F54995440513E26D6517",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "You've unlocked the {C:1}Title Screen variation{C:0}.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C4562224270454495B29257113F69E053062"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "83E846FC54EAC34AD058C496B78A1DF69754",
                            "defaultText": "당신은 잠금을 해제했습니다{C:1}타이틀 화면 변형{C:0}."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "5B8A1E063E0AC24B45585C525B81078A7AC7",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "Luck UP (1/2): {C:1}+2% Crit, +10% Drop Rate{C:0}.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "38D588936DBC864E438AFA800CE7072E92A7"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "E89F944D73E760419D88DA0165B6413CE10B",
                            "defaultText": "행운 UP(1/2):{C:1}치명타 +2%, 드롭률 +10%{C:0}."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "1683621F50FFB540FA1AE7E8FCB2EAF314BD",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "Luck UP (2/2): {C:1}+5% Crit, +20% Drop Rate{C:0}.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "AB94F84313AA624E0B0AF733B2DF3B10FEC9"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "D1697C4C0FE30845795864C74A76811FE6CF",
                            "defaultText": "행운 UP(2/2):{C:1}치명타 +5%, 드롭률 +20%{C:0}."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "3AA1FDDD4F5D214C009BCB9963432D765A55",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "Reach the \"Heart of the forest\" to the north.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4A3801F9274CD249B7196D38D7C54367DFD3"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "5F33C9856A0F01409E9AB639DDEE7400334A",
                            "defaultText": "북쪽의 \"숲의 심장\"에 도달하세요."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "96201B5D17F8B24C2B3BD8E4A328EE91FAF4",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "Defeat all the bandits.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D9BC3335698AE1473E2A459827D9D48C368D"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "4515E56C0EF2684A493BEE84241A373B53C8",
                            "defaultText": "도적들을 모두 물리치세요."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "B64B30CD140B23463E29ABF6E91ECEAA2547",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "Kill Master Alvano...!?",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A6E6FCD026822140459A9AE53E8193388E8D"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "C3689F405C9386459D5825A4AC9CA67EC352",
                            "defaultText": "알바노 스승님를 죽여라...!?"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "117EE65C8515284DF958FB581B22F5C2E4A1",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "Survive until 08:10 PM.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "CD30F0736729344B7F2B31A1FE5514E62D20"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "2419DDB545CD2546C5690A341C98C9BD6DB9",
                            "defaultText": "오후 8시 10분까지 생존하세요."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "82BE3C084F272047F05B09424EA0CAF93BB5",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "Defeat Menmus (recommended) or Survive (1:00 PM).",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "09DD51B346ABF74B7D6B596955D49BB33E64"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "7635D5198834C841A8090A3494791F85415E",
                            "defaultText": "멘무스를 처치(권장)하거나 생존하세요(오후 1시)."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "C4EEF6172BB520416A3A3EE0194CBB468F7B",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "Defeat all Cultists by 7:45 PM.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "61A9DDFC5B595048810BD8D90FC3F73ACC39"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "DDA89B3A38637742D81A00B4B052F52C52F0",
                            "defaultText": "오후 7시 45분까지 모든 이교도를 처치하세요."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "A48264BB6F7C8248461AD8620DEB155061A7",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "Find Faratras before 06:55 AM.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E2D10E3F825109456C083913899284EEE1BC"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "727CC2693EC22843FF787B51A2755707BF21",
                            "defaultText": "오전 6시 55분 이전에 파라트라스를 찾으세요."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "B9F868A67B58E744C5599CF48F8F165EC541",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "Prevent monsters from reaching the Shrine until 1:00 AM.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "BD501046331E2344BD8BB758A12690C689D3"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "9944D7D872BA76417D5AA201FAB05B3A76E0",
                            "defaultText": "오전 1시까지 몬스터가 신전에 접근하지 못하도록 하세요."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "627B759F9862A048604895C75EFBF030A1E3",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "Stop \"Faratras\" before 6:00 AM!",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0D542346880B324A1928C3432339BC6C657E"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "BC2A560B3C677940150B5ED13EA4032D1030",
                            "defaultText": "오전 6시 이전에 \"파라트라스\"를 중지하세요!"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "E775DA06337C074ECE7AFDC090DF1C71419F",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "Reach the cottage before 11:40 AM.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C75CE9C379D77743E6182B177FE4D8D1B6EE"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "302ED0DE190DC44B3A698D4887A8DEBCC5FD",
                            "defaultText": "오전 11시 40분 이전에 별장에 도착하세요."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "682251735C0DA14D6D5AB220B54B9A83A2EB",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "Reach the house before 3:40 PM.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "000A1EFD99C5F749B528ACB8A7ADF1B1F3E0"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "983F78B62E110547214BB1F66E6ACE87CCAC",
                            "defaultText": "오후 3시 40분 이전에 집에 도착하세요."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "82E0D54B194F2345EF3BE373957B24DCE386",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "Reach the oasis by 1:30 PM.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "FB63F0DB454EB944D69AE0B7D29A9E739383"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "C910D4980FC5B343CC3933776D9D6CA77EE7",
                            "defaultText": "오후 1시 30분까지 오아시스에 도착하세요."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "4ED372EA9A66A143592A48668881FFCAA7A7",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "Reach the fort by 3:00 PM.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B3E544EE6441B44F7439EDC571B51C8E7ACF"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "7E0AA0958B0E1943DB1B05688B564E72C8AA",
                            "defaultText": "오후 3시까지 요새에 도착하세요."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "82666358683CF2491A19B144C80F5B4A2338",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "Reach the new destination by 5:45 PM.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3258773536CF104DF47907B3DD0962FA06CC"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "036E0DF24EBCC64A0E181B57043C48418096",
                            "defaultText": "오후 5시 45분까지 새로운 목적지에 도착하세요."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "51259CCB2494424B4A4B5E16D55BCD828A77",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "Reach Soraya by 11:00 AM.",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "02D0ADC5885CE747AB7BDC75EED0A189A9AB"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "A30182179CF8C44C64892542F57A2F0F6289",
                            "defaultText": "오전 11시까지 소라야에 도착하세요."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "5ECBA96A608E144422180A5621E8CC7BBD2C",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "input",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "finalcristoph",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "10E997F17AAC15406F6B028629A6A885F11D"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "7F5D6DE63A8DD54AB329BE973FB86B2C493E",
                            "defaultText": "적의 스킬 상태 이상 확률이 절반으로 줄어듭니다!"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "7BBBCCD8667BE140516B6D90CC32519A2B4B",
                    "expanded": true
                }
            ],
            "index": "8702F94B1D3721474D3BA95558013689261E",
            "booleanVariables": [
                {
                    "name": "",
                    "index": 0,
                    "scope": 0
                }
            ],
            "numberVariables": [
                {
                    "name": "",
                    "index": 0,
                    "scope": 0
                }
            ],
            "stringVariables": [
                {
                    "name": "input",
                    "index": 0,
                    "scope": 0,
                    "domain": "com.degica.vnm.default"
                }
            ],
            "listVariables": [
                {
                    "name": "",
                    "index": 0,
                    "scope": 0
                }
            ]
        },
        "localizableStrings": {
            "AEC2414017E2484172785D05F430F7E07739": {
                "t": "You can now access your {C:1}Inventory{C:0}.",
                "d": {
                    "eid": "5ADDE9A458946747D979C5B7C79305120A48"
                }
            },
            "B0042F20786A934E2E4BAFA8FA33DE9B6BF2": {
                "t": "Apparently, you have a dog now.",
                "d": {
                    "eid": "F7F6481943E3F541F448DE6270CB46E9EF9C"
                }
            },
            "E45A2C128AF3804F2E793B5883B5AC48F7CD": {
                "t": "Any food you had will be unavailable during dinner.",
                "d": {
                    "eid": "9C98F1EB641B304D670B20F7C175665CD421"
                }
            },
            "4FD29D7728DFD34F418BB088CD0B437A846B": {
                "t": "{C:1}Suzaku{C:0} can now use {C:2}Stella Triplet{C:0}.",
                "d": {
                    "eid": "F0AE7C36440FC9473C7A7788EB39532A252C"
                }
            },
            "26D6661150342849441AB213D1A0286CE9F0": {
                "t": "It's confirmed, you have a dog now.",
                "d": {
                    "eid": "5A6FC7EE6B29674EB66A0245A128919C14D6"
                }
            },
            "C69BC3D82DDF0647902BC3A4955624979754": {
                "t": "New party member: {C:1}Hooded man{C:0}.",
                "d": {
                    "eid": "46709ED38921674D9508A9069463624ACEC7"
                }
            },
            "44BD30DF8F3C234BF91B7463921D85DF5826": {
                "t": "You also obtain {C:3}3000 G{C:0}.",
                "d": {
                    "eid": "E2348C065721204F802843019CE4E47D8596"
                }
            },
            "2A9882333070564DD5489852F6225149965F": {
                "t": "New party member: {C:1}Useless knight{C:0}.",
                "d": {
                    "eid": "4A7463BB819D414FB149BDA2742750E99E3E"
                }
            },
            "460EA46605825544E52803D53C4386BDED65": {
                "t": "New party member: {C:1}Royal chestnut{C:0}.",
                "d": {
                    "eid": "23F2D7F63E05E247BC19845076867F427A05"
                }
            },
            "87B7AE963031204E77897959F56A6484002F": {
                "t": "New party member: {C:1}Stupid hunk{C:0}.",
                "d": {
                    "eid": "EC8DE1C15E34424F168817F92317E127C1F1"
                }
            },
            "720136A72D90214FC95B68B9A2B539C5FCE0": {
                "t": "You delivered: {C:1}Potato x1{C:0}.",
                "d": {
                    "eid": "6FAC4C0121473242E409EC90B24AAA8C0EFB"
                }
            },
            "61BC62BB9AEFC540380BE795241C4C101402": {
                "t": "{C:1}Andre{C:0} and {C:1}Poledro{C:0} join as {C:2}Adjutants{C:0}.",
                "d": {
                    "eid": "846958F92A29F145FE8A46485955151BC421"
                }
            },
            "94D4CE03017EA848D239D710E45FB26223D4": {
                "t": "Your allies prepared for combat and learnt {C:2}new skills{C:0}.",
                "d": {
                    "eid": "972C929A6B7917492C58DD922F30BB668141"
                }
            },
            "CD14152C918F7343291ADD162193C022E5DA": {
                "t": "{C:1}Menmus{C:0} joins as an {C:2}Adjutant{C:0}.",
                "d": {
                    "eid": "B65A2F507ABFD249C7787FA5D2B4EDE15C85"
                }
            },
            "909637E28150674C9989CD461E55DBEEBEA1": {
                "t": "{C:1}Cattleya{C:0} joins as an {C:2}Adjutant{C:0}.",
                "d": {
                    "eid": "2F2DAB161FC9074BCA8B72F4C6079CB13F03"
                }
            },
            "D632D6A22437594B0E1AFE04A5DB49398071": {
                "t": "The {C:1}Skill Trees{C:0} are now available in the Inventory.",
                "d": {
                    "eid": "AACA81CD38B2B44A515BB3479E8104854552"
                }
            },
            "E3122FC3926C5341FE0B2F5417C46F5AE50D": {
                "t": "You're joined by your allies and Adjutants.",
                "d": {
                    "eid": "F699D18645F2834FF73A8690CEA583AF7493"
                }
            },
            "03DE85DD8D8A104C148AA315B61C4D2B21AE": {
                "t": "You're joined by your allies.",
                "d": {
                    "eid": "11DB6191802C784CEC9A3C07544C775E399B"
                }
            },
            "6D28B2C6943CA24CDA18A4B49CF90CDAB925": {
                "t": "The main objective has been updated.",
                "d": {
                    "eid": "14F1BAB930A1E240B01A37584D98985C3864"
                }
            },
            "665DDF318735D849B279DEE47CCD84AA143D": {
                "t": "You found {C:3}2500 G{C:0}.",
                "d": {
                    "eid": "23CA85A3208F604C47396993606FB68FB6F3"
                }
            },
            "801C7DDB7258474CAA393697C5B85188133A": {
                "t": "{C:1}Kalevala{C:0} joins as an {C:2}Adjutant{C:0}.",
                "d": {
                    "eid": "61E0B4701699B34AD218F78878A5BAA348AA"
                }
            },
            "74FCAB00271CF641796824B28EF8C4799863": {
                "t": "{C:1}Garion{C:0} & {C:1}Djambo{C:0} join as {C:2}Adjutants{C:0}.",
                "d": {
                    "eid": "F86134175D12194E5978BE73E3CBF0CBBF6A"
                }
            },
            "2565243217C8154FF88A3B48EAFB85896BC1": {
                "t": "You collect {C:1}Scott's toy{C:0} from the barrel.",
                "d": {
                    "eid": "0EFBE1BA29EA444A0F494383B3DF100FB458"
                }
            },
            "2D16371C17BAF141103B1E52DFD461633274": {
                "t": "{C:1}Schwarz{C:0} joins as an {C:2}Adjutant{C:0}.",
                "d": {
                    "eid": "5016689866C0D8404A38B082AFF76665BA0E"
                }
            },
            "901E697E11FD92400358D8D457BB12EACCB1": {
                "t": "You received your entry permit.",
                "d": {
                    "eid": "C184C2882FC37143AB69DF41E10DBC8F4C78"
                }
            },
            "3501AF907E8A234CDA19CF913BC4D91F69F2": {
                "t": "You handed the girls their visas.",
                "d": {
                    "eid": "2ED0A95F0F44A044B87A174372D75132CC47"
                }
            },
            "1606C3A92B2CC145463B7A934E349814313E": {
                "t": "You can now cook {C:1}Fa's Special{C:0} at the camp.",
                "d": {
                    "eid": "F40F9FC357246743E63931340C8C3C842F74"
                }
            },
            "DD0D3B7E8724C048202942E43C1405C38FB6": {
                "t": "{C:1}Azurite{C:0} joins as a {C:2}Temp. Adjutant{C:0} for this chapter.",
                "d": {
                    "eid": "AB95DB9F6C98D24AC68AC8D70EEFA4AE897B"
                }
            },
            "524016890730C3422D5A768083F77BCB5367": {
                "t": "{C:1}Azurite{C:0} leaves the party.",
                "d": {
                    "eid": "93BD3C1072CFF54721389E7193B551270C3C"
                }
            },
            "25DC67A55CDAA64E085A0A57D13D51B9ED9D": {
                "t": "Pietro'll make {C:1}Pixie Incense{C:0} at the camp from now on.",
                "d": {
                    "eid": "D65304B98C180545697A77A54783250260F8"
                }
            },
            "BA61C0AE74F0804C20182E77A04F17002164": {
                "t": "{C:1}Ceapana{C:0} joins as an {C:2}Adjutant{C:0}.",
                "d": {
                    "eid": "D27D2EB0553105453789A088C1AA10B90115"
                }
            },
            "A0854E0A2D25C3478F1BF984CDDAF9215CA9": {
                "t": "Woot woot woot! Woooot.",
                "d": {
                    "eid": "E96153B72FDDD14F632AA0471D81BEE051BD"
                }
            },
            "B104732F0253574AB779C9742836DABA56EC": {
                "t": "{C:1}Saai{C:0} joins as a {C:2}Temp. Adjutant{C:0} for this chapter.",
                "d": {
                    "eid": "45111DAE57D407441D7985F30B7F3B5F83FF"
                }
            },
            "3D5DFB9088F5A74D771B55F7797D01F4BD0A": {
                "t": "You found some beautiful lilies.",
                "d": {
                    "eid": "C38A25CF701D0847307A1036374F18AC9573"
                }
            },
            "B34B95D78386D740027B69011DAE194C32A0": {
                "t": "{C:1}Shiori{C:0} unlocked her full potential.",
                "d": {
                    "eid": "464E5A159DD78443BF291A6703A23C0B9983"
                }
            },
            "55FFDA5225CDB44934782F87334775463449": {
                "t": "{C:1}Royce{C:0} joins as an {C:2}Adjutant{C:0}.",
                "d": {
                    "eid": "41DBDF4F263DE341D83B7D146B4CE2676465"
                }
            },
            "877672F810D02145748B9BD7563019990FC8": {
                "t": "{C:1}Lepto{C:0} joins as a {C:2}Temp. Adjutant{C:0} for this chapter.",
                "d": {
                    "eid": "91E0F8971B564745AA081BC1537DBDE68689"
                }
            },
            "FFF8B7727E3969424A193344C431E213408A": {
                "t": "The Manacrest obtained {C:7}1200 MP{C:0}.",
                "d": {
                    "eid": "2B46431900B81346F84BB5A273FCD0CFCCEC"
                }
            },
            "85ED9A7B4D7ED5432A3AA1C4EB444E68ED49": {
                "t": "{C:1}Lepto{C:0} joins as an {C:2}Adjutant{C:0}.",
                "d": {
                    "eid": "9A1E95CE5628C74D7F29A633713C7493A7F9"
                }
            },
            "D637C8C847FBE4401E0AAFD830034F7F2CBA": {
                "t": "{C:1}Azurite{C:0} joins as an {C:2}Adjutant{C:0}.",
                "d": {
                    "eid": "9C17F5D5150D98498638DEA36975900424BB"
                }
            },
            "925D2108778760486618997438CA8A2A8EE9": {
                "t": "{C:1}Sae'rah{C:0} joins as a {C:2}Temp. Adjutant{C:0} for this chapter.",
                "d": {
                    "eid": "A3CA633834456546EF2B6EE1B4ACE8820037"
                }
            },
            "80AAFEB87D9D04438269351391938752D852": {
                "t": "You receive a {C:1}broken Manacrest{C:0}.",
                "d": {
                    "eid": "A0D617D0836D184D761801608286058483F2"
                }
            },
            "B74B44E77CBCC94B6309582867AE3687D156": {
                "t": "{C:1}Sae'rah{C:0} joins as an {C:2}Adjutant{C:0}.",
                "d": {
                    "eid": "7F118C9B6B73A541E3891167073075B5D969"
                }
            },
            "2526045D1700074A536A6E72DBDDDEC43EE1": {
                "t": "The Manacrest obtained {C:7}1500 MP{C:0}.",
                "d": {
                    "eid": "8C5B91622983F8415A780E953B989F1B5E0D"
                }
            },
            "B045E14A1EA088458C1BF5586679877FB436": {
                "t": "{C:1}Phoebe{C:0} joins as a {C:2}Temp. Adjutant{C:0} for this chapter!",
                "d": {
                    "eid": "16DF64351721104A70680B23A525A0C62D05"
                }
            },
            "5CDE38F017F9B4481B6A3E93D31AA1206C51": {
                "t": "Shiori and Faratras learned {C:1}new spells{C:0}!",
                "d": {
                    "eid": "9390FF8A1415D947F54995440513E26D6517"
                }
            },
            "83E846FC54EAC34AD058C496B78A1DF69754": {
                "t": "You've unlocked the {C:1}Title Screen variation{C:0}.",
                "d": {
                    "eid": "5B8A1E063E0AC24B45585C525B81078A7AC7"
                }
            },
            "E89F944D73E760419D88DA0165B6413CE10B": {
                "t": "Luck UP (1/2): {C:1}+2% Crit, +10% Drop Rate{C:0}.",
                "d": {
                    "eid": "1683621F50FFB540FA1AE7E8FCB2EAF314BD"
                }
            },
            "D1697C4C0FE30845795864C74A76811FE6CF": {
                "t": "Luck UP (2/2): {C:1}+5% Crit, +20% Drop Rate{C:0}.",
                "d": {
                    "eid": "3AA1FDDD4F5D214C009BCB9963432D765A55"
                }
            },
            "5F33C9856A0F01409E9AB639DDEE7400334A": {
                "t": "Reach the \"Heart of the forest\" to the north.",
                "d": {
                    "eid": "96201B5D17F8B24C2B3BD8E4A328EE91FAF4"
                }
            },
            "4515E56C0EF2684A493BEE84241A373B53C8": {
                "t": "Defeat all the bandits.",
                "d": {
                    "eid": "B64B30CD140B23463E29ABF6E91ECEAA2547"
                }
            },
            "C3689F405C9386459D5825A4AC9CA67EC352": {
                "t": "Kill Master Alvano...!?",
                "d": {
                    "eid": "117EE65C8515284DF958FB581B22F5C2E4A1"
                }
            },
            "2419DDB545CD2546C5690A341C98C9BD6DB9": {
                "t": "Survive until 08:10 PM.",
                "d": {
                    "eid": "82BE3C084F272047F05B09424EA0CAF93BB5"
                }
            },
            "7635D5198834C841A8090A3494791F85415E": {
                "t": "Defeat Menmus (recommended) or Survive (1:00 PM).",
                "d": {
                    "eid": "C4EEF6172BB520416A3A3EE0194CBB468F7B"
                }
            },
            "DDA89B3A38637742D81A00B4B052F52C52F0": {
                "t": "Defeat all Cultists by 7:45 PM.",
                "d": {
                    "eid": "A48264BB6F7C8248461AD8620DEB155061A7"
                }
            },
            "727CC2693EC22843FF787B51A2755707BF21": {
                "t": "Find Faratras before 06:55 AM.",
                "d": {
                    "eid": "B9F868A67B58E744C5599CF48F8F165EC541"
                }
            },
            "9944D7D872BA76417D5AA201FAB05B3A76E0": {
                "t": "Prevent monsters from reaching the Shrine until 1:00 AM.",
                "d": {
                    "eid": "627B759F9862A048604895C75EFBF030A1E3"
                }
            },
            "BC2A560B3C677940150B5ED13EA4032D1030": {
                "t": "Stop \"Faratras\" before 6:00 AM!",
                "d": {
                    "eid": "E775DA06337C074ECE7AFDC090DF1C71419F"
                }
            },
            "302ED0DE190DC44B3A698D4887A8DEBCC5FD": {
                "t": "Reach the cottage before 11:40 AM.",
                "d": {
                    "eid": "682251735C0DA14D6D5AB220B54B9A83A2EB"
                }
            },
            "983F78B62E110547214BB1F66E6ACE87CCAC": {
                "t": "Reach the house before 3:40 PM.",
                "d": {
                    "eid": "82E0D54B194F2345EF3BE373957B24DCE386"
                }
            },
            "C910D4980FC5B343CC3933776D9D6CA77EE7": {
                "t": "Reach the oasis by 1:30 PM.",
                "d": {
                    "eid": "4ED372EA9A66A143592A48668881FFCAA7A7"
                }
            },
            "7E0AA0958B0E1943DB1B05688B564E72C8AA": {
                "t": "Reach the fort by 3:00 PM.",
                "d": {
                    "eid": "82666358683CF2491A19B144C80F5B4A2338"
                }
            },
            "036E0DF24EBCC64A0E181B57043C48418096": {
                "t": "Reach the new destination by 5:45 PM.",
                "d": {
                    "eid": "51259CCB2494424B4A4B5E16D55BCD828A77"
                }
            },
            "A30182179CF8C44C64892542F57A2F0F6289": {
                "t": "Reach Soraya by 11:00 AM.",
                "d": {
                    "eid": "5ECBA96A608E144422180A5621E8CC7BBD2C"
                }
            },
            "7F5D6DE63A8DD54AB329BE973FB86B2C493E": {
                "t": "Enemy skill ailment chances are halved!",
                "d": {
                    "eid": "7BBBCCD8667BE140516B6D90CC32519A2B4B"
                }
            }
        },
        "parentId": "6ED66A9042ECB3444948D814E41FB327288F"
    },
    "summary": [
        "name",
        "type",
        "order"
    ],
    "externalItems": []
}
