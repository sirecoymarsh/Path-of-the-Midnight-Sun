GS.dataCache['AFE5AA3064165844F939ACF22F4A821636BF'] = {
    "uid": "AFE5AA3064165844F939ACF22F4A821636BF",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C11B-2 Arrive at Han'naje",
        "type": "vn.scene",
        "parentId": "04D12A924ED7E240E4793325D061E98BB345",
        "chapterUid": "8A78B92E5A59F446F05823F4DB00C78A28B3",
        "order": 1,
        "localizableStrings": {
            "8A8BE2274948074F084AD7E9FACFCC2AF7A9": {
                "t": "It would seem that after sealing Tacitus, the Mana Scourge stopped affecting these lands as well.",
                "d": {
                    "cid": 0,
                    "eid": "BEBE7B887297684474487EF262799C561ED1"
                }
            },
            "3D143B85481CD146C9581D251E8ACBE952EC": {
                "t": "The Mana Scourge is incredibly intense here...",
                "d": {
                    "cid": 0,
                    "eid": "846074536AAE6445BB183D93CE2C1CC8517A"
                }
            },
            "131A4F1B4E4F8846C93808B7625263D3822A": {
                "t": "Don't let your guard down. Remember, according to Empress Phoebe's information, an Archdemon is supposed to be hiding in these lands.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "4D9C5F962DD1E04AC5182DB37FB2DE9F1798"
                }
            },
            "EEB0B5CB5E46A740A15B18D8DDB266D563A0": {
                "t": "I wouldn't even know where to start looking for it...",
                "d": {
                    "cid": 0,
                    "eid": "1C1FA9FC8E676444E74B4081DB2198A6AE8A"
                }
            },
            "199D820C77340542F51BB3E4EAA4922C5018": {
                "t": "And should I do that? If an Archdemon were to control my mind, forcing me to turn my sword towards my comrades again...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "2CC7F3124AB72342326B4223211A8068AF68"
                }
            },
            "3A7B488672917642B25A8081F7406540A1C0": {
                "t": "You look awfully pale. What's wrong?",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "C04B1DA426F0D64E543826A254F1A1A7FF75"
                }
            },
            "55F2626E269E71436C2B3ED126BBEF3264A0": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "17ECF29600297246E32B5FD252AFC5E6892E"
                }
            },
            "BAFAC0BF36B0844BC828B776CBF2187917B6": {
                "t": "I-I was just overthinking things. After all, I'm the airhead of the group!",
                "d": {
                    "cid": 0,
                    "eid": "34BB90186451D846AA6A3EB48B03DD8FFA47"
                }
            },
            "8DFCEDA974E6A24DAB08543838A093D2E042": {
                "t": "Stop making me worry, you fool... I can tell when you're hurting inside.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "D2B2363E6CAC9749687A4999E5A49E5A3B83"
                }
            },
            "30656D703354F6443E193F512BE789F3731D": {
                "t": "Since when does Lady Faratras keep such a close eye on me?",
                "d": {
                    "cid": 0,
                    "eid": "FB3AFFD528645045994904B4A9E49C6F85B3"
                }
            },
            "9DD526BB5569C742321AAC740B3CB4B967D4": {
                "t": "Don't answer my questions with more questions.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "BDEE683C3725C041E34B1CD2C42796FAB48F"
                }
            },
            "478A0A2D635FE54191397642C7D7C91D52A2": {
                "t": "Still... I'm glad that, after all that happened, she still cares for me...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "2EF757D41A7AC146B1482A14FC84A62F63E6"
                }
            },
            "9308185F92044343654A49B744A8D75880A6": {
                "t": "This is no time for jokes, useless knight.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "61C5BB025FD5B74A6F18D0C41E0B5C8E5D4A"
                }
            },
            "5D8878CD7F7CE24CF458A301C63CC423772A": {
                "t": "You don't need to worry about me, really. Rather, where's Empress Phoebe's informant?",
                "d": {
                    "cid": 0,
                    "eid": "4103E2886890E248BC9AB3641E211C924593"
                }
            },
            "D2EA90BF6195B34835797D66E5A1AC670442": {
                "t": "Look over there. He's coming this way.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "C95B0F238BC6314D6D1ACEA306588AF25970"
                }
            },
            "F6AC802F60D663403F58173209D0D345E306": {
                "t": "Already? Great.",
                "d": {
                    "cid": 0,
                    "eid": "9102FB48555CB242852B5DD3F25784EE7790"
                }
            },
            "2A751DE15DDE55478D99C4698942B2671816": {
                "t": "I wonder who this informant chosen by Phoebe herself might be? Surely it must be someone of extraordinary talents...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "DA7C65588B3AA846F428E3C2FACBFDE9F1C1"
                }
            },
            "60FD27105626044CDB1BB56822F65FCD5E82": {
                "t": "I already see from his physique that he has a poise out of the ordinary...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "55657E467C4570410B382526400CAAF22852"
                }
            },
            "CAA2BDB80815F4400D69FD93E25A5B5BF6FA": {
                "t": "Moreover, his face is the kind that remains etched in your mind. So etched that I feel like--",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "31FCBA6A8D2B584F096813A3D743CACF57AF"
                }
            },
            "ED2FBDB82B5BF444CD7BB5322FA82132D375": {
                "t": "???",
                "d": {
                    "eid": "432EF7860E9B464B89088EA3966B5CD4CDCC"
                }
            },
            "947E68824FFA514D588B798243E12D401CAF": {
                "t": "MAAAAAN!!",
                "d": {
                    "cid": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "eid": "E64FB5D0772A60474A285D2146F870565D8A"
                }
            },
            "8E35430E152234414D29CC9358ED0A237A25": {
                "t": "Azurite",
                "d": {
                    "eid": "A8BD468B8F087645D368947665DCE9AA557B"
                }
            },
            "F43AFF0884E4104575387F22411ED127BC83": {
                "t": "...like I've already seen him.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "6F71ABDA50044145D2891B773280E3A18FA3"
                }
            },
            "DE13CF1912F9F747A78AD14826A8AB7DDFDA": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "34AC3012032A85427E688BA65468A2765747"
                }
            },
            "0E6523DC32D6D844AD49DEF3EADFB7467429": {
                "t": "It's been a while, folks!! What a surprise to see you again in the middle of this hellish heat!",
                "d": {
                    "cid": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "eid": "2AE432B870E93746493A998367C568A4C4B8"
                }
            },
            "FBB3B42D4E757043629A7ED1E5BC73A2ECE7": {
                "t": "Although last time you were at the hot springs, so I'm assuming you're high temperature lovers, man!",
                "d": {
                    "cid": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "eid": "C81F8D7614EC1841A10999A4EEDB19528876"
                }
            },
            "34F5143B1FAE04495098FD24D06C00C9E0BC": {
                "t": "Woot woot!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "43B65A7D5A8BB44EB089F968FBE245407D70"
                }
            },
            "4ED281F04303B34E8879FFD823B752AE5116": {
                "t": "It's... you.",
                "d": {
                    "cid": 0,
                    "eid": "5E949CA0624397488D991968F945A2590B19"
                }
            },
            "86209D025590A74CC22AFB9164372B8CC1E0": {
                "t": "It appears that the most experienced mercenary in this area is none other than Azurite.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "A0E0964E7BD8A24A9F8832969D30201E35BF"
                }
            },
            "E13011726684B946CF8A1442F5AD1D7D5DEC": {
                "t": "Haha! How could I pass up the riches of this place? They pay you through the nose!",
                "d": {
                    "cid": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "eid": "368BE4975ECA06462B19AB051B916A12908F"
                }
            },
            "33BCC3E66ED0954B24692DF2E60B4D463E09": {
                "t": "Woooooooot!!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "D7D6A64A2036A348B6097517205795A5F62B"
                }
            },
            "66500B7A5C0CF84B4C1BADB52BCB66EB6634": {
                "t": "You and Luckos always make a scary pair...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "2A673534218A714AD73BFDA02ADCED6B62FD"
                }
            },
            "AE43B73F7D855848E638D341799F5E351CD6": {
                "t": "Whoa, man! I see you're always chasing wealth eh? Lord Valonja would not appreciate such greed!",
                "d": {
                    "cid": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "eid": "FB2F9FDD1FE9F3459D29C5D6B4CE78A08D6F"
                }
            },
            "8A7CEBCE23D9D449052AC84601DDDA61A335": {
                "t": "Come on MAAAN, it's been a while since we've seen each other and you're already criticizing me?",
                "d": {
                    "cid": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "eid": "6165B70544DF5148481A4D98E69FD0CCECBF"
                }
            },
            "DF1D149C7BF48042D71AAEF658DEB9989955": {
                "t": "Besides, Lord Valonja gave me a sick mother to take care of, so...",
                "d": {
                    "cid": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "eid": "F458E02565492240E07B69B1105EAB5C0CEB"
                }
            },
            "BA9D64881A676847C808E1E466677721BD14": {
                "t": "I'm sorry to interrupt this delightful talk, but... let's cut to the chase.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "B3861F091494964275598FD1BDB0548450EF"
                }
            },
            "03CBA9D73647824075789E511C4640F67813": {
                "t": "Agreed.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "543D0689542446496618E208DB886C5836D8"
                }
            },
            "BBB684EA5B9DA84AFC4A1FD1F6C6557BC490": {
                "t": "Phoebe must've already told you everything, so now it's your turn to fill us in on what you know.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "CAD7A5530496224261992EB520FB41311C3A"
                }
            },
            "68163A3D26AC9641305A94472319512A6101": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "B3B0949E5A49534EE2991B3920942951CDE2"
                }
            },
            "D272321C3964864C348B3DD5B2B17AFCDEB8": {
                "t": "Aye, aye, you can never catch your breath with you princesses, eh \"Farore\"?",
                "d": {
                    "cid": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "eid": "48ED4E1D7F42A143111A9B6812587A6EEE74"
                }
            },
            "AD8DD285542B6249A37A0EA86616AD9B6563": {
                "t": "I-I was undercover that time!",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "94A7858920EE694645786A83D3CFF86B9476"
                }
            },
            "24D4FC3928F7604D47494584325429043B07": {
                "t": "I'm surprised the Lazuleans bought that story, to be honest...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "CE5B602E1C8FE540165A10974888AA20A4CB"
                }
            },
            "A61BFEC5692A4040AB1B9EC8151201CFDC39": {
                "t": "So, Azurite?",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "0BF6862D74AA0846B1493564A695F1C89E5C"
                }
            },
            "B755F8B023E9C14CDE1BEF644D319075EF27": {
                "t": "From what I've been able to learn, there's a curious phenomenon that has been happening in the desert since last month, yo!",
                "d": {
                    "cid": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "eid": "A2C8FFA50B4C6244B6084B1119913D6158B9"
                }
            },
            "A1E8DDA220B8494A471BEF39341A592C5771": {
                "t": "The dunes and oases... they {SP:2}{C:1}shift{C:0}.",
                "d": {
                    "cid": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "eid": "BD96AC661EC078496E3AB4F8E9BD34216649"
                }
            },
            "CF4CA67D42CBA145CF3802D3A7127A48D6E0": {
                "t": "Er, they do what now?",
                "d": {
                    "cid": 0,
                    "eid": "A261E13B3536A14D59889F195DC6C26272FE"
                }
            },
            "3D886ED12DDFB2404B588CA8AFBEA366EEA4": {
                "t": "They shift. Also, you said it started happening \"last month\", right? A more than familiar time frame.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "DED5D9E31EA884489D3BFE30B3A1EE163E4B"
                }
            },
            "AE27884D8F54864FD178E4C1E0BB3DC20674": {
                "t": "It's definitely related to Hellios' awakening.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "7AD273DB3660884394791AC6BB0731A7410B"
                }
            },
            "39F6BAE4829EB240122959D7EF7C10D72EE6": {
                "t": "The Demon King has the power to twist nature at will, remember?",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "4E49AFFF53D3484C3E5B63C5099AB169637C"
                }
            },
            "1DB6BBA915BB324C37389F26E79A9F87C162": {
                "t": "So... Hellios is here?",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "787B6D2505F39744DB6B2566128707A1FBDF"
                }
            },
            "43A18EF625B6B44E83782194969448609B33": {
                "t": "Not necessarily, Nini. An Archdemon might possess some of the {SP:2}{C:1}qualities{C:0} of the Demon King Himself...",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "4308C24E73B9334E8939F6E3AAC821DCB751"
                }
            },
            "09B68D0744FDD3427D2AAC73368F55F827D8": {
                "t": "Not necessarily, Nini. Remember what happened with Tacitus?",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "FF03E43C6AD3E4471919B3F81B887CA869AF"
                }
            },
            "57A81F2717D8444BD11902E2B2DEA5A1FCDD": {
                "t": "This Archdemon might possess some of the qualities of the Demon King too...",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "1FC057344B49F54FCF2972A864B019564073"
                }
            },
            "7B7B6E20298D114C6F496AF4A4C4C64C6DC8": {
                "t": "Either way, this means that a demonic creature is hiding in the desert. All we have to do is find it.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "424F88B38A9B22490A199111A435CBAE975A"
                }
            },
            "D8776B3D504E6242AA8B9B725A6B2C5A81D7": {
                "t": "Always in a hurry, man! Easier said than done.",
                "d": {
                    "cid": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "eid": "FCF256EA4F4C494D5588006600FF8F3699ED"
                }
            },
            "EDFDC08056F8B34E7C2B1AD582445B11E295": {
                "t": "Other groups of mercenaries hired by Empress Phoebe have already combed the area... to no avail.",
                "d": {
                    "cid": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "eid": "BA9A81DB63A4854CE8184A831051F97600C5"
                }
            },
            "9606B89F1B3BD74E4B093433DF3D7BC6F94B": {
                "t": "Nothing at all? How is that possible?",
                "d": {
                    "cid": 0,
                    "eid": "2EBE81AA3981F34A2428C927AAA8451B112E"
                }
            },
            "1AA78F6A64EA7544E20A3D8468D96D12B50D": {
                "t": "We'll just have to ask at the citadel if anyone has any information.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "A5E6FD694E511145964A0E24B4AF51BC4B11"
                }
            },
            "666F1E2922733348FB7B4BE67FC839449E2F": {
                "t": "Correct. Let's do that right now.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "7A2A35AD8C2FE246A20B25C55C3632815F0D"
                }
            },
            "48B11C5C25F3F54E5D188B02EB25B590B222": {
                "t": "Hey! Aren't you forgetting something?",
                "d": {
                    "cid": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "eid": "F25C408374FC2243B44924591CFE48FC4F6E"
                }
            },
            "0D466E8B3CF77348792887304D5602556EAE": {
                "t": "Ahem. I guess I'm officially part of your team now, am I not?",
                "d": {
                    "cid": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "eid": "D9685E1244FAD54C2F78C060001B5590AE1E"
                }
            },
            "0D0436DD0B64684F2849A7C35C984B2D8C15": {
                "t": "Whoa, that's true, man! That's exciting news!",
                "d": {
                    "cid": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "eid": "DBAF29BA49C4B843803BDD5874E4FC7BD69A"
                }
            },
            "DA9B6ABE52B4B641112B4BD0E67594EF4CAE": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "A8E438E935B4744A3C6B04F72B0DE54DB8C3"
                }
            },
            "33CA40D7501616401F583390406999726A3A": {
                "t": "MAAAAN! We're gonna conquer this Archdemon fella together!",
                "d": {
                    "cid": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "eid": "62A5BAE53E21D2487E1B0CC41FA352F8ABF4"
                }
            },
            "0047040361510741CE896E88C48600844948": {
                "t": "Very... \"exciting\" indeed...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "7692BCBF3DDB04404B6844A5A3D65B9A2EB0"
                }
            },
            "D927C4CA312DC543623997330C44C28B7DC7": {
                "t": "I'd say we split into two groups.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "1CC803723BB2B848E988ADB6B61EDABC4C9A"
                }
            },
            "751DFF1B1D92D84B358933D1F787271088A1": {
                "t": "Shiori, you will go with Cristoph and Azurite. They'll help you get used to your surroundings. Do you agree?",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "3DF33F945267454A712BF2190B3A1BE21E46"
                }
            },
            "8B978A38222F5345656BC041A0638811A5C2": {
                "t": "Absolutely! I couldn't ask for better company.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "FC9658FE6BFD524ED37A2E1332FCB38DE6F6"
                }
            },
            "E3E15FFC79F9A741AA68F180FF31AE34D8CC": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "E0BA5A115D17E844647B61516AAEA588B898"
                }
            },
            "1120B7639E02514FF61838161414F7FBE519": {
                "t": "Hey, you're going to make me blush!",
                "d": {
                    "cid": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "eid": "AB9141C77CF71341A53A0C2486724B64B0F2"
                }
            },
            "8150FA8D533CB7497D1BCB31EA0E2C02C165": {
                "t": "A better company than mine?\nThank goodness we're in Midbar. I can go hide in a mausoleum or something.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "3450506B7EF625481928BAB2E59717AE5B85"
                }
            },
            "23E7284F2643324421595CB50FA4D9AB7069": {
                "t": "...Just kidding. I know you're in good hands with Cristoph.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "3DC768C723FED34B8C6B1CC22C73FA7BCC02"
                }
            },
            "056B72008AACF44DBB2B3BF42502CA18C9DC": {
                "t": "I'm almost jealous...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "764C1750561C1847F799A1368E0A99FCA2B1"
                }
            },
            "4BB812546FB4444B413B21F45EEC87D3DE6E": {
                "t": "I, on the other hand, will be going with Lady Faratras and... the two of them.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "66246C87318CA2415D5AEAA80C8DDB17903D"
                }
            },
            "1DD0C2E190724847B519D657219A473ADB0C": {
                "t": "More than pleasant company, at least as far as Rya is concerned.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "1FAF20DA3A5A12454D4AA3B45262F2C579D6"
                }
            },
            "2F1DABF7649FE0473B6A946142B8A85B6D57": {
                "t": "Sure, sure. I enjoy your company too, Vassal.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "137F3AA965D9A447672B3F6088D7299D5E24"
                }
            },
            "61C6D7F66E22B4466D1A730962881A4C01E8": {
                "t": "You could be more honest sometimes, though!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "51CA31DA2D8CF84EAA28D59531D6CBDB3C99"
                }
            },
            "4AFB84615B49A6493F6A5815A6ACF3CBBF6A": {
                "t": "Shut up.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "9003701651E2914800587546E615AC34A843"
                }
            },
            "9D5785E84E7DF345F75BE8B880C067AE1704": {
                "t": "What's wrong with everyone today? Ouch.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "900257375554F3484B1B3207B2252E278EF9"
                }
            },
            "584BF09D2E7BE74C168821A706CA611E5CEC": {
                "t": "Wait Rya, did you say... \"two\"?",
                "d": {
                    "cid": 0,
                    "eid": "B5715D3C7922654FCA1BE227A2A96BBFFBD6"
                }
            },
            "AC93109688EEC94B2E4A2E4258C93F32F6F8": {
                "t": "Woot woot!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "CC86986C9B344341A43A36B463598538E6BF"
                }
            },
            "76992A3C4B5736462538D0584FBFCB2A66FF": {
                "t": "Oh, Luckos is included. You're excited to explore a new place, aren't you, little one?",
                "d": {
                    "cid": 0,
                    "eid": "310781C84889C84C5F799981B79BAA3C0C91"
                }
            },
            "94CBF88A51BA4448116BEE717B442DE958C3": {
                "t": "Wooooooot!!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "364A6EAC658AA349518920C228B4A0EF6435"
                }
            },
            "4783E2A2179B444FAE7B413354D6DC4F8A96": {
                "t": "Remember, we're not here to grab wealth, though. Or steal from merchants. Or...",
                "d": {
                    "cid": 0,
                    "eid": "8CAF53508CC2E34037582D027B6600E15ED1"
                }
            },
            "1F81FA554710584BF87B9293A331F3678630": {
                "t": "Woooot...?",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "3BF1E7CF1EAA7447FE88C1B40197D1143A01"
                }
            },
            "6D2A20577EF3B64312294A9491CF9121A815": {
                "t": "You know what... nevermind. Just don't leave my sight.",
                "d": {
                    "cid": 0,
                    "eid": "AB70618068CC3046BF692F557996DAE15DC4"
                }
            },
            "73ABAFE76EF1484C8D7B359785D3D80917B2": {
                "t": "Then we're off! Teh heh.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "DB84D55A1C3A5646180AC993BED4AA7F9019"
                }
            },
            "B7A1F31A6FA507484F9AD3438C4323B2C71D": {
                "t": "Awesome! When do we meet again?",
                "d": {
                    "cid": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "eid": "8D8A1D7D10A7D14DA37951660294299703A3"
                }
            },
            "708BC2531BBDA54AB749A3254FE9EDA63B28": {
                "t": "There is no timetable. If you obtain information, please wait here in the plaza.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "43BA1CA53870B6431D1B02D17F604D16AF5B"
                }
            },
            "8D814B8E27B4B747F63952604D523ACABEB9": {
                "t": "Great! Let's go, team!\nI've already spotted something interesting in that direction!",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "63E732D08B95054D63199BA50DFFCEDFD37B"
                }
            },
            "91EA83B67A65474494183BA81523BA125AEA": {
                "t": "A-Ah! Wait for me!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "B3DF8B75559CB146CE09C7D8205527C85488"
                }
            },
            "F4BEF10F5F65D741532A7032E48F5B91F271": {
                "t": "Vuoto",
                "d": {
                    "eid": "6DB7A8E07C55394FB78B627649CC8E8F87BC"
                }
            },
            "C69DCB067417624F2F1B6956F5D2B50010A7": {
                "t": "They all seem a little too enthusiastic... It's not a pleasure trip.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "3677DBDA1C59084B1D686C8336A41EBED4B6"
                }
            },
            "B394A14347008947E119D9858CEC08323509": {
                "t": "And I'm especially worried about Shiori. I feel like she hasn't got used to her sight yet, but...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "A2B214634C4D474D3F7977F3769700BE86A8"
                }
            },
            "3C02A90E2C6C67457B1ABAF51F80C28E179A": {
                "t": "...as usual, she tries her hardest to make it seem like she isn't suffering. Old habits are hard to die, I guess.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "1D1589092ED81740B46A2AB7810C0C3FC63E"
                }
            },
            "21BF1EC93483084B535B867560068716AC16": {
                "t": "I'm glad that Shiori seems to feel a little better after the events in Tarmen, though.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "17E83AEA6DF6204224685D206BCC475D6A4B"
                }
            },
            "35A2F0F629E81847DA197B5683E7068B12BE": {
                "t": "It will still take some time for her to fully recover, but... it's a great step in the right direction.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "06AF65330504F247F2682E958440269E3AA1"
                }
            },
            "D99C84E74D3B63479E7AC642370FE59204E3": {
                "t": "We could take a look at the plaza and then the neighborhood in the opposite direction.",
                "d": {
                    "cid": 0,
                    "eid": "077269A5060D32495D1B96410EE438C89CA5"
                }
            },
            "E5D510878A735149A01B92B6CA9B5632E210": {
                "t": "A plan I can get behind.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "B99A4D2687726543149B83F244EE6523FA48"
                }
            }
        },
        "commands": [
            {
                "id": "gs.Comment",
                "params": {
                    "text": ""
                },
                "indent": 0,
                "uid": "C537E7FC6DFB784B2849054312DCC8B6B690"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "CB90878A7E52A545AC187542C22565DB9D3B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0A1613016430244332290E998CBBBB538A54"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "2D020C1916A3814359783A811324EF00AF65",
                        "name": "92 - Shiori Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "1956C7724A9E71425E3B46090D16B5686F12"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "2B96228807C91543086AF8734CBB0AD4A6B9",
                        "name": "93 - Faratras Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "20ADB1C4039FB744BA2B0A58FA8688B1C0F8"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "0FCC16EC8F14214F211BD711C5EF156BDE65",
                        "name": "95 - Rya Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "DDCEFD1D8E4A5742E789D8F36354C19686D3"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "567F1E3489D91446CF4A0ED6AF508D6BB339",
                        "name": "96 - Cristoph Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "3E29D0855821E344B54978E2C57B8D61EA08"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "FEEB28CE186A3342E70A634062AF25688319",
                        "name": "1 - Luckos"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "D3227AEE2178674536590DF267305BAABE2B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            20,
                            1,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "9B03925D3EA1344DD28A964167FB1ED576A6"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "0BC2C0C3487B3640D76BCB35D7EA8EC0B97A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A70A513225A8E54B4568D387471107FB55D7"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "FA76F7647737C64D0C7A63A6233BDA8CB55A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C59A4E1A4F59E2479C282BF8473DEACA6224",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "811FAEB06F5DA346D11922E8284890A39B51"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Defeated Tacitus?",
                        "index": 230,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DB7934991202074DE72A6260CE4D927D3E63"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CB714D94714A504FBA8BF0D8BC0540C586A7",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "B22D40FB5940754C960AF6E4081AC419F36E"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "0748172D04133145EE38AF47F88682173BA9"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "E3F86DAA1FC9034CA14A0D10FE693F0528EC",
                    "model": {
                        "name": "MidbarChild.model.live2d",
                        "folderPath": "Live2D/Z2 - NPCs/Midbar",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 750,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 970,
                        "y": 648,
                        "zoom": {
                            "x": 0.26,
                            "y": 0.26,
                            "d": 0.26
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0E85E8E33CF7674A9C281695E2BF50AF4B8B",
                "expanded": false
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "2D0546348124814BEE4A75C12A4C74B6F787",
                    "model": {
                        "name": "MidbarMan.model.live2d",
                        "folderPath": "Live2D/Z2 - NPCs/Midbar",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 750,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 345,
                        "y": 585,
                        "zoom": {
                            "x": 0.32,
                            "y": 0.32,
                            "d": 0.32
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "544B72C56117E9495479B8D7707C60F89818",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "03DEA4954ABD5648B72A16630CB12FEB0C7F",
                    "parameters": {
                        "values": [
                            15,
                            200,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "61A0AEEA12AC004F25190F319A07BD812CFC"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 84
                },
                "indent": 0,
                "uid": "BBC055AA2F8BE348EA2AC5B16BF60AC76599"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "DD16E36579CE1142445BB034B8DC2D4ED58E"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "05A5499F68C967445F7819D180000A8DA6DA"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "D37256CF3817F148586986A5D79B8A344E86"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 54,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "E39033FD4FA3B244AA28CA77BAF1188A3057"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "71ED7F069D87674F7B5B64E44926EF4FCBAA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "981454338340924CC57ACC623BC0E02716F5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6D86A04F88751349088A99690113EE7E6B6C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "80ECFAFA9AF4114CB98BDC1270FD80731C84"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Defeated Tacitus?",
                        "index": 230,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7070F06610F105412349C898BACBA9513A3C"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "If been to Tarmen before"
                },
                "indent": 1,
                "expanded": true
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8A8BE2274948074F084AD7E9FACFCC2AF7A9",
                        "defaultText": "타키투스를 봉인하자 마나 재앙도\n이 땅에 영향을 주지 않게 된 모양이야."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "BEBE7B887297684474487EF262799C561ED1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "0F0054A2885A214A7A083321B0F937097518"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "C430684847D8C740EE6B4A769E1C608B0B42"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "else"
                },
                "indent": 1,
                "expanded": true,
                "uid": "622FAB733F42944B052A4104E66339EC4385"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3D143B85481CD146C9581D251E8ACBE952EC",
                        "defaultText": "이곳의 마나 재앙은 엄청나게 강해..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "846074536AAE6445BB183D93CE2C1CC8517A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "471DE53B313265403C1B1E24603F331DC89A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AE83F46324157442D97B29673EE3FAF7A5C7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ED272ACD9D9E434817593C545B73DA089709"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "131A4F1B4E4F8846C93808B7625263D3822A",
                        "defaultText": "방심하지 마. 피비 여제의 정보에 따르면\n이 땅 어딘가에 대악마가 숨어 있어."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4D9C5F962DD1E04AC5182DB37FB2DE9F1798",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "93A36F0213B7924EDF6968A94A968EC6290E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A27A09D749CC784CD1596E15D58DD4036EB6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EEB0B5CB5E46A740A15B18D8DDB266D563A0",
                        "defaultText": "어디서부터 찾아야 할지조차 모르겠어..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1C1FA9FC8E676444E74B4081DB2198A6AE8A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "785B502642ED45404E3860D1418B0B458C40"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "66B7897D360A864A5C79E548F64EB4B1EAC8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "199D820C77340542F51BB3E4EAA4922C5018",
                        "defaultText": "정말 그래야 할까? 대악마가 내 정신을 지배해\n다시 동료들에게 검을 겨누게 한다면..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2CC7F3124AB72342326B4223211A8068AF68",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B6748C0B540EE6488998FCE900E5261C2B7F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A580E5BA9B6828475D49390821AED367D61A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C604E18C3859914DDC89F0F606DF2544AF11"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3A7B488672917642B25A8081F7406540A1C0",
                        "defaultText": "얼굴이 너무 창백해. 무슨 일이야?"
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C04B1DA426F0D64E543826A254F1A1A7FF75",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A97D670066CE254B2A8B13907DF2F4228BA2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E15476F14AB0B64B0A0976908D70AD9956AC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "55F2626E269E71436C2B3ED126BBEF3264A0",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E3-Ornieres_line24_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "17ECF29600297246E32B5FD252AFC5E6892E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "24F710075C9E434A8059C7F4A5693B22DAF4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "628B39A7717D19479E188E60EE7DE2FE1092"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BAFAC0BF36B0844BC828B776CBF2187917B6",
                        "defaultText": "그, 그냥 생각이 너무 많았어.\n아무래도 난 이 일행의 얼간이니까!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "34BB90186451D846AA6A3EB48B03DD8FFA47",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D7A0FD217CC2B8435E2843C6DC5D23354692"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "278673EE53C0C14F4D0AF972D5544AF7F6BC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E0D9E0B57251A74CF788CE5360A4C39517B2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2560B4898EB4204AEB1B1E57C9BA3BECF74C",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "330D75C1099B7644E28A1CB387D3502FD599"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3293D0813825544C364817C878B7DD908FEF"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "If Affection with Fa is high\n(she blushes)"
                },
                "indent": 1,
                "uid": "9FF30BE878745545A80A511646925444C210",
                "expanded": true
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8DFCEDA974E6A24DAB08543838A093D2E042",
                        "defaultText": "걱정하게 만들지 마, 바보야...\n네가 속으로 괴로워하면 난 알아."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "D2B2363E6CAC9749687A4999E5A49E5A3B83",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "9918459D29F4F543566BCEC47AB562AB7052"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "D8F0FCC81F00C6441848AF935C15BA20D150"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "30656D703354F6443E193F512BE789F3731D",
                        "defaultText": "파라트라스 님은 언제부터 저를 그렇게 세심히 살피셨죠?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "FB3AFFD528645045994904B4A9E49C6F85B3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "8208688E72341244598857C81CD51091EE04"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "D5AC870D6E70574D2448A422E20C010D48A8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9DD526BB5569C742321AAC740B3CB4B967D4",
                        "defaultText": "질문에 질문으로 대답하지 마."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "BDEE683C3725C041E34B1CD2C42796FAB48F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "4D6BC6FC4E54504D39698C241189ED073E46"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "3B81649D47FD4446A688CF5773BD82D50DDA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "478A0A2D635FE54191397642C7D7C91D52A2",
                        "defaultText": "그래도... 그 모든 일이 있었는데도\n여전히 날 걱정해 줘서 기뻐..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "2EF757D41A7AC146B1482A14FC84A62F63E6",
                "expanded": true
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "4405384533A897428A582193166E25EBBE76"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "if Affection is normal or low\nOR if cruelty is too high"
                },
                "indent": 1,
                "uid": "BD54EA1F721A80414549FBE906750CFC0F36",
                "expanded": true
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9308185F92044343654A49B744A8D75880A6",
                        "defaultText": "농담할 때가 아니야, 쓸모없는 기사."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "61C5BB025FD5B74A6F18D0C41E0B5C8E5D4A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2755B34697FCA34BFB0A0233B96D42A9E437"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9DCBE4E658006345415A9A612CF3A0EA1BE2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5D8878CD7F7CE24CF458A301C63CC423772A",
                        "defaultText": "난 정말 괜찮으니 걱정하지 마.\n그보다 피비 여제의 정보원은 어디 있지?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4103E2886890E248BC9AB3641E211C924593",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "072707CD722692472C8AC3131A57F2115182"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "793292BE7ECEE34C675B23C339A0A21BE216"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D2EA90BF6195B34835797D66E5A1AC670442",
                        "defaultText": "저길 봐. 이쪽으로 오고 있어."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C95B0F238BC6314D6D1ACEA306588AF25970",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "78B8C9A054BB6945484AC591AA3E0DD87C70"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BBABC1E359DB764CBF5A2F86492D7B2037AF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F6AC802F60D663403F58173209D0D345E306",
                        "defaultText": "벌써? 잘됐네."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9102FB48555CB242852B5DD3F25784EE7790",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "FEC6CF68687C72423749D068C951563F55CD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AECC51D8884E274E2E4BA7A1618B735CF69C"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "1AF9F0456F128841F349BA93543BF8BE55B4"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "close;reopen"
                },
                "indent": 0,
                "expanded": true,
                "uid": "71B0D4327C7327479078B659E06721F19867"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8F174CCF8684E843C8282607F306008E6ECE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1871123A1165544377683CF082AC92BADA92"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2A751DE15DDE55478D99C4698942B2671816",
                        "defaultText": "피비가 직접 고른 정보원은 누구일까?\n분명 비범한 재능을 지닌 사람이겠지..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DA7C65588B3AA846F428E3C2FACBFDE9F1C1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A320D8A035AFD8460F5A8E76633B0E2ED433"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "60FD27105626044CDB1BB56822F65FCD5E82",
                        "defaultText": "체격만 봐도 범상치 않은 기품이 느껴져..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "55657E467C4570410B382526400CAAF22852",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1D307DD31551E94AB03A0F785DF382741402"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CAA2BDB80815F4400D69FD93E25A5B5BF6FA",
                        "defaultText": "게다가 저 얼굴은 머릿속에 새겨질 만큼 인상적이야.\n너무 선명해서 마치--"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "31FCBA6A8D2B584F096813A3D743CACF57AF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1A987FFD1C8C154A1F5BA9E8C4BF3C017F3E"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Azurite's name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "ED2FBDB82B5BF444CD7BB5322FA82132D375",
                        "defaultText": "???"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "432EF7860E9B464B89088EA3966B5CD4CDCC",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Azurite"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Azurite's name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C404593D56D47648DB3B82A123BA8C2D2FA7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "CA3DCF95197D4547DA3874C8442C10F17A7E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0F20E01A2A51604CEF28BB186870B20C07C6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "947E68824FFA514D588B798243E12D401CAF",
                        "defaultText": "이봐아아아!!"
                    },
                    "position": 0,
                    "characterId": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E64FB5D0772A60474A285D2146F870565D8A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E5DBE47197BE9440CF7ABBA556EB61D4BA14"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Azurite's name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "8E35430E152234414D29CC9358ED0A237A25",
                        "defaultText": "Azurite"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A8BD468B8F087645D368947665DCE9AA557B",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Azurite"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Azurite's name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4E89713E9985F64A5C8BADD1A4FF0776CCA0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "67FA6E641D5638429D3B3FB6FB60D1852B15"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F43AFF0884E4104575387F22411ED127BC83",
                        "defaultText": "...이미 본 적이 있는 것 같아."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6F71ABDA50044145D2891B773280E3A18FA3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "81C3B50888B8914F905B0EA67B8027A84003"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6B9893101D314443FB8BC5C3CC9566409A5D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 72
                },
                "indent": 0,
                "uid": "09EF6F9C6EFBF246E68BA9F44BA7864B0682"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "model": {
                        "name": "Azurite.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 800,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 278,
                        "y": 22,
                        "zoom": {
                            "x": 1.7,
                            "y": 1.7,
                            "d": 1.7
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 48,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "EC5E9CAC86C96945260BF2646E957D26B08D",
                "expanded": false
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.8,
                    "idleIntensity": 0.8,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 1
                    }
                },
                "indent": 0,
                "uid": "5D667FEB448AD14529585579CB40A97B54BD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            6
                        ]
                    }
                },
                "indent": 0,
                "uid": "F69986F552039743F07BCED5FDDBBF267874"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "9CAC19643E6F654C2C8942852CFEE75B8AE4"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "851C3FC23DFEB5462F6B3F14AF74BF280604"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 90
                },
                "indent": 0,
                "uid": "3DE72B608AFCB14CA75835906566FAD2EDBC"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Meet Azurite"
                },
                "indent": 0,
                "expanded": true,
                "uid": "2F9711EA2A41124B8029E3A7C365DBB19508"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "64D3B5435EB7B741788AA535D2EE0D836710"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F21C1E5635DB124FBF1BFA554D7655004BE3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DE13CF1912F9F747A78AD14826A8AB7DDFDA",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Azurite",
                        "name": "E3-Azurite_line2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "34AC3012032A85427E688BA65468A2765747",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "7949ACF223C5084AC33994433F7D96434975"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "670EF8841582E4466C7992B008447722D913"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0E6523DC32D6D844AD49DEF3EADFB7467429",
                        "defaultText": "오랜만이야, 친구들!! 이 지옥 같은 더위 한가운데서\n또 만나다니 놀랍네!"
                    },
                    "position": 0,
                    "characterId": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2AE432B870E93746493A998367C568A4C4B8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7A1EAB9232819642E289E123F03F276A01CE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FBB3B42D4E757043629A7ED1E5BC73A2ECE7",
                        "defaultText": "지난번에는 온천에 있었으니\n너희는 고온을 좋아하나 봐, 친구!"
                    },
                    "position": 0,
                    "characterId": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C81F8D7614EC1841A10999A4EEDB19528876",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C0F02EE925ABB54BD13A7DC62C4BFC04C8E4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FA75E4D6187BF443326BEEC70F9B7890D295"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D3C1C54842E6F14AC12B5BB28673ED8EC8C4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "34F5143B1FAE04495098FD24D06C00C9E0BC",
                        "defaultText": "우후 우후!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "43B65A7D5A8BB44EB089F968FBE245407D70",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0A1D52C63EEC8945B1896046D41C7172A495"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E7BD1C098FA38349B47849C91EBF2A7E6E1E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4ED281F04303B34E8879FFD823B752AE5116",
                        "defaultText": "너...구나."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5E949CA0624397488D991968F945A2590B19",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F9DCB36E95640745B32BD994F943E199A700"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D1855D8E14B7D3480C89C2F1410C4F64CF27"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "715D926597BB6641D009EE38DE3A55F052C0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "86209D025590A74CC22AFB9164372B8CC1E0",
                        "defaultText": "이 지역에서 가장 노련한 용병은\n다름 아닌 아주라이트인 모양이군."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A0E0964E7BD8A24A9F8832969D30201E35BF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D8A4146B4AE873459C9A6C853CE41CE92FF6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "02C9C82C9498314DF35BC23973412AB9A727"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F0AAEC0995F20545BA298F0773FF0EC4B442"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E13011726684B946CF8A1442F5AD1D7D5DEC",
                        "defaultText": "하하! 이곳의 부를 어떻게 마다하겠어?\n보수가 엄청나다고!"
                    },
                    "position": 0,
                    "characterId": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "368BE4975ECA06462B19AB051B916A12908F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0932B6A50DFC2848684947513C27DF7C4820"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "EA61077F9DA3A746582A2BD824D6EB45F57B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B0AA415C2C0F564FCD4B99E112ED782D859C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "33BCC3E66ED0954B24692DF2E60B4D463E09",
                        "defaultText": "우우우우후!!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D7D6A64A2036A348B6097517205795A5F62B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7A2097F27E22F04691481B20A0036108FCA2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4C060F9B8AF6E14B078937F2D97506D6AE71"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "66500B7A5C0CF84B4C1BADB52BCB66EB6634",
                        "defaultText": "너와 루코스는 언제나 무서운 한 쌍이야..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2A673534218A714AD73BFDA02ADCED6B62FD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0A9648294844C946FF2BC105AA88BB01B8AA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5EA326257D0A58446B1A7E31059D74C5F24C"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "EF470C6F8240B94603480CC6C52C134F99A6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "24A9A6D127FA58441869FD523C660159C7FE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "360AE4A78FA5E544854A9905B876718EB5CB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AE43B73F7D855848E638D341799F5E351CD6",
                        "defaultText": "이봐, 친구! 여전히 부를 좇고 있구나?\n발론자 님은 그런 탐욕을 좋게 보지 않으실 텐데!"
                    },
                    "position": 0,
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FB2F9FDD1FE9F3459D29C5D6B4CE78A08D6F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C13553064854A0433039C517DDB839AAAB94"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "A765FBFD5A1F7243877B4F374180532E2B2E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FCDE8AE31E8AA1438778F5598DE376A20E5F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8A7CEBCE23D9D449052AC84601DDDA61A335",
                        "defaultText": "아, 친구! 오랜만에 만났는데 벌써 날 비판하는 거야?"
                    },
                    "position": 0,
                    "characterId": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6165B70544DF5148481A4D98E69FD0CCECBF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B85ACC4411AE77429B09B501B492FA0E7F74"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DF1D149C7BF48042D71AAEF658DEB9989955",
                        "defaultText": "게다가 발론자 님이 아픈 어머니를 돌보게 하셨으니..."
                    },
                    "position": 0,
                    "characterId": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F458E02565492240E07B69B1105EAB5C0CEB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5A88ED474A9D9544630937581CADCE9E6EA9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            6
                        ]
                    }
                },
                "indent": 0,
                "uid": "87F3A55C8EE2D548F3786895E90C04379D7D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "129DADF83C17B546CC3AE9493B0384BBF60D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "79220AB373D4B14CD22884950FA54703D0D4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4647A3AD1EA68947D57B8E38C384F65BC4AA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B8B7571C397A8640628A73F8C08DFF651910"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BA9D64881A676847C808E1E466677721BD14",
                        "defaultText": "즐거운 이야기를 방해해서 미안하지만... 본론으로 들어가자."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B3861F091494964275598FD1BDB0548450EF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AB49B1C58E0FB64F088860D4D64E7E49DDF9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "05BBA303028B924E4C5948E2E465E282EF58"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "FDA1C2C385B0684CB6595431E19FADC6B47F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CE881CF59115484D294984B80C704D8FF2FF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "668BD6CF920D6547F489CDF7CDF56874B935"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "03CBA9D73647824075789E511C4640F67813",
                        "defaultText": "동의해."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "543D0689542446496618E208DB886C5836D8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "B9241C013F03404C748B0C25B42DC922F53D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A18145305D08424C816825980250B967840D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 84
                },
                "indent": 0,
                "uid": "DE0307681A5D9245BF29D633E439BF8603D9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "EFF7C0F1645CF849AA2B1B4142A42C29178C"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E467A33463644242107878B2B6C71F99FF58"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "509FD68D50F35442366910307673BF70E71A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "470102CA5B3D594D091B35F28E5A105D94DB"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "close; reopen with princesses as the main focus"
                },
                "indent": 0,
                "uid": "6EDE68F653F0974253190442D4EDE17CF2CE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F5271C884F7FF345EB6958865649C1812142"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "322F513443391542D1089CB57441FDEF306E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D053FD881324824D911A62B1FAEAC7377E98"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BBB684EA5B9DA84AFC4A1FD1F6C6557BC490",
                        "defaultText": "피비가 이미 전부 말해 줬겠지.\n이제 네가 아는 걸 우리에게 알려 줘."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CAD7A5530496224261992EB520FB41311C3A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6655EF68256EC84F187A12C95B60F1C0CF00"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "DE571AC0952FD44C077BD678811945E80E3C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F5BA5D0C01B2114C633A2E7123FEE160B4ED"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "68163A3D26AC9641305A94472319512A6101",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Azurite",
                        "name": "E3-Azurite_line6.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B3B0949E5A49534EE2991B3920942951CDE2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B44824CB80697448E1087808ED694C92ECAE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A593941C7287884116280B49B64A1D4E3D52"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D272321C3964864C348B3DD5B2B17AFCDEB8",
                        "defaultText": "그래, 그래. 공주님들과 있으면 숨 돌릴 틈도 없다니까.\n안 그래, “파로레”?"
                    },
                    "position": 0,
                    "characterId": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "48ED4E1D7F42A143111A9B6812587A6EEE74",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "97F95E2E0CCE9141055969B60880BD079E5B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ED85295D543C034F004990781ED15B7B347C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "DB1A301A8F75C242D56B00C2B1D7FC46517C"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "24061C8C917D6245099B80E6ACF9039896F1"
            },
            {
                "id": "vn.L2DParameter",
                "params": {
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "param": {
                        "name": "PARAM_BLUSH",
                        "value": 1
                    },
                    "duration": 15,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "9753F5C3711A47443A1B5624F3C39AB444B4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C8C9AB924DF9394BBF6BADF2B5D0E276E01E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AD8DD285542B6249A37A0EA86616AD9B6563",
                        "defaultText": "그, 그때는 잠입 중이었어!"
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "94A7858920EE694645786A83D3CFF86B9476",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2C434BFD65C8A849EE5B7386852817986DCD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E41ACE1A1A4DD54E6A5889D8FEB439A248C2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "24D4FC3928F7604D47494584325429043B07",
                        "defaultText": "솔직히 라줄리스인들이 그 이야기를 믿었다는 게 놀라워..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CE5B602E1C8FE540165A10974888AA20A4CB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C834A8406810314F472A22E16B5659A41B3D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "76CFF1405E943742975B4F83BD8DCAB1C5FF"
            },
            {
                "id": "vn.L2DParameter",
                "params": {
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "param": {
                        "name": "PARAM_BLUSH",
                        "value": 0
                    },
                    "duration": 15,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "30C112EA16D9E44C236B24914A107A0D748E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A310702020824645C389200235CA57FBCEA2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A61BFEC5692A4040AB1B9EC8151201CFDC39",
                        "defaultText": "그래서, 아주라이트?"
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0BF6862D74AA0846B1493564A695F1C89E5C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "57EE6F2841842240D0194BA54DF2BBF38CFF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2131356299D58043FC38C4C0A5D80E567423"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B292706D3D21064C8D6AC1C1F396F85F29E7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B755F8B023E9C14CDE1BEF644D319075EF27",
                        "defaultText": "내가 알아낸 바로는 지난달부터 사막에서\n이상한 현상이 벌어지고 있어!"
                    },
                    "position": 0,
                    "characterId": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A2C8FFA50B4C6244B6084B1119913D6158B9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9EFF17B4524F724D3E2BA1A8AAF77A860FF4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A1E8DDA220B8494A471BEF39341A592C5771",
                        "defaultText": "모래언덕과 오아시스가... {SP:2}{C:1}이동해{C:0}."
                    },
                    "position": 0,
                    "characterId": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BD96AC661EC078496E3AB4F8E9BD34216649",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3F2F2D533378A44FB1982C56D0639597E718"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "89E4A61505C544452619DD188CBD2500F189"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CF4CA67D42CBA145CF3802D3A7127A48D6E0",
                        "defaultText": "어, 지금 뭐라고?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A261E13B3536A14D59889F195DC6C26272FE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CBF2A29A1906A443B14BC824D435FB0E58F9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "650F262D62FDD64EDE7A34B2A622592A4BD0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "55F7A9D448E7F64B1D58B7D60A4C9860121D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3D886ED12DDFB2404B588CA8AFBEA366EEA4",
                        "defaultText": "이동한다고. 그리고 “지난달”부터 시작됐다고 했지?\n너무나 익숙한 시기야."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DED5D9E31EA884489D3BFE30B3A1EE163E4B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A5F3A1E856DF88453E695647E29C832BD663"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4E7FBD3F912BB84D47491943C57073B0920E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AE27884D8F54864FD178E4C1E0BB3DC20674",
                        "defaultText": "분명 헬리오스의 각성과 관련이 있어."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7AD273DB3660884394791AC6BB0731A7410B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2162C56413A9C54F1609125281DA59D087E0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "39F6BAE4829EB240122959D7EF7C10D72EE6",
                        "defaultText": "마왕은 마음대로 자연을 뒤틀 수 있어. 기억하지?"
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4E49AFFF53D3484C3E5B63C5099AB169637C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FD273A452776A1443C884B45101B90EC436F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E677BC387ABD654D6D5B81E09669EB570EF1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1DB6BBA915BB324C37389F26E79A9F87C162",
                        "defaultText": "그럼... 헬리오스가 여기에 있는 거야?"
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "787B6D2505F39744DB6B2566128707A1FBDF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "88B927DF079AF5431C9B4BC339F94FB5BC42"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "140CA93D57C8234B1F5B337330FB01298C64"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "DBC6228741E2E2438C381543372B766FA31C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B43302C23C35D44EAD2B24F8C4968E3525FC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "26A020178D05874BC86928274596A08F048E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FB5E7A6F1F75B64A7B2BEA1886CB60D51700"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Defeated Tacitus?",
                        "index": 230,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0EF948AA581BD44B87888352CE896F08A339"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "43A18EF625B6B44E83782194969448609B33",
                        "defaultText": "꼭 그렇지는 않아, 니니. 대악마에게도 마왕의\n{SP:2}{C:1}특성{C:0} 일부가 있을지 몰라..."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "4308C24E73B9334E8939F6E3AAC821DCB751",
                "expanded": true
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "026D28A660B7904A8C895C9863C043B14BED"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "09B68D0744FDD3427D2AAC73368F55F827D8",
                        "defaultText": "꼭 그렇지는 않아, 니니. 타키투스 때를 기억해 봐."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "FF03E43C6AD3E4471919B3F81B887CA869AF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "5387BC376C527848763B6AA17B1A9ABEBA21"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "57A81F2717D8444BD11902E2B2DEA5A1FCDD",
                        "defaultText": "이 대악마도 마왕의 특성 일부를 지녔을지 몰라..."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "1FC057344B49F54FCF2972A864B019564073",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AC7C19724EF8E147AF2B2D52EE646985D77F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "92780C0A52F6554D405AFEC6901DCA91D1B8"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "9585DC6F137834444C8B2D24547A11D16BBE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2D21D15265B2474BC1881AE46AB38A6923B7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "81EF26176CF42146C769DF22F09E0855E6DD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "57ED52ED8BA4234DCF5BF2B1F3FDBB1154EF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7B7B6E20298D114C6F496AF4A4C4C64C6DC8",
                        "defaultText": "어쨌든 악마가 사막에 숨어 있다는 뜻이야.\n찾기만 하면 돼."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "424F88B38A9B22490A199111A435CBAE975A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5B0A390781C5954D131B5E15218E6FFA30AA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "8311487250FFB14A8A1B0D574C60BBF6B8B7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "69A92680817B534E6E1AEEB5F03950E4577F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D8776B3D504E6242AA8B9B725A6B2C5A81D7",
                        "defaultText": "늘 성급하다니까, 친구! 말처럼 쉽지 않아."
                    },
                    "position": 0,
                    "characterId": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FCF256EA4F4C494D5588006600FF8F3699ED",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6D46BC7354C226432D79D1784AB00F22FA9A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EDFDC08056F8B34E7C2B1AD582445B11E295",
                        "defaultText": "피비 여제가 고용한 다른 용병단도 이미\n이 지역을 샅샅이 뒤졌지만... 아무것도 못 찾았어."
                    },
                    "position": 0,
                    "characterId": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BA9A81DB63A4854CE8184A831051F97600C5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BE968C485C32614211288225FC3DA8A2F278"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3CD28E9F27C6D6441F5A3058F85156221F65"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9606B89F1B3BD74E4B093433DF3D7BC6F94B",
                        "defaultText": "정말 아무것도? 어떻게 그럴 수 있지?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2EBE81AA3981F34A2428C927AAA8451B112E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "13019019243B89440C1B5806D52F365C2B38"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "37B75D030D11264A4E9821D12CCCFB1FD07F"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "22B441450207A641C84A08C22DBDA18CC825"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "36E23EF1568EA24EF1692F1917C94A6B0F9D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "776B35CA263FC7474A1BB413741D78B197EB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1AA78F6A64EA7544E20A3D8468D96D12B50D",
                        "defaultText": "누가 정보를 가졌는지 성채에서 물어보는 수밖에 없겠어."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A5E6FD694E511145964A0E24B4AF51BC4B11",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AA11947E3D264542C68B93699DA4AD3E8D34"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A7478E721028C4482E2B9491DFC0BEB41CB1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "666F1E2922733348FB7B4BE67FC839449E2F",
                        "defaultText": "맞아. 지금 바로 그렇게 하자."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7A2A35AD8C2FE246A20B25C55C3632815F0D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "31A33F815CEAD249263BAED8B67A1A3D1BD1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "FAC566AE44926245D64A9B84EB2C012072FA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "539FD4691442F145020AE1554FFC471F115D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "48B11C5C25F3F54E5D188B02EB25B590B222",
                        "defaultText": "이봐! 뭔가 잊은 거 아니야?"
                    },
                    "position": 0,
                    "characterId": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F25C408374FC2243B44924591CFE48FC4F6E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "53C3E31E5EF2C248900AEC31225912C1DC40"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "AD77AD3626ECE84B7E38ED48DC0F5A62A65C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DB8873992E32F641E01A2E112AC86970F41C"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "close; reopen with Azurite as main"
                },
                "indent": 0,
                "uid": "AD0808530FD4D64AB3495C84FEEA92B0A410",
                "expanded": true
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 72
                },
                "indent": 0,
                "uid": "515EDEA50D6A574CCD6A92A5287C730C8588"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "BF1AC4BF73F6344E6F68F7D231733F6F948C"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E083892C4E96064C6C3829D6E0A131133055"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            6
                        ]
                    }
                },
                "indent": 0,
                "uid": "4B8E64091851D14C595B6BE8D34BB29317CB"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "B63B1D772F31B749731B5655EDBEBF381892"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D6716C6648F63843538B6B87930EBD81ED83"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9E6E95B874D13048CE587C254E553BBD8306"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0D466E8B3CF77348792887304D5602556EAE",
                        "defaultText": "흠흠. 이제 나도 정식으로 너희 일행이 된 것 아닌가?"
                    },
                    "position": 0,
                    "characterId": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D9685E1244FAD54C2F78C060001B5590AE1E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ACA99EA86313A049FA38F467CB55E1EDED5F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8AAB1EB52AA5314FFC8B0F669351A136EBFD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "8E9A45635A90C446C82B6F51C73049D0A3DC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9BE2201E1BEA764EC74A10D132090F8C59C9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0D0436DD0B64684F2849A7C35C984B2D8C15",
                        "defaultText": "와, 정말이네, 친구! 신나는 소식이야!"
                    },
                    "position": 0,
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DBAF29BA49C4B843803BDD5874E4FC7BD69A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "49C36D912103C3447A3BE4184A3409D6E34A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "CF7C71A9589362402E9BE99664387E673EA9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DA9B6ABE52B4B641112B4BD0E67594EF4CAE",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Azurite",
                        "name": "E3-Azurite_line3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A8E438E935B4744A3C6B04F72B0DE54DB8C3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "66C5459C09A2D44B7A2870A988C58E4BA278"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E4B2C1E21C4BF54F2F594FB3CB27B1D14ED0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "33CA40D7501616401F583390406999726A3A",
                        "defaultText": "이봐아아! 이 대악마 녀석을 함께 정복하는 거야!"
                    },
                    "position": 0,
                    "characterId": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "62A5BAE53E21D2487E1B0CC41FA352F8ABF4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "75530D5B222AA6427E1A62F9F5D6966812E3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "134427A56225314691282D712ED5E1ECDD34"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "F23D92547A91004A0E8A6585DF0945A127A5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "422B49CA8A63A04CB338ADD9E56A9BFB25A0",
                    "parameters": {
                        "values": [
                            "",
                            {
                                "lcId": null,
                                "defaultText": "{C:1}Azurite{C:0} joins as an {C:2}Adjutant{C:0}."
                            },
                            "",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C946F8381CEAE846C16B5B69A8A3D8A2610E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6FE3C1466BE6D749E93B1A1763C2A8DE2900",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "7E4BE531860E314FC81B646523C22955669E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "7DEFA4E056B0424037680879F6D7F754DF58",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1D840F946F85F64EB37920A3FD6E7EFD3D62"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "AD45D7F67670274F782B2CD23D572F5515B8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D86A0B755C3931407F0ABD74F73B1E1241A9",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "F2EE7B2718559246D0695A08E29DE019F8BD"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "68E4FFED0AF6634AC889A7813B48E21DE971"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "DA048C7E6697C7481188AF30A50BC2CCAA55",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7"
                        ]
                    }
                },
                "indent": 1,
                "uid": "322FBB952C8BE84993388D9465821D09619F"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "57BEE836747521438A58FD483ADB5CE723FF"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "add him to the party"
                },
                "indent": 0,
                "uid": "CC11AB8033ED08492F8A3055863EF66A556A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6A007E692EB9F346CE699E92C06B202FCC35"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FF1824283AAA884E7028EC3042BFC1CDD72F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0047040361510741CE896E88C48600844948",
                        "defaultText": "참... “신나는” 일이네..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7692BCBF3DDB04404B6844A5A3D65B9A2EB0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1449C499726566471119E181D9C73F4F6449"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DE974F6C6CF3124D8518E916E60EB31BE652"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CEDCD7914451A847F80A7861955A5E95150D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D927C4CA312DC543623997330C44C28B7DC7",
                        "defaultText": "두 조로 나누는 게 좋겠어."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1CC803723BB2B848E988ADB6B61EDABC4C9A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FA910E501D73D94FC33B72E74988A021929B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "751DFF1B1D92D84B358933D1F787271088A1",
                        "defaultText": "시오리, 넌 크리스토프와 아주라이트와 함께 가.\n주변에 익숙해지도록 도와줄 거야. 괜찮겠어?"
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3DF33F945267454A712BF2190B3A1BE21E46",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0236A8A7453AF7445748AE2542D5F50F5D78"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B8216BF231A1124D747969872E8DEE5D060E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "62E1A5623F3DB34FE30B990210BD2BB4EF4B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8B978A38222F5345656BC041A0638811A5C2",
                        "defaultText": "물론이죠! 이보다 더 좋은 동행은 없을 거예요."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FC9658FE6BFD524ED37A2E1332FCB38DE6F6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "325C84577AE082441F6AF87321FF73EF8959"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "109FAD15738B614CCF3A7E312369CE097141"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "B164B2E415B3D741927802E6F31693FE3DCD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3F53B0B74E9A6444824A192237255831070B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "947CF01225DB58402A7BE7476A672D7F1DDB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "8D6D20F09EC6734E9E3956A527046315372B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E3E15FFC79F9A741AA68F180FF31AE34D8CC",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cristoph",
                        "name": "E3-Cristoph_line13_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E0BA5A115D17E844647B61516AAEA588B898",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "CEB636736A70C34B8838EC34DE7CD33D951D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2655EE193378B644217A6F57FAABE5B17D78"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1120B7639E02514FF61838161414F7FBE519",
                        "defaultText": "이봐, 이러면 내가 얼굴이 붉어지잖아!"
                    },
                    "position": 0,
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AB9141C77CF71341A53A0C2486724B64B0F2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D27D88E47FB50248664A641218515096831F"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "Sarcasm",
                        "type": 0,
                        "value": 50
                    },
                    "targetVariable": {
                        "name": "sarc",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "682990775704314DB519892840CEDAFFCA96"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CDD11A3187DAD94F1F08E223F7292AFD6DA3"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "sarc",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 55,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 3,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E909274407D2044E1A38F179B7B9B317267A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8150FA8D533CB7497D1BCB31EA0E2C02C165",
                        "defaultText": "나보다 더 좋은 동행이라고?\n미드바르라 다행이군. 영묘에라도 숨어야겠어."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "3450506B7EF625481928BAB2E59717AE5B85",
                "expanded": true
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Ornières x Cristoph",
                        "index": 404,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 60,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 3,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "68DC929A2399104AFA6BA635FEDDAED4CE70"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "206E16AB11A2C649174A24C4A38D9CB250D4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            4,
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "C32EC623873181407978C9C45E7C25D87A17"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "31385E6921EE5547E41BE7719B52943C46FC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "23E7284F2643324421595CB50FA4D9AB7069",
                        "defaultText": "...농담이야. 크리스토프와 함께라면 안심할 수 있어."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "3DC768C723FED34B8C6B1CC22C73FA7BCC02",
                "expanded": true
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "82045FEC3E1B954B6C1A052206D0B925EC60"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "056B72008AACF44DBB2B3BF42502CA18C9DC",
                        "defaultText": "질투가 날 지경이네..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "764C1750561C1847F799A1368E0A99FCA2B1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "631A602A9A05404A3089C2543694DBB5DD49"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D2A73EEA739FE644A36907619C21C3A7F563"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "B388EC745EA69740495B86812C41E27CE479"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "DC5BBD146ACCE24BA97A75C7F20ACEB95C49",
                    "parameters": {
                        "values": [
                            2,
                            2,
                            0,
                            0,
                            750,
                            0,
                            799,
                            50,
                            10,
                            -5,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1982C45B588BE54B7B49DAC5FD2E996FAD99"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "601965023B979749E05A20B15B0848CFE086",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            0,
                            0,
                            750,
                            0,
                            799,
                            -100,
                            0,
                            -3,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D2AB26909E7C13420F7B32F6A5463A73D8D4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "791883F40B7D44490B2989586833B94A6F64"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            12,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "95ED0F2A220A554A0178E544E86C9351E1A4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7520E5A11ED6274DBE6943A4AF158EE5F06C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "136E92CC4DC3B645A749F1C40DAB4F3D753B",
                    "parameters": {
                        "values": [
                            8,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "54F1FB928D8016430758F4E444F238DB5569"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 120
                },
                "indent": 0,
                "uid": "4D60CC9182C185441E5B37F57D563A9A0C55"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5D8679223C5E8744E028E00226E59A0D3BC8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EB282A508E3C674AA49B11C65DAC5049D5A0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9311122951846543A7597E700B45C1B73002"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4BB812546FB4444B413B21F45EEC87D3DE6E",
                        "defaultText": "반면 나는 파라트라스 님과... 저 둘과 함께 가겠다."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "66246C87318CA2415D5AEAA80C8DDB17903D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5E2ACB40673A574627388E077823E35B66F5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D283C7E28C3DB24D2378276196A00D380385"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EA1774E41C929443C909EC67346253D8AA82"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1DD0C2E190724847B519D657219A473ADB0C",
                        "defaultText": "적어도 리아만큼은 아주 즐거운 동행이겠지."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1FAF20DA3A5A12454D4AA3B45262F2C579D6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "082AD2A7932F254FD889D7D737B16F77C0DE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2560B4898EB4204AEB1B1E57C9BA3BECF74C",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "6D84F4182AA0674A887BCC028C8ED3E102EF"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "73089E877A41A4478A08DD9996EB49ADF6C5"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "If affection with Fa is high"
                },
                "indent": 1,
                "uid": "276270E02E08054EB46888A81C10C3C5C745",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "5DCECE0C7E09A348D63845C5DED88E0395C9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2F1DABF7649FE0473B6A946142B8A85B6D57",
                        "defaultText": "그래, 그래. 나도 네 곁이 좋아, 그릇."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "137F3AA965D9A447672B3F6088D7299D5E24",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "6911624B5B1296496C5911933DAF3C33CA5D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "7B608472422A874FFA7AEC0176FF33991B9C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "61C6D7F66E22B4466D1A730962881A4C01E8",
                        "defaultText": "가끔은 좀 더 솔직해져도 되잖아!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "51CA31DA2D8CF84EAA28D59531D6CBDB3C99",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "71F3A7A82573F44A992BDE989F8FECB101E0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            1,
                            4,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "",
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "D2AC5B602FAC37408C1B8F56713034D10126"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            4
                        ]
                    }
                },
                "indent": 1,
                "uid": "071CFEE55FC3B848BB48DCA13E1864A94C11"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 1,
                "uid": "F28E98BA5363E344A15BB847D4468FECDAA0"
            },
            {
                "id": "vn.L2DParameter",
                "params": {
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "param": {
                        "name": "PARAM_BLUSH",
                        "value": 1
                    },
                    "duration": 15,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 1,
                "uid": "E49C432470551246E5585A218AC34D6A6000"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "B5005781786E60490F992DF04947A2A94899"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4AFB84615B49A6493F6A5815A6ACF3CBBF6A",
                        "defaultText": "닥쳐."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "9003701651E2914800587546E615AC34A843",
                "expanded": true
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "0CAC9BD2102867458B6B15333EE16ACA635F"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "If affection with Fa is low"
                },
                "indent": 1,
                "uid": "F6EE1EA74D62D447B51A5B1469C02ACFD5E0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "F9B7DD9F2E9B674E778893C3308C47C7E358"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9D5785E84E7DF345F75BE8B880C067AE1704",
                        "defaultText": "오늘은 다들 왜 이래? 아야."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "900257375554F3484B1B3207B2252E278EF9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9AEC5A6F2622054605294141D600F4C726FF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EB88A5958CEC814D303971F5096E856DC29C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "584BF09D2E7BE74C168821A706CA611E5CEC",
                        "defaultText": "잠깐, 리아. “둘”이라고 했어?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B5715D3C7922654FCA1BE227A2A96BBFFBD6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4DE3AB1063DEC044AC98B638BE791D4BBB5B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "35847EE544F086492D4B69F64233088C781A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "5E7D1D7B6325A7451F4A97812C10C0D385EF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6659D8124671024EBE58AF209BA9D4FCE87D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B2443E86944917429A2BD9E0EA22F4869CC2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AC93109688EEC94B2E4A2E4258C93F32F6F8",
                        "defaultText": "우후 우후!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CC86986C9B344341A43A36B463598538E6BF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "23F7294136F1B143652A01A68514A743E6A2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9FA2376C53A03546751B08E63B61541330BE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "76992A3C4B5736462538D0584FBFCB2A66FF",
                        "defaultText": "아, 루코스도 포함이구나.\n새로운 곳을 탐험하게 돼서 신났지, 꼬마야?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "310781C84889C84C5F799981B79BAA3C0C91",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EA38491294AFE745D37859F5C14307181693"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            5
                        ]
                    }
                },
                "indent": 0,
                "uid": "F65083D365B44649CA68E3A7973ED7286E9F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E125F12737A105442538A0D48AA70DA03984"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "94CBF88A51BA4448116BEE717B442DE958C3",
                        "defaultText": "우우우우후!!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "364A6EAC658AA349518920C228B4A0EF6435",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "620F673A3DB5E543FD2887A65183344F05E4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "53BCAF337A91064DF559CB409AE84468823F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4783E2A2179B444FAE7B413354D6DC4F8A96",
                        "defaultText": "하지만 부를 챙기러 온 건 아니야.\n상인에게 훔쳐서도 안 되고. 또..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8CAF53508CC2E34037582D027B6600E15ED1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "57D77A7A7C29E849E72B83519921D974D2AA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "2BC9B428718082425A19CB12F99CE5D57734"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B9A6511B69CC174E125837B31D8811184392"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1F81FA554710584BF87B9293A331F3678630",
                        "defaultText": "우우후...?"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3BF1E7CF1EAA7447FE88C1B40197D1143A01",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "346F2D4A805583449C4B6E333F2D9B4ED3FC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "756A486326ECB14E5E2BB358548032669CC7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6D2A20577EF3B64312294A9491CF9121A815",
                        "defaultText": "있잖아... 됐어. 그냥 내 눈앞에서 벗어나지 마."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AB70618068CC3046BF692F557996DAE15DC4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "17A8440F6AC4F94B857B94746056DD187CBD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            6,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D552023C1E9DF3447C2AA9077875C306D768"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "844EB0B456A6B240EA99816596723D411306"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "73ABAFE76EF1484C8D7B359785D3D80917B2",
                        "defaultText": "그럼 출발할게! 테헤헤."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DB84D55A1C3A5646180AC993BED4AA7F9019",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2F8373638DE0D84AD9384DB26658BB6BA55C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F9984A794D2AC140AC4AF14158E2F46998B4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B7A1F31A6FA507484F9AD3438C4323B2C71D",
                        "defaultText": "좋아! 언제 다시 만나지?"
                    },
                    "position": 0,
                    "characterId": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8D8A1D7D10A7D14DA37951660294299703A3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F37F704F7D2D224F7D9917D2B39A2F801CF0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "203C2ABE8BB954424D795AA90FB99092B1BC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "708BC2531BBDA54AB749A3254FE9EDA63B28",
                        "defaultText": "정해진 시간은 없어. 정보를 얻으면 광장에서 기다려 줘."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "43BA1CA53870B6431D1B02D17F604D16AF5B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9AF98D9C0879544310182BC29FED4D0F695B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ACE922559B83784EC47BB4C3E8CC120CD501"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8D814B8E27B4B747F63952604D523ACABEB9",
                        "defaultText": "좋아! 가자, 팀!\n저쪽에서 벌써 흥미로운 걸 발견했어!"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "63E732D08B95054D63199BA50DFFCEDFD37B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "3EB11CCD136C674E5D69DE76EC1E1990264F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B022A7916AAE994CF29B489568D941F70C8B"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "A0DBF48497B88346B0396964B77FF3F464B6"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "duration": 30,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "7B2FE25B8B14714C964860C855CE2B64414D"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "duration": 30,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "8F1F83757EE542420F193013BAF3D39BA515"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AA53A3133140C74BB979A0645E51B4BE7E40",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E"
                        ]
                    }
                },
                "indent": 0,
                "uid": "258CDCEC64B9A34DCB0A9C03ED13F5E09EA2"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 84
                },
                "indent": 0,
                "uid": "350E44E94D9658413328B1697FBF0345060D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            8,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D70109D05381C84FE64A7ED9CFC52B945036"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            14,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5FABBF4929DB724CD2494099B311D3C9722A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DF2E245633D2174ECE3928A35BD10921F79B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F7DAA49E9E060346535A5697223FD5569906"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "91EA83B67A65474494183BA81523BA125AEA",
                        "defaultText": "아, 아! 기다려 줘!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B3DF8B75559CB146CE09C7D8205527C85488",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "3FE69A7B6DD9D04F9A2B9858AC5D9C335D09"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "154364601B87B5403138485129B3AE234D55"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9667DE5307013447DE28C3D3C36B74D9FF0F"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "9D069D83502083474369A8262DADB69FB735"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "duration": 30,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "F1035AC49DFFC343A3281627CA6793A2398D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 120
                },
                "indent": 0,
                "uid": "52F6EA107C9296419B8BF3352A344F819808"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AA53A3133140C74BB979A0645E51B4BE7E40",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07"
                        ]
                    }
                },
                "indent": 0,
                "uid": "31FE31080BF0A9483D19317480FC8601AD02"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Vuoto",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "F4BEF10F5F65D741532A7032E48F5B91F271",
                        "defaultText": "Vuoto"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6DB7A8E07C55394FB78B627649CC8E8F87BC",
                "expanded": true
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Character Slot 1",
                        "index": 20,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 2,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "813358B00F90A2457019D7B1816E507EE836"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Character Slot 2",
                        "index": 21,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Vuoto",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "DCED183B193695471589BD72B5E3864EC8B5"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Character Slot 3",
                        "index": 22,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Vuoto",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "386F34CE37CED84F0E8A5551EC32B6C5E3E7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A1D985ED15C11240A32B0359FDACB5E75EAB",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "",
                            "45918E0E12BBF148635A9360998958409EFE",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 3,
                "uid": "5709E8F3595DA2458F48C4A26D7A3E71C36A"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "close;reopen\nthey disappear"
                },
                "indent": 0,
                "uid": "123F829B1714A44F151AB1C6C6BB73F7DD17",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C4CD9DE41E943849F17B2E28150C797846C1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "66AEFA0C4433074A857B1776AF513CE7714A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C69DCB067417624F2F1B6956F5D2B50010A7",
                        "defaultText": "다들 조금 지나치게 들뜬 것 같아... 유람하러 온 게 아닌데."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3677DBDA1C59084B1D686C8336A41EBED4B6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "026927BA605A4043436BDAC40DE78AB288E1"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Defeated Tacitus?",
                        "index": 230,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BE1284363F6A6642B01BF9A5EDD9010EEF69"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B394A14347008947E119D9858CEC08323509",
                        "defaultText": "특히 시오리가 걱정돼. 아직 시야에\n익숙해지지 못한 것 같은데..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "A2B214634C4D474D3F7977F3769700BE86A8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "C4E1E02981DDD14F6129101030C0B43C3FFB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3C02A90E2C6C67457B1ABAF51F80C28E179A",
                        "defaultText": "...늘 그렇듯 괴롭지 않은 척 최선을 다하네.\n오랜 버릇은 쉽게 사라지지 않나 봐."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "1D1589092ED81740B46A2AB7810C0C3FC63E",
                "expanded": true
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "78415B915A6E934D8D390D958594C8F559FD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "21BF1EC93483084B535B867560068716AC16",
                        "defaultText": "그래도 타르멘에서 있었던 일 뒤로\n시오리가 조금 나아진 것 같아 기뻐."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "17E83AEA6DF6204224685D206BCC475D6A4B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "5A109ABA70A3F74DE66A2886BE0D5B0216C6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "35A2F0F629E81847DA197B5683E7068B12BE",
                        "defaultText": "완전히 회복하려면 시간이 더 필요하겠지만...\n올바른 방향으로 내디딘 큰걸음이야."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "06AF65330504F247F2682E958440269E3AA1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "59399C7C8E645248EE2B8E34744EF29AD7D9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E44074EE5E717142BD1A2FB8CAE221C3B8CF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D99C84E74D3B63479E7AC642370FE59204E3",
                        "defaultText": "광장을 살펴본 뒤 반대편 동네로 가 보자."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "077269A5060D32495D1B96410EE438C89CA5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "62025A703AF2C34FC638F1E650B12D581161"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F65DF72834CE674AC488616871CFE8F49C7F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "626A9AD091B7614DC5593C85673CB22809A0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E5D510878A735149A01B92B6CA9B5632E210",
                        "defaultText": "마음에 드는 계획이야."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B99A4D2687726543149B83F244EE6523FA48",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "3B9D19AE7C5019479A5A8A9145A0B68106E1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0E15D8756161D346A35A7D646AE5213FCDD6"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "B444621D38F55547063B39F025820C859802"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1BD8725E0D9E344CE22BA0F8C56A41689C28",
                    "parameters": {
                        "values": [
                            "Han'naje House 1"
                        ]
                    }
                },
                "indent": 0,
                "uid": "E1A986D12B87C04587794A1726FCA4AFD6A9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D1D322CB2E2602402C88D2428C77C01E35E6",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E87DAD90071A0246FF1A8FC8245BC44EFDC6"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "4966F3B72A2C0642077863957133C6E6A957"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1BD8725E0D9E344CE22BA0F8C56A41689C28",
                    "parameters": {
                        "values": [
                            "Han'naje House 2"
                        ]
                    }
                },
                "indent": 0,
                "uid": "2D59EDC222D6484F708B36D1232BA2BE770A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D1D322CB2E2602402C88D2428C77C01E35E6",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "51481970811231478458D0372C722F5662E1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E6230C567FB46248DF3B5A91C2AAD05178C4",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "ECE9EAA32AAC394CDF48F8B6329B303950DC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "491D626C40FA144C1B4832E147AEC0586E74",
                    "parameters": {
                        "values": [
                            1,
                            "3989CE0F143D5845B23A4111011B566624F4"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6F26AF794FECB240807B9D52A20506975006"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "97743A035EE7D14DC52943F03C3AA43EE1C5"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A08C5FAD0A269845C3495724D8243761357C"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "3989CE0F143D5845B23A4111011B566624F4",
                        "name": "C11B-3 Han'naje (Exploration)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "70234F088ACEC4436709B5C5214235F714BF"
            }
        ],
        "livePreviewDisabled": true,
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "sarc",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "stringVariables": [
            {
                "name": "Azurite's name",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "Vuoto",
                "index": 1,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}