GS.dataCache['61EEA3E94950184E9919F0B63D1EBD29D6B1'] = {
    "uid": "61EEA3E94950184E9919F0B63D1EBD29D6B1",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C7-02 (safe) S3 Garion",
        "type": "vn.scene",
        "parentId": "AB77AAC47D6E1140E85A8E50396DB3C6544D",
        "chapterUid": "0F52095B7D21614CFF6A4784A9F9BE129CC6",
        "order": 2,
        "localizableStrings": {
            "22C13AD1114AD1444A09ACF3F31656BA4B77": {
                "t": "Wait, everyone!",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "B71CFE244E08884E47192B7506E9FB2A7C1E"
                }
            },
            "9620E9F971384345C2394E88B1510421D211": {
                "t": "This malice I'm sensing... it's familiar.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "BC3DBB0007BCE6462D5A4611BF00F2689359"
                }
            },
            "4023A64F9F9F0740761B3C56A48088A72E32": {
                "t": "Come out! I know you're behind that tree!",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "2AC6304091BF9548CD0872454550933B27B9"
                }
            },
            "B68EB73E6B435141562841740DAA720FF245": {
                "t": "???",
                "d": {
                    "eid": "3A82FDEA2388824FB16B3F3637C3552F48E1"
                }
            },
            "361DAB222DA1774CF368CF2785D72D8D5CB2": {
                "t": "Tsk! There really is no hiding from that power!",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "2D039A0F095D2346B68B55A8B0FD2BE8C230"
                }
            },
            "F56F2F873C7185454579F4A9B5ADFFB46997": {
                "t": "What!? These two...!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "F7F71C834B3AD44511895445AE23359E9E6F"
                }
            },
            "6305052C8D8AA74E006B0634BCD47A1F3A69": {
                "t": "(Unsheathe your sword.)",
                "d": {
                    "eid": "DCD7E0CB4682D843B078A4B682A0CFDA2286"
                }
            },
            "77D0346B8442D446E39AAEE01FDDFD3EDC40": {
                "t": "(Wait and see.)",
                "d": {
                    "eid": "B9834A6C52B6E541C33925A5C808BE0803E8"
                }
            },
            "4C6C2DFC4AFFA44D192BFB95AD7A93AA3A2A": {
                "t": "Wait...! Strangely enough, they're not malicious towards us this time. Quite the opposite...",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "547EBCB76E830345053BECA42E0C28155491"
                }
            },
            "C71FA4CD270B374A818A5D56C99EA22F51CE": {
                "t": "Garion",
                "d": {
                    "eid": "6052CDA29947354329297A56DD6ECABF0D5A"
                }
            },
            "48D7EAEB7288744EC79AC9F679DAD38930F4": {
                "t": "Hey.",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "3D53744632DD884ADF0829634ABA8461239D"
                }
            },
            "E76CE5CD5EEEA541709951A6DDF77ECC44B8": {
                "t": "That voice! It's really you then, Garion and Djambo.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "2172809B10B60148273B77624EE297B388EC"
                }
            },
            "B3E7E4052831B545235A4EA17D743B2B3DCA": {
                "t": "You don't seem very surprised, light mage!",
                "d": {
                    "cid": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "eid": "43F1C8FA7352274AC3987F206370C5A6DE4C"
                }
            },
            "768F821E6E4FE6420E496682CD3BA47DC6E7": {
                "t": "I have a name, and that's Shiori.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "D1BB6FA682962443010B4A82DBD7B2D03F28"
                }
            },
            "C07DD26253D72541A348DAC471C70D50E562": {
                "t": "But you're wrong, I'm indeed a bit surprised. What are you doing here?",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "25C6D66F571FB242CE0BDD92AA851BE96942"
                }
            },
            "96B2A1D81951F54F6F495054E95DDADF0CDF": {
                "t": "Knowing how accurate Shiori's power is, she should already know the answer to that question...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "7B042DE91FAC2240443A9C896A97B4763E72"
                }
            },
            "1F54CF44196A584D7B8A3FB872EED125817D": {
                "t": "I think she's trying to make them confess something. I'll play along.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "A27673621E8B9247378B7CF6458EF737003F"
                }
            },
            "AE584F9F537B274B4A3952C1BBBF0276B4F4": {
                "t": "You'll be better off not trying anything funny, you know!",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "9A31E94928B044443C0A79F60664AC44DDFA"
                }
            },
            "501D1FE065D3A841E118FA63D5065214B9CE": {
                "t": "Shut up, you!",
                "d": {
                    "cid": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "eid": "F65AFD747D131443DD38AF2903D3292EAA03"
                }
            },
            "43725CD5398C96465728AB30AF673FA2FC2F": {
                "t": "Should we dispose of them, after all?",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "5FC926937FA170470448747254B16F30E5E7"
                }
            },
            "0979A0418686F343AC3AF84852BAB19C964E": {
                "t": "Wait, everyone! Let me handle this.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "1824CA735CDE494D6E59D0110F8779B0DBD4"
                }
            },
            "B926E55C2E00D641A588AAE6BF9CC0E2FA59": {
                "t": "You too, Djambo. Behave.",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "9710DA1886073749283933E92C37FFE3290E"
                }
            },
            "733309E1776EC24C7E0ADD71B909FC2C8609": {
                "t": "... ... ...",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "5DEF5B5F933FB5422F2BD1994F32D5724816"
                }
            },
            "3AD254DA85C2C6456038D5C4CBFC714E39A4": {
                "t": "So?",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "C943A6392A74434607285D34A3F11E5A37DB"
                }
            },
            "AAFC5CC79A22E04914480E151F53A6193194": {
                "t": "Let's say that I decided to redeem myself for my past mistakes... Shiori.",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "66362E5F238D774DAD2AAFB7651915B28975"
                }
            },
            "C20958BB8593E84D9A590EA6240914F86699": {
                "t": "And how would you do that? By helping us, maybe?\nI thought you hated us.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "D4A48081010B18434A2A97F0ACC9FE314A79"
                }
            },
            "CBE3D1F09C5927480C1966768E57AC7E9C0D": {
                "t": "Do you expect me to not hate you after you killed my men!?",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "6A158AAB85DAE746446AD516726A16E3D5B5"
                }
            },
            "3341FF8657323849905BB436058B0A5B1E9E": {
                "t": "And stop reading my emotions, that power is getting on my nerves!",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "EEFC668B4358C24E340A861139C7D94C8802"
                }
            },
            "6FDE5AEE2F5067459D38677407B0043F28AF": {
                "t": "This power of mine is the only reason you're still alive. We'd have executed you on the spot if I had seen malice in you.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "BEA72BA0679023467C3AC460ED6ACD1E0E4F"
                }
            },
            "40A660B58971F54EE7684A9438D07D7ECB09": {
                "t": "If you don't believe me, then go on.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "F2A69E965F9EC14426891FF4A1F72D6675A6"
                }
            },
            "DBFFA594558CF1470B3A6CF1840C3C9FE399": {
                "t": "Get malicious. Kill me, if you can.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "BF5539084AB5C440DB09A501D343ECE1C85A"
                }
            },
            "6D2AA6543A4E3643FF8823D89C4A0C79BE33": {
                "t": "Nnnrgh... Grrrr...",
                "d": {
                    "cid": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "eid": "AF001CA05C2403486C584696788C9E908DEB"
                }
            },
            "23AD0E15084EB24F5A6A8187D51B71E2F479": {
                "t": "Behave.",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "42252A2D0853954C3958C201E8EDD6800C8D"
                }
            },
            "53D847201836E14F8D189B134B0912CCE08D": {
                "t": "... Damn!!",
                "d": {
                    "cid": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "eid": "DB63BEB64F0B6644C778BBD798B3050BF16C"
                }
            },
            "6873D52B706D6842428993B8AAE596025FEC": {
                "t": "... ... ...",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "B36CF4F34472774D4619FFA1E5C0D5B99192"
                }
            },
            "1DA9971345AB7247D17AE360CBF59DB22C6A": {
                "t": "Relax, both of you! I was just kidding, teh heh!",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "5D7E7BC82873E54FD06B2C279F8D2085CC4D"
                }
            },
            "FAE938DF84FF1548798A87E891F2C9BDE86F": {
                "t": "I know you're telling the truth. Your reaction just now confirmed that.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "0B27AB163D46B94BF68AF1C11F19CEEDD547"
                }
            },
            "57CFF6CB64BE5446897835821823568F6501": {
                "t": "Shiori can sure be scary at times... Even more than Lady Faratras and Rya...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "5EF01296895F164EC32B89062BB0957FACC2"
                }
            },
            "04F2585E33301647182835136087F16C19E7": {
                "t": "Listen, you and I are not friends.",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "96886E9A0CEC4441A5381C07496DCCCEF066"
                }
            },
            "9243EC8F77DEC94AF75B6DF10D83575545DF": {
                "t": "You have your interests. I have mine. That's all.\nAnd now...",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "3BE3AE79743BE941243ADA381C845A5C6612"
                }
            },
            "5D70467E6D6572405B88A0A618003B52A546": {
                "t": "My only interest is to help the princess who spared my life.",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "0CA2D01372EF504BD21940F8B563AE9345A2"
                }
            },
            "B03E2E9958DCB844633994516B56319735AD": {
                "t": "That's... unexpected.",
                "d": {
                    "eid": "910A5039339373415E8A31D2300F289AA27A"
                }
            },
            "4C6EAF8A57A6284A95785BB467FDA806263C": {
                "t": "Welcome aboard.",
                "d": {
                    "eid": "123B10BC3BB0C64D9038C49109B2B96F5CC0"
                }
            },
            "9E0CF2C2794DC94F503B9A420A8EF9D1FC22": {
                "t": "You're a bit old for her, man.",
                "d": {
                    "eid": "2F21AA8D16E62649CD3ADA13111BF05F0E4A"
                }
            },
            "09B859C51D60F64E5A9940971C55AF1188D8": {
                "t": "I hope you don't mind. This is very important to us.",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "ECAEC1E3465D9440A96B9BE6DCE61E11EDAB"
                }
            },
            "E3060FC05C866041F5380DB4C1B568FC2874": {
                "t": "I'll make sure your trust isn't misplaced.",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "48CB47786652D94B637AA9A2B4A941785227"
                }
            },
            "3C738BDF1CB92544E63B3C140BE0AF2CAC51": {
                "t": "Hey, don't get the wrong idea!",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "9EB680488AF47240988BB9B4E12DDFBBB7C8"
                }
            },
            "CA19873275A8864486593199831D8E0F3E5C": {
                "t": "That's right! We may have been cultists, but we're men of honor. We always repay our debts.",
                "d": {
                    "cid": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "eid": "C4D6C226528ED047158B56D526E47E8B230F"
                }
            },
            "818D5FA56DD971472C48F574FD4EF78B2599": {
                "t": "Garion, Djambo... this is fantastic!",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "03421895854484497C5806378A49B5F62EE0"
                }
            },
            "6F2AA2485F31A248C84854116A025BED8267": {
                "t": "What?",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "7FE7D9103D4F7747FA6AA5A9D99E31BC093F"
                }
            },
            "A30E75EF400137459B9A53375886C9F16DF9": {
                "t": "Since I just spared your lives as well, it means you're in debt with me too!",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "FF282DFA20887845EF2B021222BA9DC07297"
                }
            },
            "10B5960C47C976461A3B94E5674A4911A5F4": {
                "t": "Why, you little..!",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "2B9935B2740CB1414B7B78321896C9B3EB2C"
                }
            }
        },
        "commands": [
            {
                "id": "gs.Comment",
                "params": {
                    "text": "This event only happens if Garion hasn't been imprisoned"
                },
                "indent": 0,
                "uid": "4ED2A9D178DE754140887A37752ACD0C0266",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "21CB77C16DEB404FA26A8F35BFB39B2FD0D7",
                    "parameters": {
                        "values": [
                            "2D020C1916A3814359783A811324EF00AF65",
                            "0FCC16EC8F14214F211BD711C5EF156BDE65",
                            "",
                            "",
                            "",
                            "",
                            ""
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9FA701A33541624EF029C528FC9D487A1DCF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BBA341F53645B74582982FB5C8A3AD088F7A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EA8F6E938C9E58431B4B784556C848387ED7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "71C99C758AFC56456D1A52037BA7AF2C7F52"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "22C13AD1114AD1444A09ACF3F31656BA4B77",
                        "defaultText": "잠깐, 여러분!"
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "B71CFE244E08884E47192B7506E9FB2A7C1E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "03EAE560786CF64F441A20C851704A302A4F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9620E9F971384345C2394E88B1510421D211",
                        "defaultText": "지금 느껴지는 이 악의... 낯익어요."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "BC3DBB0007BCE6462D5A4611BF00F2689359"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1E959BE180465740BE3B6F77C8730D26B78F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "24F435615E1DE14DCE1A4534FC34AE5890A1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "13E150EC15E5404B6539A446A9056B48C175"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4023A64F9F9F0740761B3C56A48088A72E32",
                        "defaultText": "나와요! 그 나무 뒤에 있는 거 알아요!"
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2AC6304091BF9548CD0872454550933B27B9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7E4F96DF2338D648A50A37694695F358A5E5"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "B68EB73E6B435141562841740DAA720FF245",
                        "defaultText": "???"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3A82FDEA2388824FB16B3F3637C3552F48E1",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Garion"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5A914F3E45A7C740E5888B532E4B88D7381A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "210E50457F4264469B484B847C3914763FA8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "361DAB222DA1774CF368CF2785D72D8D5CB2",
                        "defaultText": "쳇! 정말 그 힘을 피해서 숨을 수는 없군!"
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2D039A0F095D2346B68B55A8B0FD2BE8C230",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "FEC76E7E6B5544453319ADF8D1896C147711"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "14DEF2086365D44AAC79D3428C6F477414E8"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "C73B4368334A0449F07B44B8CAB00EFE05C1"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "model": {
                        "name": "Garion.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 801,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 214,
                        "y": 154,
                        "zoom": {
                            "x": 1.6,
                            "y": 1.6,
                            "d": 1.6
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 54,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "622747008C5577439C4925646C4E3B4DE791",
                "expanded": false
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.75,
                    "idleIntensity": 0.6,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 1
                    }
                },
                "indent": 0,
                "uid": "15C0C54C0E06F54BFD7818504FCE61491F80"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "A7896CBE4CB94541B638BF96B5DACB2DF439"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "model": {
                        "name": "Djambo.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 800,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 789,
                        "y": 250,
                        "zoom": {
                            "x": 1.33,
                            "y": 1.33,
                            "d": 1.33
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 39,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "8317065E44A8364B0329961102D21F45359C",
                "expanded": false
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 1,
                    "idleIntensity": 0.8,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 1,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 1
                    }
                },
                "indent": 0,
                "uid": "0CFCB58167D0A34E078B8F7324DB3F40FFF1"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 66
                },
                "indent": 0,
                "uid": "F663EDF245F6A6496818F84425C0E489FB39"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "EFF7C0F1645CF849AA2B1B4142A42C29178C"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C8A5D0A14AAE33425F58F7A1B675A3D0EBDB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4DADC68D780364448B394CD0F157C4FF92E5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0CDD47BE2A79D54EF319C3A26E095D6E9AC2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F56F2F873C7185454579F4A9B5ADFFB46997",
                        "defaultText": "뭐!? 이 두 사람은...!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F7F71C834B3AD44511895445AE23359E9E6F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "16E2E8CA156941487B582051F2ECF079E696"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "6305052C8D8AA74E006B0634BCD47A1F3A69",
                        "defaultText": "(검을 뽑아라.)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DCD7E0CB4682D843B078A4B682A0CFDA2286",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "77D0346B8442D446E39AAEE01FDDFD3EDC40",
                        "defaultText": "(기다려보세요.)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B9834A6C52B6E541C33925A5C808BE0803E8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "Fight",
                            "wait",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "EBB6AB5A4423154D9F98E8222E81D61AE6C6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E725A7562E059746567AE030C87BEBC61C1D"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "Fight"
                },
                "indent": 0,
                "uid": "8AB124702B0D114C789822324A4645A0B4B2"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "fight",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "49F7E5B56F7FD94A539BAEA70188106E923C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "523B023696323140013ADAD5B8F96229CA4E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2FD27388768E5346705803E51B0E5AB69F65"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4C6C2DFC4AFFA44D192BFB95AD7A93AA3A2A",
                        "defaultText": "잠깐...! 이상하게도 이번엔 우리를 향한 악의가 없어요.\n오히려 정반대예요..."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "547EBCB76E830345053BECA42E0C28155491",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FA6AA28D6A91B0434609D2C19863B8B51543"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "wait"
                },
                "indent": 0,
                "uid": "F9DD4CED8B1256496B2BBAC06000FABE8F1C"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "C71FA4CD270B374A818A5D56C99EA22F51CE",
                        "defaultText": "가리온"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6052CDA29947354329297A56DD6ECABF0D5A",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Garion"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0A993076809A444C96293168D79011505505"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BD8465427ED265422D7AF1B6DAF4383E0BE7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "48D7EAEB7288744EC79AC9F679DAD38930F4",
                        "defaultText": "안녕."
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3D53744632DD884ADF0829634ABA8461239D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "14F9F7A8244FB149E0284C685E559170A8BE"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "fight",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4B85847A71616642A80B33E0FB439613BD64"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "87FF43709546B64FB93AF9919DA1E70F53B5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "840016B53430B244118BF3B2BD1871CD0F8D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0832D91067DB34456D1A5E18350A41717CFF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E76CE5CD5EEEA541709951A6DDF77ECC44B8",
                        "defaultText": "그 목소리! 정말 너희였구나, 가리온과 잠보."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2172809B10B60148273B77624EE297B388EC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B604BFE766A5A94077297495A8D758A25B6C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "765BD36F86B755489869F9D7BAADAAD537E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C9C9FABD3EE0D24F7C78C244A19D8ACD7760"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B3E7E4052831B545235A4EA17D743B2B3DCA",
                        "defaultText": "별로 놀라지 않는군, 빛의 마법사!"
                    },
                    "position": 0,
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "43F1C8FA7352274AC3987F206370C5A6DE4C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C9F5F6003DE217466B286F252032F902E24A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "0989288C686E22422B0907F052879CC982A5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B339492491C1C641108B5EB56927D7A9C528"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "768F821E6E4FE6420E496682CD3BA47DC6E7",
                        "defaultText": "내 이름은 시오리야."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D1BB6FA682962443010B4A82DBD7B2D03F28",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "33AE11033CE5A546C17B8A4761E5D6418A74"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FF967B36476B964DB5899FF318CD814EA3D8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C07DD26253D72541A348DAC471C70D50E562",
                        "defaultText": "하지만 네 생각과 달리 조금은 놀랐어. 여기서 뭘 하는 거지?"
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "25C6D66F571FB242CE0BDD92AA851BE96942",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2A76874B68B81845315955E804F226EDA544"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A362B1288378D0435148FB7662C3E86AB2F5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "96B2A1D81951F54F6F495054E95DDADF0CDF",
                        "defaultText": "시오리의 힘이 얼마나 정확한지 생각하면 이미 답을 알고 있을 텐데..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7B042DE91FAC2240443A9C896A97B4763E72",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "47874B8D81D7A4445D294CB5697ED011552D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1F54CF44196A584D7B8A3FB872EED125817D",
                        "defaultText": "뭔가 자백하게 하려는 모양이군. 장단을 맞춰 주지."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A27673621E8B9247378B7CF6458EF737003F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BDF8E456816C464BAF8ACD91E62A8829AA38"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C77E9B2B68080846EF690325BE35C73F20AF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AE584F9F537B274B4A3952C1BBBF0276B4F4",
                        "defaultText": "수작 부릴 생각은 하지 않는 게 좋을 거야!"
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9A31E94928B044443C0A79F60664AC44DDFA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0BF236B044D10044D2580E154CC9729ABA4E"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Djambo.model.live2d",
                            "folderPath": "Live2D/Z4 - Adjutants",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "Shouting.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2EDF39BC382E184DE2793FE81C77F3F25E0F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "765BD36F86B755489869F9D7BAADAAD537E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C35AECCB881F79418A38FE444587B886099A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "501D1FE065D3A841E118FA63D5065214B9CE",
                        "defaultText": "넌 입 다물어!"
                    },
                    "position": 0,
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F65AFD747D131443DD38AF2903D3292EAA03",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "31130405096CA14C4A5ABE68869B6693AA89"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F36183ED597E784DEA6ABD7447F8E830EF84"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "55FC3C828550D14D856AE8E6BFFBA976EC4E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "43725CD5398C96465728AB30AF673FA2FC2F",
                        "defaultText": "역시 처리해 버릴까?"
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5FC926937FA170470448747254B16F30E5E7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B5DACAF19456C848300B83D1DA482937008A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "5976B4F57A32B549167964B54E96F94F797E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "606262A0658EC047E229C383AF555C92DDA0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0979A0418686F343AC3AF84852BAB19C964E",
                        "defaultText": "잠깐, 여러분! 제가 맡을게요."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1824CA735CDE494D6E59D0110F8779B0DBD4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3CD84418673C284C5E791B942C0E82E6E26F"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Garion.model.live2d",
                            "folderPath": "Live2D/Z4 - Adjutants",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "violent serious.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A717853571598246CA880EB66635EAF97673"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "229B66644F3CA34B4B79C0B71096D6951879"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B926E55C2E00D641A588AAE6BF9CC0E2FA59",
                        "defaultText": "너도 얌전히 있어, 잠보."
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9710DA1886073749283933E92C37FFE3290E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "749E7E5F37074843F178B906EE367234BAA2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "183EA0690A91A24A505B0CB2BE0B4E02DDA4"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Djambo.model.live2d",
                            "folderPath": "Live2D/Z4 - Adjutants",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "angry sad.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F8E249A36F2A96441E4B27921425C2BEAF65"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 96
                },
                "indent": 0,
                "uid": "D54A572062A8A144E178AA75AE5CF6B1E887"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "943DDDAA885C794E8E4A7357EDC66E64636C"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Garion.model.live2d",
                            "folderPath": "Live2D/Z4 - Adjutants",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "idle.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F6F1236A79BC734FE72AE8186F9908B0A3B8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D70E76E1697B0746A43BE5A81B441D22A6AE"
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 1,
                    "idleIntensity": 1,
                    "lipSyncSensitivity": 0,
                    "fieldFlags": {
                        "breathIntensity": 1,
                        "idleIntensity": 1,
                        "lipSyncSensitivity": 0
                    }
                },
                "indent": 0,
                "uid": "F381E5BD357A1448F80B15F1C355072305E9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "733309E1776EC24C7E0ADD71B909FC2C8609",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5DEF5B5F933FB5422F2BD1994F32D5724816",
                "expanded": true
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 1,
                    "idleIntensity": 1,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 1,
                        "idleIntensity": 1,
                        "lipSyncSensitivity": 0
                    }
                },
                "indent": 0,
                "uid": "77F3C0876A0E554CB99AD855A623ACC215D9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A00613B76650694039196AC7EC1306D830E0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5E7403B2363EF84F263907880B5A5313B3C7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "650770360CD87244406994A2E39540B76076"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3AD254DA85C2C6456038D5C4CBFC714E39A4",
                        "defaultText": "그래서?"
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C943A6392A74434607285D34A3F11E5A37DB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A14157262CB4F7462A5B46629478E7F6F6C5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "11CD9AE67F1564450B48C5796FA57FD0B2D9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AAFC5CC79A22E04914480E151F53A6193194",
                        "defaultText": "과거의 실수를 속죄하기로 했다고 해 두지... 시오리."
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "66362E5F238D774DAD2AAFB7651915B28975",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "00E4B8FF3BD4C44354586B25B11935D052D3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DE5D9CBC23D05946A23BC6E03F4BCB1FD349"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C20958BB8593E84D9A590EA6240914F86699",
                        "defaultText": "어떻게 속죄하겠다는 거지? 설마 우릴 도와서?\n우리를 증오하는 줄 알았는데."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D4A48081010B18434A2A97F0ACC9FE314A79",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "36DBE9858975F349349B7BD1C9CFA14A7F2B"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Garion.model.live2d",
                            "folderPath": "Live2D/Z4 - Adjutants",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "violent serious.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "ACAE4E912E8325417229A7735BB5B42F159F"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Djambo.model.live2d",
                            "folderPath": "Live2D/Z4 - Adjutants",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "Shouting.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1FCAB42D3C33274A3229F3F6BB8F615575CB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C84622F1898B714B85095636AADFF7CFE85E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CBE3D1F09C5927480C1966768E57AC7E9C0D",
                        "defaultText": "너희가 내 부하들을 죽였는데 증오하지 않길 바라는 거냐!?"
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6A158AAB85DAE746446AD516726A16E3D5B5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8F8032F12085184C6F4882714ABAF21422D1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3341FF8657323849905BB436058B0A5B1E9E",
                        "defaultText": "그리고 내 감정을 읽지 마. 그 힘은 정말 신경에 거슬려!"
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EEFC668B4358C24E340A861139C7D94C8802",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AB08A21431B7F24B1628E1146ACA6AEF04E8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "083253E7309BB2461A680A74D8D4934F0D8F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6FDE5AEE2F5067459D38677407B0043F28AF",
                        "defaultText": "네가 아직 살아 있는 건 오직 내 힘 덕분이야.\n네게서 악의를 봤다면 그 자리에서 처형했을 거야."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BEA72BA0679023467C3AC460ED6ACD1E0E4F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B81FB61B3A65A3492069AE31C5B6BAE92370"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "F8DAF92E3EC1D64F703BD265E5C1BB0372F4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "40A660B58971F54EE7684A9438D07D7ECB09",
                        "defaultText": "내 말을 못 믿겠다면 어디 한번 해 봐."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F2A69E965F9EC14426891FF4A1F72D6675A6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B1583C9010681544904B432540D4068F0DC3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DBFFA594558CF1470B3A6CF1840C3C9FE399",
                        "defaultText": "악의를 품어 봐. 할 수 있다면 날 죽여 봐."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BF5539084AB5C440DB09A501D343ECE1C85A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "4DCDF9FD47103045C21AB9F77FCD3BEE20E8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B45CAC0653853248567B597492EDD11A4587"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 96
                },
                "indent": 0,
                "uid": "FD7F7E6842093648C9093149B56ADD520F0C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "51FCBD424E410246E3191BA6D185607B7BF3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "765BD36F86B755489869F9D7BAADAAD537E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F97CA8DF3E5CC44A768860F351DAE39C2BEA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6D2AA6543A4E3643FF8823D89C4A0C79BE33",
                        "defaultText": "으으윽... 크르르..."
                    },
                    "position": 0,
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AF001CA05C2403486C584696788C9E908DEB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1CC4D5BE123F714DC1883DC9D852EE08950E"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Garion.model.live2d",
                            "folderPath": "Live2D/Z4 - Adjutants",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "idle.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9F06785F4C6BD6407D891AC76AC663427099"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FFB9319D4ABC204A664B68E044904ADB8EBF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "23AD0E15084EB24F5A6A8187D51B71E2F479",
                        "defaultText": "얌전히 있어."
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "42252A2D0853954C3958C201E8EDD6800C8D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "57137FC55C679846576A44B7E45F362D66B1"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Djambo.model.live2d",
                            "folderPath": "Live2D/Z4 - Adjutants",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "angry sad.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E23B4F683143B340464BB012E3014E7A8E8E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "765BD36F86B755489869F9D7BAADAAD537E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7E0505F74F7ED6458A6818E6E39542FB38AD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "53D847201836E14F8D189B134B0912CCE08D",
                        "defaultText": "...젠장!!"
                    },
                    "position": 0,
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DB63BEB64F0B6644C778BBD798B3050BF16C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D7A6D2036DB3B84098790F46D25D5A8B1827"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "838D87C89E439741F94A5748CF0AD204D57E"
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 1,
                    "idleIntensity": 1,
                    "lipSyncSensitivity": 0,
                    "fieldFlags": {
                        "breathIntensity": 1,
                        "idleIntensity": 1,
                        "lipSyncSensitivity": 0
                    }
                },
                "indent": 0,
                "uid": "AA3BEB1A4973294B37183D5921C864156ECD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6873D52B706D6842428993B8AAE596025FEC",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B36CF4F34472774D4619FFA1E5C0D5B99192",
                "expanded": true
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 1,
                    "idleIntensity": 1,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 1,
                        "idleIntensity": 1,
                        "lipSyncSensitivity": 0
                    }
                },
                "indent": 0,
                "uid": "B112DF7B5BFD41416D88514404F37B54924F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C40DD3EF6DBB074BD079DF290B9555067CAC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            4
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D09BBCD80798724FC51BC774884C27D1BD12"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AE1CC2B65A065047744A00A9F6CA0193F096"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "45F518A062FFB24C817B17919C051C5DBFEB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6B362FE5607CD34F1E0A2D072887485399C5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1DA9971345AB7247D17AE360CBF59DB22C6A",
                        "defaultText": "둘 다 진정해! 그냥 농담이었어, 헤헤!"
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5D7E7BC82873E54FD06B2C279F8D2085CC4D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B8A1ECE45B4AE44B9478ADC4F394F1912734"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FAE938DF84FF1548798A87E891F2C9BDE86F",
                        "defaultText": "진실을 말하는 건 알아. 방금 반응으로 확인했어."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0B27AB163D46B94BF68AF1C11F19CEEDD547",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "030EA31B492D55470A78E9456BB727A5D348"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "217BC084770F74470B3A24C8413EBFD3D756"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "57CFF6CB64BE5446897835821823568F6501",
                        "defaultText": "시오리는 가끔 정말 무섭다니까... 파라트라스 님이나 리아보다도..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5EF01296895F164EC32B89062BB0957FACC2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2F323CFC94410649972BA427BA1E576C8BE2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1F5AF9DE94C5244CA3181D438984D5FE528B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8A304EBB253C35421E581A727184B403AC91"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "04F2585E33301647182835136087F16C19E7",
                        "defaultText": "잘 들어. 너와 난 친구가 아니야."
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "96886E9A0CEC4441A5381C07496DCCCEF066",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "02827F8375D8C64C446B1518D6CDE1330D9D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9243EC8F77DEC94AF75B6DF10D83575545DF",
                        "defaultText": "너에겐 너만의 목적이 있고, 내겐 내 목적이 있어. 그게 전부야.\n그리고 지금..."
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3BE3AE79743BE941243ADA381C845A5C6612",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "12261BB7581EB14DF21B42285CC44328B436"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "BF1AC4BF73F6344E6F68F7D231733F6F948C"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "556FB800349406431D8AE491563550963CD4"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Garion.model.live2d",
                            "folderPath": "Live2D/Z4 - Adjutants",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "gentle smile.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F34D88FF4EA9864B9619C1827307F01D5664"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Djambo.model.live2d",
                            "folderPath": "Live2D/Z4 - Adjutants",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "tsundere smile.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "204BFD0C6F718446D31965E48EDCD38F83F1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BD27874602F05047C60839D513FD7DA808F7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5D70467E6D6572405B88A0A618003B52A546",
                        "defaultText": "내 유일한 목적은 목숨을 살려 준 공주를 돕는 것이다."
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0CA2D01372EF504BD21940F8B563AE9345A2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "B35E4D196D7384452A4AB36506E833A44CD8"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "B03E2E9958DCB844633994516B56319735AD",
                        "defaultText": "그건... 예상치 못한 일이군요."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "910A5039339373415E8A31D2300F289AA27A",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "4C6EAF8A57A6284A95785BB467FDA806263C",
                        "defaultText": "탑승을 환영합니다."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "123B10BC3BB0C64D9038C49109B2B96F5CC0",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "9E0CF2C2794DC94F503B9A420A8EF9D1FC22",
                        "defaultText": "당신은 그 사람에게 좀 나이가 많아요."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2F21AA8D16E62649CD3ADA13111BF05F0E4A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "unexpected",
                            "welcome",
                            "old4her",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "4C0C8F374CCCD145C01B67C7156899E0F99D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "D7D5D0684B822449167A941312FE91954D1D"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "unexpected"
                },
                "indent": 0,
                "uid": "A340B09B47F9A14254698BB8A4AC9F1DE3AA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D4C50F80140CE64FB509C4F0E822D3F82B08"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "09B859C51D60F64E5A9940971C55AF1188D8",
                        "defaultText": "괜찮았으면 좋겠군. 우리에게는 아주 중요한 일이야."
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "ECAEC1E3465D9440A96B9BE6DCE61E11EDAB",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after final",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "4C126DC37D5FF24D824873133123C0C5CF80"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "welcome"
                },
                "indent": 0,
                "uid": "BB3AA5B97C0FC140D1793D13E8BA32E8BD4C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            1,
                            8,
                            2,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F541A94D2558F64AB818FA48ED6AB3CD1E89"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6361FD09833D34423E285177C7C6C3F9322F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E3060FC05C866041F5380DB4C1B568FC2874",
                        "defaultText": "그 믿음이 잘못되지 않았다는 걸 증명하지."
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "48CB47786652D94B637AA9A2B4A941785227",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after final",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "272DBC8E0E345042FC2AA9F8A9765754574A"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "old4her"
                },
                "indent": 0,
                "uid": "5532E42F60ECB74A6338F9180E5AF9E87F7F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            8,
                            4,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D2F074E995CC834DAD5B5575EFE60BB85F41"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "Ornières x Faratras",
                        "index": 401,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 1,
                    "source": 0,
                    "sourceValue": 2,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "357CB354320E3844F85BFBA7460AAA1DD94C"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Garion.model.live2d",
                            "folderPath": "Live2D/Z4 - Adjutants",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "violent serious.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "10E64F0E190CA84D0978F3B0BD43C45B45D7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "20AD660C65D2E94714284A289CCCFE754B5F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3C738BDF1CB92544E63B3C140BE0AF2CAC51",
                        "defaultText": "이봐, 착각하지 마!"
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9EB680488AF47240988BB9B4E12DDFBBB7C8",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after final"
                },
                "indent": 0,
                "uid": "3A10CAF57CB43147B919FCE8F1CFE02358C8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2AF4A0223141384F583A5CD79F4C5A930D22"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "765BD36F86B755489869F9D7BAADAAD537E7",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5B7BD1D80DA5504A969A536677EC4572D436"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CA19873275A8864486593199831D8E0F3E5C",
                        "defaultText": "맞아! 우리가 광신도였을지는 몰라도 명예를 아는 사내들이야.\n빚은 반드시 갚아."
                    },
                    "position": 0,
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C4D6C226528ED047158B56D526E47E8B230F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E13BB60F8114A14F926A0856FFB8C959B442"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "6D20B93E36ADA643779AF91108D006543B74"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "929BB2D15EA005425C281066E0279B5C3A14"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "818D5FA56DD971472C48F574FD4EF78B2599",
                        "defaultText": "가리온, 잠보... 정말 잘됐어!"
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "03421895854484497C5806378A49B5F62EE0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6F5D3DC348E2C24FFD9AAE312DA32DDC573F"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Garion.model.live2d",
                            "folderPath": "Live2D/Z4 - Adjutants",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "idle.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C014426E8E418449C19AD841BC8F5AF4C2FD"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Djambo.model.live2d",
                            "folderPath": "Live2D/Z4 - Adjutants",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "idle.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C0BBB5EC1C020747AC1898F46E8A6CFB1419"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9E1A2FD002081646274BC8C4B2DB551AA0E3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6F2AA2485F31A248C84854116A025BED8267",
                        "defaultText": "뭐?"
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7FE7D9103D4F7747FA6AA5A9D99E31BC093F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FC1B29A012B9C24BE09B4BC5EF5F1BB9DD2E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4075564122B1C6410E3A53F91AD68FF2FD0F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A30E75EF400137459B9A53375886C9F16DF9",
                        "defaultText": "방금 나도 너희 목숨을 살려 줬으니 이제 나한테도 빚진 거네!"
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FF282DFA20887845EF2B021222BA9DC07297",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DC3DE7E532CDA54DD92B53733A11830E3E8C"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Garion.model.live2d",
                            "folderPath": "Live2D/Z4 - Adjutants",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "violent serious.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "FA678D0737C8F44A4A6A00F71534B6E69708"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Djambo.model.live2d",
                            "folderPath": "Live2D/Z4 - Adjutants",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "Shouting.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C7855B226E9A2849A77BE685136C6B6D6F7B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "22016FE3671FF44BEC6836C341092812B30E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "10B5960C47C976461A3B94E5674A4911A5F4",
                        "defaultText": "이 조그만 게..!"
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2B9935B2740CB1414B7B78321896C9B3EB2C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "7F98271769C3E3466E4A72C1F5698CD286C4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F058F0D70DDD1442A44AFA65C9A6B9199F7B"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "E14793AB8362C64E1969E8E67BBD2FF01FB3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "7DEFA4E056B0424037680879F6D7F754DF58",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "2177D72F25A01143D979ADB52E3B5923564E"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4632B6281A79D6401D6A38961CE4446D3B5B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D86A0B755C3931407F0ABD74F73B1E1241A9",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "737C050B87F9A243B10A8F15032EB13CEBC7"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "4ABAC4B88F251343B4780DF593ACCE87EBFF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "DA048C7E6697C7481188AF30A50BC2CCAA55",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6"
                        ]
                    }
                },
                "indent": 1,
                "uid": "4DAD8CD1958A8945036818E86DF2B07866A9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "7DEFA4E056B0424037680879F6D7F754DF58",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "247C0F7D42C1D6422779BFB50DB72A74E785"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B610167B8CA8B84B0E1AC137ABA3C388BCCC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D86A0B755C3931407F0ABD74F73B1E1241A9",
                    "parameters": {
                        "values": [
                            "765BD36F86B755489869F9D7BAADAAD537E7",
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "ADA354A4225BE640959834B1F3B06AC5BF90"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "3D85FE478B53E44F5B6BD02492424C6D70BF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "DA048C7E6697C7481188AF30A50BC2CCAA55",
                    "parameters": {
                        "values": [
                            "765BD36F86B755489869F9D7BAADAAD537E7"
                        ]
                    }
                },
                "indent": 1,
                "uid": "06837BF679B18445F5794CD1AB89054986FE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "422B49CA8A63A04CB338ADD9E56A9BFB25A0",
                    "parameters": {
                        "values": [
                            "",
                            {
                                "lcId": null,
                                "defaultText": "{C:1}Garion{C:0} & {C:1}Djambo{C:0} join as {C:2}Adjutants{C:0}."
                            },
                            "",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4E91617B6377F743A26A5355754BD78A2D82"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6FE3C1466BE6D749E93B1A1763C2A8DE2900",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "BBE5BE2336D0D744544933D7169E10691642"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            6
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "376C3F3E36E7B54B5D189B2661493FBB7F50"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "0C01DC89290B2544274A6FE483CDD652C620"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "duration": 42,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "B2F5FAB817C0544FEB7A7E14542DC908372B"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 21
                },
                "indent": 0,
                "uid": "89188028885CC54C411ACE721A7D5D0AB70E"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "duration": 33,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "4487E0058BA4F5470F89FE57FE3D195CAB26"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "5D2674BA8E8B73449A8A35163C7754769917"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "DB2CDEC354069646936B3126CD5DE8C8245C"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2DE12C2E42F09041DD6847F5328B9B8D0DBB"
            }
        ],
        "livePreviewDisabled": true,
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}