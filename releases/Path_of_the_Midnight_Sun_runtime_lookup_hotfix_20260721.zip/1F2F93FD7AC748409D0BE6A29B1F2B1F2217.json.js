GS.dataCache['1F2F93FD7AC748409D0BE6A29B1F2B1F2217'] = {
    "uid": "1F2F93FD7AC748409D0BE6A29B1F2B1F2217",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "Names of all Character Skills {to GT:315}",
        "type": "data_record",
        "order": 6,
        "category": "commonEvents",
        "id": "1F2F93FD7AC748409D0BE6A29B1F2B1F2217",
        "isFolder": false,
        "data": {
            "name": "Names of all Character Skills {to GT:315}",
            "startCondition": 0,
            "conditionEnabled": false,
            "parallel": false,
            "autoPreload": false,
            "singleInstance": false,
            "inline": false,
            "parameters": [
                {
                    "label": "Item",
                    "type": 3,
                    "stringVariable": {
                        "name": "uid comparison",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "stringValueType": "text",
                    "stringValueLocalizable": false
                }
            ],
            "commands": [
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": "",
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "4679B0766767D442548A49E4A4342B2F5BB5",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "CF2204C51119C14C4B39CCE5A2C0B74CD9D0"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "BA6AE26784BA7846E418B62917A6D6A80F29",
                            "defaultText": "섀도우 마스터리"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "AB2694E895292847F58B3240EE24AEEE4386",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "2F8D38681005F44D392B1111658909DB7434"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "14799A476F7DF34924596E438C45CDBBCF4C",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "914B9A719BA222415889B5E3F244559AA136"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "CCC8B30601A2A8413E3AB1B20ECD0EF50574"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "53A06D948887F249FA3A4E69B01C80A36126",
                            "defaultText": "그릇의 신조"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "BA67BA6C57900640D699F6D821556DFFD035",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "82D84A558CC24145407855E09437E3FD2086"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "DEB2463E11927144F96810E40B7B6FAA7A3A",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3513A87043B15047CB1B9CF31167BE232A73"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8AA4927D32B4024218892CD821CCE5C12526"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "C69E0BFC6BC2A442EA8A8A257D42AA09597D",
                            "defaultText": "멘사나"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "A0288B2E20B1E8494058C8E95948F0EC9E70",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "D74A6391553BC84F5E290187B98735DDE943"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "DE4A3D7C57BAC4432638EA883F134CD6F2BF",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "1E98CF58473D7247980B9150B21CC4E41EE6"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8DF558A86E5F7642717AF3D71E2E4C3C9D79"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "F5B1443F671E3441981A1F359737866EFCEC",
                            "defaultText": "네레기스"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "175110F95BCB6542C48B02468C4554F3682B",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "F9F9548D029C9849074B75331211EA6A9763"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "0E7A8E6E5C685840932A35887C55179DC1DD",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "BFB4F8426FB7C243CD2998E8E0A32DD1EFF8"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "FF9FDDBD5E69584F3548EF459AEF50F8E7F2"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "2E6C71C51E6AC448C67B351817DA068CF71F",
                            "defaultText": "바쿠아녹스"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "4ED43B9962749145F53AB4668D396E69B07B",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "EDEAFD40657BC34FB08A2B75D7411C1EF8FF"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "CB0EE3C125E3234E7438EF3983EB4CD56700",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "522AE6B31C919745FA489F9939ED98ED77DB"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8D87F54D611AE6459549E0D7F1371FEC4BAD"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "0BA6BB8A6B3AE84A8D88B979A3A2BFD8A870",
                            "defaultText": "스쿠투말리스"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "E508498341798440BC8892C1395B6F7A36D0",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "EF2B7B656A5A014E480914D6BEC573FD2E34"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "B02BD66B75945744C46B4F22F80FF0942FAE",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4F60A97788AB61479E688D2124ED1824F27F"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "46D3DEC49A413742653BA6A633FC6BF058AC"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "3A18608227FF79456E5BA8C0A9D1C3EDF85E",
                            "defaultText": "오브럼브라"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "549EC0FC9FC8454ED27B5D02FD146A715F73",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "F113632B2DEC764689689584E986BF422C50"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "B88F122899DA744342499FB4F891747AF9F7",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "63DA7D1F75BBD64C2D798D77E59EFC5B6F4D"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3FF4AFEE4C77B5487918C864EEB1AFB8599F"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "193ADCEC28C1D2404E49DFC203CCA2CF1353",
                            "defaultText": "프로벨럼"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "55B2E16B45FD4546C319ACC60E8565066374",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "14B9AADA7FFFE84637097285C1C6ED5EC487"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "B7A1D6E17F70324818485208BE3803D78DA2",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B917C93B74B6444E0B993761DB796EAA1445"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9BA63E07536A5947097B8AB6E9F2DDE3D715"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "F3748CFD6807C9446D5A89E7A0841AA5B064",
                            "defaultText": "코스모템"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "BA3BFA1D479F434CEF49B6E01ADF4B519B95",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "A472D5871BAEE44729480953FB0ED32956CE"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "1B0D24AF08DEF747111BB59760826AE1BDC4",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4F0E0CC38ADCD946905AACC365268B44D8F3"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "CEBC2E6E6A522849B17BCFB51561ABB6AE85"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "475C34D33C964740C53857E2B35482FA90D0",
                            "defaultText": "눈에는 눈"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "0FF2D7E63FA6A4446D89F4A1A984C968A18D",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "CD68E04601BCF846A89B2DB52B1793045DF6"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "BC53BBE5360A0647C918DAB4E7CB6DF7F2F0",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "943BE03F210E9342294ABA07BD4313C8DB63"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4E7476893470204C9E5B9C23C36BD79C799E"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "C503576F4F01C248A5191AE43C82AA088572",
                            "defaultText": "내면의 심연"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "857C16D6554A224B6339E5C1809A9BD5EA34",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "1A38F05E19281048DF2952D4000B97D8DB9F"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "6274A297552466429A489353596A69B5176B",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4D5F652C13C9F544C56A4BF30E1B2D55BB48"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "1DD410662B6CB24E1E28A591CFFD28573077"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "5965B4953AA702471B5A3BF1113F2D7FF9B2",
                            "defaultText": "포르테네브라"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "D3F541A144DF7844571BBC686FCB7E9093A3",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "86EE581877A275435D6BABA7A6182AC44550"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "C434609F2E2CB0401598E77398FCA107C818",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "77D5ACA338D10448CC688A282B6B3A6691BA"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "7ECBB9A029AFD743047ABD91F9313934E029"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "4607059D5FB457488F2A0638E1E26D79FBDB",
                            "defaultText": "솔라비서스"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "AC3FEA7D8FC2F84262792AC39B76FB187769",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "D8AF7540279BD44DC439CAF3034ADF54D8E1"
                },
                {
                    "id": "gs.Comment",
                    "params": {
                        "text": "Shiori"
                    },
                    "indent": 0,
                    "uid": "F43A85FB262C01452A88A3C7DA940C119B38",
                    "expanded": true
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "82306A8F59F3C046ED5889E7565D1B442168",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "AD8B6AAC7AB8524BAA38E88452615700EEE0"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "937585831A9DE242983A4B9427A9C4B5C0D3"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "18ECFCBA549DA645D34B139356D1DAFF4EEF",
                            "defaultText": "라이트 마스터리"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "2EE5CF419CE186446278C307AD05506CE14F",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "8812EF2810D25449255BFE922A92E727DA44"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "C7C1C7EB73C8A5430F58BA87BA1FC3BF7CF1",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "95BD56050060A64D314A6EF888E7BABC748B"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A91440637CEAD64E1549C6F411F8B5E1DB37"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "Shiori's eyes (OFF = blue)",
                            "index": 139,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "",
                        "switchValue": 0,
                        "valueType": 1,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "E49EAAB64160A841D4689074CC868B97B497"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "8EED89AE7031154A4B2BDD449FFBFA6D784D",
                            "defaultText": "엄청난 예언자"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 2,
                    "uid": "A660CB2D95A25844D18B56689EA6CC0D4F91",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElse",
                    "params": {},
                    "indent": 1,
                    "uid": "E3C8F90B8C4F48408E590F21E5AD959E6D69"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "4236E5753439A846E2882F7461365268CBFD",
                            "defaultText": "눈먼 공주"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 2,
                    "uid": "2672E92F84D604474C3BD513D99D6D6093E7",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "88EC07DD5CD1714DC63A80E5BC2F70850251"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "722947113DE0934EE0482E27C929F86693F9",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "16171B285157C3421158A6D24B9CEA056178"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "631B948B39859841EB2A1D14A69091F2A133"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "514A1F631E96E742D02BC535670D7307F664",
                            "defaultText": "스파이럴룩스"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "CC56F41D6BEF074D40996A946A96F55845AC",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "51CF89565A4EE74D1E2A2E83AE79CB2A0A02"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "BDAF35DE7DCD42495F490E65C3D752C8D81B",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2D4B429A6A7F184CB78924979AE49328D01A"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "253051A052C053455B793AC3ADF2AF7E14FE"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "CD6060347B8FD742981813C14E8CA629B3C7",
                            "defaultText": "치유하다"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "E7F5E5B24B273746A94899F798DF3638446D",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "596402C366FB0945FC393A92379613B13BE3"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "E07FD1D144339548FE298C177C5E3BF733C8",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "7770B0B86A8F7647426BB8418DE75A6B6308"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "6B565AA786B6A2462479C46301AD4E0D182E"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "956F157D4FC6874D335981C71A22C348F670",
                            "defaultText": "캔들 아브라"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "15CF7807671FF54E7E3BBF250E24D8E3E9B6",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "773FB8362A5B0244DB082117AD4CADDA1EC1"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "7BB41FA45AD5E146828A5C579D4A87D59712",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2E72844F950325417259E8A01032FF7105BF"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "82B93E1013720540A68B73118F4DFD4B1D15"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "Shiori's eyes (OFF = blue)",
                            "index": 139,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "",
                        "switchValue": 0,
                        "valueType": 1,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "46EE84362C58B7432739028520793646E145"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "219566B696C293450F2BDD60A68771CB1230",
                            "defaultText": "감지하다"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 2,
                    "uid": "5D8EA53468979941AE48CC34987CFEFA94AD",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElse",
                    "params": {},
                    "indent": 1,
                    "uid": "97F768D825E2B54A9D487DD322E61093EDF3"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "92F23B1730A4E143FF1943057EE25753D1B6",
                            "defaultText": "식스센스"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 2,
                    "uid": "5D2CBD4128CA4343B299B4F6A05E66EA07DF",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "3F1FE0CF71957640F86A77E43444C44D2B5E"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "A7C0641046B0D047AA2A36D86F488AC3145C",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9CD18E198681864FB8195D6968EBD0D92CBB"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "414230D346EF714B4E8BF558384232F3B395"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "80EF4F716A482240E15BFA033FAFE837E5BA",
                            "defaultText": "판사의 빛"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "6CD495391239E743B61AD92850D98B94F52A",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "042607405D6A6442827A6400E9911A33029E"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "ED24F65C0714714BB93A9FB7D325105EA953",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "98646406279AE043953B0E65CAEBAF55E9A9"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "08519AED4E12F14408281C0202E584E21BAF"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "Shiori's eyes (OFF = blue)",
                            "index": 139,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "",
                        "switchValue": 0,
                        "valueType": 1,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "01D8A253775BF443433BE0B5CF8F93822385"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "25C7FFCC252137459E483480CE735F5CF4C2",
                            "defaultText": "공감"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 2,
                    "uid": "E4EB33219FD8164A9A58EAB6C47CE6377315",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElse",
                    "params": {},
                    "indent": 1,
                    "uid": "423F633912BDE446B31A6BC77BF9C08577AA"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "730D3A5294ACD647349AA6932AB3D4B05EED",
                            "defaultText": "이상한 공감"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 2,
                    "uid": "BCD837462384864AB21A7912FE0754E2E39F",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "FE31F8E383D0294B8159B4E0DE6FE0BD5D1E"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "D97F5A181B66A44923985E20A558FA5C45B1",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E49ADBB19E51B7423F29D1937760477AA57C"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A694582612371347C36B4D26B6BF00204F7C"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "Shiori's eyes (OFF = blue)",
                            "index": 139,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "",
                        "switchValue": 0,
                        "valueType": 1,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "1ADD16CB2A177840596854A37BF0834034E8"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "E5EF0E1A436382447449625207A5542636FB",
                            "defaultText": "프리마우라"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 2,
                    "uid": "41BD66CF223EA8452089D1527501ABCC6274",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElse",
                    "params": {},
                    "indent": 1,
                    "uid": "422A9F6B67E6B5424279B8E77E0408AE3942"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "424DAE1A05BB164EE31A3118F42810564FC3",
                            "defaultText": "네오 프리마우라"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 2,
                    "uid": "A8142F48276FB243FE29410905DC6995AB96",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "B24DFF263E4691466E8B32D3EA91023C43FE"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "3AC77DB316E9754BBF4B76F7F4CE842DCEC9",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "14A727A326B2C14F8078DEC1F945FFFC6BBA"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "6442C77E53AF414CE668F892883F9F1DFE16"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "Shiori's eyes (OFF = blue)",
                            "index": 139,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "",
                        "switchValue": 0,
                        "valueType": 1,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "F2C12A2A2FB366439C48E796151100493B0D"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "35CF56AF16A51847861A8C55989DDCDE5175",
                            "defaultText": "나는 당신을 볼 수 있습니다!"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 2,
                    "uid": "08C683368A47374DA32B85A6FEC9DF531885",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElse",
                    "params": {},
                    "indent": 1,
                    "uid": "AEB45C1A32AE274646688501EB182B71D0CB"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "F8BE5A7E301FF048F5989A0760EF9C08D954",
                            "defaultText": "맹점!"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 2,
                    "uid": "516C54751773B64ED3785AF3E3043CBDC649",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "2321CB2B34393642D169FC977D75C7B99747"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "83CF91BF06749641C26B1A416C45B7FCD2A9",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "DC1FEDE933D78747233972A24AE1329F5C5B"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3D37A7D77A20084DF94BA07788D3FDE77CD4"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "D80C7E12577CB442BB48158140A91C77A79C",
                            "defaultText": "내면의 행복"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "613D947451EDF4444B193CA39036057AD77F",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "E91E05602C81664E1F2978E53D74B71911B0"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "6F9C0B987979824B511A4E47A14FD4F6A611",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "251DE98D51D8D340D09A56804B0F89C5D91B"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3ED0D7C248C7B449174B21E501CC11C637D3"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "9EBADE1D1B1E3148A84B3F98026CAC651012",
                            "defaultText": "기둥 치유"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "BD54AC2B3B69B14F138AD493E9CE9CE16B13",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "40F9C9693718A244957BDE823FC28BE1D792"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "6780CC147919054C112AACB91D94AEF5E0D5",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "57294F5929E323441158A1C2F90DB0B14FC4"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "BBA0E41D642A6449185A12D268F5D5E9A307"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "07937CB36F5BE94C1B0AEE93AF3F92D8446D",
                            "defaultText": "미드나잇 플래시"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "2A8D7C44519B3249FF2BF4F99A647E63FB24",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "CA57B33E97DF394D1D48A935B7E6986B8D37"
                },
                {
                    "id": "gs.Comment",
                    "params": {
                        "text": "Hellios"
                    },
                    "indent": 0,
                    "uid": "B16A23530AF9364C0D8808944DFE8ECC0AB4",
                    "expanded": true
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "AD9C47B372680846D248E0E7B35B4C12ACAA",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3829795B870FA2431D381024AB468D5D5E9D"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E9EF9E616124C44DA13B29035BB9CDFC297E"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "9F28CC843B1D554E4A998BE4BDE2F5906AD2",
                            "defaultText": "블러드 아트"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "E240537E25F5774E5D0BED42755C909956C9",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "DDB99FA42C7F0447730A8F86FB83F816A78C"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "E77E9F07414DD7407F2B59388981EE06898D",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "ED67A53231CA7443FF69FBC54082E941CA89"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D9F9B5DB589C984AEA6B9D94F5EDD8824A6B"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "AB9047285346C242AF6B410419DDC86A3C16",
                            "defaultText": "차원왕자"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "21CB0F567A8E1446815AB1C9DAC26C5D8AF5",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "271161612A6BF249BF5B66A899C5F2001903"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "E2CE467D8EC01243E64889C99F515DB40D80",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F17BA33F4EE9B74BDA2B4D0456FF5056D10D"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C28C6DFE8B4E5843378B87E076D5E06D5B12"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "31FDE0535F9951465F5982F9A9E045AA5F9D",
                            "defaultText": "사자의 아귀"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "E6A3544A37A7634BA008CEE81F8C7E4A5313",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "29CDDD10736897417399B688786E940125D7"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "BAFB027F451C464C287AA5F42BC1E31DB891",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "AFC5018165852544B878B263BF7C7862D1F8"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "BAC9301B2202C24F72295029A84349845415"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "295DBC9D4C55C24E0E691D38283B8AEB20F0",
                            "defaultText": "순간이동"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "2B36858B282E844A2A494E6337AB216F3111",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "C18E1AEC2F2B154BA25A1A08427E79887EE0"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "BDED09AC955D1248702B5697EB0861175445",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D7AF2A42691298492C3ABC015F3B40B3BBB7"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D43D231B3236134D75782DC7820FB89B3DA6"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "20F8E76F1C58D9463E492B5873F86FCC45F1",
                            "defaultText": "혈역학"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "845A82379F7A464CF83829D3670E13E22CFF",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "CA814A2C83A688400039B31668C1EAE482B4"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "5B83BA704434824B0B6B1A455A118B3CE49D",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "AAD51BF3571FA74D29284603F7F8C1FFB031"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "48032A2D1136C243968BF98215C4614B5EE2"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "91ACFE2A4D21504A7C7B439851CC06EC88B3",
                            "defaultText": "치수절단"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "552596F892049444FD0BD428783BE80200B2",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "12907B950B9678498B0B35F3B8C7B203A795"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "7E12294D86B5D54E5749251661AC554DC5E9",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "279463CC92C574485588EE52D15E933589C2"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C2C172DD39EA9547AD581C1123D0E472F30F"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "88F0D63E6177184ADD8BCD8428DD7F4F1ABF",
                            "defaultText": "오우거 슬래시"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "7C5B143D75F7F54D454B76D7EE83F2D6DDBF",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "F3EDCFF45301164ABD8BB184B8547D3690D7"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "4EEDD5D611D9374A9C2B426873D9CB2EA286",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3AA96C234FB1D845A97AD18964DC498B65D1"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "85952C8657A6164E970B105644C953A41377"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "03A28C442401984F0D7B7CA24F12EF76CC68",
                            "defaultText": "팬텀 형제"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "8091D9902818034B726820822A83671C32C2",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "A65BE3457E35A54DA58A4E0258F2EAA5FDA2"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "1C52F0BF114F3646AF1912E260299A22B5C6",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C34C39763DEAF64BD9691DD213079EDCD691"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "421A885725E05240CE69C5F77557B2DBC740"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "A5AC97896909D649AD490F52BDACD0B1A4E9",
                            "defaultText": "상처 속의 소금"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "8CEE01168D2BE74D0A4B9E25AE40F9444236",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "D7BD211F9A8573445769AF2017250E7E5F75"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "BB67C23E5716094DC088B923C378207ED2AC",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "29D6A57C25B5D641165854679E68C4D56B9C"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D37E05775CA00343F12937E59AAF32C588C7"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "7FB8597A1D639249218B09140A8314A57C28",
                            "defaultText": "차원의 사신"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "2B2683BE85C78548EB790A188BFDEB5D6BE3",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "BB2619A10D97954FA10A0BD586D01584D67B"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "2BDD96096CDC9844450ADCD15FFBAF673582",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4CC307B5783B964BC16892E4E5107B844EEC"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8DFD2C4D18F7864C673985D4CAA6E96EE0B5"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "CD7F659195CC514A0398F2C893F58DCC5CB0",
                            "defaultText": "타이타닉 스플래터"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "2D98F732765D60492A7BD391B5E6423B5B6D",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "4B7C27FD69D2674FCA7B2123AC0EDDC7CF2A"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "1FCFEEF85DB7B644AC2863A47D14046935EB",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "91422815234AD14318698315F0A180E55479"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "36FC28A110851446345BEF6012CAD3EEF797"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "F51C2D0438A746456A28A4A6954B3AFC3C3C",
                            "defaultText": "클로킹 처형"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "1E7AA69B35D523497D4A1A4242965CA76E45",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "863A8443601E324D5E9826A88F5C95CD77C8"
                },
                {
                    "id": "gs.Comment",
                    "params": {
                        "text": "Rya"
                    },
                    "indent": 0,
                    "uid": "638534F5384E33472649D9E88C9D4DD0199D",
                    "expanded": true
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "200DED0865BFD241827AB3C13029EED62120",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2D8B3B948272E6401E2BFC35DD55B5D86211"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D56CF46585D132491938E8B24C9B36F09199"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "BF686543765EC84ED819D69321554C05DE2B",
                            "defaultText": "제국 전술"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "A14E5EF4224D12469D0A98F7A7DD242780D2",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "C5E309648D7AC544BE28BF52F85F355214FB"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "BADFDBD75ED5334DAC8B9F451D18B28E3D24",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "28EE633A5A43624A8A08F432753718D08AB1"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "1958EAE8313ED443197BA74295CC6E788EE2"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "7F3651C26DC7F24D5D295605ADB5837875A9",
                            "defaultText": "원소의 숙달"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "51ADAB395B58E849CF8B8AE391AA2E4A9472",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "F96A7C9F9E38B44AE9096A28493DF00036AC"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "419448437C96854700381421AA9A3267AFD0",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2CCF43401F0E1147942A01143464EF3CEE87"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "6FFB497A8B40104640881E986AFA2D95062C"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "9EE3A5A83620B54FF93BBD51DF8C08F61371",
                            "defaultText": "피뢰침"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "B13207BB135BF4431919EC76332DA9D3E7E0",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "C22D35CB542B564BA25A4C3513DB8350BF38"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "2FE3E82C8B0F0546DE99AB20C7A211EAAACA",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C765DCBE51281243B64947B831E239FD37C8"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9122754B12377749D45862C308DC12091E81"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "DC17E2AF7DFC8542FA0A4BF1BE873BA737E0",
                            "defaultText": "괴롭히다"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "80E7232B6D91904C2E691C89340D5ABCE70E",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "712D3A8D9E36F6424F080D73420248875BE9"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "4A880DCF9EB2634AD58B2579371EC6FEAEA3",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "1994CE7F151A84431B78436853065C98AF33"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "78F5DB5230119848145978865B2DF85E4845"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "142D62B15F53E541AA4800E4BB7BD64B4C3A",
                            "defaultText": "맹렬한 사격"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "D9366C20234EA848C06916B8AF285D901DC6",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "D3FE201933D25249E239B4C1CDB65DCD58FA"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "15755CE590F9D64C109A82F8B971F4F03BE4",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B8469488221F65497279EF9253150496FA65"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "672F4DEB36D528434F2B48346D3E37E3ADEA"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "F86494065A6085423289CF471F5A13F23461",
                            "defaultText": "측면 댄스"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "F6FD0891597E2743C83A68B102CA216FE892",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "198DBD978709644E571B1694F3787BDEE812"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "B52CBAD25577454B9C1BC79724CD2F9BA39B",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0CA610BB3F45C840878BFF5642E3398D47F8"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2BA0A7FB856E9545282908C599FB2A17FF46"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "0B59E11229B6804E6C786986A31D2D9A2367",
                            "defaultText": "쏟아지는 비"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "C1B523441AA4634A0C2BD633C396C4F7BB78",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "A47252095355A44D13287D96DBB96F0F2A1D"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "40C020AB0416E24B31999BF1D218AE3CF79F",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "BCFFEAB51145974BD52B70A7C05B1D3FC500"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "FE5C7CF34431D749A02A51758081972370EA"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "F188942C3260C7427D9AA1B56AA4D5795B33",
                            "defaultText": "은퇴하는 댄스"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "F137E15F7F8E29441B5B58A78D7E2F43BDF2",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "CBCF0C722CC084438D780688529F54F23B38"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "AA27F7B82D218344BE19794389F8FF79B039",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "FEEE382D88CC404DB75A8A70BB0E40BC7B99"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C66E015B093E534EBC5B1C675DBFF5503F79"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "7ADE827446A0154BA9597B590416FA437F42",
                            "defaultText": "불칸 레인"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "121325548495234A23283088281637BA2D2E",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "931F165A8B607440F7986A64738E545C5053"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "D3DE4DCA6089354EDA29FCB46D84D222AE45",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B679DBFB1218D648487AD16199E5B60B2C76"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C2C27C081B12834D3B5A09C73E0337C4D323"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "FE5D7B098FA2E3440F78E7A46A218D7EEE68",
                            "defaultText": "옴니샷"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "B26713DF1FEB964BC99A99C2E70240B3AA6B",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "B0DDA52D408591484A59183101EF988439E9"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "A096A6F026AB31481C19C00001294B2111AC",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "29FA1BB33CDEC649FD8B02A5751611CCA1E3"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E4773ADA9730364011088AE4448F6DA5EE28"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "1A7F4EB86629E642824AFEF8338DE952307B",
                            "defaultText": "빙하비"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "162BD3165C42B547F39BE3F1EE5AB633F972",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "17AACCD578CC684207890880249A34ABC107"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "D31F45E80159B44DCB9B6027707E752CD669",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D7A3BA86263EF646331BF730164ADAC14D94"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "1F3E2A8F1D8257414B59AB911C694C063C04"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "602BE1D08F52C944EE780166B93EB60BA50B",
                            "defaultText": "치사율"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "C34750FD614369425A49E6A2B2A8B4390028",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "E070ADE28DA245472B7B19470BB16FCE8DAD"
                },
                {
                    "id": "gs.Comment",
                    "params": {
                        "text": "cristoph"
                    },
                    "indent": 0,
                    "uid": "4770EE4B8825954ECF8A43182B36BA14E3A4",
                    "expanded": true
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "9E2174DE2E4F394B485AE5426EE3F6450E65",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4A0F841C01F736477E994AF47DE8741E9BAC"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2D33A39D7A61C1480629E4B961547E0BA2ED"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "C2D9A1F429FC9441812A36A0B424C2510644",
                            "defaultText": "근육 훈련"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "076874AB70A6544A733B7DE54FC3F12625C8",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "13952B2458896442F10802A340F5B324F05D"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "A4732C551E30984BF2897F63E731C297E560",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8892117A4F5B184B914AE872AC3C78F01591"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "CDF6469C3741E44B0B7B1D366C2F6BFC2111"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "D54DCC9F29C563469B2B0207F31C36478A1C",
                            "defaultText": "열렬한 신자"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "77E1363D40B9B248D30B3796575752A0D7AD",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "A93076950D79014DA23817C34C173E80FCAA"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "F7CCEA104A31924AA41899F550ED1206DC66",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "EC0B02902EC11245D48B3837F39D2B6E745C"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A7FD4508276AD141213BA23408D48EBC40B2"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "5D99CB3C4A91F646C718C8A621DD9804B756",
                            "defaultText": "헤드 스플리터"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "BED25AD0514AE447384820F6E549C6B71892",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "7CF501841A4B424FE02923E8E26DDF9EC3E2"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "79672D0A63DCF243381949E28933849153B9",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "80A02A4F67413040546AF2C5D20CDCC8CF36"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2BC9008F353CE5465C6BB68349AEA74251A1"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "EDCBB80D829BB6443A194F14AFBD5077D32F",
                            "defaultText": "성스러운 바람"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "B9B193070394E1436F790475B2E0EB784BFA",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "C13A25AC16105145C31808B370AF30064B74"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "27EABC647287444F3A4B1257201849D7384A",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "7C86D50C50982246E43B73755D1351D8B0DF"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D6ECC87676D7F042589A17D59ADED41E48EC"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "56ACEC0B2FBFC64A9A2935744E58C2C25CA3",
                            "defaultText": "레그 커터"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "527CFBE29BE85743710AC9423085D8A6FF98",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "495DA0DB5C81D541278B73E4C287D8213B4C"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "F6ABBCDE12D3744A41894D75A215EAF60250",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "737BA5273E7C984DF62BA3E109AC25D10DC8"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "214EF9F2587AB34E326B91019BBC5963C522"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "3F0AEF8B224601487899C0935C1DCAF9BB80",
                            "defaultText": "기도"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "995E14F53F3C454F36385CC7B6E1A8A9F803",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "C2E5B96D448F974A4F1828882903EC4FA2BA"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "2002B95D1B7512471169D2E7DCC34289E157",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "CC7FA7775EE604457219F7C2B40AFC9F5986"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3FA64B21748018459F9BB4A6BCE31D706F72"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "077F7A7D0117744C4C088A651975B0E114E1",
                            "defaultText": "뼈 분쇄기"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "477E2CCD36E74243BE7AE868DD24002B0C1A",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "A3CE846E7422D14DF40A066742AA3468BC44"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "3C9E6DAE60130949542B4123033D0B471F67",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "AA138CDA97BD6446400BD8540304FE9C433B"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9B28D8501E2544417A084DD18CA8EBFE10A7"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "564284D91552E5413A889B545E4789CF8CB9",
                            "defaultText": "진지한 기도"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "93D979CE70B9844343796CB6B146BDE2AA5B",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "BF8C6B5D8380C44AEC6BD5A1B78FD7E16988"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "962C97EE11CF6348591B2D16F922058C43C8",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "AE0FD08F20E8E34EFE7BDFD7C4AFF83157AD"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "962C27616843C146B88AF410CA2EC1C52376"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "115E36481F2A41489C49F675EF3BDD5E09C9",
                            "defaultText": "적응 정신"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "E9992627626BD84D3D59747903B12FA8779B",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "D85322CC8C65624254485337095A0E2BAA89"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "E231CC9B62F4E844EC78D8677B5DDA717D41",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C987A2F32AB722422E0849F6FD3FBA6CD74C"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9A74F23C7AF4C44FFE6BBAA7229FD2DB7388"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "791052D21AAE68449149DE15C6EDA3EB03AD",
                            "defaultText": "황금빛 바람"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "2D9A645A42C1794B4B5ABA54DBE475EC2795",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "2FF62A605539444E88586F41EFCB887B1487"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "CBF8C57F199C52466E28B1660702E54948A2",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F4E01A556A798844911A5009C8B6CD7D65C1"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "182B9EBE52A4764AE478577992B897D9E097"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "99F7A0CB0AA2634C278A9C069AF892C96716",
                            "defaultText": "팔굽혀펴기 100개!가다!"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "8190A6D8804AD8484939812992FDF7922DCF",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "8EFB19CB6A27484E03387E63DB8B36219E13"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "551FE5432AD98340DB8AF339C46BB0571145",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "EE29149293DBD349A58859327D9553390099"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A189FD379D1300449A28274545CCFFA115A9"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "98B56DC64BABB04C3799EF017EBE609E28B9",
                            "defaultText": "집중기도"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "383E2C9C65AE914E446B4997A722476FD8C5",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "58E00811839A15428F696A02A8F51FB8DF75"
                },
                {
                    "id": "gs.Comment",
                    "params": {
                        "text": "Nini"
                    },
                    "indent": 0,
                    "uid": "0A3EA70723E94249A08B0835633F3B890102",
                    "expanded": true
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "0E09CEC93D560543237BB1E4861A09F08AC1",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "FFBF2F7232258240FE6AC626A5BAF89175B8"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "03FCA5905D638540C4889C00281093E69B9D"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "A21AD19D14A5F84C3429FB3579267C901E2C",
                            "defaultText": "성기사의 과거"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "92B352AD4BDAF741BB4B0AD4CCAE550CC83F",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "596C458F5098674942187661BA8E2020D5DC"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "83B0EA19817F0843029AACC988B8475E1D19",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8DEF9A24889456409A2A81916C6A727AA1C9"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "57DA9DBC74CB544B0E0953858598D96BBE7A"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "DD6A52973A7A82451A29A90878C0ADBFC70C",
                            "defaultText": "마나 재무"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "20E7B2A33F6EA54F755AA9A00283C53D0A14",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "31CD93401E179147C29B94E4E79EE29302AD"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "99C1C4A37414D144082BD4090B87C0DC29E3",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9AC7B7C217F37944142937D29F3FC3C0C64A"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E46531E48EE5514C581B5B510D66AE36B169"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "9A9E4C84495D6845AA492EE41627A74CE7DE",
                            "defaultText": "스텔라 삼중항"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "876148FD315CD247D92B2448B35D9F0F9C4B",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "AECF7F463B54664D9A3980C38F9048AD61AE"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "DD2E9650650BB543BC38ECC94367D2FE5D3B",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "1FD2D91B8DAFD44C0F887F6716173C090086"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4D7A3B14801E944E1F68C216F8ED1728E0F9"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "59CAC170695F02453F584873EDADECA9EF64",
                            "defaultText": "마나 전송"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "3B6B83E27C2E584CBD48CBF88FB91FCB758B",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "11754EE35ED8554D08595BE5BCC1EE0EEEBE"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "52F444075A47A746C739B216B68518096D46",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "655EECFF46F7A448127B7D516C76F320B01D"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E32560F1591C0843391BFB753D17E90535DA"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "5CF8A842330C98496C5AF4A4645960BC1D05",
                            "defaultText": "울티마 플레어"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "BD080BD894743149834B7736AF8007233A80",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "3993F8046968B944E02B47F3307ECCF69FF8"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "87329D917A8B3845571A2DD053A32B11C9F1",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "82EA09BE7AA4744B6F18C34240B7EE6B562F"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D959147F46AD2841961A596063FBD32E6404"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "3AAF1E066ADCF74F765945F55CDA3592D4B6",
                            "defaultText": "마나 퍼지"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "04110B296A452646537AA4C83C4F81FF89DC",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "750E0E6965477848AB59F027D88D013E1226"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "A738D3CC73AF774D884AF4A32631BE4C6AC8",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "82BFCCA534B8994EB179F041B53BC4577A68"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9693BF14752E224202487A312AD5CDF0FEB1"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "36964E176841F94A592A6CA7D43D85978EA6",
                            "defaultText": "울티마 폭풍우"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "5D6D4C940DC5C14F9B19FF997CE088ECB73F",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "9B06079C108F9745AA69B807355B2091CD61"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "E72FF6E89A481948424A3594F6CC9F77585B",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C726ACA73CDA334D1C8B1A9763639BE195B2"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2DAA2969899E62479738EC873399A61A265D"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "D870D2207092C24EAC498C81F6804013D58C",
                            "defaultText": "마나 쉴드"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "082EBBED1F3E21436B39796067CD294EE5B2",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "FD6DE8667AE89741CD4BBDF8D41648541BFF"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "AF0FBC4030463340698B166420A261EACA47",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0D3EE4BF315737496E2AB24415E4ECAB3D7C"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5DC9D8367C61F745647A189174E2BAF75E5B"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "D2CF3D2479E06141E09806A986C458375C88",
                            "defaultText": "울티마 글레이셔"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "923CCB012D4DD84728081BA6AA29617DF0B1",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "5B25F1A13F27354829586501898BC39630C3"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "50D40D4D6C7FD64CE00B8C507FB6A1B09420",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "7EBC15F41118C34DDF5AC204937DA791F771"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "6A7A4C2D0E52D542134ACD7175E8B0F91123"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "627BA4535BC88741DA8BD3E737D78A945F48",
                            "defaultText": "보호 오라"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "C16BA4E062AD734C696BA2A6ABD4E2C4D1CC",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "0D817FCB5095F8499E7A4CC77467C2F10918"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "E876FFFE79FC334F10499039B61E72567357",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2F76725A10DA62400D796436679C811CB6D1"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "18EF66547F560747B23B48B14D1CFF738151"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "2DC5C51B4B0D0949CB58B8925635531495D7",
                            "defaultText": "울티마 제퍼"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "157F2A0936E01740B41B24D2E144D9A8E89C",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "83334253194F8442AC3AC0281D895FC6AD0A"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "CF82379C4B92E540A2590E746BED3DCD7664",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "DFA6601968881443612BFC069327E7395EB5"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A64CD5B82F8A11487B5935C8B4CA1A1049BC"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "6E8D5FCC7A4D614F2459BA7896055259F688",
                            "defaultText": "마나 축복"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "3C07F5CE3DBA694D451BE6C7E4D45D95563F",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of skillnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "8F186DDC4C75034E6C38CA09B3B6784A77E6"
                },
                {
                    "id": "gs.Label",
                    "params": {
                        "name": "end of skillnames"
                    },
                    "indent": 0,
                    "uid": "A0FE41218CB4334E312BC485652E9D79AAD1"
                }
            ],
            "index": "1F2F93FD7AC748409D0BE6A29B1F2B1F2217",
            "booleanVariables": [
                {
                    "name": "",
                    "index": 0,
                    "scope": 0
                }
            ],
            "numberVariables": [
                {
                    "name": "",
                    "index": 0,
                    "scope": 0
                }
            ],
            "stringVariables": [
                {
                    "name": "uid comparison",
                    "index": 0,
                    "scope": 0,
                    "domain": "com.degica.vnm.default"
                },
                {
                    "name": "current uid",
                    "index": 1,
                    "scope": 0,
                    "domain": "com.degica.vnm.default"
                }
            ],
            "listVariables": [
                {
                    "name": "",
                    "index": 0,
                    "scope": 0
                }
            ]
        },
        "localizableStrings": {
            "BA6AE26784BA7846E418B62917A6D6A80F29": {
                "t": "Shadow Mastery",
                "d": {
                    "eid": "AB2694E895292847F58B3240EE24AEEE4386"
                }
            },
            "53A06D948887F249FA3A4E69B01C80A36126": {
                "t": "Vassal's Creed",
                "d": {
                    "eid": "BA67BA6C57900640D699F6D821556DFFD035"
                }
            },
            "C69E0BFC6BC2A442EA8A8A257D42AA09597D": {
                "t": "Mensana",
                "d": {
                    "eid": "A0288B2E20B1E8494058C8E95948F0EC9E70"
                }
            },
            "F5B1443F671E3441981A1F359737866EFCEC": {
                "t": "Neregis",
                "d": {
                    "eid": "175110F95BCB6542C48B02468C4554F3682B"
                }
            },
            "2E6C71C51E6AC448C67B351817DA068CF71F": {
                "t": "Vacuanox",
                "d": {
                    "eid": "4ED43B9962749145F53AB4668D396E69B07B"
                }
            },
            "0BA6BB8A6B3AE84A8D88B979A3A2BFD8A870": {
                "t": "Scutumalis",
                "d": {
                    "eid": "E508498341798440BC8892C1395B6F7A36D0"
                }
            },
            "3A18608227FF79456E5BA8C0A9D1C3EDF85E": {
                "t": "Oblumbra",
                "d": {
                    "eid": "549EC0FC9FC8454ED27B5D02FD146A715F73"
                }
            },
            "193ADCEC28C1D2404E49DFC203CCA2CF1353": {
                "t": "Probellum",
                "d": {
                    "eid": "55B2E16B45FD4546C319ACC60E8565066374"
                }
            },
            "F3748CFD6807C9446D5A89E7A0841AA5B064": {
                "t": "Cosmortem",
                "d": {
                    "eid": "BA3BFA1D479F434CEF49B6E01ADF4B519B95"
                }
            },
            "475C34D33C964740C53857E2B35482FA90D0": {
                "t": "Eye for an Eye",
                "d": {
                    "eid": "0FF2D7E63FA6A4446D89F4A1A984C968A18D"
                }
            },
            "C503576F4F01C248A5191AE43C82AA088572": {
                "t": "The Abyss Within",
                "d": {
                    "eid": "857C16D6554A224B6339E5C1809A9BD5EA34"
                }
            },
            "5965B4953AA702471B5A3BF1113F2D7FF9B2": {
                "t": "Fortenebra",
                "d": {
                    "eid": "D3F541A144DF7844571BBC686FCB7E9093A3"
                }
            },
            "4607059D5FB457488F2A0638E1E26D79FBDB": {
                "t": "Solarabyssus",
                "d": {
                    "eid": "AC3FEA7D8FC2F84262792AC39B76FB187769"
                }
            },
            "18ECFCBA549DA645D34B139356D1DAFF4EEF": {
                "t": "Light Mastery",
                "d": {
                    "eid": "2EE5CF419CE186446278C307AD05506CE14F"
                }
            },
            "8EED89AE7031154A4B2BDD449FFBFA6D784D": {
                "t": "Prodigious Seer",
                "d": {
                    "eid": "A660CB2D95A25844D18B56689EA6CC0D4F91"
                }
            },
            "514A1F631E96E742D02BC535670D7307F664": {
                "t": "Spiralux",
                "d": {
                    "eid": "CC56F41D6BEF074D40996A946A96F55845AC"
                }
            },
            "CD6060347B8FD742981813C14E8CA629B3C7": {
                "t": "Heal",
                "d": {
                    "eid": "E7F5E5B24B273746A94899F798DF3638446D"
                }
            },
            "956F157D4FC6874D335981C71A22C348F670": {
                "t": "Candle Abra",
                "d": {
                    "eid": "15CF7807671FF54E7E3BBF250E24D8E3E9B6"
                }
            },
            "219566B696C293450F2BDD60A68771CB1230": {
                "t": "Detect",
                "d": {
                    "eid": "5D8EA53468979941AE48CC34987CFEFA94AD"
                }
            },
            "80EF4F716A482240E15BFA033FAFE837E5BA": {
                "t": "Judgelight",
                "d": {
                    "eid": "6CD495391239E743B61AD92850D98B94F52A"
                }
            },
            "25C7FFCC252137459E483480CE735F5CF4C2": {
                "t": "Empathray",
                "d": {
                    "eid": "E4EB33219FD8164A9A58EAB6C47CE6377315"
                }
            },
            "E5EF0E1A436382447449625207A5542636FB": {
                "t": "Primaura",
                "d": {
                    "eid": "41BD66CF223EA8452089D1527501ABCC6274"
                }
            },
            "35CF56AF16A51847861A8C55989DDCDE5175": {
                "t": "I Can See You!",
                "d": {
                    "eid": "08C683368A47374DA32B85A6FEC9DF531885"
                }
            },
            "D80C7E12577CB442BB48158140A91C77A79C": {
                "t": "The Bliss Within",
                "d": {
                    "eid": "613D947451EDF4444B193CA39036057AD77F"
                }
            },
            "9EBADE1D1B1E3148A84B3F98026CAC651012": {
                "t": "Pillar Heal",
                "d": {
                    "eid": "BD54AC2B3B69B14F138AD493E9CE9CE16B13"
                }
            },
            "07937CB36F5BE94C1B0AEE93AF3F92D8446D": {
                "t": "Midnight Flash",
                "d": {
                    "eid": "2A8D7C44519B3249FF2BF4F99A647E63FB24"
                }
            },
            "9F28CC843B1D554E4A998BE4BDE2F5906AD2": {
                "t": "Blood Art",
                "d": {
                    "eid": "E240537E25F5774E5D0BED42755C909956C9"
                }
            },
            "AB9047285346C242AF6B410419DDC86A3C16": {
                "t": "Dimensional Prince",
                "d": {
                    "eid": "21CB0F567A8E1446815AB1C9DAC26C5D8AF5"
                }
            },
            "31FDE0535F9951465F5982F9A9E045AA5F9D": {
                "t": "Lion's Maw",
                "d": {
                    "eid": "E6A3544A37A7634BA008CEE81F8C7E4A5313"
                }
            },
            "295DBC9D4C55C24E0E691D38283B8AEB20F0": {
                "t": "Teleportation",
                "d": {
                    "eid": "2B36858B282E844A2A494E6337AB216F3111"
                }
            },
            "20F8E76F1C58D9463E492B5873F86FCC45F1": {
                "t": "Hemokynesis",
                "d": {
                    "eid": "845A82379F7A464CF83829D3670E13E22CFF"
                }
            },
            "91ACFE2A4D21504A7C7B439851CC06EC88B3": {
                "t": "Dimension Cut",
                "d": {
                    "eid": "552596F892049444FD0BD428783BE80200B2"
                }
            },
            "88F0D63E6177184ADD8BCD8428DD7F4F1ABF": {
                "t": "Ogre Slash",
                "d": {
                    "eid": "7C5B143D75F7F54D454B76D7EE83F2D6DDBF"
                }
            },
            "03A28C442401984F0D7B7CA24F12EF76CC68": {
                "t": "Phantom Sibling",
                "d": {
                    "eid": "8091D9902818034B726820822A83671C32C2"
                }
            },
            "A5AC97896909D649AD490F52BDACD0B1A4E9": {
                "t": "Salt in the Wound",
                "d": {
                    "eid": "8CEE01168D2BE74D0A4B9E25AE40F9444236"
                }
            },
            "7FB8597A1D639249218B09140A8314A57C28": {
                "t": "Dimension Reaper",
                "d": {
                    "eid": "2B2683BE85C78548EB790A188BFDEB5D6BE3"
                }
            },
            "CD7F659195CC514A0398F2C893F58DCC5CB0": {
                "t": "Titanic Splatter",
                "d": {
                    "eid": "2D98F732765D60492A7BD391B5E6423B5B6D"
                }
            },
            "F51C2D0438A746456A28A4A6954B3AFC3C3C": {
                "t": "Cloaked Execution",
                "d": {
                    "eid": "1E7AA69B35D523497D4A1A4242965CA76E45"
                }
            },
            "BF686543765EC84ED819D69321554C05DE2B": {
                "t": "Imperial Tactics",
                "d": {
                    "eid": "A14E5EF4224D12469D0A98F7A7DD242780D2"
                }
            },
            "7F3651C26DC7F24D5D295605ADB5837875A9": {
                "t": "Elemental Mastery",
                "d": {
                    "eid": "51ADAB395B58E849CF8B8AE391AA2E4A9472"
                }
            },
            "9EE3A5A83620B54FF93BBD51DF8C08F61371": {
                "t": "Lightning Rod",
                "d": {
                    "eid": "B13207BB135BF4431919EC76332DA9D3E7E0"
                }
            },
            "DC17E2AF7DFC8542FA0A4BF1BE873BA737E0": {
                "t": "Distract",
                "d": {
                    "eid": "80E7232B6D91904C2E691C89340D5ABCE70E"
                }
            },
            "142D62B15F53E541AA4800E4BB7BD64B4C3A": {
                "t": "Scorching Shot",
                "d": {
                    "eid": "D9366C20234EA848C06916B8AF285D901DC6"
                }
            },
            "F86494065A6085423289CF471F5A13F23461": {
                "t": "Lateral Dance",
                "d": {
                    "eid": "F6FD0891597E2743C83A68B102CA216FE892"
                }
            },
            "0B59E11229B6804E6C786986A31D2D9A2367": {
                "t": "Bolting Rain",
                "d": {
                    "eid": "C1B523441AA4634A0C2BD633C396C4F7BB78"
                }
            },
            "F188942C3260C7427D9AA1B56AA4D5795B33": {
                "t": "Retiring Dance",
                "d": {
                    "eid": "F137E15F7F8E29441B5B58A78D7E2F43BDF2"
                }
            },
            "7ADE827446A0154BA9597B590416FA437F42": {
                "t": "Vulkan Rain",
                "d": {
                    "eid": "121325548495234A23283088281637BA2D2E"
                }
            },
            "FE5D7B098FA2E3440F78E7A46A218D7EEE68": {
                "t": "Omnishot",
                "d": {
                    "eid": "B26713DF1FEB964BC99A99C2E70240B3AA6B"
                }
            },
            "1A7F4EB86629E642824AFEF8338DE952307B": {
                "t": "Glacial Rain",
                "d": {
                    "eid": "162BD3165C42B547F39BE3F1EE5AB633F972"
                }
            },
            "602BE1D08F52C944EE780166B93EB60BA50B": {
                "t": "Lethality",
                "d": {
                    "eid": "C34750FD614369425A49E6A2B2A8B4390028"
                }
            },
            "C2D9A1F429FC9441812A36A0B424C2510644": {
                "t": "Muscle Training",
                "d": {
                    "eid": "076874AB70A6544A733B7DE54FC3F12625C8"
                }
            },
            "D54DCC9F29C563469B2B0207F31C36478A1C": {
                "t": "Avid Believer",
                "d": {
                    "eid": "77E1363D40B9B248D30B3796575752A0D7AD"
                }
            },
            "5D99CB3C4A91F646C718C8A621DD9804B756": {
                "t": "Head Splitter",
                "d": {
                    "eid": "BED25AD0514AE447384820F6E549C6B71892"
                }
            },
            "EDCBB80D829BB6443A194F14AFBD5077D32F": {
                "t": "Holy Breeze",
                "d": {
                    "eid": "B9B193070394E1436F790475B2E0EB784BFA"
                }
            },
            "56ACEC0B2FBFC64A9A2935744E58C2C25CA3": {
                "t": "Leg Cutter",
                "d": {
                    "eid": "527CFBE29BE85743710AC9423085D8A6FF98"
                }
            },
            "3F0AEF8B224601487899C0935C1DCAF9BB80": {
                "t": "Prayer",
                "d": {
                    "eid": "995E14F53F3C454F36385CC7B6E1A8A9F803"
                }
            },
            "077F7A7D0117744C4C088A651975B0E114E1": {
                "t": "Bone Crusher",
                "d": {
                    "eid": "477E2CCD36E74243BE7AE868DD24002B0C1A"
                }
            },
            "564284D91552E5413A889B545E4789CF8CB9": {
                "t": "Serious Prayer",
                "d": {
                    "eid": "93D979CE70B9844343796CB6B146BDE2AA5B"
                }
            },
            "115E36481F2A41489C49F675EF3BDD5E09C9": {
                "t": "Adaptive Mind",
                "d": {
                    "eid": "E9992627626BD84D3D59747903B12FA8779B"
                }
            },
            "791052D21AAE68449149DE15C6EDA3EB03AD": {
                "t": "Golden Wind",
                "d": {
                    "eid": "2D9A645A42C1794B4B5ABA54DBE475EC2795"
                }
            },
            "99F7A0CB0AA2634C278A9C069AF892C96716": {
                "t": "100 Push-ups! Go!",
                "d": {
                    "eid": "8190A6D8804AD8484939812992FDF7922DCF"
                }
            },
            "98B56DC64BABB04C3799EF017EBE609E28B9": {
                "t": "Focused Prayer",
                "d": {
                    "eid": "383E2C9C65AE914E446B4997A722476FD8C5"
                }
            },
            "A21AD19D14A5F84C3429FB3579267C901E2C": {
                "t": "Holy Knight's Past",
                "d": {
                    "eid": "92B352AD4BDAF741BB4B0AD4CCAE550CC83F"
                }
            },
            "DD6A52973A7A82451A29A90878C0ADBFC70C": {
                "t": "Mana Treasurer",
                "d": {
                    "eid": "20E7B2A33F6EA54F755AA9A00283C53D0A14"
                }
            },
            "9A9E4C84495D6845AA492EE41627A74CE7DE": {
                "t": "Stella Triplet",
                "d": {
                    "eid": "876148FD315CD247D92B2448B35D9F0F9C4B"
                }
            },
            "59CAC170695F02453F584873EDADECA9EF64": {
                "t": "Mana Transfer",
                "d": {
                    "eid": "3B6B83E27C2E584CBD48CBF88FB91FCB758B"
                }
            },
            "5CF8A842330C98496C5AF4A4645960BC1D05": {
                "t": "Ultima Flare",
                "d": {
                    "eid": "BD080BD894743149834B7736AF8007233A80"
                }
            },
            "3AAF1E066ADCF74F765945F55CDA3592D4B6": {
                "t": "Mana Purge",
                "d": {
                    "eid": "04110B296A452646537AA4C83C4F81FF89DC"
                }
            },
            "36964E176841F94A592A6CA7D43D85978EA6": {
                "t": "Ultima Tempest",
                "d": {
                    "eid": "5D6D4C940DC5C14F9B19FF997CE088ECB73F"
                }
            },
            "D870D2207092C24EAC498C81F6804013D58C": {
                "t": "Mana Shield",
                "d": {
                    "eid": "082EBBED1F3E21436B39796067CD294EE5B2"
                }
            },
            "D2CF3D2479E06141E09806A986C458375C88": {
                "t": "Ultima Glacier",
                "d": {
                    "eid": "923CCB012D4DD84728081BA6AA29617DF0B1"
                }
            },
            "627BA4535BC88741DA8BD3E737D78A945F48": {
                "t": "Protective Aura",
                "d": {
                    "eid": "C16BA4E062AD734C696BA2A6ABD4E2C4D1CC"
                }
            },
            "2DC5C51B4B0D0949CB58B8925635531495D7": {
                "t": "Ultima Zephyr",
                "d": {
                    "eid": "157F2A0936E01740B41B24D2E144D9A8E89C"
                }
            },
            "6E8D5FCC7A4D614F2459BA7896055259F688": {
                "t": "Mana Blessing",
                "d": {
                    "eid": "3C07F5CE3DBA694D451BE6C7E4D45D95563F"
                }
            },
            "4236E5753439A846E2882F7461365268CBFD": {
                "t": "Blind Princess",
                "d": {
                    "eid": "2672E92F84D604474C3BD513D99D6D6093E7"
                }
            },
            "92F23B1730A4E143FF1943057EE25753D1B6": {
                "t": "Sixth Sense",
                "d": {
                    "eid": "5D2CBD4128CA4343B299B4F6A05E66EA07DF"
                }
            },
            "730D3A5294ACD647349AA6932AB3D4B05EED": {
                "t": "Odd Empathray",
                "d": {
                    "eid": "BCD837462384864AB21A7912FE0754E2E39F"
                }
            },
            "424DAE1A05BB164EE31A3118F42810564FC3": {
                "t": "Neo Primaura",
                "d": {
                    "eid": "A8142F48276FB243FE29410905DC6995AB96"
                }
            },
            "F8BE5A7E301FF048F5989A0760EF9C08D954": {
                "t": "Blind Spot!",
                "d": {
                    "eid": "516C54751773B64ED3785AF3E3043CBDC649"
                }
            }
        },
        "parentId": "6ED66A9042ECB3444948D814E41FB327288F"
    },
    "summary": [
        "name",
        "type",
        "order"
    ],
    "externalItems": []
}
