GS.dataCache['AA9723213DBA0242070B632390C12E5C5327'] = {
    "uid": "AA9723213DBA0242070B632390C12E5C5327",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "(Safe area) Tacitus' house",
        "type": "vn.scene",
        "parentId": "9AB50C53210E05484A1B0A220DAF39285D09",
        "chapterUid": "EF3BAE1B50D8764F0D184715C435B627D64E",
        "order": 1,
        "commands": [
            {
                "id": "gs.Comment",
                "params": {
                    "text": "You see a great number of dolls. You have to click on all of them."
                },
                "indent": 0,
                "uid": "98B7F18162E998421C78D1348D0E565D40A7",
                "expanded": true
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "A new clickable element, the \"portal\", appears.\nOnce you click on it, a confirmation prompt appears.\nThen you jump to C11A-6."
                },
                "indent": 0,
                "uid": "82D36D957013594E92586FB3D59ABCE141EC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            20,
                            1,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "E44D3C126DEE3447D47BF7A6E5F924B5BFBF"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "F6D0D80A5243D84BFF5812F62675C23C05EB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "7D53F7F251B431471E8B4AF60E16DE84DA67"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "D0BA74DA1B785645601AF1F6992D58C6DB61"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "BCE9E4818A9884472A7B3581DBD291EAD6B0",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9EAF78A896839548754AD5D7586B9DCE3D50"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CB714D94714A504FBA8BF0D8BC0540C586A7",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "AB9718577E63C949011B0042D00ECDE8E869"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 3,
                    "blendMode": 0,
                    "zOrder": 702,
                    "duration": 0,
                    "origin": 1,
                    "waitForCompletion": 0,
                    "positionType": 1,
                    "position": {
                        "x": 794,
                        "y": 766,
                        "angle": 0,
                        "zoom": 0,
                        "horizontalFlip": false,
                        "data": {
                            "x": 398,
                            "y": 371,
                            "zoom": 0.08,
                            "angle": 0,
                            "horizontalFlip": false,
                            "width": 124.4,
                            "height": 120
                        },
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 0
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 0,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "doll.png",
                        "folderPath": "Graphics/Backgrounds/Tarmen",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "ED2169CD0E4CA84C323B020743A76139DE25",
                "expanded": false
            },
            {
                "id": "gs.TintPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 3,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -20,
                        "green": -20,
                        "blue": -10,
                        "grey": 35
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "23F4AD48149DE14A3958E75388B605F63A8D"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 4,
                    "blendMode": 0,
                    "zOrder": 702,
                    "duration": 0,
                    "origin": 1,
                    "waitForCompletion": 0,
                    "positionType": 1,
                    "position": {
                        "x": 1358,
                        "y": 798,
                        "angle": 0,
                        "zoom": 0,
                        "horizontalFlip": false,
                        "data": {
                            "x": 665,
                            "y": 394,
                            "zoom": 0.13,
                            "angle": 0,
                            "horizontalFlip": false,
                            "width": 174.16000000000003,
                            "height": 168.00000000000003
                        },
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 0
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 0,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "doll.png",
                        "folderPath": "Graphics/Backgrounds/Tarmen",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "F63390258C7CF24CA5698E32700CF9136E55",
                "expanded": false
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 5,
                    "blendMode": 0,
                    "zOrder": 702,
                    "duration": 0,
                    "origin": 1,
                    "waitForCompletion": 0,
                    "positionType": 2,
                    "position": {
                        "x": 690,
                        "y": 774,
                        "angle": 0,
                        "zoom": 0,
                        "horizontalFlip": true,
                        "data": {
                            "x": 397,
                            "y": 383,
                            "zoom": 0.06,
                            "angle": 0,
                            "horizontalFlip": true,
                            "width": 99.52,
                            "height": 96
                        },
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 0
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 0,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "doll.png",
                        "folderPath": "Graphics/Backgrounds/Tarmen",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "468DA68B8CC71547457A60E64ABD3631C963",
                "expanded": false
            },
            {
                "id": "gs.TintPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 5,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -60,
                        "green": -60,
                        "blue": -55,
                        "grey": 50
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CF010E2A2C9D4342326AD6086B4E48F0E258"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 6,
                    "blendMode": 0,
                    "zOrder": 702,
                    "duration": 0,
                    "origin": 1,
                    "waitForCompletion": 0,
                    "positionType": 2,
                    "position": {
                        "x": 460,
                        "y": 762,
                        "angle": 0,
                        "zoom": 0,
                        "horizontalFlip": true,
                        "data": {
                            "x": 222,
                            "y": 375,
                            "zoom": 0.09,
                            "angle": 0,
                            "horizontalFlip": true,
                            "width": 124.4,
                            "height": 120
                        },
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 0
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 0,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "doll.png",
                        "folderPath": "Graphics/Backgrounds/Tarmen",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "F0D0747F338CD942661902B7B1B156134E7C",
                "expanded": false
            },
            {
                "id": "gs.TintPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 6,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -20,
                        "green": -20,
                        "blue": -10,
                        "grey": 35
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5C71B4E0605D774A2568E125BD8244DEB885"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "46DED04F7CFDE64DB61B1B2795A11B46C21A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "781BEF7698B8444C681B43373D09796D41DD"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3CD8BFA794528246AC2B331662F28101919E"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 45,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 2,
                        "movement": 0,
                        "mask": {
                            "graphic": {
                                "name": "9.png",
                                "hue": 0,
                                "opacity": 255,
                                "blending": 0,
                                "tone": {
                                    "red": 0,
                                    "green": 0,
                                    "blue": 0,
                                    "grey": 0
                                },
                                "folderPath": "Graphics/Masks"
                            },
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CF1211822C46F6478B7B2970CB90646A5B29",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 15
                },
                "indent": 0,
                "uid": "EA7B57343F0231401C68DDC12A0EF219ECEB"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Spend time (during travel?)",
                        "index": 96,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CD66B5AD12CA924DDE5843C3B7113E30E0D0"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Spend time (during travel?)",
                        "index": 96,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "88583D753018A74EA09B6572BF2ED74ACAE5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "03DEA4954ABD5648B72A16630CB12FEB0C7F",
                    "parameters": {
                        "values": [
                            {
                                "name": "Tempo d'attesa",
                                "index": 32,
                                "scope": 1,
                                "domain": "com.degica.vnm.default",
                                "changed": true
                            },
                            250,
                            1,
                            2000,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "0E1565908390484756084A8668E4CE2408D5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "7601D85C3700D2424D6B5E62901196D79FD3",
                    "parameters": {
                        "values": [
                            20
                        ]
                    }
                },
                "indent": 0,
                "uid": "BC3D5A8C0C1C3943306A258881CD4FBAD4DA"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "PREVENT LOADING EXPLORATION?",
                        "index": 97,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "59524FC81ABF224E574A24505D0E0A7E5B5C"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "567F1E3489D91446CF4A0ED6AF508D6BB339",
                        "name": "96 - Cristoph Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 3,
                "uid": "9A937BA8650E37471F1B41C1C5EDDCB7211C"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "2B96228807C91543086AF8734CBB0AD4A6B9",
                        "name": "93 - Faratras Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 3,
                "uid": "BD7CB657168DF84FA56904B5F87A8037E01F"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "0FCC16EC8F14214F211BD711C5EF156BDE65",
                        "name": "95 - Rya Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 3,
                "uid": "02BD0BB805EEB44075185570FF4FF8DEB746"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "F3823FD62416494D4B19AC16A32B0551CD5B",
                        "name": "91 - Ornieres Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 3,
                "uid": "5FBFAAED771D89470F4B29703B5B6DC26162"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "5E3EF75772FBB5456A3ACFC11E395AA57898",
                        "name": "36 - Lepto"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 3,
                "uid": "4C1471902A315647332B6941A598E3F8CBDA"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "8410EB175A4D614BF01B3B5753218AE970FB",
                        "name": "37 - Finn"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 3,
                "uid": "38F687DC82F07243BE88D15241C410B87972"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "INDICE HOTSPOTS\n1-5 Hotspot pg\n6-15 Elementi di background\n16-20 Monetine"
                },
                "indent": 0,
                "uid": "BCEAD7B103B5144B8F48D116CE98FF249068",
                "expanded": true
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "first time seen?",
                        "index": 39,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "249A499F7A87C7459F298181634CE19CEEA3"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "Exploration Unique No. (Lazulis, Midbar)",
                        "index": 359,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 0,
                    "source": 0,
                    "sourceValue": 0,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "7EFCF16C3DF061440C1A0BF6E5D0089AE4D8"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "",
                        "index": 39,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "70A2565A2D04D44F2A592A9821D94EEF6D54"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EBBBD21C835A8549AB794FB7C1212E74CB9E",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "237426EA64DE75468D5BBAD52CFADFF94398"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "091972C139B6D445C2381079EB837ECD90FE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "EEEBC6D53602244AB32A9BF65AB211FF8D89"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "7A17A64F2E3A114F191AF178ED2640350AAB",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "87614EB22C3A23441B6B03271AD1E0AE3BBA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "7A17A64F2E3A114F191AF178ED2640350AAB",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "C0DECEC124332844E16A9008647487698B56"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B756A1F325B9D74EF94A3EE6943B33EDB05B",
                        "defaultText": "여기다! 내 직감이 이곳이 틀림없다고 말하고 있도다!"
                    },
                    "position": 0,
                    "characterId": "7A17A64F2E3A114F191AF178ED2640350AAB",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "expanded": true,
                "uid": "21D0C1868958614E388A838482EA30F5DA4A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "35E4EDE52113D545A259D026BC09D81B3A47"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "51783774748BB249273952F30EB9AC449EC8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "8A3A062A6D6001495D8AB6452E62972D0CF4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D51097961B1D9645010B1691CE0F536583A7",
                        "defaultText": "또 버려진 집이야?"
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "5BC904D40E54D247E939DC24C6730CDB981C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "F3583F5F2BE868436079EE469C303F83BFCF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "3CD40BE31868B14DFB8A69B864AB4F2F89F7"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 1,
                "uid": "4C74AE674A140947F15A1F30202618B267DB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "0503317C787B754671594394B48760C663C6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "A1F5B24A65AFE649AF3A748207B6AD5596CF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "22FF242F21127245C84A92A4D5B36872AA4F",
                        "defaultText": "여긴 뭔가 이상한 느낌이 들어... 저 인형들이 불길해."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "047DCB4671B44647BA39C356CA5240E2A3C8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "8B67FD4F75780340D66BFF930A46E19D9060"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "7333BC110AA614403F2BE591EAD10281F06F",
                        "defaultText": "???"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "13981EB6220B0140A75A1DA4CD61BA87871B",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "4710D13F3222C446D43B7AA2C0D878B69C42",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "???"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "C63A60198BB6D445DF6B40683ABCE90CE617"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "D6591BA148A24347EF1B7BC2C935577202F1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1FC6157E8091F24D577B43039553FF79BCFB",
                        "defaultText": "어... 그 말에는 동의할 수밖에 없겠네!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "672A058A61BBE847A519D0221341DFF5690B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "3BF24E081321D64B427A4B613438904D3BB2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "7855C89965569145C4091CE2EC1584185093"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7C024B6D24FC184A1478A23581DCCAC628AD",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Doll_line8.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "16EC3D4E622AD94C1E1851F170D27688B0F7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "14AA097E8031624251296B11A08429F48EC1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4710D13F3222C446D43B7AA2C0D878B69C42",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "B339171F5DEA26443F5B66D4F49B0C352422"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1E5E16420B927848ED8858801B8D7DA773DE",
                        "defaultText": "드디어 왔구나. 아무도 날 찾아오지 않아... 모두 무서워하거든."
                    },
                    "position": 0,
                    "characterId": "4710D13F3222C446D43B7AA2C0D878B69C42",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "1E7592357314214A3938A9D11289FE11A84F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "FF98A939286A54491C1862B58EC613826DD3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "C7751097959F81495D98926067AECE9DC114"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6C5239031BB60041FE9866F1463E666B0A73",
                        "defaultText": "인형이 말을 하잖아!?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "DDEBF5A023AA424F463A87C9DB9265F04FE6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "838552F85CC44543665BC324A0A0417ED5E6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4710D13F3222C446D43B7AA2C0D878B69C42",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E0E2953E4A3358456B7853087D770211579D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EBF4D9AB88533746BF682BB6F99514CF8BA0",
                        "defaultText": "나와 함께 있어 줄래? 너희도 날 혼자 두지 마..."
                    },
                    "position": 0,
                    "characterId": "4710D13F3222C446D43B7AA2C0D878B69C42",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "E7D83A817A49874E7C791FE2A6B5646ED8FB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "4A128038592F784D6B5A54560AC1A57495F8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "7A17A64F2E3A114F191AF178ED2640350AAB",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "793DA91141CDC04D0C386BD9F4BE67132701"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 1,
                "uid": "DF6B21F902ABE841B49A6472EABE33C4AD13"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "3A7C0DF741A0F148E73A1C188CA08DFE6E01"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "5C44D6AB453D504C2518844884CAD7CE1984"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6AFA24BA666E8744606A593448087DD71CD6",
                        "defaultText": "어린 여자아이의 영혼이... 깃들었을지도 몰라."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "B49EFF1B9FE915435F0B3902C45D5A5372AF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "36F23367508B054AB02A092639875B0BE89A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "559DD32505AF944E1E59F7F12BD4D74EB6A1"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 1,
                "uid": "61C51FAC3B6F484A56886414DD19B3D78F96"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "D4F3F2641405B047294A041857BD6A2C91A1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "DB396F676EB8F241874BDA95185EAC769D8F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "60BD47A52877C346A428FE828666567AF6E9",
                        "defaultText": "그게 가능한 일이야? 이제는 놀랍지도 않지만."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "BC2C010A413E76438D3BAB68D1FA989D37BB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "7B938F095756554AFF4B298333AF07E571D3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "FD75D9B42B37154346193E232ADB5B8CD2B0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7ECDCBB81653844FC6293701C457A745A342",
                        "defaultText": "확실하진 않지만 현실이 눈앞에 있어.\n적어도 이 아이에게 나쁜 의도는 없는 것 같아."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "0467DEDD3A0237468118C587045AABEF700E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "208455113755114EE9680481BEF8BBAECC4C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6BBC8ECD81A9F44DE839CDE9184BDEDF9E4C",
                        "defaultText": "어쩌면 우리 임무에 도움이 될 만한 걸 알고 있을지도 몰라."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "A61445D44EAAD8462B19970490D3E9BA738C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "397EF0063915E540A268E9522B4347196C42"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "CFE672F83C86204BDA987AA919612185452B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "86CC39EF8815B74073099FF61B50172D18A8",
                        "defaultText": "렙토, 솔라리스가 정말 여기 있는 거 맞아?"
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "C0160B8A7BB73447DB1B8C81F60D0EC838D1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "BE66C2EE31DDC64E13897688A3F61388D9EC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "3637AC3B5C4F314EF45987F4BE63F54451ED"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 1,
                "uid": "407EC0D8812BE141C96B8295578DD2CC8F2D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "7A17A64F2E3A114F191AF178ED2640350AAB",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "49C93AF53BEAE64619399C49E9E0C3057918"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "6BB05EC5699FE44C681AF2D42A5A3998192E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "80EB81E07EF7074D3C898E0102F02177605C",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lepto",
                        "name": "E3-Lepto_line8.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "E72B6F8913C56642DD58B362F9115BFA1BE1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "778A60CE2304044A164905B8D830D858774A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "7A17A64F2E3A114F191AF178ED2640350AAB",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "2BF7AE7B3660234CEA89036840D9EAA2FA46"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "13EC7FF589E60146B828DA16668B308381AB",
                        "defaultText": "내 전설의 도적 직감은 틀리지 않도다. 찾기만 하면 되느니라!"
                    },
                    "position": 0,
                    "characterId": "7A17A64F2E3A114F191AF178ED2640350AAB",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "E1DBD5A136471040C248B4890B6650680C8C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "C2A869DA02B621425F98F7110442DC5FDCF3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "F052D80D7D930649C0882E751B4C5D5E02A2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E002FD774C32D24CA8794D0762F5C3C82A3C",
                        "defaultText": "그렇다면..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "1FA7B4F26837F247CD8BF276BF8039FBF1D1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "96E8865C46A6744AF298785563F5D69BB4F3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "0E06A31F50F3B74EF32962B9CD67BF4F054B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "1099EE6560FB7342757BEC916CEFDE45C475"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "66D9C39F9935E2479D0B14A11E7AE1FEFF97"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "7601D85C3700D2424D6B5E62901196D79FD3",
                    "parameters": {
                        "values": [
                            20
                        ]
                    }
                },
                "indent": 1,
                "uid": "21C9E5FB455C1248EB986FE2CD73E701776B"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "INDICE HOTSPOTS\n1-5 Hotspot pg\n6-15 Elementi di background\n16-20 Monetine"
                },
                "indent": 0,
                "uid": "E71491AF664D764BF869FD1230987549FFDA",
                "expanded": true
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "P\nE\nR\nS\nO\nN\nA\nG  G  I    E SCENE DIALOGHI"
                },
                "indent": 0,
                "uid": "45BF662F4EFF114DA68A18B28739F402F1E5",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "retrace lepto"
                },
                "indent": 0,
                "uid": "9BAFB10C399AA347A53A8173B43DAEF9F34F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A1F3F1D799DDC043B218386049F1B8B86EA2",
                    "parameters": {
                        "values": [
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B7B9DF7B8B26374AE85AFBD17224524812E5"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "E\nL\nE\nM\nE\nN\nT\nI  C L I C K A B I L I (descrizioni)"
                },
                "indent": 0,
                "uid": "F60F59EF759AE345AB2B16D16BFCF5DB7BAD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "B91A2FE514A67748E769D0B36E440EBDFCDF",
                    "parameters": {
                        "values": [
                            "C95ED9737B97D4484B6918C3BE6B45A77FBB",
                            "886FFFF21ACFC743573AA329063B13C5A046",
                            "84F0B4124D4AD74E364AEED8F4FF1FEFC938",
                            "5BEA03C81BC439480A2A6F3418B5E876A712",
                            "",
                            "",
                            "",
                            "",
                            "",
                            ""
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "618ED1644298F44A192AAFC842285B58661C"
            },
            {
                "id": "gs.AddHotspot",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 6,
                    "shape": "rect",
                    "positionType": 0,
                    "actions": {
                        "onClick": {
                            "type": 4,
                            "bindValue": 6,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "AttivaClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onEnter": {
                            "type": 4,
                            "bindValue": 6,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "InfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onSelect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDeselect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onLeave": {
                            "type": 4,
                            "bindValue": 6,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "UnInfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrag": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrop": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDropReceive": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        }
                    },
                    "dragging": {
                        "enabled": 0,
                        "variable": {
                            "scope": 1,
                            "index": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "horizontal": 1,
                        "vertical": 0,
                        "rect": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 200,
                                "height": 50
                            }
                        }
                    },
                    "position": 1,
                    "box": {
                        "x": 500,
                        "y": 780,
                        "angle": 0,
                        "zoom": 1,
                        "data": {},
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 160
                        },
                        "size": {
                            "width": 76,
                            "height": 90
                        }
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "085B25478AE0B44D0F2A94A8187C37E63E68",
                "expanded": false
            },
            {
                "id": "gs.AddHotspot",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 7,
                    "shape": "rect",
                    "positionType": 0,
                    "actions": {
                        "onClick": {
                            "type": 4,
                            "bindValue": 7,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "AttivaClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onEnter": {
                            "type": 4,
                            "bindValue": 7,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "InfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onSelect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDeselect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onLeave": {
                            "type": 4,
                            "bindValue": 7,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "UnInfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrag": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrop": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDropReceive": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        }
                    },
                    "dragging": {
                        "enabled": 0,
                        "variable": {
                            "scope": 1,
                            "index": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "horizontal": 1,
                        "vertical": 0,
                        "rect": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 200,
                                "height": 50
                            }
                        }
                    },
                    "position": 1,
                    "box": {
                        "x": 710,
                        "y": 780,
                        "angle": 0,
                        "zoom": 1,
                        "data": {},
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 160
                        },
                        "size": {
                            "width": 54,
                            "height": 72
                        }
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "62EA8FAF73F6E84918297E53875CB791FD9F",
                "expanded": false
            },
            {
                "id": "gs.AddHotspot",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 8,
                    "shape": "rect",
                    "positionType": 0,
                    "actions": {
                        "onClick": {
                            "type": 4,
                            "bindValue": 8,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "AttivaClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onEnter": {
                            "type": 4,
                            "bindValue": 8,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "InfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onSelect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDeselect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onLeave": {
                            "type": 4,
                            "bindValue": 8,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "UnInfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrag": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrop": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDropReceive": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        }
                    },
                    "dragging": {
                        "enabled": 0,
                        "variable": {
                            "scope": 1,
                            "index": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "horizontal": 1,
                        "vertical": 0,
                        "rect": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 200,
                                "height": 50
                            }
                        }
                    },
                    "position": 1,
                    "box": {
                        "x": 808,
                        "y": 776,
                        "angle": 0,
                        "zoom": 1,
                        "data": {},
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 160
                        },
                        "size": {
                            "width": 50,
                            "height": 88
                        }
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "56C509B34D6F8348145A24B2473615CFFDA8",
                "expanded": false
            },
            {
                "id": "gs.AddHotspot",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 9,
                    "shape": "rect",
                    "positionType": 0,
                    "actions": {
                        "onClick": {
                            "type": 4,
                            "bindValue": 9,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "AttivaClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onEnter": {
                            "type": 4,
                            "bindValue": 9,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "InfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onSelect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDeselect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onLeave": {
                            "type": 4,
                            "bindValue": 9,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "UnInfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrag": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrop": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDropReceive": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        }
                    },
                    "dragging": {
                        "enabled": 0,
                        "variable": {
                            "scope": 1,
                            "index": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "horizontal": 1,
                        "vertical": 0,
                        "rect": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 200,
                                "height": 50
                            }
                        }
                    },
                    "position": 1,
                    "box": {
                        "x": 1358,
                        "y": 832,
                        "angle": 0,
                        "zoom": 1,
                        "data": {},
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 160
                        },
                        "size": {
                            "width": 84,
                            "height": 124
                        }
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0E1C36FE789699476A899A778E3865064B60",
                "expanded": false
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "C\n  O\n     I\n       N\n          S"
                },
                "indent": 0,
                "uid": "6BCD6AAF0E829746E95B64D595BD7B77E0E9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2BB01B9A8522474499180AA87EFC414D3CC7",
                    "parameters": {
                        "values": [
                            "",
                            "",
                            "",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "D890BCAF3737D6484B4999E616A8A3B6E0B2"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "PIEDINO DI ESPLORAZIONE"
                },
                "indent": 0,
                "uid": "A613AB0F379CB347623A65B8939E4379015D",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "piedino"
                },
                "indent": 0,
                "uid": "1CBC704C306A93438C78FF96952739E46EB7"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Location SCENE 1",
                        "index": 286,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "1495FE3124C26446C1492BF108398CC1943E",
                        "defaultText": ""
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "850B083F290DB440015BEB03400186045A43",
                "expanded": true
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Flag locale 2",
                        "index": 161,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "59D0B7A93E2B28487A6B0251F20B0F057EF6"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Location SCENE 1",
                        "index": 286,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "A74B615350F2744F9D686AF4FE6D4C607AD6",
                        "defaultText": "E4C0E83C3047A141A5497F27BB33CC454785"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "B71C7EA415C1414DA4687248D04391D46DAF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "86CBAC798809154F145BAB489EC84573234C",
                    "parameters": {
                        "values": [
                            {
                                "lcId": "7934799D262A8440AB6803E1AF7619739651",
                                "defaultText": "Illusionary Wall"
                            },
                            {
                                "name": "Location SCENE 1",
                                "index": 286,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            5,
                            3,
                            "",
                            "",
                            0,
                            0,
                            "",
                            "",
                            0,
                            0,
                            "",
                            "",
                            0,
                            0,
                            "",
                            "",
                            0,
                            0,
                            "",
                            "",
                            0,
                            0
                        ],
                        "uid": "F843D21C4E30A54A755BDCC2F77700F72382"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4D271A885966954213194D40CCD1D8F1502E"
            },
            {
                "id": "gs.ListLength",
                "params": {
                    "listVariable": {
                        "name": "Lista Nomi di Luoghi Visitabili",
                        "index": 510,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6C5DDA251B7B65452A2A34812D7E09029150"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Numero Multiuso 1",
                        "scope": 1,
                        "index": 0,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "971ADDFE383DB34D30293187DEC7461D1754"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "4445F1AC8A63F745F518340809A7E970C52A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "BE429D846C13E94652199725ACBACF619C0F"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "EVENTI EVENTUALI"
                },
                "indent": 0,
                "uid": "EF5E754669EC8740B89A5CF2EA6CA48FFF06",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "Eventi Scena"
                },
                "indent": 0,
                "uid": "A177E3F5435CA4438D2B0C35C180798B46B1"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "once you examined the doll and the diary"
                },
                "indent": 0,
                "uid": "8144AB4D6165D1481F48FDC5B635BE9D23F5",
                "expanded": true
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Exploration Unique No. (Lazulis, Midbar)",
                        "index": 359,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "numberValue": 4,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 0,
                    "operation": 3,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "58CA072243EBB44FDD0975873DD4A19175D9"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Flag locale 2",
                        "index": 161,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "2B9721F02BF6D340F2794F522FC85970B716"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Flag locale 2",
                        "index": 161,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "595246C414D0544A6F9A7EA518B814A4A8DD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "4A329A96986EA6411A3B0A7592C82687917A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 2,
                "uid": "5ACCF2288857964DB98B52E3A9AB8F5986D5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 2,
                "uid": "14C600432A293443492A06D935DA14564C99"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "BAE7D1FD3D842646E878E5D53C9243C376DB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "C347CDA247B97140865B96D241985569E3B4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "008CC6641F8D164EB13B956486C962587649",
                        "defaultText": "정말 슬픈 이야기네."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "8158DD745753E445817BC4775F2BF5DF5C50",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "7768CB0340FF22421E2899628E597C146C79"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "A5F656D736F9F449623A0576EA654D21A4A1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "BF14837B607AE643697A1C21B522A3DA971A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "71B67F503757B7460E4A7227824DD50E5A29",
                        "defaultText": "맞아. 그래도 솔라리스의 흔적은 보이지 않아."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "BCD5946583AAB14F6C6A49F6D5FBB094B0CF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "9E5CF7B417CCA74CBA1AC5A62F78B315381B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "7A17A64F2E3A114F191AF178ED2640350AAB",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "995714E617EBB540E748D636FF87C5927D02"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "7A17A64F2E3A114F191AF178ED2640350AAB",
                            2
                        ]
                    }
                },
                "indent": 2,
                "uid": "6EA3B4723DE2174C956B3021C5DED375C2A2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 2,
                "uid": "01EDA7D4631BD24E2E682195303B25E06007"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5871865B2F01D640B3489127578CB743C8E4",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lepto",
                        "name": "E3-Lepto_line12_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "763FFB3C702682466D88E647B53672EADB62",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 2,
                "uid": "ADC2B14D5B89D24A78685AB84FD7FF5F8950"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "7A17A64F2E3A114F191AF178ED2640350AAB",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "04A021DA848A304227191277AB3506AA9011"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F794C3F20C86574DE72A437143E720528B10",
                        "defaultText": "이해할 수 없도다... 분명 이곳에 있어야 하는데."
                    },
                    "position": 0,
                    "characterId": "7A17A64F2E3A114F191AF178ED2640350AAB",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "6107499246162346E75B50E2082FB87CDD94",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "794FB67E2969D74B428AE97187CB73AB1530"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "85D072FD5AC90447666B0836D52311ABE9CD"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 2,
                "uid": "C5CF2D91010F97407C2BFDF37C7286A5BDCD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "E06D3B1E88B2D941161B90F2F294791215BE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "D2320F4F19C852452A3897326D81E57D3559"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "53C60EA34D1EC142C22B2E427478968A32F1",
                        "defaultText": "이제 가족에게 도둑보다 농부가 적성에 맞는다고 고백할 때도 되지 않았어?"
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "366E1E809060394A455AAFD6A550BA1777C8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "1FDE323A807059444858FBA28535147BDBF7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            3
                        ]
                    }
                },
                "indent": 2,
                "uid": "7A0B66233D0D574C5A6823F816F877ACE499"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "7A17A64F2E3A114F191AF178ED2640350AAB",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "9A4F01048CA5E24BBB3A40C7D98D3BADA9AB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "62C1BFEF136926414F8865A427838A7BB209",
                        "defaultText": "조용히 하라! 내 직감은 지금까지 틀린 적이 없느니... 으으윽..."
                    },
                    "position": 0,
                    "characterId": "7A17A64F2E3A114F191AF178ED2640350AAB",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "C04B5C611E7D06457F387E189FDDC84FD146",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "C6F576C96BEDB44E2858AEA877C43BB6B5F1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            2
                        ]
                    }
                },
                "indent": 2,
                "uid": "735295E45A5B7548851984D5D8CD81162808"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "E45391CD620FC44ABB48BDA89D13E5589DDA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B69D95984886A6435349CEA7CAE51B1E3DBB",
                        "defaultText": "이번엔 또 왜 그래? 혹시-- 으악...!!"
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "5943E2F307E396425C7869A6EBECBAFBB76D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "A684DE4930030746FF885AD66E14AA97063E"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "HEARTBEAT.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 1,
                    "loop": 1,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "9ED257381E43934D595A723061F212B2E8A2",
                "expanded": false
            },
            {
                "id": "gs.ScreenEffect",
                "params": {
                    "type": 0,
                    "pixelate": {
                        "enabled": false,
                        "size": {
                            "width": 10,
                            "height": 10
                        }
                    },
                    "blur": {
                        "enabled": false,
                        "power": 0
                    },
                    "wobble": {
                        "power": 15,
                        "speed": 15,
                        "orientation": 2
                    },
                    "duration": 30,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "zOrder": 800,
                    "fieldFlags": {
                        "zOrder": 0,
                        "easing.type": 1
                    }
                },
                "indent": 2,
                "uid": "116FF7214FAEF844FB2BDE60B5E41993B193",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "7A17A64F2E3A114F191AF178ED2640350AAB",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "C82ABA178A5CB64A272A8098BD8453AB520A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 2,
                "uid": "0FB6FD016554C644D4588201CD914F712EE2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "B92B1B523A28964D8919AFD43216F51FD165"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            2
                        ]
                    }
                },
                "indent": 2,
                "uid": "CAC7D0833E65704FEC9833641A6E623A64B3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "A5CD3C3B352843410338B9731325131A7FD8"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "E7F14CC87EA65345C6583881790FB1BC1991"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "3CF1487C6407884D167A6988E859525A5466"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3E7DAD708384044C1918A29336CCB4FAC58F",
                        "defaultText": "머리가... 욱신거려... 너희도 느껴져?"
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "91D2A0A756F3E6436559B251AC4F75E0E210",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "50C85B090585A0442258EFB165AC715EDFB6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "D8AF31931EE2E340F83871B6C0A8341CD24A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9C5859958725444FE808FBD6B29A0F004B75",
                        "defaultText": "어떻게 못 느끼겠어!? 끔찍하게 아파..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "161BAF079B9764462F3A51E2881A8197DBF5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "37D17B28200D834FE828DD761526933B5907"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "E2CD028222151747F57A91824C6315A3301C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DA94567B26F410462D792E59029FEC137C44",
                        "defaultText": "기억상실이 일어났을 때와 똑같아...\n하지만 이번에는... 모두가 영향을 받는 것 같아..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "9F82E70A5F03B54FC31A200513F89E4EA874",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "A400EC012CDF17448C7BD6943D737F0C92C0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "885012035EDE954180093DC668CA92AAAF03"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 2,
                "uid": "8381520845F2C34F244A6F31109F8C7062FD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "657D8BD06780364A913B067916F92F232BFF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            2
                        ]
                    }
                },
                "indent": 2,
                "uid": "96A63C298ACE294A144933F74BB48E669FE7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "294663C55130234B432A48672194606855E7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F037C49503D0C74EA0384377CBF76C819EE1",
                        "defaultText": "이봐, 이거 무슨 장난이야? 이게 무슨 뜻인지 알지?"
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "1892D7CB0FB5F44EF039E8475B746BE90B31",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "F6C7957355ED05450D78CC44C838BDB6556B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "6D2F8E5272DA734D784ACB02F21CDA04EE09"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5C6108554F8C944E4A2B3B489B464FDA442B",
                        "defaultText": "우리 모두... 저주받은 건가? 하지만 어떻게!?\n마나크레스트가 지켜 줘야 하는 것 아니야?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "98ED3D8C1E099946346B33740F01E695BFC6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "79256CA18CBE2842AF4AF6B279D94EC4DC51"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "0273587D7262E641CC491D804399F596092F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "8C9B23118FA68143F23BB395DE5E1CB2B2A2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4710D13F3222C446D43B7AA2C0D878B69C42",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "6E59B94B2D71714F0A7B3FE47758DC2940BC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A114EA3718C64748C568AAB4D1772CD98624",
                        "defaultText": "히히히... 히히히."
                    },
                    "position": 0,
                    "characterId": "4710D13F3222C446D43B7AA2C0D878B69C42",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "74CD02599C86C049B0883D77FC08E0D1B148",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "E0FCCB2051BF244D8F8B38F3D1762453076B"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 40,
                    "blendMode": 0,
                    "zOrder": 4999,
                    "duration": 13.2,
                    "origin": 1,
                    "waitForCompletion": 1,
                    "positionType": 1,
                    "position": {
                        "x": 1586,
                        "y": 734,
                        "angle": 0,
                        "zoom": 0,
                        "horizontalFlip": false,
                        "data": {
                            "x": 364,
                            "y": 31,
                            "zoom": 0.3,
                            "angle": 0,
                            "horizontalFlip": false,
                            "width": 497.6,
                            "height": 480
                        },
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 0
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 0,
                        "movement": 2,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 0,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 0,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "doll.png",
                        "folderPath": "Graphics/Backgrounds/Tarmen",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 2,
                "uid": "A32A517D87AEF440FA4AB0500A327B874C75",
                "expanded": false
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2898AE7F45D5B843308B9A53CBD3AF528EB4",
                        "defaultText": "너희는... 도망치지... 못해..."
                    },
                    "position": 0,
                    "characterId": "4710D13F3222C446D43B7AA2C0D878B69C42",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "B71259C4231C154A0E489958216EDB31038D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "9D94E2B790D368458D8A9952088E48680427"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 2,
                "uid": "387E158525DBA84074786C68A2F2DF9E9CE9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CEC6983C7B952941C42A5303548A5FD98CE1",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Doll_line9.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "B6EC350946F6E2470E2839E52C462F3311DF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 2,
                "uid": "CFED26594B02564A9E08AE78766298510F30"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4710D13F3222C446D43B7AA2C0D878B69C42",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "CBEC8D8971656247127B5E87CFA158AB211F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9A4FF3DA37BD9742AE496833EFFFEB8F61A4",
                        "defaultText": "영원히 나와 함께 있어... 나와 놀아 줘..."
                    },
                    "position": 0,
                    "characterId": "4710D13F3222C446D43B7AA2C0D878B69C42",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "EF226E13970B33436D7A6C97E8CDE45D5452",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "86FF3DE13065F748FF2B289984A7D2964C31"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "2A609728508BD34302186E613749AB81139E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            4
                        ]
                    }
                },
                "indent": 2,
                "uid": "FDEDC70098794540297817C6B90997FECB6B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "DE8158F92AC4554A560B2F768C56548F2DAA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "25D672272571D64B5769CC96B8DE805E05C9",
                        "defaultText": "쳇!!"
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "C4D6BC814CF72341732A14C872A22F7CA9C6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "7E08423B8C5A104EBB6BE2A1D2BF33DDAC9D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            3
                        ]
                    }
                },
                "indent": 2,
                "uid": "B98695796059B643A56B98E308C03D59E6FB"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 2,
                "uid": "A47481B20454954709995434B57180261C38"
            },
            {
                "id": "gs.StopSound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "HEARTBEAT.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "5805BDE5237F5843465BF0791B5CA939C1CE"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 2,
                "uid": "03D8AB441584D04B8C0A2F0468F9D848CA19"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Battle Animation sounds/Enemy attacks sounds",
                        "name": "GEN_FIRE.ogg",
                        "volume": 100,
                        "playbackRate": 129
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "4F34329244E0284A2E885303C0BE804EB4D0"
            },
            {
                "id": "gs.FlashPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 40,
                    "color": {
                        "red": 201,
                        "green": 28,
                        "blue": 44,
                        "alpha": 255
                    },
                    "duration": 21,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "C5E499C03C10C8430528CA5514639746592D"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 3,
                    "duration": 10.799999999999999,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 2,
                "uid": "B2C87D4F4B59C842717B2663DC27B432620C"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 4,
                    "duration": 10.799999999999999,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 2,
                "uid": "FB19782C22BE474DA57B66B13E7266A57D64"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 5,
                    "duration": 10.799999999999999,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 2,
                "uid": "5613837C5247C34D315907540AC591E3603C"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 6,
                    "duration": 10.799999999999999,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 2,
                "uid": "AFEA5E114E66A54112697AB8C1888B0D755F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "577D4C6E2D68654FF2883C59BF0F9D33436D",
                    "parameters": {
                        "values": [
                            0,
                            4,
                            220,
                            1
                        ]
                    }
                },
                "indent": 2,
                "uid": "864EAA0D294527488448088693A9AF0B36FA"
            },
            {
                "id": "gs.ScreenEffect",
                "params": {
                    "type": 0,
                    "pixelate": {
                        "enabled": false,
                        "size": {
                            "width": 10,
                            "height": 10
                        }
                    },
                    "blur": {
                        "enabled": false,
                        "power": 0
                    },
                    "wobble": {
                        "power": 0,
                        "speed": 0,
                        "orientation": 2
                    },
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "zOrder": 800,
                    "fieldFlags": {
                        "zOrder": 0,
                        "easing.type": 1
                    }
                },
                "indent": 2,
                "uid": "05B260909EC07549A8386005D27B9550AD99",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 2,
                "uid": "90FCDF1B6361A240FA08B115AB04BD74B6A0"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 40,
                    "duration": 13.2,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 0,
                        "movement": 2,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 0
                    }
                },
                "indent": 2,
                "uid": "D5D4212C11652846A87878D2F5071484CBA5",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "8CE128BD3DB5844E808A8999E7C98C9D598F"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 108
                },
                "indent": 2,
                "uid": "31488ED330FEF2453019C371F84D7EE9E8C2"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Finn destroys the doll with a fire swing"
                },
                "indent": 2,
                "uid": "BC131E568FF15644754ABAE1A6762DE95A95",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "754054E63F0AC64B2269672220AFD2B97E64"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "41B4935A2C167042F1197DF4CA409538F3FB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "07DD43707FD19641D5295472CA6F86D7FA79"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0D96FBFC8937764CF00B1C76B7D47A6B1199",
                        "defaultText": "다들 괜찮아...?"
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "A557C908860D24499F0871F286542FDEEADC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "6FAE89CC7900914B766B70D2342166E83464"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "2ABEF0839A58114E604975246AA82717DC5B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "300CC68837702148F128C566ED3F16668CC5",
                        "defaultText": "난... 나아진 것 같아."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "DAA65CFC55AE7543437841D30B7D32251BA7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "41944D011A6BC2433B9A755683898005C472"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F6E5B5AA395875496C3A8E86F4D2F9D50E42",
                        "defaultText": "하지만 인형들을 불태웠잖아--"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "2192E6A61159D84A0348D687258324A76F12",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "9532EE972864D343B5095F66AD4828415969"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "A6F443D716DE644A021883441F2AF71A9FA8"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "7057FE0F81B8604C7C3A6DC78F6028DBF588"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 2,
                "uid": "657D6A774AC2D8488A8A72C78D8E4A98EA21"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6EE535D123E71440A359FAE2A05DE59F4E0C",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Tacitus",
                        "name": "E3-Tacitus_line11_1b.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "E658924C4D62F040D23A1BC185EE2E441F2B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 2,
                "uid": "FCA452331158D24C2F3AD241DC4A21183B75"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "8A022433614B4242C64ABBE11A588D95C0DD",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "91946E8A611C234A546910565116F078E93A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2C34295F113244460C5B1833578BD5A016ED",
                        "defaultText": "저 불쾌한 불꽃... 전에 한 번 본 적이 있어."
                    },
                    "position": 0,
                    "characterId": "8A022433614B4242C64ABBE11A588D95C0DD",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "2B1982329F83F24ECD180389CD9F8F565015",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "7AB0CFE45078D044437B72F5223C3C172AE1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "53146D44208E71434E6B344701130F040A5A",
                        "defaultText": "그 부대 사람들의 이름은 절대 잊을 수 없어...\n{SP:2}{C:1}로이스{C:0}, 너야?"
                    },
                    "position": 0,
                    "characterId": "8A022433614B4242C64ABBE11A588D95C0DD",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "B982364E71C40548505B591091A4EE15D303",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "F49A9D9917C90442AC491B17C1FDEA3A3124"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            4
                        ]
                    }
                },
                "indent": 2,
                "uid": "3E5009D6395E354CE478DE169994348AC26A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "08C9FFAE94155342FE0891C6C91478CC66D6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0910F4368896054B1E19675803E3E67AB08E",
                        "defaultText": "이번에는 누구냐? 모습을 보여라!"
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "B3F9F2DD493E934B559955918D028EBE2B10",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "880638BB2CA032467638B98099E82BF34F0B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "8A022433614B4242C64ABBE11A588D95C0DD",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "7529E1156E7D1944636985146CDA923CA1F0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C600A04972AA8348DB698019A45ED2CDD46C",
                        "defaultText": "아니... 네가 아니군. 넌 로이스 발리노르가 아니야."
                    },
                    "position": 0,
                    "characterId": "8A022433614B4242C64ABBE11A588D95C0DD",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "07A429DA5762A84F772919D7B945E656CC41",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "8233EB752083C64BB63A932476D792520928"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 40,
                    "blendMode": 0,
                    "zOrder": 4999,
                    "duration": 13.2,
                    "origin": 1,
                    "waitForCompletion": 1,
                    "positionType": 1,
                    "position": {
                        "x": 1586,
                        "y": 734,
                        "angle": 0,
                        "zoom": 0,
                        "horizontalFlip": false,
                        "data": {
                            "x": 364,
                            "y": 31,
                            "zoom": 0.3,
                            "angle": 0,
                            "horizontalFlip": false,
                            "width": 497.6,
                            "height": 480
                        },
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 0
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 0,
                        "movement": 2,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 0,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 0,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "doll.png",
                        "folderPath": "Graphics/Backgrounds/Tarmen",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 2,
                "uid": "4D39A5DA81344647802879A51A39386A15A5",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4710D13F3222C446D43B7AA2C0D878B69C42",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "32F03A364CF6154C4B1AF6C9A32AC893DC85"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5E84EA3B6A8BA747ED1B746562AD8FDFEC87",
                        "defaultText": "넌 로이스가 아니야! 로이스가 아니라고!"
                    },
                    "position": 0,
                    "characterId": "4710D13F3222C446D43B7AA2C0D878B69C42",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "5AB16FC64A108841168BEB94D84F9EDB2A96",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "004C856190053347B128611654730A8ACBC7"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "483ACA0F08AA454CD159020337968A6DEE82",
                        "defaultText": "로이스?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "7B4C5C1B64D74541015AE7A8944DA68E341F",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Finn"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "4394A9202AB6B94FCD4AEC99C41AD7792C3C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "4E4F728229F0874A4A1BB34392B5CA6EED9A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B41B88DF3BDEF146A019E0B5BAB01793369B",
                        "defaultText": "뭐라고!?"
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "4454FA922399F54793394B1677EBF1EF7F80",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 2,
                "uid": "17126E558B1060494C891FE498315BC47650"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 40,
                    "duration": 13.2,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 0,
                        "movement": 2,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 0
                    }
                },
                "indent": 2,
                "uid": "A4F3B85670FC814CD9781556202F4A9F6A53",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "60C6CFA327E9584CD18BC884840CAB163F88"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 90
                },
                "indent": 2,
                "uid": "AB2398F46BBC16481A8A1497475E13A3E6CD"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Battle Animation sounds/Spell sounds",
                        "name": "Hell_Teleport.ogg",
                        "volume": 100,
                        "playbackRate": 80
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "1ACE5B5296BB1840FD8BBA744412B9414B33"
            },
            {
                "id": "gs.PlayPictureAnimation",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 10,
                    "viewport": {
                        "type": "ui"
                    },
                    "animationId": "B88FE5124ED3B24C7A9B38014F3D16891148",
                    "predefinedPositionId": 0,
                    "blendMode": 2,
                    "zOrder": 702,
                    "duration": 60,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 2,
                    "position": {
                        "x": 590,
                        "y": 340,
                        "angle": 0,
                        "zoom": 1,
                        "horizontalFlip": false,
                        "data": {
                            "x": 281,
                            "y": 168,
                            "zoom": 1.5,
                            "angle": 0,
                            "horizontalFlip": false,
                            "width": 646.4000000000001,
                            "height": 640
                        },
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 0
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 0,
                        "zOrder": 0,
                        "blendMode": 0,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "40EB442A60B981438299A0787345BA117A1A",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "577D4C6E2D68654FF2883C59BF0F9D33436D",
                    "parameters": {
                        "values": [
                            0,
                            6,
                            350,
                            1
                        ]
                    }
                },
                "indent": 2,
                "uid": "6B02609E6733084C1629E9F986273983E1AD"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 2,
                "uid": "90BAF08A5F353140792938758F1AA4032CB1"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "a portal opens"
                },
                "indent": 2,
                "uid": "F35545C88422684B8E796BE9422D7D18EF9D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "85F9C72D88984748A368D96213C8C348F20A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 2,
                "uid": "A8716B603D9C8648C87A79C8F5DB0A6B9996"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B3A1B4054C85D248BB6B5BA4F8A47CAD05A1",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Tacitus",
                        "name": "E3-Tacitus_line2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "995F99BE3E85B940974B3B63B67047A0B0C4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 2,
                "uid": "7802E39C10309347296B4C086EAFB7C42ADD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "8A022433614B4242C64ABBE11A588D95C0DD",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "5B38BC4D9166824F67990F32D4A2841AAD87"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CEFF699F46DBE14D0F4AC9016786A64F765A",
                        "defaultText": "위대한 마왕님의 명령으로 너희에게 저주를 내렸다.\n마나크레스트가 진행을 늦추지만 영원히 막지는 못해."
                    },
                    "position": 0,
                    "characterId": "8A022433614B4242C64ABBE11A588D95C0DD",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "22AEF4082F4A26463818D4A7DD5612066067",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "883C55516009654A58799A0745256F5D56CA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4CC30BFC1EA5354708295987FCDEE06AE3A6",
                        "defaultText": "그 집에서 쥐처럼 죽든지, 나와 싸우러 오든지 해라. 결과는 달라지지 않아."
                    },
                    "position": 0,
                    "characterId": "8A022433614B4242C64ABBE11A588D95C0DD",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "A8FB9C2180AE9347C19A7F94F853B0873C4A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "33B82B5679684243D9682274BC0E5F1D9578"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 40,
                    "blendMode": 0,
                    "zOrder": 4999,
                    "duration": 13.2,
                    "origin": 1,
                    "waitForCompletion": 1,
                    "positionType": 1,
                    "position": {
                        "x": 1586,
                        "y": 734,
                        "angle": 0,
                        "zoom": 0,
                        "horizontalFlip": false,
                        "data": {
                            "x": 364,
                            "y": 31,
                            "zoom": 0.3,
                            "angle": 0,
                            "horizontalFlip": false,
                            "width": 497.6,
                            "height": 480
                        },
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 0
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 0,
                        "movement": 2,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 0,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 0,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "doll.png",
                        "folderPath": "Graphics/Backgrounds/Tarmen",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 2,
                "uid": "18BE657A6BBB754ADF587A39A74665235B2B",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4710D13F3222C446D43B7AA2C0D878B69C42",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "8B471FCB9867184BA0895BA18E418051E221"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "061AE06B36BB934212384F01575B91382701",
                        "defaultText": "저들은 가망이 없어요, 아빠! 누구도 우리의 인연을 끊을 수 없어요!"
                    },
                    "position": 0,
                    "characterId": "4710D13F3222C446D43B7AA2C0D878B69C42",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "DE3BE68E121DA546429B9B46BE906E3F1465",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "1DFC3F5A2769B54E429A6171578B1B3A97C4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "DDA6B8AA8D9C304EE768CC37408BA6A991BF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "722E8BA06CE53645194BA9685FA4E286ADCC",
                        "defaultText": "벽에 불길한 {SP:2}{C:1}차원문{C:0}이 생겼고, 저 인형은 아직 살아 있어!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "8641CCF73BA261481569BD96366F37D3B6E1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "443DE78B4A425747465B4FE8B5F7252439A3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "8A022433614B4242C64ABBE11A588D95C0DD",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "31F1B6F05E9F364CFA098F74C5A6E9CF50A8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "79AF9E60610A7048F92AA570BB6C07EB6716",
                        "defaultText": "알고 있다, 다미아나. 이 교단의 개들이\n고통스러워하는 얼굴을 직접 보고 싶을 뿐이야."
                    },
                    "position": 0,
                    "characterId": "8A022433614B4242C64ABBE11A588D95C0DD",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "1719133080EEC34C8329DD8164BDC439E4DC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "1AA252467270064A9C49913648366ACBE91F"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 40,
                    "duration": 13.2,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 0,
                        "movement": 2,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 0
                    }
                },
                "indent": 2,
                "uid": "BEB4BB683D41474BD0390EE273B0299F24F4",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "0B39F5B55DFD104DB83B8463CE318425964B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "A4FA455D576E494CAC38FCC93796891D6EFE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "44D96CA23CB07946E918C5F3DCCD6B58C511",
                        "defaultText": "어떻게 하지?"
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "ECA8611A39647949B7784A113E0F195EBFB4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "6F0EB85175D622465B090A785882211671C9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "C645ECEA2D7C8641CE3AC7553AD2FD4340E2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            4
                        ]
                    }
                },
                "indent": 2,
                "uid": "FDC776DD6215D54EEE5A639423C04585F68C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "1853A67013DFE3453238E5B5CCC57A9CA0CA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2D1A13F04710C840FA488BB75DAEF49D57AE",
                        "defaultText": "물어볼 필요가 있어? 여기 있으면 악마로 변할 거야."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "751CBB2573037441A998C4167E0A8BCD2D66",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "C68C45278261404DC088B256DA424C51A724"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "EA8A9E1620A382475B3A52462D1F0B2CC341"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 2,
                "uid": "AE6767B46AD9334D7968D7F6272B3474E348"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "B281E28A8363314DF61B54072C46FF97BD4F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            4
                        ]
                    }
                },
                "indent": 2,
                "uid": "E44E25F358F29445478A91050580C872EDA3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "49D81B2E76C7684ECC88466387A0609A5D5C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B20CA96B1A95A44B2F1A1E1915D4932B9B32",
                        "defaultText": "동의해. 차원문 너머에서 해결책을 찾을지는 몰라도 여기서 썩는 것보다는 나아."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "2863C7DC71BA314EE36A9FC57E0BF8472B14",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "7F40515F5F593641264B9737E7E523A213D2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "9A962719121D424FFA9BBE4336DEE0C1C9D4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7D62A5F67722554FE39AE160AA22A3254310",
                        "defaultText": "...이 일이 끝나면 제대로 설명해 줘, \"로이스\"."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "1C3AB45F192E8341A088A3C3BDFAD1F539B2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "CE80F60027B53549787AAAA01E4D526DA69C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "FDB2762C0280654E279B26B523F24CC16573"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "5B52B9560337F24F9768D36266A786D759F3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "ACFEE9133D77E84E802AF617946491BE95AC",
                        "defaultText": "그래... 물론이지."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "0FE7541F2FAED4412A3A48967FE7F76CEDB6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "C30F282F317B0644C5291C8005A244DD87C5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "C91E7FBA2866C249EF0AD308172329ED3458"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3453DF6123B67440E40B030824BD420DBBF8",
                        "defaultText": "저 차원문 너머에는 극도로 위험한 무언가가 있어. 느껴져!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "1B4D91773B59D449676A67210163BEC0E75B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "386889853C759846E3893080A82F5AAE0DE1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "98A5F19A4EDB6544698A04E854E324178A18",
                        "defaultText": "차, 차원문도 불안정해 보여... 정말 통과해도 안전할까?\n앞에 무엇이 있든 철저히 준비해야 해."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "9178FA3E2191A8431E6AD8C4BE36B0087E70",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 2,
                "uid": "F2B3706C09D49240499B2266611CA173BC85"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "0F1644673E1174431C38BBA4CB7E12BFFFEB"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 2,
                "uid": "8292EBDD0AD03848C66A061251EB4CC7F98B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1BD8725E0D9E344CE22BA0F8C56A41689C28",
                    "parameters": {
                        "values": [
                            "Illusionary Wall"
                        ]
                    }
                },
                "indent": 2,
                "uid": "68C5CEED1216A44F212BAD562A517ADB80CD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D1D322CB2E2602402C88D2428C77C01E35E6",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 2,
                "uid": "32D6EB789086584D655B1B33258579BEF6DC"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "piedino",
                    "target": "activeScene"
                },
                "indent": 2,
                "uid": "CE1FD2CC405B7747429A45B6EF5C237C540F"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Pause allowed bc IN EXPLORATION / CHOICE?",
                        "index": 156,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "35C89852601DA442374B6240FD3EE2FCBA78"
            },
            {
                "id": "gs.Idle",
                "params": {},
                "indent": 0,
                "uid": "EE1104A71D60554A714B7472092D73BE7465"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D7547A96549313459078E4251677136450B5",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "24E851F684D5F743BC78F0298D6DD8C38D3D"
            }
        ],
        "livePreviewDisabled": false,
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "localizableStrings": {
            "B756A1F325B9D74EF94A3EE6943B33EDB05B": {
                "t": "This is't! Mine own instincts bid me this is the right lodging!",
                "d": {
                    "cid": "7A17A64F2E3A114F191AF178ED2640350AAB",
                    "eid": "21D0C1868958614E388A838482EA30F5DA4A"
                }
            },
            "D51097961B1D9645010B1691CE0F536583A7": {
                "t": "Another abandoned house?",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "5BC904D40E54D247E939DC24C6730CDB981C"
                }
            },
            "22FF242F21127245C84A92A4D5B36872AA4F": {
                "t": "Something feels a bit off here... Those dolls are ominous.",
                "d": {
                    "cid": 0,
                    "eid": "047DCB4671B44647BA39C356CA5240E2A3C8"
                }
            },
            "7333BC110AA614403F2BE591EAD10281F06F": {
                "t": "???",
                "d": {
                    "eid": "13981EB6220B0140A75A1DA4CD61BA87871B"
                }
            },
            "1FC6157E8091F24D577B43039553FF79BCFB": {
                "t": "Huh... I can't disagree with that one!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "672A058A61BBE847A519D0221341DFF5690B"
                }
            },
            "7C024B6D24FC184A1478A23581DCCAC628AD": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "16EC3D4E622AD94C1E1851F170D27688B0F7"
                }
            },
            "1E5E16420B927848ED8858801B8D7DA773DE": {
                "t": "You've come, at last. Nobody ever visits me... they're all afraid.",
                "d": {
                    "cid": "4710D13F3222C446D43B7AA2C0D878B69C42",
                    "eid": "1E7592357314214A3938A9D11289FE11A84F"
                }
            },
            "6C5239031BB60041FE9866F1463E666B0A73": {
                "t": "The dolls are talking!?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "DDEBF5A023AA424F463A87C9DB9265F04FE6"
                }
            },
            "EBF4D9AB88533746BF682BB6F99514CF8BA0": {
                "t": "Will you keep me company? Don't leave me alone too...",
                "d": {
                    "cid": "4710D13F3222C446D43B7AA2C0D878B69C42",
                    "eid": "E7D83A817A49874E7C791FE2A6B5646ED8FB"
                }
            },
            "6AFA24BA666E8744606A593448087DD71CD6": {
                "t": "They... could be possessed by the soul of a little girl.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "B49EFF1B9FE915435F0B3902C45D5A5372AF"
                }
            },
            "60BD47A52877C346A428FE828666567AF6E9": {
                "t": "Is that even possible? Although I'm not even surprised anymore.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "BC2C010A413E76438D3BAB68D1FA989D37BB"
                }
            },
            "7ECDCBB81653844FC6293701C457A745A342": {
                "t": "I'm not sure, but this reality lies before us. At least this girl doesn't seem to have bad intentions.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "0467DEDD3A0237468118C587045AABEF700E"
                }
            },
            "6BBC8ECD81A9F44DE839CDE9184BDEDF9E4C": {
                "t": "Perhaps she even knows something that could help us in our quest.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "A61445D44EAAD8462B19970490D3E9BA738C"
                }
            },
            "86CC39EF8815B74073099FF61B50172D18A8": {
                "t": "Hey Lepto, are you sure the Solaris is here?",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "C0160B8A7BB73447DB1B8C81F60D0EC838D1"
                }
            },
            "80EB81E07EF7074D3C898E0102F02177605C": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "E72B6F8913C56642DD58B362F9115BFA1BE1"
                }
            },
            "13EC7FF589E60146B828DA16668B308381AB": {
                "t": "Mine own legendary thief instinct is not wrong, we just needeth to searcheth!",
                "d": {
                    "cid": "7A17A64F2E3A114F191AF178ED2640350AAB",
                    "eid": "E1DBD5A136471040C248B4890B6650680C8C"
                }
            },
            "E002FD774C32D24CA8794D0762F5C3C82A3C": {
                "t": "Well, then...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "1FA7B4F26837F247CD8BF276BF8039FBF1D1"
                }
            },
            "1495FE3124C26446C1492BF108398CC1943E": {
                "t": "",
                "d": {
                    "eid": "850B083F290DB440015BEB03400186045A43"
                }
            },
            "A74B615350F2744F9D686AF4FE6D4C607AD6": {
                "t": "E4C0E83C3047A141A5497F27BB33CC454785",
                "d": {
                    "eid": "B71C7EA415C1414DA4687248D04391D46DAF"
                }
            },
            "008CC6641F8D164EB13B956486C962587649": {
                "t": "What a sad story.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "8158DD745753E445817BC4775F2BF5DF5C50"
                }
            },
            "71B67F503757B7460E4A7227824DD50E5A29": {
                "t": "Indeed. Still no trace of the Solaris, though.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "BCD5946583AAB14F6C6A49F6D5FBB094B0CF"
                }
            },
            "5871865B2F01D640B3489127578CB743C8E4": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "763FFB3C702682466D88E647B53672EADB62"
                }
            },
            "F794C3F20C86574DE72A437143E720528B10": {
                "t": "I und'rstand not... T'was supposed to be h're.",
                "d": {
                    "cid": "7A17A64F2E3A114F191AF178ED2640350AAB",
                    "eid": "6107499246162346E75B50E2082FB87CDD94"
                }
            },
            "53C60EA34D1EC142C22B2E427478968A32F1": {
                "t": "Isn't it about time you tell your family that you're more suited to be a farmer rather than a thief?",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "366E1E809060394A455AAFD6A550BA1777C8"
                }
            },
            "62C1BFEF136926414F8865A427838A7BB209": {
                "t": "Aye, quieten down! Mine own intuition hast nev'r been wrong so far... Nnnngh...",
                "d": {
                    "cid": "7A17A64F2E3A114F191AF178ED2640350AAB",
                    "eid": "C04B5C611E7D06457F387E189FDDC84FD146"
                }
            },
            "B69D95984886A6435349CEA7CAE51B1E3DBB": {
                "t": "What's wrong now? Are you trying to-- Argh...!!",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "5943E2F307E396425C7869A6EBECBAFBB76D"
                }
            },
            "3E7DAD708384044C1918A29336CCB4FAC58F": {
                "t": "This... pulsing pain in my head... Can you feel it too?",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "91D2A0A756F3E6436559B251AC4F75E0E210"
                }
            },
            "9C5859958725444FE808FBD6B29A0F004B75": {
                "t": "How could I not feel it!? It's terribly painful...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "161BAF079B9764462F3A51E2881A8197DBF5"
                }
            },
            "DA94567B26F410462D792E59029FEC137C44": {
                "t": "It's just like when I had my bout of amnesia... But this time... everyone seems affected...",
                "d": {
                    "cid": 0,
                    "eid": "9F82E70A5F03B54FC31A200513F89E4EA874"
                }
            },
            "F037C49503D0C74EA0384377CBF76C819EE1": {
                "t": "Hey, is this some kind of joke? You know what that means, right?",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "1892D7CB0FB5F44EF039E8475B746BE90B31"
                }
            },
            "5C6108554F8C944E4A2B3B489B464FDA442B": {
                "t": "Have we... all been cursed? But how!? And shouldn't the Manacrest protect us?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "98ED3D8C1E099946346B33740F01E695BFC6"
                }
            },
            "A114EA3718C64748C568AAB4D1772CD98624": {
                "t": "Hehehe... HEHEHE.",
                "d": {
                    "cid": "4710D13F3222C446D43B7AA2C0D878B69C42",
                    "eid": "74CD02599C86C049B0883D77FC08E0D1B148"
                }
            },
            "2898AE7F45D5B843308B9A53CBD3AF528EB4": {
                "t": "You will not... escape...",
                "d": {
                    "cid": "4710D13F3222C446D43B7AA2C0D878B69C42",
                    "eid": "B71259C4231C154A0E489958216EDB31038D"
                }
            },
            "CEC6983C7B952941C42A5303548A5FD98CE1": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "B6EC350946F6E2470E2839E52C462F3311DF"
                }
            },
            "9A4FF3DA37BD9742AE496833EFFFEB8F61A4": {
                "t": "Stay with me forever... Play with me...",
                "d": {
                    "cid": "4710D13F3222C446D43B7AA2C0D878B69C42",
                    "eid": "EF226E13970B33436D7A6C97E8CDE45D5452"
                }
            },
            "25D672272571D64B5769CC96B8DE805E05C9": {
                "t": "Tch!!",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "C4D6BC814CF72341732A14C872A22F7CA9C6"
                }
            },
            "0D96FBFC8937764CF00B1C76B7D47A6B1199": {
                "t": "Is everyone okay...?",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "A557C908860D24499F0871F286542FDEEADC"
                }
            },
            "300CC68837702148F128C566ED3F16668CC5": {
                "t": "I'm... better, I think.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "DAA65CFC55AE7543437841D30B7D32251BA7"
                }
            },
            "F6E5B5AA395875496C3A8E86F4D2F9D50E42": {
                "t": "But the dolls, you burnt them--",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "2192E6A61159D84A0348D687258324A76F12"
                }
            },
            "6EE535D123E71440A359FAE2A05DE59F4E0C": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "E658924C4D62F040D23A1BC185EE2E441F2B"
                }
            },
            "2C34295F113244460C5B1833578BD5A016ED": {
                "t": "Those obnoxious flames... I've encountered them once before.",
                "d": {
                    "cid": "8A022433614B4242C64ABBE11A588D95C0DD",
                    "eid": "2B1982329F83F24ECD180389CD9F8F565015"
                }
            },
            "53146D44208E71434E6B344701130F040A5A": {
                "t": "I could never forget the names of the people in that\nsquad... {SP:2}{C:1}Royce{C:0}, is that you?",
                "d": {
                    "cid": "8A022433614B4242C64ABBE11A588D95C0DD",
                    "eid": "B982364E71C40548505B591091A4EE15D303"
                }
            },
            "0910F4368896054B1E19675803E3E67AB08E": {
                "t": "Who is it now? Show yourself!",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "B3F9F2DD493E934B559955918D028EBE2B10"
                }
            },
            "C600A04972AA8348DB698019A45ED2CDD46C": {
                "t": "No... It's not you. You aren't Royce Valinor.",
                "d": {
                    "cid": "8A022433614B4242C64ABBE11A588D95C0DD",
                    "eid": "07A429DA5762A84F772919D7B945E656CC41"
                }
            },
            "5E84EA3B6A8BA747ED1B746562AD8FDFEC87": {
                "t": "You're not Royce! You're not Royce!",
                "d": {
                    "cid": "4710D13F3222C446D43B7AA2C0D878B69C42",
                    "eid": "5AB16FC64A108841168BEB94D84F9EDB2A96"
                }
            },
            "483ACA0F08AA454CD159020337968A6DEE82": {
                "t": "Royce?",
                "d": {
                    "eid": "7B4C5C1B64D74541015AE7A8944DA68E341F"
                }
            },
            "B41B88DF3BDEF146A019E0B5BAB01793369B": {
                "t": "What!?",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "4454FA922399F54793394B1677EBF1EF7F80"
                }
            },
            "B3A1B4054C85D248BB6B5BA4F8A47CAD05A1": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "995F99BE3E85B940974B3B63B67047A0B0C4"
                }
            },
            "CEFF699F46DBE14D0F4AC9016786A64F765A": {
                "t": "By order of the supreme Demon King, I've placed my curse upon you. That Manacrest is slowing the process, but it won't last forever.",
                "d": {
                    "cid": "8A022433614B4242C64ABBE11A588D95C0DD",
                    "eid": "22AEF4082F4A26463818D4A7DD5612066067"
                }
            },
            "4CC30BFC1EA5354708295987FCDEE06AE3A6": {
                "t": "You can die like rats in that house, or try to face me in combat. The result won't change.",
                "d": {
                    "cid": "8A022433614B4242C64ABBE11A588D95C0DD",
                    "eid": "A8FB9C2180AE9347C19A7F94F853B0873C4A"
                }
            },
            "061AE06B36BB934212384F01575B91382701": {
                "t": "They don't stand a chance, Dad! No one can break our bond!",
                "d": {
                    "cid": "4710D13F3222C446D43B7AA2C0D878B69C42",
                    "eid": "DE3BE68E121DA546429B9B46BE906E3F1465"
                }
            },
            "722E8BA06CE53645194BA9685FA4E286ADCC": {
                "t": "There's an ominous {SP:2}{C:1}portal{C:0} on the wall, and that doll is still alive!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "8641CCF73BA261481569BD96366F37D3B6E1"
                }
            },
            "79AF9E60610A7048F92AA570BB6C07EB6716": {
                "t": "I know, Damiana. I just want to see the suffering faces of these Church dogs with my own eyes.",
                "d": {
                    "cid": "8A022433614B4242C64ABBE11A588D95C0DD",
                    "eid": "1719133080EEC34C8329DD8164BDC439E4DC"
                }
            },
            "44D96CA23CB07946E918C5F3DCCD6B58C511": {
                "t": "What do we do?",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "ECA8611A39647949B7784A113E0F195EBFB4"
                }
            },
            "2D1A13F04710C840FA488BB75DAEF49D57AE": {
                "t": "Is there any need to ask? If we stay here, we'll turn into demons.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "751CBB2573037441A998C4167E0A8BCD2D66"
                }
            },
            "B20CA96B1A95A44B2F1A1E1915D4932B9B32": {
                "t": "I second that. We're not sure we'll find a solution beyond that portal, but it's still better than staying here and rot.",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "2863C7DC71BA314EE36A9FC57E0BF8472B14"
                }
            },
            "7D62A5F67722554FE39AE160AA22A3254310": {
                "t": "... I hope you'll explain yourself once we're done, \"Royce\".",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "1C3AB45F192E8341A088A3C3BDFAD1F539B2"
                }
            },
            "ACFEE9133D77E84E802AF617946491BE95AC": {
                "t": "Yes... Of course.",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "0FE7541F2FAED4412A3A48967FE7F76CEDB6"
                }
            },
            "3453DF6123B67440E40B030824BD420DBBF8": {
                "t": "Whatever lies beyond that portal is extremely dangerous, I can feel it!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "1B4D91773B59D449676A67210163BEC0E75B"
                }
            },
            "98A5F19A4EDB6544698A04E854E324178A18": {
                "t": "I-It also looks unstable... Is it really safe to traverse it? We need to make sure we are well prepared for what lies ahead.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "9178FA3E2191A8431E6AD8C4BE36B0087E70"
                }
            },
            "7934799D262A8440AB6803E1AF7619739651": {
                "t": "Illusionary Wall",
                "d": {
                    "eid": "F843D21C4E30A54A755BDCC2F77700F72382"
                }
            }
        },
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "stringVariables": [
            {
                "name": "name",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "listVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}