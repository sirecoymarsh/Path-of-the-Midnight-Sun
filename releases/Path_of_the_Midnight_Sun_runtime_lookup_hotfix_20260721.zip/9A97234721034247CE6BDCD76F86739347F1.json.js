GS.dataCache['9A97234721034247CE6BDCD76F86739347F1'] = {
    "uid": "9A97234721034247CE6BDCD76F86739347F1",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C5 (event) Menmus post fight",
        "type": "vn.scene",
        "parentId": "29920A5794487547901B0992ADE09E42037D",
        "chapterUid": "27B6E8FB2921364C12682182E915B49DA958",
        "order": 9,
        "localizableStrings": {
            "6B39D3FE505F7341EB189569E3873544AE30": {
                "t": "What's wrong?{W:300} It seems like you're still holding back.",
                "d": {
                    "cid": "B29C753D58E5974A8B3A68575D84136FE572",
                    "eid": "2CEA95BD8F8E15486F4B0D32E51B915A77F6"
                }
            },
            "A621F4455DB3F4477F39BC4170D47DC06B13": {
                "t": "I...{W:300} can't do this.",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "A7C6DD256920A9442C0AC4E5B97659AF0A70"
                }
            },
            "B1F0BEB94F186748396B09C8FAB8CFED7E66": {
                "t": "We grew, we trained together.{W:300} I know your strength better than anyone.",
                "d": {
                    "cid": "B29C753D58E5974A8B3A68575D84136FE572",
                    "eid": "5D5FB75021FE964E8C0B4C23BEA635E715B0"
                }
            },
            "0F6655EF2532F6475C694EF37D197ACB04F8": {
                "t": "What?",
                "d": {
                    "cid": "B29C753D58E5974A8B3A68575D84136FE572",
                    "eid": "4D6410FB65134846FD89697432AD06423B53"
                }
            },
            "4A6B76065B10864E7979B4770FF222B3E21A": {
                "t": "Is fighting you the right thing to do?{W:300} It doesn't matter how long I keep thinking about it...",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "429FBEDA1AD354411B9A85B1C835C22FC1CF"
                }
            },
            "4F1E5FEC24F034418A784D91178452204227": {
                "t": "I still feel that betraying the queen would be wrong, absurd!",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "681670881245D648D51A2D69BA6C5C094317"
                }
            },
            "DA7B2ED72D704541884AAAC42C0A87DADFC1": {
                "t": "And yet...{W:300} Vassal, if you're telling the truth, how much pain do you carry inside?",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "1A46D9362E00D14DA819BB369B73296485CF"
                }
            },
            "C139431C2BB7D2465D09ED25DA0ECF86C234": {
                "t": "Look at us.{W:300} A whole army. Fighting for something we believe in.",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "5E7856376084E2457338DAE346020E199DF6"
                }
            },
            "F43C2C6E6D1DF244D81ADD51D8604946549C": {
                "t": "And look at you.{W:300} Alone.{W:300} Abandoned by the ones you used to love.",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "CD4CBF2867BC254E54289226AE5899BA8240"
                }
            },
            "DE8E8B177AB178465B28D7C6E64A9F18A05E": {
                "t": "... ... ...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "928668059916E347B7882FE872F3D52EA92E"
                }
            },
            "DC13019F7400A54C7319BFA043E116E6D199": {
                "t": "Maybe I'm overthinking as usual.{W:300} Or maybe my mind's being controlled.",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "9D5253065043C14CD45BBF75FC0F347FED41"
                }
            },
            "869310BF5BA146420B392FE8DCBDF5C48CCC": {
                "t": "But now, looking into your eyes,{W:300} I don't see the terrible Demon King.",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "B83E6C5D7C030740C5481EA4B9981BED0CD0"
                }
            },
            "67C0E4D2170DF946BE9B2370BF958445AFE9": {
                "t": "I can only see our beloved Vassal,{W:300} the very same who always cared about us.",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "C548D45C07FCB44B166A79F756F92E5230F8"
                }
            },
            "C31741044968E047C91B1B99D8355000C0D4": {
                "t": "Sniff...{W:300} Captain Menmus...{W:300} You're wrong, I...{W:300} I'm the Demon King...",
                "d": {
                    "cid": "B29C753D58E5974A8B3A68575D84136FE572",
                    "eid": "57D8435145F9184A4E892DB4E5B60516A2FA"
                }
            },
            "C0D9BBE16C26A6415C8BDFB1D26372417C86": {
                "t": "To my eyes, there are no doubts those tears are yours,{W:300} not the Demon's.",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "0A174D9E0B4106436E1B674310CBA02E19F5"
                }
            },
            "0CEFF54523346547E51B0F67B5D8661AFD0E": {
                "t": "Don't do things you may regret.{W:300} You fight for Hoikade, not for me.",
                "d": {
                    "cid": "B29C753D58E5974A8B3A68575D84136FE572",
                    "eid": "E3CCEE983023544F33083E09A8CA927625B0"
                }
            },
            "87831D876EF7E641661B7E99D47A4BD175B9": {
                "t": "I don't want you to get involved, Menmus.",
                "d": {
                    "cid": "B29C753D58E5974A8B3A68575D84136FE572",
                    "eid": "306387A35E9E93473A29088272B143D81CAA"
                }
            },
            "DDBA300A7901784699683A4845D2BA2BCA96": {
                "t": "Don't become like me.{W:300}\nA fugitive...{W:300} on the run...",
                "d": {
                    "cid": "B29C753D58E5974A8B3A68575D84136FE572",
                    "eid": "D8DE7D0B65B14842B7294BD41A56199DB16D"
                }
            },
            "8C91804A78B462409A09E2B3353FFCB5A85B": {
                "t": "I know this won't be an easy path.{W:300} What I'm going to do will torment me forever.",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "E9C0374B4B94C1443B28DE32CBF6B8FE9491"
                }
            },
            "6D3491B051A1D94E3D1A9F336419632BB295": {
                "t": "But I know that if I don't follow my heart, I'll feel even worse.{W:300} I fight for what I believe in.",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "37BFBA951C675040550A6A747A13D4309F2C"
                }
            },
            "5A4F88053CA5F645FE0BA7239086F022FC00": {
                "t": "And now, Lady Faratras...{W:300} I believe in you.  ",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "1FF283F276AFC741D37989C7202DBB873E23"
                }
            }
        },
        "livePreviewDisabled": true,
        "commands": [
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "7F51AB705337E24CC28AEA98CC0744C01622"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "10E0D27851F48243A65BB350DF035D32A68B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0A5394441DFE9942C23BB1177D61A379F547",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4C89C03873C1E041CB0BA7884A13F74648C4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "02EF21C36393B4496049B238D012488E0ACE",
                    "parameters": {
                        "values": [
                            "B29C753D58E5974A8B3A68575D84136FE572",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "603FE6385D39084D397A5221C92E4E0978CD"
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "B29C753D58E5974A8B3A68575D84136FE572",
                    "eyeBlink": {
                        "enabled": 0,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 1,
                    "idleIntensity": 1,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 1,
                        "idleIntensity": 1,
                        "lipSyncSensitivity": 1,
                        "eyeBlink.enabled": 0,
                        "eyeBlink.interval": 1,
                        "eyeBlink.closedMotionTime": 1,
                        "eyeBlink.closingMotionTime": 1,
                        "eyeBlink.openingMotionTime": 1
                    }
                },
                "indent": 0,
                "uid": "0E0A796359B85249933A24919CA0BD73526B",
                "expanded": false
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "B29C753D58E5974A8B3A68575D84136FE572",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "FaratrasInventory.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "05_Eyes_Half_Closed.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "487887E36D3B614EEA2A2E56F5FA71A01DC4"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 45
                },
                "indent": 0,
                "uid": "704F31699839484C0988B862FC91FFA24F03"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D007E02518D24249142A32F1FBFB0EC659E0",
                    "parameters": {
                        "values": [
                            "B29C753D58E5974A8B3A68575D84136FE572",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "AACD1A7A705E304BE17A3D898AF40C5E5719"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "ui"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "model": {
                        "name": "Menmus.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 4999,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 1100,
                        "y": 54,
                        "zoom": {
                            "x": 1.7,
                            "y": 1.7,
                            "d": 1.7
                        }
                    },
                    "animation": {
                        "type": 0,
                        "movement": 2,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 30,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 0,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 0
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "66BCC7FC388A6847EF9983100DA0E502C440",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "50DC206237FF824FD5599D27BFA668CAF61C"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "062FED3E8D114848061B0908C7B1489C3FD0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5F4A38F377739842F16A684256A94D81F365"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6B39D3FE505F7341EB189569E3873544AE30",
                        "defaultText": "왜 그래?{W:300} 아직도 힘을 아끼는 것 같군."
                    },
                    "position": 0,
                    "characterId": "B29C753D58E5974A8B3A68575D84136FE572",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C05-04e3_line1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "2CEA95BD8F8E15486F4B0D32E51B915A77F6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C550B4D01AFE714DF27B0586B4FD6A5D8B4F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B1F0BEB94F186748396B09C8FAB8CFED7E66",
                        "defaultText": "우리는 함께 자라고 훈련했어.{W:300}\n네 힘은 누구보다 내가 잘 알아."
                    },
                    "position": 0,
                    "characterId": "B29C753D58E5974A8B3A68575D84136FE572",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C05-04e3_line2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "5D5FB75021FE964E8C0B4C23BEA635E715B0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "589CE16D68F092481F4964A7946C2A888F62"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "F6C65B6110C7224ABB7AD2D32D95982A27A8"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8F79AF843185F344B869F856963C0FD3667E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5C067DA34C6F3542574AF6F8225FDED554E0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A621F4455DB3F4477F39BC4170D47DC06B13",
                        "defaultText": "저는...{W:300} 못 하겠습니다."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Menmus",
                        "name": "C05-04e3_line3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "A7C6DD256920A9442C0AC4E5B97659AF0A70"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "F713F4CE3735F3485D096C42AF989396D310"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "B29C753D58E5974A8B3A68575D84136FE572",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "FaratrasInventory.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "04_Resolute.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DEDDF11F680D964BB95A7E76BF8E46459D93"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DAE9FA5F23A1D540952A2BF8A92376DD8E2A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0F6655EF2532F6475C694EF37D197ACB04F8",
                        "defaultText": "뭐?"
                    },
                    "position": 0,
                    "characterId": "B29C753D58E5974A8B3A68575D84136FE572",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C05-04e3_line4.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "4D6410FB65134846FD89697432AD06423B53",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "D131BDF96B9A714EF09B7266B7756E1A0D3A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "89FEAB0F26B27546608B5373B43BAF6487B0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4A6B76065B10864E7979B4770FF222B3E21A",
                        "defaultText": "당신과 싸우는 게 옳은 일입니까?{W:300}\n아무리 오래 고민해도..."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Menmus",
                        "name": "C05-04e3_line5.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "429FBEDA1AD354411B9A85B1C835C22FC1CF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EF58A43300C9844989192D41501D2F9D652C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "DC8DC402832F9240262AC634045B4EA900C9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4F1E5FEC24F034418A784D91178452204227",
                        "defaultText": "여왕님을 배신하는 건 잘못이고 터무니없는 짓이라는 생각뿐입니다!"
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Menmus",
                        "name": "C05-04e3_line6.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "681670881245D648D51A2D69BA6C5C094317"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6914EC983E699643A148E5911DE19D0EACAA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DA7B2ED72D704541884AAAC42C0A87DADFC1",
                        "defaultText": "그런데도...{W:300} 그릇이여, 당신의 말이 진실이라면\n얼마나 큰 고통을 품고 있는 겁니까?"
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Menmus",
                        "name": "C05-04e3_line7.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "1A46D9362E00D14DA819BB369B73296485CF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7401FAA882E6A6427678B033DF9D651781F2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "ED00983E38D27842654837A443CE8182DF42"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C139431C2BB7D2465D09ED25DA0ECF86C234",
                        "defaultText": "우리를 보십시오.{W:300}\n온 군대가 자신이 믿는 것을 위해 싸우고 있습니다."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Menmus",
                        "name": "C05-04e3_line8.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "5E7856376084E2457338DAE346020E199DF6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C69B625713A9A7447E79B0258D15194B582C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F43C2C6E6D1DF244D81ADD51D8604946549C",
                        "defaultText": "그리고 당신을 보십시오.{W:300} 홀로.{W:300}\n한때 사랑했던 이들에게 버림받았습니다."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Menmus",
                        "name": "C05-04e3_line9.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "CD4CBF2867BC254E54289226AE5899BA8240"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "A0CF58CC3A77D243BC397918A7A3223E88F4"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "B29C753D58E5974A8B3A68575D84136FE572",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "FaratrasInventory.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "06_Eyes_Closed.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "57C7D4A192E3484A4669822209EE0EECCAA4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "51489EB41426F4472588FCA5DB76AD2839EA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DE8E8B177AB178465B28D7C6E64A9F18A05E",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C05-04e3_line10.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "928668059916E347B7882FE872F3D52EA92E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "3FF35E022D567747008BBD8510C2B6793FDF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CA1DAB921E8B364C844B9703B99016653463"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DC13019F7400A54C7319BFA043E116E6D199",
                        "defaultText": "평소처럼 제가 너무 깊이 생각하는 걸지도 모릅니다.{W:300}\n아니면 제 정신도 지배당하는 것일지도요."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Menmus",
                        "name": "C05-04e3_line11.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "9D5253065043C14CD45BBF75FC0F347FED41"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "139FB7B125C19348FB59EFB027B7363FD31A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "923A36AD96AA5240FC2992859C5B3101ADFC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "869310BF5BA146420B392FE8DCBDF5C48CCC",
                        "defaultText": "하지만 지금 당신의 눈을 들여다보니,{W:300}\n끔찍한 마왕은 보이지 않습니다."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Menmus",
                        "name": "C05-04e3_line12.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "B83E6C5D7C030740C5481EA4B9981BED0CD0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "72F2310634250741362A44798CDE7860F362"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "67C0E4D2170DF946BE9B2370BF958445AFE9",
                        "defaultText": "언제나 우리를 아껴 주던,{W:300}\n우리가 사랑하는 그릇만 보일 뿐입니다."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Menmus",
                        "name": "C05-04e3_line13.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "C548D45C07FCB44B166A79F756F92E5230F8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "1C0C69613009F8485E5A79D5AD0E8BA79E70"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2A0B437F78D1A5495C59D9E633D0026CAA6E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C31741044968E047C91B1B99D8355000C0D4",
                        "defaultText": "흑...{W:300} 멘무스 대장...{W:300} 넌 틀렸어.\n나는...{W:300} 마왕이야..."
                    },
                    "position": 0,
                    "characterId": "B29C753D58E5974A8B3A68575D84136FE572",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C05-04e3_line14.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "57D8435145F9184A4E892DB4E5B60516A2FA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "B3BC41477BFE244A8A59E8E2441511EAB081"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "244937D469E311446068D7A39584288A16FB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C0D9BBE16C26A6415C8BDFB1D26372417C86",
                        "defaultText": "제가 보기에는 그 눈물이 마왕이 아닌,{W:300}\n당신의 것이라는 데 의심의 여지가 없습니다."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Menmus",
                        "name": "C05-04e3_line15.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "0A174D9E0B4106436E1B674310CBA02E19F5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "7D6F96419E7B7743E24BA090AF807C41B0DE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2AC85B014448274FBB496B287691B0E07F72"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0CEFF54523346547E51B0F67B5D8661AFD0E",
                        "defaultText": "후회할지도 모르는 일은 하지 마.{W:300}\n넌 내가 아니라 호이카데를 위해 싸우잖아."
                    },
                    "position": 0,
                    "characterId": "B29C753D58E5974A8B3A68575D84136FE572",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C05-04e3_line16.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "E3CCEE983023544F33083E09A8CA927625B0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9864E47A0B78A14C6A9AC5A51369CA422B67"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "B29C753D58E5974A8B3A68575D84136FE572",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "FaratrasInventory.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "02_Troubled.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9084AEC17EC95740347B4C15382A27C7C57E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "87831D876EF7E641661B7E99D47A4BD175B9",
                        "defaultText": "네가 말려들지 않았으면 해, 멘무스."
                    },
                    "position": 0,
                    "characterId": "B29C753D58E5974A8B3A68575D84136FE572",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C05-04e3_line17a.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "306387A35E9E93473A29088272B143D81CAA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EE95CA407565D848C75AED667818FDC009CB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DDBA300A7901784699683A4845D2BA2BCA96",
                        "defaultText": "나처럼 되지 마.{W:300}\n도망치는...{W:300} 도망자 말이야..."
                    },
                    "position": 0,
                    "characterId": "B29C753D58E5974A8B3A68575D84136FE572",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C05-04e3_line17b.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "D8DE7D0B65B14842B7294BD41A56199DB16D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "1B8BCE1F48B1A343A91A6FD40E7835F8A4AB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "07A8B1050414524A3B48B8181DE24C0F2141"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8C91804A78B462409A09E2B3353FFCB5A85B",
                        "defaultText": "이 길이 쉽지 않을 건 압니다.{W:300}\n제가 하려는 일은 평생 저를 괴롭힐 겁니다."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Menmus",
                        "name": "C05-04e3_line18.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "E9C0374B4B94C1443B28DE32CBF6B8FE9491"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2E3EDCF233C189440698D565239E58659A2D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6D3491B051A1D94E3D1A9F336419632BB295",
                        "defaultText": "하지만 마음을 따르지 않으면 더 괴로울 것도 압니다.{W:300}\n저는 제가 믿는 것을 위해 싸우겠습니다."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Menmus",
                        "name": "C05-04e3_line19.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "37BFBA951C675040550A6A747A13D4309F2C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D71C2BF86651E44BF119866571F22ABA46CC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "AFE26E6D6160974F40988DA6B2CBEB8CA112"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5A4F88053CA5F645FE0BA7239086F022FC00",
                        "defaultText": "그리고 이제, 파라트라스 님...{W:300} 당신을 믿습니다."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Menmus",
                        "name": "C05-04e3_line20.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "1FF283F276AFC741D37989C7202DBB873E23"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "7B7AF867215A7747915A9C26D02F8468E6D4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "212458D23DAD504CDE488802C2A4609E69F4",
                    "parameters": {
                        "values": [
                            "B29C753D58E5974A8B3A68575D84136FE572",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "6EEB682A55DD1844D2898C6625163808F3EA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6410A56314B6E248263A7A7869FA7223A315",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3FEC3D277B153143D4296EB72804A715C364"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "61A711D8061FC544E729B285F615C345ED4F"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "duration": 36,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 0,
                        "movement": 2,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 0
                    }
                },
                "indent": 0,
                "uid": "88CD944445E992492F887B864D286D68D42D",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0A5394441DFE9942C23BB1177D61A379F547",
                    "parameters": {
                        "values": [
                            0,
                            1,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AB401F6B75C4A644330B6664134A24F1DAEC"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "7F0276345F4255475B0A49367FD54DC9DC1C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D86A0B755C3931407F0ABD74F73B1E1241A9",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "DC9DF9707322964457892ED506B384266616"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "422B49CA8A63A04CB338ADD9E56A9BFB25A0",
                    "parameters": {
                        "values": [
                            "",
                            {
                                "lcId": null,
                                "defaultText": "{C:1}Menmus{C:0} joins as an {C:2}Adjutant{C:0}."
                            },
                            "",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7F63966E1212544F4328EFF3848ADE10F1A6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6FE3C1466BE6D749E93B1A1763C2A8DE2900",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1BC74E183DEE7142AC5866B31EEEECADCB26"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "41D6DA1382187149CD5BE7620DA17AFD9CD1"
            }
        ],
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}