GS.dataCache['1ED502916856C948A0693432B19D9B1101B0'] = {
    "uid": "1ED502916856C948A0693432B19D9B1101B0",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C4-02 Magnolia Palace (Exploration)",
        "type": "vn.scene",
        "parentId": "8D381E7C10471941382A2AC92CD7DB63FF30",
        "chapterUid": "6FC0AF36453CA744B128EAF83314DDE5F897",
        "order": 1,
        "livePreviewDisabled": true,
        "commands": [
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "PREVENT LOADING EXPLORATION?",
                        "index": 97,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1DD425BD8AA23345492B5AB79141D0CE710F"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 1,
                "uid": "422831DB15957143605A13D1A35054BE4E26"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 10001,
                    "blendMode": 0,
                    "zOrder": 0,
                    "duration": 1.2,
                    "origin": 0,
                    "waitForCompletion": 1,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 1,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "sfondo nero.png",
                        "folderPath": "Graphics/Pictures/CG Gallery",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 1,
                "uid": "1E47AFF2832CD74E213BA0A85B56C10FEB12",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "82BDC87C5C78E24A9B3B6B4142A084CAFA38"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 1,
                "uid": "E3FC49B073AC43445678E45940F145EA3853"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FBE97F211A99D64C389BB1C15BEF1A80D6BB",
                    "parameters": {
                        "values": [
                            20,
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "528FE91A6FFC8444FC586FD7ED45C5AC0EF5"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "model": {
                        "name": "Rya Overworld Model.model.live2d",
                        "folderPath": "Live2D",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 800,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 1800,
                        "y": 465,
                        "zoom": {
                            "x": 0.43,
                            "y": 0.43,
                            "d": 0.43
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 0.06,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 1,
                "uid": "86ACAFDC7D473841323B01C47D60099A222A",
                "expanded": false
            },
            {
                "id": "vn.SetObjectData",
                "params": {
                    "objectType": 4,
                    "number": 0,
                    "numberDomain": "com.degica.vnm.default",
                    "layer": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "field": 6,
                    "numberValue": -43,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0
                },
                "indent": 1,
                "uid": "ECD9D74578E5774075898732EE792A0B1094"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "param": {
                        "name": "Espressione corrente",
                        "type": 0,
                        "value": 0
                    },
                    "numberValue": 0,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 1,
                "uid": "AD46389F378AA6405B2830A4B6C35EDFB839"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 1,
                "uid": "7FC48AD47CB7544AA10B41B9E1D35F8367E3"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Numero Identificativo Suono",
                        "index": 159,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "85FFE8F789BE49498A28D232DF17A8504D24"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "6A2AC46D47CF55422B0BDFA266DFDAE00D44"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "5763240C7DFA974ABC6ACCF0A48D1D999122"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 10001,
                    "duration": 45,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 2,
                        "movement": 0,
                        "mask": {
                            "graphic": {
                                "name": "9.png",
                                "hue": 0,
                                "opacity": 255,
                                "blending": 0,
                                "tone": {
                                    "red": 0,
                                    "green": 0,
                                    "blue": 0,
                                    "grey": 0
                                },
                                "folderPath": "Graphics/Masks"
                            },
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "48990A7B0203164CE42900057E25F95E298B",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 15
                },
                "indent": 1,
                "uid": "54991A3C184C12482B8884848CF1B745150D"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Spend time (during travel?)",
                        "index": 96,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "7D0EA565163134411E6A7C35032A939509D1"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Spend time (during travel?)",
                        "index": 96,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "2BAC8B522D68174E652B5F654CB0A212905B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "03DEA4954ABD5648B72A16630CB12FEB0C7F",
                    "parameters": {
                        "values": [
                            {
                                "name": "Tempo d'attesa",
                                "index": 32,
                                "scope": 1,
                                "domain": "com.degica.vnm.default",
                                "changed": true
                            },
                            250,
                            1,
                            2000,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "3197D7690969444FA93B67C641DC60423745"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "7601D85C3700D2424D6B5E62901196D79FD3",
                    "parameters": {
                        "values": [
                            20
                        ]
                    }
                },
                "indent": 1,
                "uid": "2A963BF1658BA24F895AE9156652EC5B95B2"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "PREVENT LOADING EXPLORATION?",
                        "index": 97,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4FDE37D57C777745E1689162B73045D7ACEC"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "INDICE HOTSPOTS\n1-5 Hotspot pg\n6-15 Elementi di background\n16-20 Monetine"
                },
                "indent": 0,
                "uid": "375048E868C5084D34288C06FB2BC842C8D8",
                "expanded": true
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "P\nE\nR\nS\nO\nN\nA\nG  G  I    E SCENE DIALOGHI"
                },
                "indent": 0,
                "uid": "D53B55EC89C4A54A658808D441F864775D00",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "21CB77C16DEB404FA26A8F35BFB39B2FD0D7",
                    "parameters": {
                        "values": [
                            "0FCC16EC8F14214F211BD711C5EF156BDE65",
                            "567F1E3489D91446CF4A0ED6AF508D6BB339",
                            "FEEB28CE186A3342E70A634062AF25688319",
                            "2B96228807C91543086AF8734CBB0AD4A6B9",
                            "51FE568238DE384B4F8A0356581EC6A54FA8",
                            "",
                            ""
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C55151536BDE9845521B649795DEB5493D72"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A1F3F1D799DDC043B218386049F1B8B86EA2",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            "",
                            "",
                            "",
                            "",
                            "D51C041D7AF1A2430C3914532F7C6F84BAA7",
                            "",
                            "",
                            "",
                            "",
                            0,
                            0
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D1AAF77041CD484E46284AD5659996F2069A"
            },
            {
                "id": "gs.AddHotspot",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1,
                    "shape": "rect",
                    "positionType": 0,
                    "actions": {
                        "onClick": {
                            "type": 4,
                            "bindValue": 1,
                            "bindValueVariable": {
                                "name": "Numero ID pg EXPLORE",
                                "index": 255,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "TalktoNPC",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onEnter": {
                            "type": 4,
                            "bindValue": 1,
                            "bindValueVariable": {
                                "name": "Numero ID pg EXPLORE",
                                "index": 255,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "Info",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onSelect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDeselect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onLeave": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "UnInfo",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrag": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrop": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDropReceive": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        }
                    },
                    "dragging": {
                        "enabled": 0,
                        "variable": {
                            "scope": 1,
                            "index": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "horizontal": 1,
                        "vertical": 0,
                        "rect": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 200,
                                "height": 50
                            }
                        }
                    },
                    "position": 1,
                    "box": {
                        "x": 1540,
                        "y": 448,
                        "angle": 0,
                        "zoom": 1,
                        "horizontalFlip": false,
                        "data": {
                            "x": 589,
                            "y": 237,
                            "width": 166,
                            "height": 426,
                            "horizontalFlip": false,
                            "zoom": 1,
                            "angle": 0
                        },
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 160
                        },
                        "size": {
                            "width": 336,
                            "height": 464
                        }
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7F2B33EC1F2AB3449F596047E77179791B3E",
                "expanded": false
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "E\nL\nE\nM\nE\nN\nT\nI  C L I C K A B I L I (descrizioni)"
                },
                "indent": 0,
                "uid": "009418AC6AE7C74BC55B4CC1D5504FEFAD44",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "B91A2FE514A67748E769D0B36E440EBDFCDF",
                    "parameters": {
                        "values": [
                            "4FD4EFB43333374AAC7AE7D809A101010A6D",
                            "5D7EB6EC1E5701446F48E393BFBAE65A3D5B",
                            "04CFEE0A8E9E2544298B3EC9A3B73DACC1F2",
                            "90AA0E6C0B9AC14E465BEAE5E9FCE9DB03AD",
                            "",
                            "",
                            "",
                            "",
                            "",
                            ""
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C5D4A95550A44445735B4FC3B3A5B94FEC15"
            },
            {
                "id": "gs.AddHotspot",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 6,
                    "shape": "rect",
                    "positionType": 0,
                    "actions": {
                        "onClick": {
                            "type": 4,
                            "bindValue": 6,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "AttivaClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onEnter": {
                            "type": 4,
                            "bindValue": 6,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "InfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onSelect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDeselect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onLeave": {
                            "type": 4,
                            "bindValue": 6,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "UnInfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrag": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrop": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDropReceive": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        }
                    },
                    "dragging": {
                        "enabled": 0,
                        "variable": {
                            "scope": 1,
                            "index": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "horizontal": 1,
                        "vertical": 0,
                        "rect": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 200,
                                "height": 50
                            }
                        }
                    },
                    "position": 1,
                    "box": {
                        "x": 852,
                        "y": 402,
                        "angle": 0,
                        "zoom": 1,
                        "data": {},
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 160
                        },
                        "size": {
                            "width": 150,
                            "height": 404
                        }
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CA8A195B53ED634C9D78E625BF59FF80F73E",
                "expanded": false
            },
            {
                "id": "gs.AddHotspot",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 7,
                    "shape": "rect",
                    "positionType": 0,
                    "actions": {
                        "onClick": {
                            "type": 4,
                            "bindValue": 7,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "AttivaClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onEnter": {
                            "type": 4,
                            "bindValue": 7,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "InfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onSelect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDeselect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onLeave": {
                            "type": 4,
                            "bindValue": 7,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "UnInfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrag": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrop": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDropReceive": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        }
                    },
                    "dragging": {
                        "enabled": 0,
                        "variable": {
                            "scope": 1,
                            "index": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "horizontal": 1,
                        "vertical": 0,
                        "rect": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 200,
                                "height": 50
                            }
                        }
                    },
                    "position": 1,
                    "box": {
                        "x": 1516,
                        "y": 0,
                        "angle": 0,
                        "zoom": 1,
                        "data": {},
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 160
                        },
                        "size": {
                            "width": 404,
                            "height": 338
                        }
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8644E7E242D1874E018870A8A2E016320EDC",
                "expanded": false
            },
            {
                "id": "gs.AddHotspot",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 8,
                    "shape": "rect",
                    "positionType": 0,
                    "actions": {
                        "onClick": {
                            "type": 4,
                            "bindValue": 8,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "AttivaClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onEnter": {
                            "type": 4,
                            "bindValue": 8,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "InfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onSelect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDeselect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onLeave": {
                            "type": 4,
                            "bindValue": 8,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "UnInfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrag": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrop": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDropReceive": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        }
                    },
                    "dragging": {
                        "enabled": 0,
                        "variable": {
                            "scope": 1,
                            "index": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "horizontal": 1,
                        "vertical": 0,
                        "rect": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 200,
                                "height": 50
                            }
                        }
                    },
                    "position": 1,
                    "box": {
                        "x": 274,
                        "y": 614,
                        "angle": 0,
                        "zoom": 1,
                        "data": {},
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 160
                        },
                        "size": {
                            "width": 82,
                            "height": 182
                        }
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "224999BB12DD5849B98A32C4C2CC1E039CA2",
                "expanded": false
            },
            {
                "id": "gs.AddHotspot",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 9,
                    "shape": "rect",
                    "positionType": 0,
                    "actions": {
                        "onClick": {
                            "type": 4,
                            "bindValue": 9,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "AttivaClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onEnter": {
                            "type": 4,
                            "bindValue": 9,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "InfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onSelect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDeselect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onLeave": {
                            "type": 4,
                            "bindValue": 9,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "UnInfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrag": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrop": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDropReceive": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        }
                    },
                    "dragging": {
                        "enabled": 0,
                        "variable": {
                            "scope": 1,
                            "index": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "horizontal": 1,
                        "vertical": 0,
                        "rect": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 200,
                                "height": 50
                            }
                        }
                    },
                    "position": 1,
                    "box": {
                        "x": 166,
                        "y": -2,
                        "angle": 0,
                        "zoom": 1,
                        "data": {},
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 160
                        },
                        "size": {
                            "width": 328,
                            "height": 128
                        }
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "79DB518F169F34451729C840A55DE6152156",
                "expanded": false
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "C\n  O\n     I\n       N\n          S"
                },
                "indent": 0,
                "uid": "3C41448B52281542F77B098313EC04E572E2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2BB01B9A8522474499180AA87EFC414D3CC7",
                    "parameters": {
                        "values": [
                            "CD45361918E8A243893A34118083FE60B578",
                            "B892212C5D23C346F31AE2F1F5D00F38EFD6",
                            "",
                            "",
                            ""
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D47B09ED35A95542F97A196828F51EA8CC07"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "",
                        "index": 15,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DA42CB3F2B463147D07944137707CF61AF22"
            },
            {
                "id": "gs.AddHotspot",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 16,
                    "shape": "rect",
                    "positionType": 0,
                    "actions": {
                        "onClick": {
                            "type": 4,
                            "bindValue": 16,
                            "bindValueVariable": {
                                "name": "Numero ID Coin EXPLORE",
                                "index": 256,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "OttieniCoin",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onEnter": {
                            "type": 0,
                            "bindValue": 16,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "InfoCoin",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onSelect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDeselect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onLeave": {
                            "type": 0,
                            "bindValue": 16,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "UnInfoCoin",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrag": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrop": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDropReceive": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        }
                    },
                    "dragging": {
                        "enabled": 0,
                        "variable": {
                            "scope": 1,
                            "index": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "horizontal": 1,
                        "vertical": 0,
                        "rect": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 200,
                                "height": 50
                            }
                        }
                    },
                    "position": 1,
                    "box": {
                        "x": 58,
                        "y": 734,
                        "angle": 0,
                        "zoom": 1,
                        "data": {},
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 160
                        },
                        "size": {
                            "width": 60,
                            "height": 60
                        }
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "7F546F3A123556457E2BA882852B6080C517",
                "expanded": false
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "",
                        "index": 16,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "811B80712B577646ED6A9000B031F0632B2B"
            },
            {
                "id": "gs.AddHotspot",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 17,
                    "shape": "rect",
                    "positionType": 0,
                    "actions": {
                        "onClick": {
                            "type": 4,
                            "bindValue": 17,
                            "bindValueVariable": {
                                "name": "Numero ID Coin EXPLORE",
                                "index": 256,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "OttieniCoin",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onEnter": {
                            "type": 0,
                            "bindValue": 16,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "InfoCoin",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onSelect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDeselect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onLeave": {
                            "type": 0,
                            "bindValue": 16,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "UnInfoCoin",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrag": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrop": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDropReceive": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        }
                    },
                    "dragging": {
                        "enabled": 0,
                        "variable": {
                            "scope": 1,
                            "index": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "horizontal": 1,
                        "vertical": 0,
                        "rect": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 200,
                                "height": 50
                            }
                        }
                    },
                    "position": 1,
                    "box": {
                        "x": 1220,
                        "y": 72,
                        "angle": 0,
                        "zoom": 1,
                        "data": {},
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 160
                        },
                        "size": {
                            "width": 60,
                            "height": 60
                        }
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "FABB132A1B2E4344ED8BB4582EFC3C06DCA9",
                "expanded": false
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "PIEDINO DI ESPLORAZIONE"
                },
                "indent": 0,
                "uid": "60F144EB14EE054093490C177E7136104AE0",
                "expanded": true
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Flag locale 2",
                        "index": 161,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5F33601F3E66584D0938D9A37E62AC3D0CAF"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "Eventi Scena",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "54FC3F943987C344606BF3B49CA7EAE09018"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "piedino"
                },
                "indent": 0,
                "uid": "3ADE33558FEDC741A6484BB1A734ADE057F1"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Plaza"
                },
                "indent": 0,
                "uid": "A08BC15F1F79E64F750B1B2469B85142302E",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Location SCENE 1",
                        "index": 286,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "EF57428D67D54147650A50A7359A5AD2F9D2",
                        "defaultText": "5638704700A1F946E47BB0B23F3B393CB375"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0D70AF287C6A9744BE4AD2D7595EE703946B",
                "expanded": true
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Marketplace"
                },
                "indent": 0,
                "uid": "37E0C84A3FF0E542E608327193DE3128ED73",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Location SCENE 2",
                        "index": 287,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "945463299D5EA44A3A2BEAD6C4AC809C43D6",
                        "defaultText": "C7B7879217357646400B56F7CA19AB8B41B7"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B8A4DAF270AA87413429F0445430E27D35E8",
                "expanded": true
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Flag locale 3",
                        "index": 162,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CD5AFD3539D85649805A9061933C2AECA126"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "House 1"
                },
                "indent": 1,
                "uid": "7D74A99B4A8DA64A1C2B74F0FC25CA84C22E",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Location SCENE 3",
                        "index": 288,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "B416290C9816484D0F4B2968071AD8AC3779",
                        "defaultText": ""
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "DB09F9DB2B0EF94B388843099339EB7B6113",
                "expanded": true
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "House 2"
                },
                "indent": 1,
                "uid": "28A70C2C81D64849891857D21DDC0B8187C9",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Location SCENE 4",
                        "index": 289,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "39BA214C3E8AD24B657B90A3FF156658B143",
                        "defaultText": ""
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "4C6311B76E7AC24F895832F2950BAA93F04D",
                "expanded": true
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "C4363A583079564A2D4ADD230A4E264E029D"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "House 1"
                },
                "indent": 1,
                "uid": "14E218FF741D5845E32A15479B100E59F5A3",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Location SCENE 3",
                        "index": 288,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "1701FF36316FC54ED18956C2EB8D02013ADD",
                        "defaultText": "4BFE9FD5211FF249BD1A5645E45BA12B10ED"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "5628922859900741592804133E764CB5077F",
                "expanded": true
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "House 2"
                },
                "indent": 1,
                "uid": "9F6E85438F46024BC829EC733C3399955821",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Location SCENE 4",
                        "index": 289,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "CB4662272139D44FC32AB1145C51FDD44BEC",
                        "defaultText": "FAF5553D4BE3D248885B6F58A00197A898C3"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "30911F4A9AB1634CE45A153816E60B69047F",
                "expanded": true
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Flag locale 4",
                        "index": 163,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A45555496C3F0046274B40087DB5C3D45CAA"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Forest Map"
                },
                "indent": 1,
                "uid": "3D19132152EF584BD3382A372471C2D18AFF",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Location SCENE 5",
                        "index": 290,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "304E3DF818943442033A93D8A72F831C276D",
                        "defaultText": ""
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "750160D222AE8140DC293253B8D2B81F8C1E",
                "expanded": true
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "705FD78F549B82407C39FBE4A1590396D8DE"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Forest Map"
                },
                "indent": 1,
                "uid": "26F881650C9F4843022981F070EA27AA3A03",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Location SCENE 5",
                        "index": 290,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "240E7C147EB3B14F238946D4CB9D5B1AE393",
                        "defaultText": "9DA4B9C4809FB54D9A8A03B1172C93FEE803"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "785BB96636765649DC389BB03F5167F71D24",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "86CBAC798809154F145BAB489EC84573234C",
                    "parameters": {
                        "values": [
                            {
                                "lcId": "C39ABEA37C6047461579E248BEB941EB750C",
                                "defaultText": "Viborera Plaza"
                            },
                            {
                                "name": "Location SCENE 1",
                                "index": 286,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            5,
                            3,
                            "Viborera Mall",
                            {
                                "name": "Location SCENE 2",
                                "index": 287,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            5,
                            3,
                            "Magnolian House 1",
                            {
                                "name": "Location SCENE 3",
                                "index": 288,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            5,
                            3,
                            "Magnolian House 2",
                            {
                                "name": "Location SCENE 4",
                                "index": 289,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            5,
                            3,
                            "Tanaba Forest",
                            {
                                "name": "Location SCENE 5",
                                "index": 290,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            -5,
                            0,
                            "",
                            "",
                            0,
                            0
                        ],
                        "uid": "C52FCA158E4657420B492E66BA1792F9B0D5"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E73DA4C12FA8D047C59BCC249682EEF41233"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "4445F1AC8A63F745F518340809A7E970C52A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "472B7EDA2DA1214A6C1BF59176CA40728C7E"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "EVENTI EVENTUALI"
                },
                "indent": 0,
                "uid": "FB38D4352DEA0241F95A92C5A3B3FE6D58BA",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "Eventi Scena"
                },
                "indent": 0,
                "uid": "315DF7B041F848495F38BA0623054D18C7D2"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Flag locale 1",
                        "index": 160,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D1397C770C2497430C8868B8F7F87C51362D"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Flag locale 1",
                        "index": 160,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "7562507C3015F3437F2A01C175F2E2052C87"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Flag locale 2",
                        "index": 161,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "9EAE33770EEC81438829516363B99C72E077"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "piedino",
                    "target": "activeScene"
                },
                "indent": 1,
                "uid": "D114DF7D63E2534F30894613EA66095F576D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "15224E583986C649652961F8D83C325E97D6",
                    "parameters": {
                        "values": [
                            2,
                            30,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "3876AED403FC0249584A02824D342FD7853A"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Risultato calcolo %: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8B343F5B9F88D14A9F6BFD8888689A16851B"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "7E1C46E045C0544AA9882DF2D022C33FABDD",
                        "name": "C4-03 passage - To ending (time's up)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "56F76D303D4D514011284EE4B4033E662C0D"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Pause allowed bc IN EXPLORATION / CHOICE?",
                        "index": 156,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "78DECB0E68E5134D3C19F331C9BE2D0572E8"
            },
            {
                "id": "gs.Idle",
                "params": {},
                "indent": 0,
                "uid": "604D209B8821B7466619A8A434F649CE7F6E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D7547A96549313459078E4251677136450B5",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "84E3F67B1588734E341A9A64C5424016F96F"
            }
        ],
        "localizableStrings": {
            "EF57428D67D54147650A50A7359A5AD2F9D2": {
                "t": "5638704700A1F946E47BB0B23F3B393CB375",
                "d": {
                    "eid": "0D70AF287C6A9744BE4AD2D7595EE703946B"
                }
            },
            "945463299D5EA44A3A2BEAD6C4AC809C43D6": {
                "t": "C7B7879217357646400B56F7CA19AB8B41B7",
                "d": {
                    "eid": "B8A4DAF270AA87413429F0445430E27D35E8"
                }
            },
            "B416290C9816484D0F4B2968071AD8AC3779": {
                "t": "",
                "d": {
                    "eid": "DB09F9DB2B0EF94B388843099339EB7B6113"
                }
            },
            "39BA214C3E8AD24B657B90A3FF156658B143": {
                "t": "",
                "d": {
                    "eid": "4C6311B76E7AC24F895832F2950BAA93F04D"
                }
            },
            "1701FF36316FC54ED18956C2EB8D02013ADD": {
                "t": "4BFE9FD5211FF249BD1A5645E45BA12B10ED",
                "d": {
                    "eid": "5628922859900741592804133E764CB5077F"
                }
            },
            "CB4662272139D44FC32AB1145C51FDD44BEC": {
                "t": "FAF5553D4BE3D248885B6F58A00197A898C3",
                "d": {
                    "eid": "30911F4A9AB1634CE45A153816E60B69047F"
                }
            },
            "304E3DF818943442033A93D8A72F831C276D": {
                "t": "",
                "d": {
                    "eid": "750160D222AE8140DC293253B8D2B81F8C1E"
                }
            },
            "240E7C147EB3B14F238946D4CB9D5B1AE393": {
                "t": "9DA4B9C4809FB54D9A8A03B1172C93FEE803",
                "d": {
                    "eid": "785BB96636765649DC389BB03F5167F71D24"
                }
            },
            "C39ABEA37C6047461579E248BEB941EB750C": {
                "t": "Viborera Plaza",
                "d": {
                    "eid": "C52FCA158E4657420B492E66BA1792F9B0D5"
                }
            }
        },
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}