GS.dataCache['9EC2DABA4CBCA14EB308821256AD1411A18E'] = {
    "uid": "9EC2DABA4CBCA14EB308821256AD1411A18E",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C10.5-1 Aftermath of the battle (MAP)",
        "type": "vn.scene",
        "parentId": "ABB998293DB98847048AD652DAF46B657127",
        "chapterUid": "600AA11C0D65A64A4A8AD6A687CDC5D59826",
        "order": 0,
        "localizableStrings": {
            "018CFC399FB38448DC688FF39327C50E6EF3": {
                "t": "How are they?",
                "d": {
                    "cid": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "eid": "F318C39267799345F058EDF63EB4550BBC6A"
                }
            },
            "01798D633A207346883BE1A8CBA47F0B54DE": {
                "t": "Ceapana has done a great job. They're no longer near death.",
                "d": {
                    "cid": "9760108A5D7AD641848A7399B71F90434295",
                    "eid": "0E97930230EDE348B0688B18D02F9AADAC98"
                }
            },
            "CF63E7C64CBA784E828BB5449EA54432F988": {
                "t": "Thank the Holy Father! What a relief. She really is a 'miraculous healer'...",
                "d": {
                    "cid": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "eid": "E611CC55033DD644550846A27B4A327D2965"
                }
            },
            "C8FD73857DFAE84BC00B49130A3B2F9F84E4": {
                "t": "Holy Father or not, their condition is still unstable. For now, they must rest as much as possible.",
                "d": {
                    "cid": "9760108A5D7AD641848A7399B71F90434295",
                    "eid": "EC67876B3575524EAD9BDB1807CBFA222848"
                }
            },
            "80CB350F939A5040422ACB4294C861EF7D54": {
                "t": "Truth be told, I'm surprised the Vassal is still alive after that...",
                "d": {
                    "cid": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "eid": "881B212B45E2E8465128E4B8B27CA2EE7FE2"
                }
            },
            "8DE89A806EB2214B3B697F6009DDED8ACB2F": {
                "t": "Hmh. I've thought long and hard about what happened back then... And I have a theory.",
                "d": {
                    "cid": "9760108A5D7AD641848A7399B71F90434295",
                    "eid": "5C4B9FA45EBD894651486AA6A6C08B8DB624"
                }
            },
            "03EB90B42E3C2443EA49C7168D1F3AC733D2": {
                "t": "From what we know, if the soul of the Demon King is forcibly extracted...",
                "d": {
                    "cid": "9760108A5D7AD641848A7399B71F90434295",
                    "eid": "424B403473844245203A66B603D7ECEB5CD0"
                }
            },
            "C97538670A086049998B3F439727DC34915D": {
                "t": "Oh yeah! Reminds me of when I left a glass of wine out, last winter.",
                "d": {
                    "cid": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "eid": "9DF9E7495FDE0445957A1BA4159C2C462D2E"
                }
            },
            "C5B7CDF19D942546914A9FB7FEB23F45CDFC": {
                "t": "When I returned, the liquid had solidified and... boom!",
                "d": {
                    "cid": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "eid": "ABBC671E40D2F54A09097B1186A6A167B82A"
                }
            },
            "C9A0394F99D34246E62BA62649BA3DFC2333": {
                "t": "... Where did that metaphor come from?",
                "d": {
                    "cid": "9760108A5D7AD641848A7399B71F90434295",
                    "eid": "ECC6CA4239A66041616A9D768227C6D72328"
                }
            },
            "663B86917A5951458F7A71A6E14795D841F9": {
                "t": "Hey, c'mon Rya! I may act silly at times, but I know a thing or two myself!",
                "d": {
                    "cid": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "eid": "51307FA1964F4943D54AF54148DA0DD99A93"
                }
            },
            "FA6518AF5DF060449C198B0301820C09D04C": {
                "t": "Well, that was surprisingly... effective in describing what I meant.",
                "d": {
                    "cid": "9760108A5D7AD641848A7399B71F90434295",
                    "eid": "3A483A1D323C584AA11987576E1D4C86F9A0"
                }
            },
            "96C9FDA61437D24B212874D4C7D399E77D7F": {
                "t": "What if the seal wasn't perfectly intact?",
                "d": {
                    "cid": "9760108A5D7AD641848A7399B71F90434295",
                    "eid": "C9DF5C6508FFA947C11A26E309702F048871"
                }
            },
            "BE7ECDCA2A3C0845C24A17B818C7C2854626": {
                "t": "Well, the wine would warm up and eventually be spilled out of the glass...",
                "d": {
                    "cid": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "eid": "45590719371F404D3B2A5AF662B002D9FAEF"
                }
            },
            "EE98E45B285E8546267BDC7207C91D457C36": {
                "t": "And the glass would remain intact. I think that the same happened to Faratras and Hellios here.",
                "d": {
                    "cid": "9760108A5D7AD641848A7399B71F90434295",
                    "eid": "5AE628D31E7B7249317932F2FF21F52F94E1"
                }
            },
            "1A932E6E83DF784B581A4A6770B8737A2698": {
                "t": "He made it so that neither the seal nor her magic were restraining Him at the time.",
                "d": {
                    "cid": "9760108A5D7AD641848A7399B71F90434295",
                    "eid": "968F823027C0F149A549AD61C5039CCB7192"
                }
            },
            "B3501C7B578254497C891CD21F5348C17034": {
                "t": "What a diabolical plan He had. This has never happened before, right?",
                "d": {
                    "cid": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "eid": "95B8C320838E11474C5B1CD6C02138F971FD"
                }
            },
            "BA1AAE1E83B5C14E177928C1B2E563B1973E": {
                "t": "No... In fact, the Demon King kept getting a little bit weaker each time a Vassal died.",
                "d": {
                    "cid": "9760108A5D7AD641848A7399B71F90434295",
                    "eid": "FBA234A451333441777B29E260248B8A4473"
                }
            },
            "6EBC1F657B1A904456598F9294D333BDB018": {
                "t": "At least, it seems like Lady Faratras won't suffer any further tragic consequences.",
                "d": {
                    "cid": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "eid": "1918BFC6970FF6441A199825568A6C9E20B2"
                }
            },
            "85FA01548CF9A94AA28B27E3A3BB60A154E9": {
                "t": "I wouldn't be so sure myself. Sometimes the wounds of the heart are harder to heal than those of the body.",
                "d": {
                    "cid": "9760108A5D7AD641848A7399B71F90434295",
                    "eid": "0DBBB96777A5D844E259C3D437CAF1CED85F"
                }
            },
            "069AAEAA706E7740C29925B6E8B959F357C7": {
                "t": "And that applies not only to her, but to our whole group too...",
                "d": {
                    "cid": "9760108A5D7AD641848A7399B71F90434295",
                    "eid": "41B606AD310C514632481494EFE7EAFB68CC"
                }
            },
            "2B7AF6F93FDDF8471608BDA4F9BE8ADDC268": {
                "t": "You're right... Everyone seems pretty bitter about failing the mission.",
                "d": {
                    "cid": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "eid": "CA2C84D79E1C2542127BB7D340424AC1710D"
                }
            },
            "472C11C7451E4548FD48C78812D81B9287DF": {
                "t": "Hey Rya, do you think they would appreciate a small gift? Like some flowers?",
                "d": {
                    "cid": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "eid": "AE3D1F159C12E7479B9B49065B06551C813B"
                }
            },
            "A5003ECD8D20A24DF65AB377F2FDE74C9291": {
                "t": "That might be a considerate idea, yes.",
                "d": {
                    "cid": "9760108A5D7AD641848A7399B71F90434295",
                    "eid": "19379D366D2B644B2079B2930517BB83F455"
                }
            },
            "48BB38DE1D7E924E3C2A53726C95913D288E": {
                "t": "That's great! I remember a place nearby where some wild lilies grow.",
                "d": {
                    "cid": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "eid": "38339F534EB8C64759687BD34A294A005377"
                }
            },
            "21D7BD8C9D2974473D79972891041A502DB8": {
                "t": "Just don't be too late. We must leave in about {SP:2}{C:1}fifty minutes{C:0}.",
                "d": {
                    "cid": "9760108A5D7AD641848A7399B71F90434295",
                    "eid": "8DB50DD3027A8545AB28FA49C07F3F2613B3"
                }
            },
            "D1D701F56C700548648B965556D6B3E3F6F6": {
                "t": "I'll be right back!",
                "d": {
                    "cid": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "eid": "15BD104A6CC04742EA499054D2A7C59978DE"
                }
            },
            "43520A7E391E0943E179AFE6C7D21BA9B0BE": {
                "t": "I mean, the Demon broke free, right? Shouldn't that process have killed her?",
                "d": {
                    "cid": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "eid": "B56B953B3C782040D649958165E1A85D52E3"
                }
            },
            "86274BDA4FD1C64BAC2BC2B3F788E6573BD7": {
                "t": "...the strain would be too much for the Vassal's body to handle, causing her death.",
                "d": {
                    "cid": "9760108A5D7AD641848A7399B71F90434295",
                    "eid": "2EA53A6E12B38643997A65D2E3241DBBDA33"
                }
            },
            "CFF4153B0A49514EB13B6F54571150214008": {
                "t": "The glass shattered! And the wine was spoilt!",
                "d": {
                    "cid": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "eid": "106FEC83554E9546927AADF629E480D988B6"
                }
            },
            "A05BD3FC88AC38457F88E1D4C60447067F58": {
                "t": "So, keeping with the same example...",
                "d": {
                    "cid": "9760108A5D7AD641848A7399B71F90434295",
                    "eid": "3A85B321212AE444C8890697FA412D3E679F"
                }
            },
            "D453CF998CC9A742129834F5026A7DB2AE46": {
                "t": "The Demon King is the wine. The seal is the glass. And the Vassal's magic is the cold environment.",
                "d": {
                    "cid": "9760108A5D7AD641848A7399B71F90434295",
                    "eid": "A81D9A3C2F919748272B7D36A5A0EA210A72"
                }
            },
            "9AA995EB3449C947951803B56B9ECCABBBED": {
                "t": "Wouldn't that mean the glass has cracks? Some drops of wine would leak out.",
                "d": {
                    "cid": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "eid": "E508EEEF8855B043214A4FF10D5C27701F6E"
                }
            },
            "AABDF560215711427B583EA8BA7ABA64075C": {
                "t": "That's how 'Hellios' was born. Faratras' seal wasn't perfect to begin with.",
                "d": {
                    "cid": "9760108A5D7AD641848A7399B71F90434295",
                    "eid": "2017D5846BF1B64AAE19D696AFA4F90CB376"
                }
            },
            "1386EFAE808C774D9E4A9F02772457E88B91": {
                "t": "But by perfectioning her magic, she managed to keep that wine frozen for 21 years.",
                "d": {
                    "cid": "9760108A5D7AD641848A7399B71F90434295",
                    "eid": "F79E0C732B61C248A75AC2B5A3620CBF6B43"
                }
            },
            "C5CE0C342B8678418D194D15C91355D689B4": {
                "t": "Oh... That's why the Demon King wasn't released even when she got drunk.",
                "d": {
                    "cid": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "eid": "CD4B45FD017CA048B83A2121FD14D4AE07C6"
                }
            },
            "1EADF59B3DBCE547B15B20027833CE89DD65": {
                "t": "Exactly. If one were to turn a glass with frozen wine... it would stay in place, at least for a while.",
                "d": {
                    "cid": "9760108A5D7AD641848A7399B71F90434295",
                    "eid": "D4FEA2EC6075D64FCD5AA927CC740CB0F5BF"
                }
            },
            "3779CB709DDE1643FD2BDDF52953D395C247": {
                "t": "But what if it was placed in a warmer environment?",
                "d": {
                    "cid": "9760108A5D7AD641848A7399B71F90434295",
                    "eid": "2A15FB5176A7D345D98BF2F593178AD0628B"
                }
            },
            "8297889912EF2244331846644B88B1053963": {
                "t": "And He broke free at His full potential...",
                "d": {
                    "cid": "9760108A5D7AD641848A7399B71F90434295",
                    "eid": "A6F4325907659540B19B1AC673D083FC2120"
                }
            },
            "78BC1D315D15C54F498BA298B2E522AE54BD": {
                "t": "Although He's still immensely powerful even now... and immortal, on top of that.",
                "d": {
                    "cid": "9760108A5D7AD641848A7399B71F90434295",
                    "eid": "7075C1C454931247F39B94C6474BC9BECDDC"
                }
            },
            "5062A44383F2E74968287154CFC88CF840E6": {
                "t": "And we have also been betrayed by a friend...",
                "d": {
                    "cid": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "eid": "BD46D431778A44408479BB0623B8E0587E4C"
                }
            },
            "87E6EEB64BAB9443527B67575B5F7234F834": {
                "t": "... ... ...",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "1658DE296398614771499A3102B4D06A15AD"
                }
            },
            "B47162D45F7C3047274BE28932CCA4994C39": {
                "t": "dummy",
                "d": {
                    "eid": "839B73D277A0454A9B8A1C3486F9B8A8A03E"
                }
            }
        },
        "commands": [
            {
                "id": "gs.Comment",
                "params": {
                    "text": "nobody is in the party aside from Cristoph\nthird person (no POV)"
                },
                "indent": 0,
                "expanded": true
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": ""
                },
                "indent": 0,
                "uid": "65DC57D756F7B34F370A961512549FAC2B2C",
                "expanded": true
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "ED6226CB6702294B6F1AC8E4A6B214696057"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Disable Inventory?",
                        "index": 224,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "53A4DEC162C5A2406628A6A70982AE28E1B3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0EA05369512AE34EA659D9781C213678839C"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "2D020C1916A3814359783A811324EF00AF65",
                        "name": "92 - Shiori Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "0F3E4C73144D984433891DD7EFA8BA3AA8C6"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "51FE568238DE384B4F8A0356581EC6A54FA8",
                        "name": "94 - Hellios Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "47B875566CBDB246B84B1BC49796996153E2"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "0FCC16EC8F14214F211BD711C5EF156BDE65",
                        "name": "95 - Rya Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "46FE00483A8467493F992568467E951AD90B"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "567F1E3489D91446CF4A0ED6AF508D6BB339",
                        "name": "96 - Cristoph Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "C0A89F746588B14214990AA57548FFB03223"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "7A52F8DE55D159434B499B596439193E987E",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F7650613425F7648544BF1B392D8815E1ACC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A1D985ED15C11240A32B0359FDACB5E75EAB",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            "",
                            "",
                            "",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "CCEB0BE9729D934FC73A809392DAA25B78CC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "942D16A85E0B3342745815540D0D511A07B0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1FB08D2B77D26343F51A72C18D8D2E7E576F"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "047E42F83840B34B425BCF01E4C4CDB2D1E0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            10000,
                            20,
                            1,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "D67CB75B80BF0242829B6F46F482F0E09B78"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "91A3C4E9828B824E7A9BFAE1EEEC945E53DC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "EBEE121F20002749FD489FE738A6B9FB1E87"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "D339ABB57A9F554B7A28EA2267882054EFE2"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "D50085881874B04C5988003672515E5AD727",
                        "name": "C10.5-1 Geography"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6FFD9D770DB9564AB2683C88C7E45C3A1178"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C8530D9F974D45414E98E702F442F4EE8DAB",
                    "parameters": {
                        "values": [
                            "520E6346151995464C6978C1DD33BF8D3708"
                        ]
                    }
                },
                "indent": 0,
                "uid": "D9316F98324E764BC339D8F24CB599E759BA"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "907A4EBA37401442A6380AD49F0A0EB5C3E6",
                    "duration": 0,
                    "waitForCompletion": 0,
                    "opacity": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "014B629B85BB274E154A6F8247BDC3C8FEC9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A872D6620B26484A3E6BB6536AFEB98386DC",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7B44F311665885435549B3A44F49954BF9D6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "7285F1B9214BF643D3982457FE50A883F047"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CCD7FE7A87F06745578ACFE3F01B21924C5C"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "1CC7298F4D9326401A5A0054E2D48A2087FD",
                    "model": {
                        "name": "RyaChibi.model.live2d",
                        "folderPath": "Live2D/Z3 - Chibis",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 1000,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 1265,
                        "y": 465,
                        "zoom": {
                            "x": 0.11,
                            "y": 0.11,
                            "d": 0.11
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "B369FA975654724DCD5AA2C4FB2F2ABDE977",
                "expanded": false
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1CC7298F4D9326401A5A0054E2D48A2087FD",
                    "loop": 1,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "RyaChibi.model.live2d",
                            "folderPath": "Live2D/Z3 - Chibis",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "idle.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8B9414863D8FD7406C99298989C3171C81A4"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "1C6434671F58744B2B3920786DC5D13FEC06"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 10000,
                    "duration": 60,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "AD894F916258C54FDF4B99B00292C23D90AC"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 72
                },
                "indent": 0,
                "uid": "779BFF4322CDA84A3C5B0138A1E75602D4F0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "96E8865C46A6744AF298785563F5D69BB4F3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "35AF67537CDBA646E86A1543CAABAA3A9A16"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "436C78703660B649027B1B44944A971F4A83"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0A5394441DFE9942C23BB1177D61A379F547",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7FBBEE21164CA74ED65916D41E1F922E3680"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "02EF21C36393B4496049B238D012488E0ACE",
                    "parameters": {
                        "values": [
                            "9760108A5D7AD641848A7399B71F90434295",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "987981CD8855764BD158F3E5B45B9FCAFFC5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "02EF21C36393B4496049B238D012488E0ACE",
                    "parameters": {
                        "values": [
                            "EF841CF211E7354DEB797140BDA25C8C07D2",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "825739155696B649417B2F75D6EDC729D64F"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Cristoph Overworld model.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "06_Sad.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E23F11923A7F124E715AE97227344A9139E0"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 42
                },
                "indent": 0,
                "uid": "D57F91417E992743379A9FF438A2C5C697F7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D007E02518D24249142A32F1FBFB0EC659E0",
                    "parameters": {
                        "values": [
                            "EF841CF211E7354DEB797140BDA25C8C07D2",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "E8DFD78B8018424A342B3671F2666D59C5E4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D007E02518D24249142A32F1FBFB0EC659E0",
                    "parameters": {
                        "values": [
                            "9760108A5D7AD641848A7399B71F90434295",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1DEA0DD32127014D528B76A3D4BA84A5F52A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "4903610A29528743F66928D9925556CE3888"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0A4DF4BB3575F840BC8BFF42ED18245C39B6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "018CFC399FB38448DC688FF39327C50E6EF3",
                        "defaultText": "상태는 어때?"
                    },
                    "position": 0,
                    "characterId": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F318C39267799345F058EDF63EB4550BBC6A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "CB1C72D315D2F6450E6A5B2374CF23161BD0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B30828C91663B244E41BBB35AB906B5127C1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "01798D633A207346883BE1A8CBA47F0B54DE",
                        "defaultText": "체아파나가 훌륭히 치료해 줬어. 이제 죽을 고비는 넘겼어."
                    },
                    "position": 0,
                    "characterId": "9760108A5D7AD641848A7399B71F90434295",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0E97930230EDE348B0688B18D02F9AADAC98",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "041A5E1C3373B5424D3A8FF7FBC5F6171B73"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E08648603891A44AC888DD518B0EB1425E9E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CF63E7C64CBA784E828BB5449EA54432F988",
                        "defaultText": "성부께 감사드려야겠군! 정말 다행이야.\n과연 '기적의 치유사'라 불릴 만해..."
                    },
                    "position": 0,
                    "characterId": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E611CC55033DD644550846A27B4A327D2965",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "52BA91675A0E404A298B59D52BD46E9035CA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3D11AD7616366842823A41D2806641595A44"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C8FD73857DFAE84BC00B49130A3B2F9F84E4",
                        "defaultText": "성부 덕분이든 아니든, 아직 상태가 불안정해.\n당분간은 최대한 안정을 취해야 해."
                    },
                    "position": 0,
                    "characterId": "9760108A5D7AD641848A7399B71F90434295",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EC67876B3575524EAD9BDB1807CBFA222848",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "601ABDDB7962D643414B3BA511A3492AB1C6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F6BFB7C669FE804B221B11E89AFC6578ADEC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "80CB350F939A5040422ACB4294C861EF7D54",
                        "defaultText": "솔직히 말해, 그런 일을 겪고도 그릇이\n아직 살아 있다는 게 놀라워..."
                    },
                    "position": 0,
                    "characterId": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "881B212B45E2E8465128E4B8B27CA2EE7FE2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C8CB64F328282644816BB9412D6FC1DE168E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "43520A7E391E0943E179AFE6C7D21BA9B0BE",
                        "defaultText": "마왕이 풀려났잖아?\n그 과정에서 죽었어야 하는 거 아냐?"
                    },
                    "position": 0,
                    "characterId": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B56B953B3C782040D649958165E1A85D52E3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "D77E120F1BBFC4449238F10145BAF27EB451"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D4CD260D5661E048AD49B1B2132D8B6C22C5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8DE89A806EB2214B3B697F6009DDED8ACB2F",
                        "defaultText": "흠. 그때 벌어진 일을 오랫동안 곰곰이 생각해 봤어...\n그리고 한 가지 가설이 있어."
                    },
                    "position": 0,
                    "characterId": "9760108A5D7AD641848A7399B71F90434295",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5C4B9FA45EBD894651486AA6A6C08B8DB624",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3EF6FE5C145A14488D3ABCE39CA4D2F73AC0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "03EB90B42E3C2443EA49C7168D1F3AC733D2",
                        "defaultText": "우리가 아는 바로는, 마왕의 영혼을\n강제로 뽑아내면..."
                    },
                    "position": 0,
                    "characterId": "9760108A5D7AD641848A7399B71F90434295",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "424B403473844245203A66B603D7ECEB5CD0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B7340D09172A674B860A92B4541BFFCC3CE2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "86274BDA4FD1C64BAC2BC2B3F788E6573BD7",
                        "defaultText": "...그릇의 몸이 감당하지 못할 만큼 부담이 커져서\n죽게 돼."
                    },
                    "position": 0,
                    "characterId": "9760108A5D7AD641848A7399B71F90434295",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2EA53A6E12B38643997A65D2E3241DBBDA33",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "93FFF0DC8FABE8408B08F007293091EDB773"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Cristoph Overworld model.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "01_Default.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1AF6EB9B6145704B02786CB0E53A8E45A8FF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F81B377E88EE79465D3AB9980496C05EE4AB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C97538670A086049998B3F439727DC34915D",
                        "defaultText": "아, 맞다! 지난겨울에 와인 한 잔을\n밖에 내놓았던 일이 떠오르네."
                    },
                    "position": 0,
                    "characterId": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9DF9E7495FDE0445957A1BA4159C2C462D2E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D407B091732BA540BF6A35A6DA3F5511CC2A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C5B7CDF19D942546914A9FB7FEB23F45CDFC",
                        "defaultText": "돌아와 보니 액체가 꽁꽁 얼어 있었고... 쾅!"
                    },
                    "position": 0,
                    "characterId": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "ABBC671E40D2F54A09097B1186A6A167B82A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FBD119230D8A734E506878128CB0B75872BB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CFF4153B0A49514EB13B6F54571150214008",
                        "defaultText": "잔이 깨졌어! 와인도 못 마시게 됐고!"
                    },
                    "position": 0,
                    "characterId": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "106FEC83554E9546927AADF629E480D988B6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "9E0FD1DF3D9886493C89F8D3EC4C8EA27D37"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "9760108A5D7AD641848A7399B71F90434295",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Rya Overworld Model.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "04_Upset.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "90BA31116C69B342447A12B35F85A4F59B13"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3B710D994A99D14FED781061C07414CC9293"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C9A0394F99D34246E62BA62649BA3DFC2333",
                        "defaultText": "...갑자기 그 비유는 어디서 나온 거야?"
                    },
                    "position": 0,
                    "characterId": "9760108A5D7AD641848A7399B71F90434295",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "ECC6CA4239A66041616A9D768227C6D72328",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "DF4A2CDB2785854FCF6975B92F9FBE33A88F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9061CE4E9CC91447394A0068D047CAC0EC1B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "663B86917A5951458F7A71A6E14795D841F9",
                        "defaultText": "왜 그래, 리아! 나도 가끔 바보처럼 굴지만\n알 건 다 안다고!"
                    },
                    "position": 0,
                    "characterId": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "51307FA1964F4943D54AF54148DA0DD99A93",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "EC5F07BB61FFD34A0C196288729C71179B28"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "9760108A5D7AD641848A7399B71F90434295",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Rya Overworld Model.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "01_Default.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D2328DFE83B2E74F3F19D7A283EFCDF2BAB6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DB11465D7AAAD44EE15B04A767A4CBAFCFA0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FA6518AF5DF060449C198B0301820C09D04C",
                        "defaultText": "뭐, 놀랍게도... 내가 말하려던 바를\n꽤 잘 설명하긴 했어."
                    },
                    "position": 0,
                    "characterId": "9760108A5D7AD641848A7399B71F90434295",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3A483A1D323C584AA11987576E1D4C86F9A0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "10AF357803995546C4981834105CF0E6C9E0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A05BD3FC88AC38457F88E1D4C60447067F58",
                        "defaultText": "그럼 같은 비유를 계속 써 보자면..."
                    },
                    "position": 0,
                    "characterId": "9760108A5D7AD641848A7399B71F90434295",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3A85B321212AE444C8890697FA412D3E679F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A3F4B0475F3C1340904840B88875BA2BBE38"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D453CF998CC9A742129834F5026A7DB2AE46",
                        "defaultText": "마왕은 와인, 봉인은 잔,\n그릇의 마력은 추운 환경인 셈이야."
                    },
                    "position": 0,
                    "characterId": "9760108A5D7AD641848A7399B71F90434295",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A81D9A3C2F919748272B7D36A5A0EA210A72",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8A459EE17731334F1C5A4A97560FE82983E7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "96C9FDA61437D24B212874D4C7D399E77D7F",
                        "defaultText": "만약 봉인이 처음부터 완전하지 않았다면?"
                    },
                    "position": 0,
                    "characterId": "9760108A5D7AD641848A7399B71F90434295",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C9DF5C6508FFA947C11A26E309702F048871",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "18D985FA5E57C64FB51AF1E44238469B552E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "725D258B8DBEF94308787E533A60585CAD44"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9AA995EB3449C947951803B56B9ECCABBBED",
                        "defaultText": "잔에 금이 갔다는 뜻이겠지?\n와인이 몇 방울씩 새어 나왔을 거야."
                    },
                    "position": 0,
                    "characterId": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E508EEEF8855B043214A4FF10D5C27701F6E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "AA4BD6AB47196743A56BF133D89171A0FD0C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "579B99792CD8664C692B06684E482E7A9D36"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AABDF560215711427B583EA8BA7ABA64075C",
                        "defaultText": "그렇게 '헬리오스'가 태어난 거야.\n파라트라스의 봉인은 처음부터 불완전했어."
                    },
                    "position": 0,
                    "characterId": "9760108A5D7AD641848A7399B71F90434295",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2017D5846BF1B64AAE19D696AFA4F90CB376",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7D3F4E9F133A9247452B7BE65DE1A236A0F5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1386EFAE808C774D9E4A9F02772457E88B91",
                        "defaultText": "하지만 마력을 갈고닦아 21년 동안\n그 와인을 얼린 채로 유지해 냈어."
                    },
                    "position": 0,
                    "characterId": "9760108A5D7AD641848A7399B71F90434295",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F79E0C732B61C248A75AC2B5A3620CBF6B43",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "1DB0F1402D6C044B8019F910070F03DA948E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "95FF3718887DC44A9D3808E599E5A709CEAB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C5CE0C342B8678418D194D15C91355D689B4",
                        "defaultText": "아... 그래서 술에 취했을 때도\n마왕이 풀려나지 않았던 거구나."
                    },
                    "position": 0,
                    "characterId": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CD4B45FD017CA048B83A2121FD14D4AE07C6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "745DECF87C505243A5490B4988557DCF744E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A9F6D29F8DC7E4494E598BA9ABFD190C74BF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1EADF59B3DBCE547B15B20027833CE89DD65",
                        "defaultText": "맞아. 얼어붙은 와인이 든 잔을 기울여도...\n적어도 한동안은 제자리에 그대로 있겠지."
                    },
                    "position": 0,
                    "characterId": "9760108A5D7AD641848A7399B71F90434295",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D4FEA2EC6075D64FCD5AA927CC740CB0F5BF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "95F63ED61C25534DBC69DB468224750A3FA2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3779CB709DDE1643FD2BDDF52953D395C247",
                        "defaultText": "하지만 더 따뜻한 곳에 두면 어떻게 될까?"
                    },
                    "position": 0,
                    "characterId": "9760108A5D7AD641848A7399B71F90434295",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2A15FB5176A7D345D98BF2F593178AD0628B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "2629F5148FE898400B18C5F1FDF99F837F3D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0F6A889B4D6BB6442199A69705174EC99391"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BE7ECDCA2A3C0845C24A17B818C7C2854626",
                        "defaultText": "와인이 따뜻해지면서 결국 잔 밖으로 쏟아지겠지..."
                    },
                    "position": 0,
                    "characterId": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "45590719371F404D3B2A5AF662B002D9FAEF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "EDBCE9271183B74A573B6908C34B430C7D3D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2BC7DCEE6AB7F34100191C517326B9D8B97A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EE98E45B285E8546267BDC7207C91D457C36",
                        "defaultText": "그리고 잔은 멀쩡히 남아 있을 거야.\n파라트라스와 헬리오스에게도 같은 일이 벌어진 것 같아."
                    },
                    "position": 0,
                    "characterId": "9760108A5D7AD641848A7399B71F90434295",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5AE628D31E7B7249317932F2FF21F52F94E1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FE8E94FB4EC344443869D3039DADD31AEFFC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1A932E6E83DF784B581A4A6770B8737A2698",
                        "defaultText": "그자는 당시 봉인도 그녀의 마력도\n자신을 붙들지 못하게 만들었어."
                    },
                    "position": 0,
                    "characterId": "9760108A5D7AD641848A7399B71F90434295",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "968F823027C0F149A549AD61C5039CCB7192",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D3F2D39D5BDBE2488F1968A5C4590A67EC53"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8297889912EF2244331846644B88B1053963",
                        "defaultText": "그리고 온전한 힘을 지닌 채 풀려난 거야..."
                    },
                    "position": 0,
                    "characterId": "9760108A5D7AD641848A7399B71F90434295",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A6F4325907659540B19B1AC673D083FC2120",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "88BBB5CA7339B34B632B0191CF31CFE117B5"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Cristoph Overworld model.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "06_Sad.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0C9881D44265724C35094E35304BAEB987A9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "80F431F40BE63346F469B5907ACDD1006A51"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B3501C7B578254497C891CD21F5348C17034",
                        "defaultText": "정말 악랄한 계획이군. 이런 일은 전에도 없었지?"
                    },
                    "position": 0,
                    "characterId": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "95B8C320838E11474C5B1CD6C02138F971FD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "9D296F085757A94734885A66FF3E75044330"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0454EE884380E34AAB687BE31440A05B3C3B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BA1AAE1E83B5C14E177928C1B2E563B1973E",
                        "defaultText": "응... 사실 그릇이 죽을 때마다\n마왕은 조금씩 약해졌어."
                    },
                    "position": 0,
                    "characterId": "9760108A5D7AD641848A7399B71F90434295",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FBA234A451333441777B29E260248B8A4473",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2C3DDBF332342942243B12E1BDEFB0EC2993"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "78BC1D315D15C54F498BA298B2E522AE54BD",
                        "defaultText": "그래도 지금조차 엄청나게 강하고...\n게다가 불사신이지만."
                    },
                    "position": 0,
                    "characterId": "9760108A5D7AD641848A7399B71F90434295",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7075C1C454931247F39B94C6474BC9BECDDC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "A2339C567C11E740DC2946476DC0341C8706"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CAF9F2334CF3704F2A5A4721976B3C9195DF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6EBC1F657B1A904456598F9294D333BDB018",
                        "defaultText": "적어도 파라트라스 님께 더 비극적인\n후유증이 생기지는 않을 것 같아."
                    },
                    "position": 0,
                    "characterId": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1918BFC6970FF6441A199825568A6C9E20B2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "91DF535F23E28844692B6103396DDD359CEA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "D22C986473A0C74CFA59A0F148139FB56526"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5E6F54621824B24F4A3BA1D077B581A5FF3F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "85FA01548CF9A94AA28B27E3A3BB60A154E9",
                        "defaultText": "난 그렇게 확신하지 않겠어.\n때로는 마음의 상처가 육체의 상처보다 치유하기 어려우니까."
                    },
                    "position": 0,
                    "characterId": "9760108A5D7AD641848A7399B71F90434295",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0DBBB96777A5D844E259C3D437CAF1CED85F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EAC11ADF3852B146FE191AD771A9ABA84102"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "069AAEAA706E7740C29925B6E8B959F357C7",
                        "defaultText": "그건 그녀뿐 아니라 우리 모두에게도 해당돼..."
                    },
                    "position": 0,
                    "characterId": "9760108A5D7AD641848A7399B71F90434295",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "41B606AD310C514632481494EFE7EAFB68CC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "46DA5E607AABF6444C88AD944EC9CC4E62E3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A4005E061122924E555B6102822806BD0DFE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2B7AF6F93FDDF8471608BDA4F9BE8ADDC268",
                        "defaultText": "맞아... 임무에 실패해서 다들 무척 괴로워 보여."
                    },
                    "position": 0,
                    "characterId": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CA2C84D79E1C2542127BB7D340424AC1710D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B7536B4C4FDAE74ED24B012898E67B07E589"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5062A44383F2E74968287154CFC88CF840E6",
                        "defaultText": "게다가 친구에게 배신까지 당했으니..."
                    },
                    "position": 0,
                    "characterId": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BD46D431778A44408479BB0623B8E0587E4C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "23D6C5C247AC564C980811D356BAB6892FF9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "87E6EEB64BAB9443527B67575B5F7234F834",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1658DE296398614771499A3102B4D06A15AD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "84D013DD2BFD974C0B885831BF34B00FE9E7"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Cristoph Overworld model.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "01_Default.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8C1B58D0294258462A69BC18C4777BA35FE0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "D3B0C562711F044C963B1963D07045FCF2BD"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2A3833063B1D014C5899DE0621502CA4991E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "472C11C7451E4548FD48C78812D81B9287DF",
                        "defaultText": "리아, 작은 선물을 주면 좋아할까?\n꽃 같은 거 말이야."
                    },
                    "position": 0,
                    "characterId": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AE3D1F159C12E7479B9B49065B06551C813B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "4E7424303FF249452999F4F5F0966C57FC09"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "9760108A5D7AD641848A7399B71F90434295",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Rya Overworld Model.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "06_Smile.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "25503DF01D37C541302BB5E1E7FDAB5B0218"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DAEC4D7240FC9447253A71E47C24D1E301E9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A5003ECD8D20A24DF65AB377F2FDE74C9291",
                        "defaultText": "그래, 세심한 배려가 될 수도 있겠네."
                    },
                    "position": 0,
                    "characterId": "9760108A5D7AD641848A7399B71F90434295",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "19379D366D2B644B2079B2930517BB83F455",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "1156071E5DDF434FDA8AB7B6C1719A8FB566"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2B1BA1177FF5C042B8692AC2C1C6C371619F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "48BB38DE1D7E924E3C2A53726C95913D288E",
                        "defaultText": "좋아! 근처에 야생 백합이 피는 곳이 있었어."
                    },
                    "position": 0,
                    "characterId": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "38339F534EB8C64759687BD34A294A005377",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "C27E2A6A439E904A76181D9722BCC02CD7AA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "38CFEB672DAEB748133BEA587B8B318C1780"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "21D7BD8C9D2974473D79972891041A502DB8",
                        "defaultText": "너무 늦지만 마. 약 {SP:2}{C:1}50분 뒤{C:0}에는 출발해야 해."
                    },
                    "position": 0,
                    "characterId": "9760108A5D7AD641848A7399B71F90434295",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8DB50DD3027A8545AB28FA49C07F3F2613B3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "846C742A1870E4412589AB43DC62BC4B6199"
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "eyeBlink": {
                        "enabled": 0,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 1,
                    "idleIntensity": 1,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 1,
                        "idleIntensity": 1,
                        "lipSyncSensitivity": 1,
                        "eyeBlink.enabled": 0,
                        "eyeBlink.interval": 1,
                        "eyeBlink.closedMotionTime": 1,
                        "eyeBlink.closingMotionTime": 1,
                        "eyeBlink.openingMotionTime": 1
                    }
                },
                "indent": 0,
                "uid": "9AB21D78561C7841EE5ACDE88580B347A8B7",
                "expanded": false
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Cristoph Overworld model.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "02_Wink.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BCCA526975B40844F36B81974E26CA6F7A30"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A67E6A4A9634844ED659DCF52952A90011D0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D1D701F56C700548648B965556D6B3E3F6F6",
                        "defaultText": "금방 다녀올게!"
                    },
                    "position": 0,
                    "characterId": "EF841CF211E7354DEB797140BDA25C8C07D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "15BD104A6CC04742EA499054D2A7C59978DE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "0F90DF5A3D1E9841E048B5A802FF62BD76AE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6410A56314B6E248263A7A7869FA7223A315",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7AD6174A4FDB194667784AA5100F74386052"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6410A56314B6E248263A7A7869FA7223A315",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3380599E1686B64A098A6420BDA4FDD2A7D3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "212458D23DAD504CDE488802C2A4609E69F4",
                    "parameters": {
                        "values": [
                            "EF841CF211E7354DEB797140BDA25C8C07D2",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "FA978266450978423F2BBB1424A471B9BC23"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "212458D23DAD504CDE488802C2A4609E69F4",
                    "parameters": {
                        "values": [
                            "9760108A5D7AD641848A7399B71F90434295",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5480C43F4E63794FCC2B20B6316AAE5AF7F1"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "966DB2B020A97848E37AD3573EC5D67A274D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0A5394441DFE9942C23BB1177D61A379F547",
                    "parameters": {
                        "values": [
                            0,
                            1,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2961B7B2817B03489719133206ADD921B0D6"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "1CC7298F4D9326401A5A0054E2D48A2087FD",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "1FB99FB95827F14DF55AC565165AB32B5D76"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "255DD03201ED9243603B4B2854088D54622E"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "907A4EBA37401442A6380AD49F0A0EB5C3E6",
                    "duration": 36,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "8851597327DDF947F57803E598E69D16945D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "9C5EB7E55B7BE34C6D28F8C7698FB42F4338"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Unskippable Checkpoint?",
                        "index": 175,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5E3AB3754BBA784D7E5ACD817F7DBD816DDD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "29AD14B0332D894DB3981DF48FA385186F52"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "231436318BC4264E803B5831B62B9C719065"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54BC87201280674C6D79D6F8CE80F2696017",
                    "parameters": {
                        "values": [
                            50,
                            200
                        ]
                    }
                },
                "indent": 0,
                "uid": "C9AA90A33B21504944390BE1EECFC9D844EF"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo Multiuso 1",
                        "index": 1,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "B47162D45F7C3047274BE28932CCA4994C39",
                        "defaultText": "dummy"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "839B73D277A0454A9B8A1C3486F9B8A8A03E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "014700B74311554D5E1BED71404349A3F22D",
                    "parameters": {
                        "values": [
                            "C10.5",
                            200
                        ]
                    }
                },
                "indent": 0,
                "uid": "D4934945725DC34D518A6B88B567842C2674"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "F2FFEA4F7FD05047AB1AD6B79C0694B4EA0B",
                    "parameters": {
                        "values": [
                            "D3B0C562711F044C963B1963D07045FCF2BD"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7151BBC513CE4846C50B01A8F278DD2A19D3"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Già caricato Musica mappa?",
                        "index": 54,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "886C9EDB82D6F9449B2AE9371E97D66E8767"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A872D6620B26484A3E6BB6536AFEB98386DC",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            255,
                            1000
                        ]
                    }
                },
                "indent": 0,
                "uid": "F413345E0DD6F94DD7693D6520A0C656D514"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255,
                                "color": {}
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 8,
                    "number": 18999,
                    "blendMode": 0,
                    "zOrder": 4998,
                    "duration": 0,
                    "origin": 1,
                    "waitForCompletion": 0,
                    "positionType": 1,
                    "position": {
                        "x": 16,
                        "y": 968,
                        "angle": 0,
                        "zoom": 0,
                        "horizontalFlip": false,
                        "data": {
                            "x": 348,
                            "y": 186,
                            "zoom": 0.5,
                            "angle": 0,
                            "horizontalFlip": false,
                            "width": 300,
                            "height": 300
                        },
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 0
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 0,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "menu_idle.png",
                        "folderPath": "Graphics/Kath's UI/Tactical Maps UI",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "CF82CE4C89C52546906BE9E77BC369506067",
                "expanded": false
            },
            {
                "id": "gs.BlendPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 18999,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "opacity": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "43CDE49A6431834C741AF94029B9BE803992"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "755DD3397DA3A345922BF0E172F452CB2BCF"
            },
            {
                "id": "gs.BlendPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 18999,
                    "duration": 58.8,
                    "waitForCompletion": 0,
                    "opacity": 180,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "3DB3998424BCC44F748AB096BC45EF3FD8C6"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 84
                },
                "indent": 0,
                "uid": "D0CF41BA606416415859BCC7A2CF849AD7D5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E14447B6616FF74BA6793E152AC39188B848",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A3C05D287F06374412192AA45C3380367161"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "GATHERING actions"
                },
                "indent": 0,
                "uid": "5C4F156F2F97C9483C9A15948D83CF3819D8"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Imposta animazioni ed eventuali Flags"
                },
                "indent": 0,
                "uid": "8487F87365F5874111599774B5EEA1D9842F",
                "expanded": true
            },
            {
                "id": "vn.GetObjectData",
                "params": {
                    "objectType": 4,
                    "number": 0,
                    "numberDomain": "com.degica.vnm.default",
                    "layer": 0,
                    "characterId": "7DDE12079CCB2348293ADCA4E66EE4273530",
                    "field": 0,
                    "targetVariable": {
                        "name": "Testo Multiuso 1",
                        "index": 1,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3D6E633D1ED866441E7BE99844FC5F0BE84D"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Testo Multiuso 1",
                        "index": 1,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Spot attuale Agenti",
                        "index": 160,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F6F685C71C0237439E99F0C111767B5FC155"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Map Event ID 6",
                        "index": 245,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "FC19675A1438924EB4596E770605119884B9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "27A224E40959A3416A4AD256927152886E33",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "D2FC188558FBA84AC68912748CEBC462DA4F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "B8695EBE888E6741B23BCC68E63A9A39CF3B",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "EBD337037A7FD44B9D2ADE6582E8E266A804"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "Verifica Eventi",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "278CC93458C64747E259B46568BB297AFC4D"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "CHEST action"
                },
                "indent": 0,
                "uid": "0BCA424C35E2B4403E38BFF1EBB732BED090"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "- FORZIERE\n- FISHING"
                },
                "indent": 0,
                "uid": "65886C301E949141194BA398E694A01E4EDD",
                "expanded": true
            },
            {
                "id": "vn.GetObjectData",
                "params": {
                    "objectType": 4,
                    "number": 0,
                    "numberDomain": "com.degica.vnm.default",
                    "layer": 0,
                    "characterId": "CCA0B51377DD9548162AFF72F198C7D42263",
                    "field": 0,
                    "targetVariable": {
                        "name": "Testo Multiuso 1",
                        "index": 1,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B6CEFC311664A44EF21B86E888DFE1BF1FDD"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Testo Multiuso 1",
                        "index": 1,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Spot attuale Agenti",
                        "index": 160,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D3B830158257E74ED68B2589299A7985A3F0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "27A224E40959A3416A4AD256927152886E33",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "2E5785C6691EB1483A5942B105362C3FC29A"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Map Event ID 5",
                        "index": 244,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "7AC221327F00C64DCD4AA1F9AE2A8B76F2A2"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 1,
                "uid": "04B76AB856A3F7426C5B16B62F4C61725810"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "422B49CA8A63A04CB338ADD9E56A9BFB25A0",
                    "parameters": {
                        "values": [
                            "",
                            {
                                "lcId": null,
                                "defaultText": "You found some beautiful lilies."
                            },
                            "",
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "A6A7E1E158822441AA7A1003A25B21F1E661"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6FE3C1466BE6D749E93B1A1763C2A8DE2900",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "A8FBDF8E532BF64E0E9BB255B73D7832490F"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 1,
                "uid": "6F19BA657397E34FCA798C518D43218B3319"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "9CB39F5B4931E2463908D028B3241342FC14",
                        "name": "C10.5-2 (event) Found lilies"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "044AB3268548E24A976A5B257D83630BA1A5"
            },
            {
                "id": "vn.GetObjectData",
                "params": {
                    "objectType": 4,
                    "number": 0,
                    "numberDomain": "com.degica.vnm.default",
                    "layer": 0,
                    "characterId": "B283437624BBF14D283BD4E8440F30A93E8F",
                    "field": 0,
                    "targetVariable": {
                        "name": "Testo Multiuso 1",
                        "index": 1,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9F7BF3294E6C24423D78E9D1EBF3D46DEE24"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Testo Multiuso 1",
                        "index": 1,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Spot attuale Agenti",
                        "index": 160,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "68156FC9830A834CB32B6E13A981AB4CAE67"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 1,
                "uid": "FEBD59177C8ED347F859E1E4D3C0FF7FB2C7"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "1F1672CB8E981849E11A9E524A27261F9CDA",
                        "name": "C10.5-1 (scene) Faratras convo (optional)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "6A8EE98E872BC4495B1ADA82E6E367F5C80B"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Map Event ID 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "EC8184160EA8D8445A1B7FE98157C21962EC"
            },
            {
                "id": "vn.GetObjectData",
                "params": {
                    "objectType": 4,
                    "number": 0,
                    "numberDomain": "com.degica.vnm.default",
                    "layer": 0,
                    "characterId": "FD2FDA8C7119E446E019DE460E81F9CB011F",
                    "field": 0,
                    "targetVariable": {
                        "name": "Testo Multiuso 1",
                        "index": 1,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A94C1F5E01E2124CFF8B0A75B2593EC279B9"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Testo Multiuso 1",
                        "index": 1,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Spot attuale Agenti",
                        "index": 160,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "60556F9D8E62C14EDA3869264524A1B5BE2E"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 1,
                "uid": "CEBF5FFD14EC1246306A92B663193B285934"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "AC99B0C988F2B548644AE33638E367267955",
                        "name": "C10.5-1 (scene) Cristoph x Shiori convo (optional)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "E8CF78C033E7444A945893E190701C3BEC6A"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Map Event ID 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "347CFA1E4C680743CD4AA8D6924658E0E2A7"
            },
            {
                "id": "vn.GetObjectData",
                "params": {
                    "objectType": 4,
                    "number": 0,
                    "numberDomain": "com.degica.vnm.default",
                    "layer": 0,
                    "characterId": "5ADFE6332BFD1441709AD72176C41AF9A43B",
                    "field": 0,
                    "targetVariable": {
                        "name": "Testo Multiuso 1",
                        "index": 1,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8C8E5A625AB43445AB4BBBC53AB45EC9D8B0"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Testo Multiuso 1",
                        "index": 1,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Spot attuale Agenti",
                        "index": 160,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2EABE8441DCB9643C00B9AD42638C867081C"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 1,
                "uid": "AE56D82B3D6627448E6B9A8141B9BB449D6A"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "5C177F838AB6C7464E5BC312C1AB976C532C",
                        "name": "C10.5-1 (scene) Ornières convo (optional)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "A9FFD6333D27A6475D5B94580FB243F4F9CE"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Map Event ID 4",
                        "index": 243,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "1F0F48408522D24AFB0B7485F1E038CEFC07"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "Verifica Eventi",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "EDED79298B67474EE9189EB52644B0FEFBF5"
            },
            {
                "id": "gs.Idle",
                "params": {},
                "indent": 0,
                "uid": "37194C9441EB434AD1482DA73B441DA4A49B"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "Verifica Eventi"
                },
                "indent": 0,
                "uid": "A29A37E39F9726419D1B67449645244D404A"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Time out"
                },
                "indent": 0,
                "uid": "5F43DA2847ED7940F27AFF4738EDF5228565",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "15224E583986C649652961F8D83C325E97D6",
                    "parameters": {
                        "values": [
                            2,
                            10,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "081362CD0EA3B94FE948C3F0C6E2DD44CE65"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "05CBAE5086732244B44B95C6D098FB1B85D1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            4
                        ]
                    }
                },
                "indent": 1,
                "uid": "30FF1416682A5240DE8BC056B2160FDC95CF"
            },
            {
                "id": "gs.StopMusic",
                "params": {
                    "layer": 10,
                    "fadeOutDuration": 75,
                    "fieldFlags": {
                        "fadeOutDuration": 0
                    }
                },
                "indent": 1,
                "uid": "DBD3EEA72D4B544E916A2731C6873EBC8209",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 90
                },
                "indent": 1,
                "uid": "0CDCF5DD86FE344B0D7B23E09BE9F8479518"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "8D8419855F68B14C0A6875F49D09164805E4",
                        "name": "C10.5-1 (event) Time out"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "1E3584197089584B364A6C51E2BCDB9B2A67"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 1,
                "uid": "6FE27AE261A9364FC97ACB43223DBFC4A9AB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            20000,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "12367216819C64437B3BC401BA735C014BA6"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 1,
                "uid": "971FFD713C0AA34AB87AF752187E4E8D4361"
            },
            {
                "id": "gs.FreezeScreen",
                "params": {},
                "indent": 1,
                "uid": "7D28AD976F56354FE6284068AA13B8E097A9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6A43C24760A7F244F54A6AB0E4E0A0AD7E9A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "BD513FEA359E474AA37967A03A221434538B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E4E5AEFC3F1CF04918390514BA99F20D3AFC",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "2580524B6FA01347AE3A8D95335135B9FE65"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 1,
                "uid": "4D3FDDB72071C2407D6975148D4148A85A18"
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "E37080BA18C7044DF79A45B12CBFA6B9D19B",
                        "name": "C10.5-2 Travel to Magnolia (World Map)"
                    },
                    "savePrevious": 0,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "1BB129E1865A414DEF5AC2D0A9D8FD17C4C9",
                "expanded": false
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "Verifica Turni",
                    "target": "activeScene"
                },
                "indent": 0,
                "uid": "AEC7D2278F7D1840BB7B14B4BC64B4934405"
            }
        ],
        "livePreviewDisabled": true,
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}