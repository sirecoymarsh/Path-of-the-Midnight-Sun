GS.dataCache['1A9DCD2732248245DD4904A9405A663193BA'] = {
    "uid": "1A9DCD2732248245DD4904A9405A663193BA",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "Settimo pg",
        "type": "data_record",
        "order": 8,
        "category": "characters",
        "id": "1A9DCD2732248245DD4904A9405A663193BA",
        "isFolder": false,
        "data": {
            "name": {
                "lcId": "12B743F23BFAE2441788DBE71F1B8C159DCC",
                "defaultText": "셉티머스"
            },
            "textColor": {
                "red": 169,
                "green": 0,
                "blue": 10,
                "alpha": 255
            },
            "defaultExpressionId": "29EA7512216723424B68FC415955D15F2170",
            "timeTalkingToVoiceVolume": true,
            "talkingVolume": 5,
            "params": [
                {
                    "name": "First name",
                    "type": 2,
                    "value": "Septimus"
                },
                {
                    "name": "Livello",
                    "type": 0,
                    "value": 1
                },
                {
                    "name": "Esperienza",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Esp. al prossimo livello",
                    "type": 0,
                    "value": 2000
                },
                {
                    "name": "Esp. complessiva livello",
                    "type": 0,
                    "value": 2000
                },
                {
                    "name": "Esp. che avanza",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Punti Abilità",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Mente",
                    "type": 0,
                    "value": 100
                },
                {
                    "name": "Sazietà",
                    "type": 0,
                    "value": 9
                },
                {
                    "name": "Salute MAX",
                    "type": 0,
                    "value": 410
                },
                {
                    "name": "Salute Attuale",
                    "type": 0,
                    "value": 410
                },
                {
                    "name": "Salute Base",
                    "type": 0,
                    "value": 410
                },
                {
                    "name": "Salute Growth",
                    "type": 0,
                    "value": 20
                },
                {
                    "name": "KO",
                    "type": 1,
                    "value": 0
                },
                {
                    "name": "Mana-gen",
                    "type": 0,
                    "value": 9
                },
                {
                    "name": "Managen base",
                    "type": 0,
                    "value": 9
                },
                {
                    "name": "Managen Growth",
                    "type": 0,
                    "value": 9
                },
                {
                    "name": "Punti Mana",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Punti Mana MAX",
                    "type": 0,
                    "value": 24
                },
                {
                    "name": "Attacco",
                    "type": 0,
                    "value": 120
                },
                {
                    "name": "Attacco base",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Attacco Growth",
                    "type": 0,
                    "value": 30
                },
                {
                    "name": "Difesa",
                    "type": 0,
                    "value": 70
                },
                {
                    "name": "Difesa base",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Difesa Growth",
                    "type": 0,
                    "value": 30
                },
                {
                    "name": "Velocità",
                    "type": 0,
                    "value": 40
                },
                {
                    "name": "Velocità base",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Velocità Growth",
                    "type": 0,
                    "value": 30
                },
                {
                    "name": "Critico",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Attacco Fuoco",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Attacco Fulmine",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Attacco Vento",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Attacco Ghiaccio",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Attacco Ombra",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Attacco Luce",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Resistenza Fuoco",
                    "type": 2,
                    "value": "0,0,0"
                },
                {
                    "name": "Resistenza Fulmine",
                    "type": 2,
                    "value": "0,0,0"
                },
                {
                    "name": "Resistenza Vento",
                    "type": 2,
                    "value": "0,0,0"
                },
                {
                    "name": "Resistenza Ghiaccio",
                    "type": 2,
                    "value": "0,0,0"
                },
                {
                    "name": "Resistenza Ombra",
                    "type": 2,
                    "value": "0,0,0"
                },
                {
                    "name": "Resistenza Luce",
                    "type": 2,
                    "value": "0,0,0"
                },
                {
                    "name": "Turni Regen",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Turni Scottatura",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Turni Cecità",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Turni Veleno",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Turni Paralisi",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Turni Confusione",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Turni Sanguinamento",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Turni Ubriaco",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Turni Terrore",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Turni Blight",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Resistenza Scottatura",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Resistenza Cecità",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Resistenza Veleno",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Resistenza Paralisi",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Resistenza Confusione",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Resistenza Sanguinamento",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Resistenza Ubriaco",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Resistenza Terrore",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Resistenza Blight",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Bonus/Malus Attacco",
                    "type": 2,
                    "value": "0,0"
                },
                {
                    "name": "Bonus/Malus Difesa",
                    "type": 2,
                    "value": "0,0"
                },
                {
                    "name": "Bonus/Malus Velocità",
                    "type": 2,
                    "value": "0,0"
                },
                {
                    "name": "Bonus GUARDIA",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Item in uso",
                    "type": 2,
                    "value": "Vuoto"
                },
                {
                    "name": "Danno accumulato",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Slot attuale in formazione",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "ID icona Turn Order",
                    "type": 0,
                    "value": 0
                },
                {
                    "name": "Arma",
                    "type": 2,
                    "value": "Vuoto"
                },
                {
                    "name": "Testa",
                    "type": 2,
                    "value": "Vuoto"
                },
                {
                    "name": "Scudo",
                    "type": 2,
                    "value": "Vuoto"
                },
                {
                    "name": "Corpo",
                    "type": 2,
                    "value": "Vuoto"
                },
                {
                    "name": "Accessorio 1",
                    "type": 2,
                    "value": "Vuoto"
                },
                {
                    "name": "Accessorio 2",
                    "type": 2,
                    "value": "Vuoto"
                },
                {
                    "name": "Cibo preferito 1",
                    "type": 0,
                    "value": 1
                },
                {
                    "name": "Cibo preferito 2",
                    "type": 0,
                    "value": 7
                },
                {
                    "name": "Cibo odiato",
                    "type": 0,
                    "value": 5
                }
            ],
            "index": "1A9DCD2732248245DD4904A9405A663193BA"
        },
        "localizableStrings": {
            "12B743F23BFAE2441788DBE71F1B8C159DCC": {
                "t": "Settimo pg",
                "d": {
                    "eid": "48B09CB1157C9844564945E694105223C84F"
                }
            }
        },
        "parentId": "ROOT",
        "uid": "48B09CB1157C9844564945E694105223C84F"
    },
    "summary": [
        "name",
        "type",
        "order"
    ],
    "externalItems": []
}