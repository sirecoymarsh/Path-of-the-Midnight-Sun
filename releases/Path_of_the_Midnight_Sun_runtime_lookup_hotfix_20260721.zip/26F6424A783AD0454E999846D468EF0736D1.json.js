GS.dataCache['26F6424A783AD0454E999846D468EF0736D1'] = {
    "uid": "26F6424A783AD0454E999846D468EF0736D1",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "Names & Descriptions of all Quests in the game (to GT:315/316)",
        "type": "data_record",
        "order": 2,
        "category": "commonEvents",
        "id": "26F6424A783AD0454E999846D468EF0736D1",
        "isFolder": false,
        "data": {
            "name": "Names & Descriptions of all Quests in the game (to GT:315/316)",
            "startCondition": 0,
            "conditionEnabled": false,
            "parallel": false,
            "autoPreload": false,
            "singleInstance": false,
            "inline": false,
            "parameters": [
                {
                    "label": "input",
                    "type": 3,
                    "stringVariable": {
                        "name": "name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "stringValueType": "text",
                    "stringValueLocalizable": false
                }
            ],
            "commands": [
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 1,
                        "target": 0,
                        "sourceVariable": {
                            "name": "name",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": "",
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output 2 for Translations",
                            "index": 315,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": "",
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "name",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "Dearly beloved",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "1B85B9FB1438E64CD12A1042045A6EFA1DBC",
                            "defaultText": "사랑하는 여러분"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "5F07355B089607415D18645649A53FA7CA67",
                    "expanded": true
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output 2 for Translations",
                            "index": 315,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "763B54C4661B684E7C68A0D33D7D1496310B",
                            "defaultText": "\"나의 사랑스러운 토비아스가 아직 돌아오지 않았습니다! 그는 나에게 숲에서\n\"선물\"을 가져오겠다고 말했고 우리는 오늘 밤 데이트를 하기로 했습니다. 하지만\n그는 이미 몇 시간이나 늦었습니다... 뭔가 끔찍한 일이 일어났을지도 모른다는\n걱정이 됩니다. 저를 대신해 조사해 주실 수 있습니까?\"- 셀리아"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "65F03AB06D119144378863125D647AFE286E",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "name",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "A rat--her obnoxious issue",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "7B8EDFD420712548C0585AD747B669ACE942"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "3102B5904925184905880AC542B56B312505",
                            "defaultText": "쥐 - 그녀의 불쾌한 문제"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "72E7D86D7741584D5478F3127AFE7ACF7B17",
                    "expanded": true
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output 2 for Translations",
                            "index": 315,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "FC414D2628186743242AD2D438D459690D5C",
                            "defaultText": "\"지난 3주 동안 고객들은 방 주변에서 짜증나는 소음이 들린다고 불평했습니다.\n확실히 구석구석에 들어가기를 좋아하는 저 빌어먹을 쥐새끼들입니다! 그들은 심지어\n새 시즌을 위한 제 식량을 우적우적 먹어치우고 있습니다... 파! 저들을\n방해하지 마세요!\"- 아를렌"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "3E925AF299FC07462C4BFE14B001D05EA845",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "name",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "The bard's request",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "063DC88A1D881646746A0866F6CE1F334C35"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "D0FD9BF371C58745E8582817279A61B65942",
                            "defaultText": "음유시인의 부탁"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "9D2FD79E9C6FD842789BBBF11E1BE3FA8612",
                    "expanded": true
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output 2 for Translations",
                            "index": 315,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "FD48AE927E7B144EDA28C3C1BE0E83857D15",
                            "defaultText": "\"불타는 마음은 오직 검증만을 추구합니다. 악의 냄새가 나는 숲에서 저주의\n불꽃을 찾습니다.\"- 칼레발라"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "238EEF028A2828423D6945E4BC55DAFEBB05",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "name",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "\"Her\" wild potato",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "BB7086332D50464BC23888D61655AB8E09C2"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "A074A7D4990A48436558C772655713294CBB",
                            "defaultText": "\"그녀\"의 야생 감자"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "082CCC6D693ED147E53BBF298CF5176FDD9B",
                    "expanded": true
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output 2 for Translations",
                            "index": 315,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "7B3B751D59D8F345F27A4175A57DEC3826F9",
                            "defaultText": "\"내 수프는 비보레라에서 최고! 아, 버섯과 멧돼지 고기가 섞인 크림의 달콤한\n향기... 감자만 있으면 요리가 완성될 거예요. 하지만 감자만 있으면 안 돼요!\n야생 감자! 비보레라가 몬스터와 싸우고 맛있는 덩이줄기를 수확하는 용감한\n모험가들과 함께 기어다니는 게 정말 행운이에요.\"- 그녀의 아내"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "CE4CE4130C43F94A1699AA694728FE90C341",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "name",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "Creamy request",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B1FDA1EA7E367449213894F0040F19E1F3A2"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "58ACE14F5F8DB942984ADA81AF8170327121",
                            "defaultText": "크리미한 요청"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "DC3891F673F4784A042B4AF56C086D486D3A",
                    "expanded": true
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output 2 for Translations",
                            "index": 315,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "ECA46D9A18E4D14FFD89FF85E0483D33402B",
                            "defaultText": "\"안드레용 아이스크림을 만들어 보세요. 아까 도살나비에서 얻은 얼음을 사용하면\n됩니다. 다른 재료는 이 근처에서 쉽게 찾을 수 있습니다.\"- 리아"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "FA63186A7A882847FC8865030BF5C9CAA86D",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "name",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "The bard's riddle",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9CF03D9D2330C84261290823DEF4D4713B7F"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "0403909E765EA6488C6BD1C7754CC0D22DA0",
                            "defaultText": "음유시인의 수수께끼"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "4D5C0F2D60BBF1406A8A26E15636720531E5",
                    "expanded": true
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output 2 for Translations",
                            "index": 315,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "EC6C1398474AA746344A0530E33C501A0F20",
                            "defaultText": "\"이 부스에는 세 가지 단서가 흩어져 있습니다. 진실을 위해 그것들을\n찾아보실래요?\"- 칼레발라"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "E8FAC5D99E2128480A8B506865C903FAFAC2",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "name",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "The SQUINKING",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F4A5A01E847D514F848813B43E3AB0AC5FE6"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "FA8FE8A409E0E54F647B1B50AE78159BCC96",
                            "defaultText": "스퀸킹"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "C089B3621DF4F84675595F7783DD22357639",
                    "expanded": true
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output 2 for Translations",
                            "index": 315,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "6869C92B5FCEC84E024BE9359CD6B742328F",
                            "defaultText": "\"내 친구가 스퀸크의 강력한 지배자를 사냥해 달라고 부탁했습니다! 그\n이름은... 스퀸킹입니다! 퀘스트에 이렇게 신나는 건 오랜만이에요, 마아아아아!\n보상도 그만한 가치가 있어요! 이 탐험에 적합한 팀을 찾을 수만 있다면...\"\n- 아주라이트"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "C927166F77D3A0462E3B79051C7A584FDDF8",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "name",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "I LOVE YOU",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4A8BAC9B633D0547BA0A8019E4B5CE66B568"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "8FF52F2463EE24420F8871964DC820A5EB57",
                            "defaultText": "사랑해요"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "F08F198011B7B245D23A90A3F406D9851C38",
                    "expanded": true
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output 2 for Translations",
                            "index": 315,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "04D25C281F0940435739005828D769D1F434",
                            "defaultText": "\"독 2병을 가져오세요. 오오오오오!!\"- 당신과 어울리는 스타 xoxo"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "6FA9AC6B125146439F9A62C8F6A7CE29E0DF",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElseIf",
                    "params": {
                        "variable": {
                            "name": "name",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "Pixie Incense is the best!",
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "7B5527DA62364046C66A8E8837688396EAEF"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "0EDEDB2833C2D649A288E810032D11076C07",
                            "defaultText": "픽시 향이 최고예요!"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "410367288EEF534AEB493379156A1881980D",
                    "expanded": true
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output 2 for Translations",
                            "index": 315,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "BDD459994256D846FF1BA328B63BA0611C14",
                            "defaultText": "\"환자의 몸이 별로 좋지 않으니 다음이 필요합니다. 약초 7개, 영혼 가루\n1개, 단단한 나무 2개 시오리 이거 좀 구해 주실 수 있나요?\"- 체아파나"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "088A5FD947EB78410E680426E0B7BB3AFAE4",
                    "expanded": true
                }
            ],
            "index": "26F6424A783AD0454E999846D468EF0736D1",
            "booleanVariables": [
                {
                    "name": "",
                    "index": 0,
                    "scope": 0
                }
            ],
            "numberVariables": [
                {
                    "name": "",
                    "index": 0,
                    "scope": 0
                }
            ],
            "stringVariables": [
                {
                    "name": "name",
                    "index": 0,
                    "scope": 0,
                    "domain": "com.degica.vnm.default"
                }
            ],
            "listVariables": [
                {
                    "name": "",
                    "index": 0,
                    "scope": 0
                }
            ]
        },
        "localizableStrings": {
            "1B85B9FB1438E64CD12A1042045A6EFA1DBC": {
                "t": "Dearly beloved",
                "d": {
                    "eid": "5F07355B089607415D18645649A53FA7CA67"
                }
            },
            "763B54C4661B684E7C68A0D33D7D1496310B": {
                "t": "\"My sweet Tobias is not back yet! He had said that he\nwould bring me \"a present\" from the forest, and we had\na date for tonight. But he is already many hours late...\nI'm afraid that something terrible may have happened.\nCould you look into it for me?\"\n- Celia",
                "d": {
                    "eid": "65F03AB06D119144378863125D647AFE286E"
                }
            },
            "3102B5904925184905880AC542B56B312505": {
                "t": "A rat--her obnoxious issue",
                "d": {
                    "eid": "72E7D86D7741584D5478F3127AFE7ACF7B17"
                }
            },
            "FC414D2628186743242AD2D438D459690D5C": {
                "t": "\"For the past three weeks, the customers have complained about hearing\nannoying noises around the rooms. It's definitely those damn ratapults\nthat love to get into every nook and cranny! They're even munching on\nmy provisions for the new season... Pah! Get them out of my way!\"\n- Arlene",
                "d": {
                    "eid": "3E925AF299FC07462C4BFE14B001D05EA845"
                }
            },
            "D0FD9BF371C58745E8582817279A61B65942": {
                "t": "The bard's request",
                "d": {
                    "eid": "9D2FD79E9C6FD842789BBBF11E1BE3FA8612"
                }
            },
            "FD48AE927E7B144EDA28C3C1BE0E83857D15": {
                "t": "\"A burning heart seeks\nnothing but validation.\nIn the forest where malice reeks\nfind the flames of damnation.\"\n- Kalevala",
                "d": {
                    "eid": "238EEF028A2828423D6945E4BC55DAFEBB05"
                }
            },
            "A074A7D4990A48436558C772655713294CBB": {
                "t": "\"Her\" wild potato",
                "d": {
                    "eid": "082CCC6D693ED147E53BBF298CF5176FDD9B"
                }
            },
            "7B3B751D59D8F345F27A4175A57DEC3826F9": {
                "t": "\"My soup is the best in Viborera! Ah, the sweet fragrance of cream mixed\nwith mushrooms and boar meat... I just need some potatoes and I'll be\nable to complete my dish. But not just ANY potatoes! Wild potatoes!\nI'm so lucky that Viborera is crawling with brave adventurers who'd\nfight off some monsters and harvest those delicious tubers.\"\n- Her wife",
                "d": {
                    "eid": "CE4CE4130C43F94A1699AA694728FE90C341"
                }
            },
            "58ACE14F5F8DB942984ADA81AF8170327121": {
                "t": "Creamy request",
                "d": {
                    "eid": "DC3891F673F4784A042B4AF56C086D486D3A"
                }
            },
            "ECA46D9A18E4D14FFD89FF85E0483D33402B": {
                "t": "\"Make ice cream for Andre.\nYou can use the ice we got from the butcherflies earlier.\nYou can easily find the other ingredients around here.\"\n- Rya",
                "d": {
                    "eid": "FA63186A7A882847FC8865030BF5C9CAA86D"
                }
            },
            "0403909E765EA6488C6BD1C7754CC0D22DA0": {
                "t": "The bard's riddle",
                "d": {
                    "eid": "4D5C0F2D60BBF1406A8A26E15636720531E5"
                }
            },
            "EC6C1398474AA746344A0530E33C501A0F20": {
                "t": "\"Three clues are scattered in this booth,\ncare to search for them for the sake of truth?\"\n- Kalevala",
                "d": {
                    "eid": "E8FAC5D99E2128480A8B506865C903FAFAC2"
                }
            },
            "FA8FE8A409E0E54F647B1B50AE78159BCC96": {
                "t": "The SQUINKING",
                "d": {
                    "eid": "C089B3621DF4F84675595F7783DD22357639"
                }
            },
            "6869C92B5FCEC84E024BE9359CD6B742328F": {
                "t": "\"A friend of mine asked me to hunt the powerful ruler of squinks!\nBehold, its name is... SQUINKING! It's been a while since I've been\nthis excited about a quest, maaaaan! The reward is absolutely worth\nit, too! If only I could find a suitable TEAM for this expedition...\"\n- Azurite",
                "d": {
                    "eid": "C927166F77D3A0462E3B79051C7A584FDDF8"
                }
            },
            "8FF52F2463EE24420F8871964DC820A5EB57": {
                "t": "I LOVE YOU",
                "d": {
                    "eid": "F08F198011B7B245D23A90A3F406D9851C38"
                }
            },
            "04D25C281F0940435739005828D769D1F434": {
                "t": "\"Bring me 2 bottles of poison.\nOHOHOHOH!!\"\n- your matching star xoxo",
                "d": {
                    "eid": "6FA9AC6B125146439F9A62C8F6A7CE29E0DF"
                }
            },
            "0EDEDB2833C2D649A288E810032D11076C07": {
                "t": "Pixie Incense is the best!",
                "d": {
                    "eid": "410367288EEF534AEB493379156A1881980D"
                }
            },
            "BDD459994256D846FF1BA328B63BA0611C14": {
                "t": "\"A patient isn't feeling very well, so I need the following:\n7x Medicinal Herb, 1x Soul Dust, 2x Hard Wood\nCan you get these for me, Shiori?\"\n- Ceapana",
                "d": {
                    "eid": "088A5FD947EB78410E680426E0B7BB3AFAE4"
                }
            }
        },
        "parentId": "6ED66A9042ECB3444948D814E41FB327288F"
    },
    "summary": [
        "name",
        "type",
        "order"
    ],
    "externalItems": []
}
