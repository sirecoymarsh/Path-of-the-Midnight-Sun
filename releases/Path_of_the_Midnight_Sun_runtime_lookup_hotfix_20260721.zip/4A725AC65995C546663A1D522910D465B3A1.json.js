GS.dataCache['4A725AC65995C546663A1D522910D465B3A1'] = {
    "uid": "4A725AC65995C546663A1D522910D465B3A1",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C6-01 Rya and Ornieres training (night)",
        "type": "vn.scene",
        "parentId": "D114372C8BA57244E87B5C53EF9DFA983139",
        "chapterUid": "6C9C582F416E10408F5A6150A01276B7C148",
        "order": 0,
        "localizableStrings": {
            "1EB64F47015CA14D9129C0767C35CE2EDCD2": {
                "t": "{LT:1}...",
                "d": {
                    "cid": "20C0FB5290F42141CD9B31546916D5A3D73C",
                    "eid": "8B1B9D6F409C974A5C2B4861B552630D29A0"
                }
            },
            "866A32952ED0144B4F089716519D5195A5A9": {
                "t": "Kill them... all... Ornières...",
                "d": {
                    "cid": "20C0FB5290F42141CD9B31546916D5A3D73C",
                    "eid": "918D8AAE4209E64F4889FD882AECE09BE6B2"
                }
            },
            "FACCFAF4891CB74B4249F8B5B420D672E86E": {
                "t": "That's your... {SP:1}{C:1}fate{C:0}... the one I thrust upon you...",
                "d": {
                    "cid": "20C0FB5290F42141CD9B31546916D5A3D73C",
                    "eid": "C9BBD4C71C2936494879FB680E10534E7E7B"
                }
            },
            "5C8ED1F7453E66424C9A23478C83816827FA": {
                "t": "Find yourself... once again... Kill them...",
                "d": {
                    "cid": "20C0FB5290F42141CD9B31546916D5A3D73C",
                    "eid": "E287387A62BEE84D8B880068BAF34AB2C09E"
                }
            },
            "9A0A38AF588AA742DC481A05414913F8C673": {
                "t": "Kill kill kill kill...",
                "d": {
                    "cid": "20C0FB5290F42141CD9B31546916D5A3D73C",
                    "eid": "19DDCFC26AEF1347FE496973B898CDFEC803"
                }
            },
            "BD468C8E48113346E01BE3A41EAF700FD792": {
                "t": "Woot woot woot woot!!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "37A1D94632A3B745B3894017CE1CBF0038C4"
                }
            },
            "5619C3EA786BF148E72822D0207B4BE2DC6A": {
                "t": "Nnnngh...",
                "d": {
                    "cid": 0,
                    "eid": "6FCA81B95380D844A519D823E134FCFC8807"
                }
            },
            "12F3035B185CE44F6A4BEEE77CAE059A4442": {
                "t": "What... was that? Another strange vision...\nNo. Was it a memory?",
                "d": {
                    "cid": 0,
                    "eid": "AB05C5DA85F3154A0A0B6CB60A65EA148DB5"
                }
            },
            "7314C2589435944E7C38F0B02F687FA8442E": {
                "t": "Wooooot...",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "DD725034403B4746B2897DC265D23C157580"
                }
            },
            "8B3693E842D2484A9B4B82B5FDF32D022E80": {
                "t": "Sorry, little one. I didn't mean to make you worry. I just closed my eyes for a minute, and...",
                "d": {
                    "cid": 0,
                    "eid": "97EA6EFA49C717438C48FB66A5EAD53B5586"
                }
            },
            "7A35AC6B21A95547393B0D681D65C046D187": {
                "t": "And you passed out, didn't you?",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "8D56F595640352434F1AF43918544D23D69D"
                }
            },
            "9A6AC86E1E9FC244597B11B486E23FBF3BAA": {
                "t": "Princess Rya...",
                "d": {
                    "cid": 0,
                    "eid": "83D65FF75FF8A345562B03220387906A01EE"
                }
            },
            "97437AE664F5E647D258B1B53D89CB6F8AC5": {
                "t": "I didn't know you were into sleeping men...",
                "d": {
                    "eid": "F5CDBFB8011CD54E5F6B0505EAED0D2B0422"
                }
            },
            "78C6D5F8854E8148E79AB9060E0650EE6004": {
                "t": "I'm funnier when I'm awake, I swear!",
                "d": {
                    "eid": "23C199E97DAC934EEC0A5D9549527832C2B3"
                }
            },
            "B5119468121E504B7758E8E6819C7AB971DC": {
                "t": "I'm sorry you had to see me like this.",
                "d": {
                    "eid": "EC87D2523A22444AEB796898C82C425B98E1"
                }
            },
            "F0E3D0EF75FED148A438E3E09F3D14753B8B": {
                "t": "I take that as an insult. It wasn't funny at all.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "8231D9B03275E148EA080E3416B7327216E1"
                }
            },
            "5B8DA8C88D966446DF4A9557151B90E7A2F6": {
                "t": "C'mon Princess, I was just kidding...",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "59E37C282E62D54E4D484E1170E2835A08D7"
                }
            },
            "8EA087EA828BC14F983A3C77019CE8EC6752": {
                "t": "She seems really sensitive to the topic... Although I admit it wasn't exactly a good joke.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "89F003BB78409445B4299D35CFB1AE90E4AB"
                }
            },
            "95989C602783D1423D7B4CB251A7C7BB3B4D": {
                "t": "Hah. Being \"funny\" wasn't necessarily one of your best traits.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "5D54D2CA05EC1044903A431034DA111799D0"
                }
            },
            "01E01B710FD9C245A08B0DE846B28B02CB65": {
                "t": "It is now, though! Take that, Princess!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "6CF50E34175BD748788A83688317545E5864"
                }
            },
            "8336C7016096E345A92B024868DF45741E55": {
                "t": "That was indeed quite different from what I'd expected of you, but I appreciate your honesty.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "D5DDD05812315440D31BB1926A80BB6132D8"
                }
            },
            "DB611C00558C3947B3793B55288B6C773051": {
                "t": "I don't want these visions to keep dictating my behavior from now on... I wonder if I can do something about them.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "16ACD32B2524984C3A6B41C873294F297D95"
                }
            },
            "B56C8AB41EC6854930496A06AA5336810BA9": {
                "t": "Whatever. If you're done making a spectacle out of yourself, let's resume our training.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "9B8994BB3418A4445F1B8431CD8A2415017C"
                }
            },
            "813DD6EB15D92045C6383AF7953A90E4E595": {
                "t": "Training? Oh, right... The Manacrest.",
                "d": {
                    "cid": 0,
                    "eid": "8C9724248666C844D32840088E9457889EAB"
                }
            },
            "B2FC19734947E14E508B93476D270BA11756": {
                "t": "No butcherflies this time, don't worry. We're just going to... talk.\nAny objections?",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "9D41B3CF43088444B14BC928A760E5C29DFD"
                }
            },
            "CC392CAA54CF774C91995CF6FADFB49840B9": {
                "t": "I think we're good. So, what did you want to talk about?",
                "d": {
                    "cid": 0,
                    "eid": "B9DF06CD7A72F541BE88BD02508D9F2A7BA8"
                }
            },
            "97647DE39A1C2444705B62F61851006E77E0": {
                "t": "For starters, just tell me if you've noticed something different in the Manacrest.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "C74416D154EBC34C4818EAF76238EED1681D"
                }
            },
            "1308CC2D4B4FC24BFD2BE8E1E63421AD5DC7": {
                "t": "I did, but I can't explain why in particular.",
                "d": {
                    "eid": "6D50B1996786714D1789908686078028AAAE"
                }
            },
            "EB4807C4702E414DAF49BAC64479BFFC4893": {
                "t": "It absorbed the Mana from our battles.",
                "d": {
                    "eid": "E1704F5F10054840C43A5F0717797360C169"
                }
            },
            "0EBA70089C7CF0474339DC238FCBD8B8301A": {
                "t": "It feels somewhat more powerful now.",
                "d": {
                    "eid": "2A89F32F1F8669430228D00877ACA3E5279B"
                }
            },
            "097B50AC4C860046F16851C8BBE8DD51E3E5": {
                "t": "I see. Well, that result had to be expected.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "991F7FC68B42534D4C3868F7C007FACD1BB5"
                }
            },
            "C3093C889622674F6869A6243C1192C21B46": {
                "t": "The question is... What are you going to do with all the Mana that's being {SP:2}{C:1}stored{C:0} in there?",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "F389A1E477498442F84A32E05AEDF4A0FC72"
                }
            },
            "874AAF8B7A0E594C3E7B3E489E58387962F5": {
                "t": "Well, huh...",
                "d": {
                    "cid": 0,
                    "eid": "CFB7201530DA42469D186F3712C60CDB3BAB"
                }
            },
            "483D663A78F2B6467F38E414B4CA3204F2A1": {
                "t": "Woot woot woot!!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "904A22F782200744BE28AC948B7F831AF97F"
                }
            },
            "027F694C7FA553410B38B5435FA1B533397B": {
                "t": "No, Luckos. I'm not feeding it to you. And actually, is this the reason you've been following me all this time?",
                "d": {
                    "cid": 0,
                    "eid": "C5BE4DDB779BB949C03A03123B781CAF622B"
                }
            },
            "7AB5922E80EB4645EB181324149A6B405666": {
                "t": "Wooooot...",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "107127038CE06345E77BD978E8E5ECD8EA57"
                }
            },
            "65E359D32336174533997B33ABD2BF1E8D3D": {
                "t": "Hmph. Well, I can suggest better ways of using it than as mere... dog food.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "76FC56987FDFD549231B9BC599C6C675ABAF"
                }
            },
            "CB89743F4C983749BA2AEBF11D54292F425F": {
                "t": "You could... {SP:2}{C:1}enhance our abilities{C:0} with that Mana, for example.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "6E3130F92824314BA8191844B2A4F17ACE77"
                }
            },
            "7BDF072C9D5236479F481AD13BB8173C7D20": {
                "t": "I'm the ultimate buffer, then!",
                "d": {
                    "eid": "84E94C127198524E5799D9273796B7926918"
                }
            },
            "6087A8F629F3C7493C5876C9712D95CFE0B7": {
                "t": "Enhance... how?",
                "d": {
                    "eid": "EA7CEED910B4764C982AFFB1B6F61C18334D"
                }
            },
            "FEDDABEF8248C5442F5A611427A5E613B869": {
                "t": "N-Never mind.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "A98BB568570AC74E8F38AA07FBBA55F5AE8D"
                }
            },
            "FB8040A6700EF141C999C66416B7760FA4A9": {
                "t": "Allow me to explain.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "5C5A220330C80249E76A28A700A2730A89F9"
                }
            },
            "3FC994461FD68542FB5BC6F0ADEE54B42B0F": {
                "t": "I'm... surprised. I didn't know that the Mana I've stored could be used this way.",
                "d": {
                    "cid": 0,
                    "eid": "71BF03A2356FF44412995730D65D040D87C7"
                }
            },
            "93AA7C753C8AC74AE989ADD33C2958712BD0": {
                "t": "It's a precious power. It's no stretch to say that it's unique in the world.\nUse it wisely.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "DD5FACB27837434FD66903C1010963B25AE0"
                }
            },
            "E974DD5A3FC3884714884C06E5FA41DBC73E": {
                "t": "Now, if only you could use that Mana for casting spells... I wonder what rare heights you'd reach.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "8FD517296C5D854A688AFC057736A18C8F1A"
                }
            },
            "B454CE8C5572E340C5891B78F9DC9A25AEC1": {
                "t": "Having nearly unlimited Mana must be fearsome in battle, indeed.",
                "d": {
                    "cid": 0,
                    "eid": "A5184DDC1B9844436C38F444DD477A3ABA1B"
                }
            },
            "E57CB28E6AF9784EC94BA4F52B7D997F73E2": {
                "t": "Too bad I don't remember how to use magic.",
                "d": {
                    "eid": "D465B7B888139545DD985335A96AA4FC8FD7"
                }
            },
            "FB147D569E186548EB4918A5A76E9FDD6A8F": {
                "t": "It's curious. We even tried teaching you some basic spells, but it's as if your body was incompatible with all kinds of magic.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "23DA9DA769E1044CD49A5313839BA0B37F18"
                }
            },
            "D50D79F03AD1F144EA4997F3AE60863D5039": {
                "t": "But I could definitely use magic before losing my memories, right? It must be connected to my amnesia...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "C10F97E213026545988BDD83D2916C69E441"
                }
            },
            "F15669043CE1C84C0F2B630719339C2A992F": {
                "t": "In any case, we should head to bed now. Having regular sleeps is important for Mana-generation.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "705702E852F5E7467E1A3297ABC68AEEF989"
                }
            },
            "7FDBB3BD0C74A64D0429B2E277F5D6E8657D": {
                "t": "Thank you for your guidance, Princess.",
                "d": {
                    "eid": "4149B1DB5408A34CEB89BBA471DC346F0787"
                }
            },
            "5828E9BF75367942761A28058C82227A75FB": {
                "t": "Goodbye.",
                "d": {
                    "eid": "006837EE2AFDA949AC2894F3439AD3856115"
                }
            },
            "278145B73B5B224BA408CA9739CB0BD176A2": {
                "t": "Hmph. It's my pleasure.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "DD8180439AEFF94A983BA0746F216FD30996"
                }
            },
            "C33ED80816502440769B604309E5AF49C967": {
                "t": "See you tomorrow. I once again expect great things from you, {LT:1}.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "56B87D962EABB0426489F165B67B8D244CCF"
                }
            },
            "58A7B7A22FC3D64AD56ACD95A3B72827635E": {
                "t": "\"Once again\", huh?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "04077B510B36D64F0668FA95068369720F44"
                }
            },
            "C24764344A70644A8B58BE35D5DF0EA12CCF": {
                "t": "I still don't know why she and Cristoph seem to know about my past, but... They don't seem to be willing to reveal anything for now.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "DE1FE79E6D0A6343126B0F847455FCA49EC4"
                }
            },
            "B40CF99112AE00479B7AB2F8572633B21A34": {
                "t": "Wooot...",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "D4B7CD09728CA8497309E6D9113B7ACC7110"
                }
            },
            "A22B16D923D082437B0BBE71CBABE098D1DF": {
                "t": "Tired, Luckos?\nPerhaps there's something we can do before heading to our tent.",
                "d": {
                    "cid": 0,
                    "eid": "498FDB7F2379C043684824D140A59A293F8A"
                }
            },
            "3F06D78C60A7E140A40804A22438482BA93B": {
                "t": "I wonder if any of our comrades are still awake.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "8AB35C5D4F77294932881DE1B47499E9B476"
                }
            },
            "130A671F06B1E3453A2BD5394E9B4642D582": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "7F5380AF37F0B9483458AED6313ECD3566EC"
                }
            },
            "1CDD74EE442FC84D4B786454FA06BA264610": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "EB1132175659464F6F8A06B1B6E8CB38DDE2"
                }
            },
            "FF544AD1583C174A1278FDA3C3E4E4FAE684": {
                "t": "It takes a lot of training to learn new skills, but with my help, everyone can surpass their limits way faster...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "CDCBE929101A594FEA5B3B98DD1AF495660A"
                }
            },
            "404C06672652434E0D78C3B449AC4793C302": {
                "t": "I will.",
                "d": {
                    "cid": 0,
                    "eid": "FCF3739C3B88D04C9B3AAB71E99A694B6D1A"
                }
            }
        },
        "commands": [
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "C47A51B489D3B04E4B496D06E9C0B96A5C97"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3D850C3A31E38440784BC891C4BC248F7256"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "21CB77C16DEB404FA26A8F35BFB39B2FD0D7",
                    "parameters": {
                        "values": [
                            "FEEB28CE186A3342E70A634062AF25688319",
                            "",
                            "",
                            "",
                            "",
                            "",
                            ""
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "344D1BEB1766F848999A33235EB9BAF705F6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "7A52F8DE55D159434B499B596439193E987E",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B0A80068278A454AE48B286527B586DF0292"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "942D16A85E0B3342745815540D0D511A07B0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "BF54F69C17016841C13848A67FDE13C0454D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "96441289159BE749487AA953739B75E07E93"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            20,
                            1,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "0420506C3111F74922096847ADA3D5FFDDD4"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "0E09CEC93D560543237BB1E4861A09F08AC1",
                    "param": {
                        "name": "Livello",
                        "type": 0,
                        "value": 0
                    },
                    "numberValue": 1,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "0BE2E1961931624D7F4B6EF0E172AA57FFD8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1E8C396462160048620BB661717B45EFC46C",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "625949A9954C6245F378D665F47CD8B38B63"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "Numero Multiuso 15 bis",
                        "index": 174,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 1,
                    "source": 0,
                    "sourceValue": 1,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "53075FC33738284AC1385DD5A6A0C0E78481"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08B6930722F90640139BB772D8B05FFAE61F",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            {
                                "name": "Numero Multiuso 15 bis",
                                "index": 174,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            }
                        ]
                    }
                },
                "indent": 0,
                "uid": "94AB5A9B86578145B08B58A63F51B4C7D53B"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "param": {
                        "name": "Salute MAX",
                        "type": 0,
                        "value": 180
                    },
                    "targetVariable": {
                        "name": "Numero Multiuso 1",
                        "scope": 1,
                        "index": 0,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "FA2EAD386C09684438591BE60148D2FC2E19"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "param": {
                        "name": "Salute Attuale",
                        "type": 0,
                        "value": 180
                    },
                    "numberValue": {
                        "name": "Numero Multiuso 1",
                        "scope": 1,
                        "index": 0,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "297A02958A8E8845BD89B9A10325F097D360"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "param": {
                        "name": "Sazietà",
                        "type": 0,
                        "value": 10
                    },
                    "numberValue": 8,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "E67B6E361450D445C649A06677FD8F9EE97C"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "82306A8F59F3C046ED5889E7565D1B442168",
                    "param": {
                        "name": "Livello",
                        "type": 0,
                        "value": 0
                    },
                    "numberValue": 2,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "3B26BAA14D6041418A5B9158E1979F1A9752"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "C7C1C7EB73C8A5430F58BA87BA1FC3BF7CF1",
                    "param": {
                        "name": "Livello",
                        "type": 0,
                        "value": 0
                    },
                    "numberValue": 2,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "AF65209E509EB8456628874273FCB4D13F40"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "722947113DE0934EE0482E27C929F86693F9",
                    "param": {
                        "name": "Livello",
                        "type": 0,
                        "value": 0
                    },
                    "numberValue": 1,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "E8D579F262AA5144D94BDA650235201D937C"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "BDAF35DE7DCD42495F490E65C3D752C8D81B",
                    "param": {
                        "name": "Livello",
                        "type": 0,
                        "value": 0
                    },
                    "numberValue": 2,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "F15619A68313B743AC8A51D284B854B79EBE"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "E07FD1D144339548FE298C177C5E3BF733C8",
                    "param": {
                        "name": "Livello",
                        "type": 0,
                        "value": 0
                    },
                    "numberValue": 1,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "C2E8F37B8339F74B9A09A631184C8812A892"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "7BB41FA45AD5E146828A5C579D4A87D59712",
                    "param": {
                        "name": "Livello",
                        "type": 0,
                        "value": 0
                    },
                    "numberValue": 1,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "D3C347A751A9F84CBE9B750116624819ED78"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1BFC3132455D2444EC2936029888561B32EB",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "10C4DBD35C70C84A4E59D9E5394C96D1BD9E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "629A6CDC36A6D5493F7BC9F2232436A89E01"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6AC647D422748145C53B90813191F30F7ED3"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Suzaku"
                    },
                    "targetVariable": {
                        "name": "name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8898FF7225A7F841FD0B99A1924AA1CC9F99"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "REMEMBRANCE SHORT.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BF6FF8097E2A22428D186CD5C5C384D82C76"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255,
                                "color": {}
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 85,
                    "blendMode": 0,
                    "zOrder": 2200,
                    "duration": 12,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "2) Hellios memory low opacity layer1.png",
                        "folderPath": "Graphics/Pictures/Memories/Hellios (60 years ago)",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "5BF96E1C3298D4441F7911E63BF5ECF13FCD",
                "expanded": false
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255,
                                "color": {}
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 86,
                    "blendMode": 0,
                    "zOrder": 2200,
                    "duration": 12,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "3) Hellios memory low opacity layer2.png",
                        "folderPath": "Graphics/Pictures/Memories/Hellios (60 years ago)",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "2EF614C4215B2441D249ACD1A2C37A1B57B1",
                "expanded": false
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255,
                                "color": {}
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 87,
                    "blendMode": 0,
                    "zOrder": 2200,
                    "duration": 12,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "4) Hellios memory Hellios no texture.png",
                        "folderPath": "Graphics/Pictures/Memories/Hellios (60 years ago)",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "D65AAB2349BE0140C22AAFD4C804332950DE",
                "expanded": false
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255,
                                "color": {}
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 88,
                    "blendMode": 0,
                    "zOrder": 2200,
                    "duration": 12,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "5) Hellios memory Hellios texture1.png",
                        "folderPath": "Graphics/Pictures/Memories/Hellios (60 years ago)",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "CA469C8219BC484D279B75629CE7E121E391",
                "expanded": false
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255,
                                "color": {}
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 89,
                    "blendMode": 0,
                    "zOrder": 2200,
                    "duration": 12,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "6) Hellios memory Hellios texture2.png",
                        "folderPath": "Graphics/Pictures/Memories/Hellios (60 years ago)",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "673EEFF705F3754D6B482304ED4C200037F7",
                "expanded": false
            },
            {
                "id": "gs.PictureEffect",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 85,
                    "duration": 0,
                    "pixelate": {
                        "enabled": false,
                        "size": {
                            "width": 10,
                            "height": 10
                        }
                    },
                    "blur": {
                        "enabled": false,
                        "power": 0
                    },
                    "wobble": {
                        "power": 85,
                        "speed": 40,
                        "orientation": 0
                    },
                    "waitForCompletion": 0,
                    "type": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "6B1A7B9E322812427B186BA31C3D415E16E0"
            },
            {
                "id": "gs.PictureEffect",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 86,
                    "duration": 0,
                    "pixelate": {
                        "enabled": false,
                        "size": {
                            "width": 10,
                            "height": 10
                        }
                    },
                    "blur": {
                        "enabled": false,
                        "power": 0
                    },
                    "wobble": {
                        "power": 80,
                        "speed": 45,
                        "orientation": 2
                    },
                    "waitForCompletion": 0,
                    "type": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "0D66C494998F6742357A0AB82C8AF91074D1"
            },
            {
                "id": "gs.PictureEffect",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 87,
                    "duration": 0,
                    "pixelate": {
                        "enabled": false,
                        "size": {
                            "width": 10,
                            "height": 10
                        }
                    },
                    "blur": {
                        "enabled": false,
                        "power": 0
                    },
                    "wobble": {
                        "power": 100,
                        "speed": 30,
                        "orientation": 1
                    },
                    "waitForCompletion": 0,
                    "type": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "CD9A855B0B99944B193ACB856398467F6324"
            },
            {
                "id": "gs.PictureEffect",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 88,
                    "duration": 0,
                    "pixelate": {
                        "enabled": false,
                        "size": {
                            "width": 10,
                            "height": 10
                        }
                    },
                    "blur": {
                        "enabled": false,
                        "power": 0
                    },
                    "wobble": {
                        "power": 90,
                        "speed": 50,
                        "orientation": 2
                    },
                    "waitForCompletion": 0,
                    "type": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "CF80C43A141F574C153AE50090A1F532F118"
            },
            {
                "id": "gs.PictureEffect",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 89,
                    "duration": 0,
                    "pixelate": {
                        "enabled": false,
                        "size": {
                            "width": 10,
                            "height": 10
                        }
                    },
                    "blur": {
                        "enabled": false,
                        "power": 0
                    },
                    "wobble": {
                        "power": 100,
                        "speed": 50,
                        "orientation": 2
                    },
                    "waitForCompletion": 0,
                    "type": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "23928F785B13E242C029C374B7B795D35EC8"
            },
            {
                "id": "gs.PlayPictureAnimation",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 90,
                    "animationId": "A71EE67348E3324C434BCA454F52B8FB0CF3",
                    "predefinedPositionId": 0,
                    "blendMode": 0,
                    "zOrder": 2200,
                    "duration": 12,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 1,
                    "position": {
                        "x": -94,
                        "y": -58,
                        "angle": 0,
                        "zoom": 2,
                        "horizontalFlip": false,
                        "data": {
                            "zoom": 2.3449521149208192
                        },
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 0
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6A57A5669CF01748BF491698310D8D83BB73",
                "expanded": false
            },
            {
                "id": "gs.TintPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 90,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": 175,
                        "green": 65,
                        "blue": 175,
                        "grey": 62,
                        "tone": {}
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5A4DF02E56C4F44265687C01AA9249C395CD"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "1EE9A2E09F531648E62A2F0215CFC309328B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1DF10D71302AF9415A88E600C59CC8173121"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "00A7F9E5142B844B718853B157AC5ED0744A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "20C0FB5290F42141CD9B31546916D5A3D73C",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5DE2FBF766DAE14D4558D8A658B22E5C6CC2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1EB64F47015CA14D9129C0767C35CE2EDCD2",
                        "defaultText": "{LT:1}..."
                    },
                    "position": 0,
                    "characterId": "20C0FB5290F42141CD9B31546916D5A3D73C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "8B1B9D6F409C974A5C2B4861B552630D29A0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4C0EB69A49AB5344435B87B5DA0D27093C20"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "866A32952ED0144B4F089716519D5195A5A9",
                        "defaultText": "모두... 죽여... 오르니에르..."
                    },
                    "position": 0,
                    "characterId": "20C0FB5290F42141CD9B31546916D5A3D73C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "918D8AAE4209E64F4889FD882AECE09BE6B2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "150C31CA1436D24BBD38BB9153DB127A0548"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FACCFAF4891CB74B4249F8B5B420D672E86E",
                        "defaultText": "그게 네... {SP:1}{C:1}운명{C:0}이야... 내가 네게 떠맡긴 운명..."
                    },
                    "position": 0,
                    "characterId": "20C0FB5290F42141CD9B31546916D5A3D73C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "C9BBD4C71C2936494879FB680E10534E7E7B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DFE26DFC89A2C2414A6A7195F2E14394C2B9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5C8ED1F7453E66424C9A23478C83816827FA",
                        "defaultText": "다시... 네 자신을 찾아... 죽여..."
                    },
                    "position": 0,
                    "characterId": "20C0FB5290F42141CD9B31546916D5A3D73C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "E287387A62BEE84D8B880068BAF34AB2C09E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D782ABD16A57774E562A59A2E111887CFC7E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9A0A38AF588AA742DC481A05414913F8C673",
                        "defaultText": "죽여 죽여 죽여 죽여..."
                    },
                    "position": 0,
                    "characterId": "20C0FB5290F42141CD9B31546916D5A3D73C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "19DDCFC26AEF1347FE496973B898CDFEC803"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "056BF4DD4939704B313A2792144611E95D8C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F5318BDE3A70464BFE3A4215AE72707D2BE2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "603348DF4516574DA65B26C142A258E40F13"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "27F91A9C1633084BC75AF6C46964D5095F68"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BD468C8E48113346E01BE3A41EAF700FD792",
                        "defaultText": "우웃 우웃 우웃 우웃!!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "37A1D94632A3B745B3894017CE1CBF0038C4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "95521CB705091043EF0A6B78B58BAEDCEAE9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "857C8A907B4A5942A66BFCE08E29A4EA4ADD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "130A671F06B1E3453A2BD5394E9B4642D582",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E3-Ornieres_line25_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7F5380AF37F0B9483458AED6313ECD3566EC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "545D0B4F7B37444FE62BA1739234EDDD9424"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2F53F2BD4B968644BF5B8925DD277943172B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "5E4FF3261B97654F3A883D06E87D1348C94E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5619C3EA786BF148E72822D0207B4BE2DC6A",
                        "defaultText": "으으윽..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6FCA81B95380D844A519D823E134FCFC8807",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "5712E9E72224614157686C12F04CD4B6976C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BE309F8C0201864E0149A18430652DBA687D"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 80,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "BB884133642F674C341B47416373565432E8"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 85,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "63B873946D47B8475F48CF75B0436D61B519"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 86,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "74C9A8E8500FC349888B1307FE9964BEDDBF"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 87,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "28E9D5E93BEFB340CB2BABE739C032199A5D"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 88,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "C9F4A9B620DA13452B6B6C5539FE99EC3981"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 89,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "9AC49BD27C7E704F5E0ADD6461F211834B09"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 90,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "C7970D4A740B0844FC7BAF3276B5CE4ECA5D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 72
                },
                "indent": 0,
                "uid": "B182A79835EE6347C4589371BCB522B35263"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 60,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 2,
                        "movement": 0,
                        "mask": {
                            "graphic": {
                                "name": "Circle_Square_Ver2.png",
                                "folderPath": "Graphics/Masks",
                                "hue": 0,
                                "opacity": 255,
                                "blending": 0,
                                "tone": {
                                    "red": 0,
                                    "green": 0,
                                    "blue": 0,
                                    "grey": 0
                                }
                            },
                            "vague": 200
                        }
                    },
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 0,
                        "animation.type": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "AC4837142A8CF842A749C970B076A05E70E4",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 72
                },
                "indent": 0,
                "uid": "23FB24AF46EA9440AC9908B4D4B4B63AE859"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "wakes up"
                },
                "indent": 0,
                "uid": "19458FE2815D684C218B92C2F5898325D9AC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "9A8FE63A6FC9F24D4B7B0BB35DC98409A840"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "089EA4F65B956342A22B8316A86F018052D0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9DC1622429109341D75B49F8CC8DF05DD9CC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "12F3035B185CE44F6A4BEEE77CAE059A4442",
                        "defaultText": "방금... 뭐였지? 또 이상한 환영이야...\n아니, 기억이었나?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AB05C5DA85F3154A0A0B6CB60A65EA148DB5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7F7C52426177564CE78A3648789AE84B25AB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2FEDAFE07E2188407A4BB6F109BD57DA3496"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "2DEDB4AE4970E5455D2878375DA820735BF6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CD7F816545788541C1089075721A8EAE3322"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7314C2589435944E7C38F0B02F687FA8442E",
                        "defaultText": "우우우웃..."
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DD725034403B4746B2897DC265D23C157580",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C9F9B23C2DE38440E94BD0969DCCDE3DD3D3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3974DFD13AFB354E2B5A11A332FDEA397FD8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8B3693E842D2484A9B4B82B5FDF32D022E80",
                        "defaultText": "미안해, 꼬마야. 걱정하게 할 생각은 없었어.\n잠깐 눈을 감았을 뿐인데..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "97EA6EFA49C717438C48FB66A5EAD53B5586",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C8EB641C62DE914832783083B970B57CEFDB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "66F2679E42FBF545918A3B37E58264E77841"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "DB1BEB246274324B278B62C3C878A1753E8F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7A35AC6B21A95547393B0D681D65C046D187",
                        "defaultText": "그러다 기절했지?"
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8D56F595640352434F1AF43918544D23D69D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "A9E2368F7251C8401A58FCF0C5AE66271881"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "55580F3F4BB81440E9495015C09C73918774"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5480405A779A634AE41BF7A6894EB6BD5D48"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 54
                },
                "indent": 0,
                "uid": "95AD3E909B9B3541355A31A989F313A76C26"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "7A635EA73F1902482F48F6A8A0C35B7873C9"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3F2B8D7C83FE2245C5687A3513A25070E9F8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF3CB6A82BA3F543FE7A3C88D43FBE81ABE4",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            800,
                            0,
                            0,
                            -40,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ACF9D62280434142AC8B942132B3DE415278"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -45,
                        "green": -45,
                        "blue": -25,
                        "grey": 40
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9CEB7F6D7B4B5442819BDCF9CE36921DCB7D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 72
                },
                "indent": 0,
                "uid": "AA061A0715A4A24FE90929B2E670FB50D008"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "4479CA6984BF3347B82916F91159E2427790"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "475EC38F20D3774FDA38BBA8B19347442AF0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3E6FA4DD3AC5704300789671DC622D8E1652"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9A6AC86E1E9FC244597B11B486E23FBF3BAA",
                        "defaultText": "리아 공주님..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "83D65FF75FF8A345562B03220387906A01EE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "7EA3C4F24E4891460888250326B50882B7AA"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "97437AE664F5E647D258B1B53D89CB6F8AC5",
                        "defaultText": "당신이 잠자는 남자를 좋아하는 줄은 몰랐어요..."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F5CDBFB8011CD54E5F6B0505EAED0D2B0422",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "78C6D5F8854E8148E79AB9060E0650EE6004",
                        "defaultText": "난 깨어있을 때 더 웃겨요, 맹세해요!"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "23C199E97DAC934EEC0A5D9549527832C2B3",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "B5119468121E504B7758E8E6819C7AB971DC",
                        "defaultText": "나를 이런 모습으로 보게 해서 미안해요."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "EC87D2523A22444AEB796898C82C425B98E1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "men",
                            "funnier",
                            "sorry",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "F7DE6A2029FED9493E8B1E224C92CF4C1C0E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "4E962F7E6DA57241D66ABF172652417DD6D4"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "men"
                },
                "indent": 0,
                "uid": "152734581288974E8D5AFFB53E22B7B2DFBB"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "-- affection\n+ sarcasm"
                },
                "indent": 0,
                "uid": "890F116B17F208494A3B6AC65D1D1B2EBDBE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            4,
                            1,
                            0,
                            8,
                            "45918E0E12BBF148635A9360998958409EFE",
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CD0152385D49144837687985BD2397B7F39D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            8,
                            3,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "",
                            1,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "C6AC18942EC4C646C3399297501E073999CC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            5,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8A2B003A4EF0814F8868C423FD33B768210C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            4,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "09A1954F8E17A548044B047658BA0A89CA3B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "786CFF32170C564FCD7B4E6223C6A655C5C5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F0E3D0EF75FED148A438E3E09F3D14753B8B",
                        "defaultText": "그건 모욕으로 받아들일게. 전혀 웃기지 않았어."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8231D9B03275E148EA080E3416B7327216E1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A4FBE7F81135454B3E492F45A41F137878DD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3F806B193EAD3446FA4A4FB1F21882878847"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5B8DA8C88D966446DF4A9557151B90E7A2F6",
                        "defaultText": "공주님, 농담이었어..."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "59E37C282E62D54E4D484E1170E2835A08D7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4B6D5EE18082F842BC3B90E35B76067EA7BB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0E1CDB2626A5D64A2C78F621381F2F2CD718"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8EA087EA828BC14F983A3C77019CE8EC6752",
                        "defaultText": "이 이야기에 정말 예민한 것 같아...\n썩 좋은 농담이 아니었던 건 인정하지만."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "89F003BB78409445B4299D35CFB1AE90E4AB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4B9BF0DD8AB940477E79DF61B5518601589C"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of choice 1",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "3A7E838919B738430D684324619B5568969B"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "funnier"
                },
                "indent": 0,
                "uid": "07C62EF48584C6452519C5A26EA26EB633C0"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "+sarcasm"
                },
                "indent": 0,
                "uid": "98BFD9191CA43448BA7922A4F10E5968B90A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            8,
                            3,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "",
                            1,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "51CB6BFD446674444C68C476878486307E81"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9CAE34147314E741408A8BB7A6F221DCFEBC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            4,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DCA3A46271DE51490B1B9E773A0C567A84D0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5381784948DA554C6B299A17A17ECA4887B1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "95989C602783D1423D7B4CB251A7C7BB3B4D",
                        "defaultText": "흥. 원래 ‘유머 감각’이 네 장점은 아니었지."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5D54D2CA05EC1044903A431034DA111799D0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D69B892C6AA1094D326A66E46CAF2DBE72EB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "566125AF3C45074E56488AD5C341BFBB1F0B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "01E01B710FD9C245A08B0DE846B28B02CB65",
                        "defaultText": "하지만 지금은 장점이야! 어떠냐, 공주님!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6CF50E34175BD748788A83688317545E5864",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "18DB68F81413B643C48A7D690519AF95E34E"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of choice 1",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "9DB4CDD068636548D25B2F17E518D190BCAC"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "sorry"
                },
                "indent": 0,
                "uid": "3BF01F00769B814F0748E6600E095A817691"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "+ aff\n- sarc"
                },
                "indent": 0,
                "uid": "FE901FDA83EA7840E44BC6123D10F64879B4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0,
                            4,
                            "45918E0E12BBF148635A9360998958409EFE",
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "113672B10E15194217998129834C9B227185"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            1,
                            8,
                            3,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "",
                            1,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "05DEA7EA36270742022B10E52EE135073787"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            6,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C39F4CAA3FF5194084782EB56198ED7DF50A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            4,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4BA411D282F6754ECD8B4042435EB0BCC626"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9DFFBC892E44014FAF1A9CF8C3B1102EC8F9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8336C7016096E345A92B024868DF45741E55",
                        "defaultText": "내가 예상했던 너와는 확실히 달랐지만, 솔직하게 말해 줘서 고마워."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D5DDD05812315440D31BB1926A80BB6132D8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F3C9592248256344589B5536166F804A27D6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "275BD822562147414B890672852EDD253E19"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DB611C00558C3947B3793B55288B6C773051",
                        "defaultText": "앞으로도 이 환영에 행동을 휘둘리고 싶지는 않아...\n어떻게든 할 방법이 있을까?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "16ACD32B2524984C3A6B41C873294F297D95",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8BE43A9B6ABEC34CBF282394E5E25FD3070F"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "end of choice 1"
                },
                "indent": 0,
                "uid": "1F8A14983AC36447E4889743A662851D8543"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "8C1E1F4C6E11364F5E28E542031576A561F0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1CDD74EE442FC84D4B786454FA06BA264610",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Rya",
                        "name": "E3-Rya_line6.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EB1132175659464F6F8A06B1B6E8CB38DDE2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "AE60A9AB13A2814AF708C4D019BA2D1B71DB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A71E1D8F6AC2E24DED58677195E10C07986A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B56C8AB41EC6854930496A06AA5336810BA9",
                        "defaultText": "됐어. 볼썽사나운 짓이 끝났다면 훈련을 다시 시작하자."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9B8994BB3418A4445F1B8431CD8A2415017C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3C96D4B65C994348FE5A9BB273A9424BBB8E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "26CBCA0F4839434BB648FDF19530D56C7972"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "813DD6EB15D92045C6383AF7953A90E4E595",
                        "defaultText": "훈련? 아, 맞아... 마나크레스트."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8C9724248666C844D32840088E9457889EAB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C628BBC153BE864C5D4B1404ED87F3D2521F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "599C404D35FC464CD919D9B2194063B056B3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            2,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "697181D23596B6476858CD87EE62A70191A4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0F6A19709764034D9D28EB48A1CA04A08A30"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B2FC19734947E14E508B93476D270BA11756",
                        "defaultText": "이번에는 도살나비가 없으니 걱정 마. 그냥... 대화할 거야.\n불만 있어?"
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9D41B3CF43088444B14BC928A760E5C29DFD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F0CDF2F96A8898434539B0460CA0377B16C2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E55B7E2C301E324CA719D0D3CD21A6F32E99"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CC392CAA54CF774C91995CF6FADFB49840B9",
                        "defaultText": "괜찮을 것 같아. 그래서 무슨 이야기를 하려고?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B9DF06CD7A72F541BE88BD02508D9F2A7BA8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "52474C8697E4C2474E781A8313C89D788BCD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "73E5BDAF1A2579477C8950756E00031B9501"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "97647DE39A1C2444705B62F61851006E77E0",
                        "defaultText": "우선 마나크레스트에서 달라진 점을 발견했는지 말해 봐."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C74416D154EBC34C4818EAF76238EED1681D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "9BEC89CE33D86044F3782E19E6DEE5EB19F3"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "1308CC2D4B4FC24BFD2BE8E1E63421AD5DC7",
                        "defaultText": "그랬지만 특별히 이유를 설명할 수는 없습니다."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6D50B1996786714D1789908686078028AAAE",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "EB4807C4702E414DAF49BAC64479BFFC4893",
                        "defaultText": "그것은 우리 전투에서 마나를 흡수했습니다."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E1704F5F10054840C43A5F0717797360C169",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "0EBA70089C7CF0474339DC238FCBD8B8301A",
                        "defaultText": "이제 좀 더 강력해진 것 같습니다."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2A89F32F1F8669430228D00877ACA3E5279B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "fake choice",
                            "fake choice",
                            "fake choice",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "B752F5C16C1BC741D949994220ECABB87C0D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "2945829C273546456C3A5313219ED681D308"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "fake choice"
                },
                "indent": 0,
                "uid": "28631E465BCE2642B25AE151EB30CE139376"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            5,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B0A2FD703217D541C12B7F9547B3478C73C6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BA6AC3707B3A8348421BDFB13C945DA6B9FE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "097B50AC4C860046F16851C8BBE8DD51E3E5",
                        "defaultText": "그렇구나. 뭐, 예상한 결과야."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "991F7FC68B42534D4C3868F7C007FACD1BB5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9F1711A27CC2C44A251B17067BDE2967C8E4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C3093C889622674F6869A6243C1192C21B46",
                        "defaultText": "문제는... 그 안에 {SP:2}{C:1}저장되는{C:0} 마나를\n전부 어떻게 쓸 생각이냐는 거야."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F389A1E477498442F84A32E05AEDF4A0FC72",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A1AB5D5F3B285347011BEDA3958361C915D5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "352A269A1AFFF549B07A5939F3437DCAF6D2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "874AAF8B7A0E594C3E7B3E489E58387962F5",
                        "defaultText": "글쎄, 그게..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CFB7201530DA42469D186F3712C60CDB3BAB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5DBB813304C3714F308BBE323BFDF845E3CA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EED9497A6231E849A84A2AA268631CBAD0A7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "867AA722427478414E385D28A662533480E0"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "D94033A68478C24F6C1883D6DBA08D51C6EB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "32FB9B76529C71415C6B8F96CCEFB9215F56"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "483D663A78F2B6467F38E414B4CA3204F2A1",
                        "defaultText": "우웃 우웃 우웃!!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "904A22F782200744BE28AC948B7F831AF97F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DBA0FC754D463841D6697C015A25415BA3AC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4C748EA160A7A346810AC4228E6A38DD7C8B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "027F694C7FA553410B38B5435FA1B533397B",
                        "defaultText": "안 돼, 루코스. 먹이로 줄 수는 없어.\n설마 이걸 노리고 줄곧 나를 따라온 거야?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C5BE4DDB779BB949C03A03123B781CAF622B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E1F4F9239251E741BB68A35734705DB293E5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "CD6D525B6052364A1B28BF83750AD70E125D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "816146B72B2B37452B896E87F89C45BB7B14"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7AB5922E80EB4645EB181324149A6B405666",
                        "defaultText": "우우우웃..."
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "107127038CE06345E77BD978E8E5ECD8EA57",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4A5057133E9C644889692647D8E48F193A7C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3615F1E15E0568464878D0C4D309E3386459"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1E0F3B6E691EB149D95A4676353C69B3E632"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "65E359D32336174533997B33ABD2BF1E8D3D",
                        "defaultText": "흥. 단순한... 개밥으로 쓰는 것보다는 나은 방법을 알려 줄게."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "76FC56987FDFD549231B9BC599C6C675ABAF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2CED72D451FFA647AF5B7042697AF0C8DA60"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AEE8111414836343CB7B7276889464EF1C08"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6027817114AA724DF47A75224BE716CA74C6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CB89743F4C983749BA2AEBF11D54292F425F",
                        "defaultText": "예를 들면 그 마나로... 우리의 {SP:2}{C:1}능력을 강화할 수 있어{C:0}."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6E3130F92824314BA8191844B2A4F17ACE77",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "6235D6993DB646412A7B6156F63353C07837"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "7BDF072C9D5236479F481AD13BB8173C7D20",
                        "defaultText": "그렇다면 나는 최고의 완충자다!"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "84E94C127198524E5799D9273796B7926918",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "6087A8F629F3C7493C5876C9712D95CFE0B7",
                        "defaultText": "강화... 어떻게?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "EA7CEED910B4764C982AFFB1B6F61C18334D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "buffer",
                            "after choice 2",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "33387ABC45706646BB789F376D4D284A87AA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "545509344724D641C559FC57FC1D3B4946D3"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "buffer"
                },
                "indent": 0,
                "uid": "02A4B5FD8F6BC04A824893B70FADE887402F"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "+ sarc"
                },
                "indent": 0,
                "uid": "CBAAB1EE74BB884F2C1890F508E68C186800",
                "expanded": true
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Rya's face goes -__-"
                },
                "indent": 0,
                "uid": "F0E2C8CA6205524163298EB49A64CC2583E9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            8,
                            5,
                            "",
                            "",
                            1,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "94ED65158790044AB0181220D39C754F81BA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            5,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2AE591A877BB55415A8A5936A6040AF7DE23"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "6FDB9CC95A55E549E52BBAD1B0D655D41C19"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CA7997BD7F0C104AF10AAD26BAF662AC6DD5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FEDDABEF8248C5442F5A611427A5E613B869",
                        "defaultText": "아-아무것도 아니야."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A98BB568570AC74E8F38AA07FBBA55F5AE8D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E95DCC7F6FD6414A804997D66C70AE74E0BE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "062B88D51EEAD249BF0A6B5218EFDC2F4A5C"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after choice 2"
                },
                "indent": 0,
                "uid": "9CC1D11983DCF248DE8AB7B7C6FA350C0DF9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F4A665B7869E2247CE783B958BB8CD14B410"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7F487BF15364264CA6086A730AF6D6575A51"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B2CF46F08E236549595AD527DCBF25F33274"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FB8040A6700EF141C999C66416B7760FA4A9",
                        "defaultText": "내가 설명할게."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5C5A220330C80249E76A28A700A2730A89F9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "34674BEE76AAB948BD690F6581076205247F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4216F4DB71214145D6694D218709A67DB768"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "96E8865C46A6744AF298785563F5D69BB4F3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E4027881363D1942AD8922333FFB966673FA"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "639EE6AC3367054EB118C2A4C52D3AB1AD1A"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Unlocked Skills?",
                        "index": 105,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "53B16E0B785B5544C52A56A5153312FB2379"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "422B49CA8A63A04CB338ADD9E56A9BFB25A0",
                    "parameters": {
                        "values": [
                            "",
                            {
                                "lcId": null,
                                "defaultText": "The {C:1}Skill Trees{C:0} are now available in the Inventory."
                            },
                            "",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "386F7D9887F5E74C9E38ECF3F0A116F73AB4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6FE3C1466BE6D749E93B1A1763C2A8DE2900",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "4E7415975D286748979BBBA9453D27530339"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "5EC32FD765EBC144614AA2758EB511B7B0DB",
                        "name": "Tutorial - Character skills"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2ED726104E68B8490A686038194530C94F1C"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "0104447D4391244D4D1AC377BAA89F4CC40C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "D17E78D56D9C434CD179A0D16DD370B00C4C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "68BD20396A648648CC68CF128E4EE3CF41AD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0E0D5F962270434BFF79E2B948991FDBA650"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3FC994461FD68542FB5BC6F0ADEE54B42B0F",
                        "defaultText": "놀랍네... 저장한 마나를 이런 방식으로 쓸 수 있는 줄 몰랐어."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "71BF03A2356FF44412995730D65D040D87C7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EAB36E0052A0F247567A9033105CAECD1A9E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3CF7E28E25FF6948AB6B9AF662F9B3BC910B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FF544AD1583C174A1278FDA3C3E4E4FAE684",
                        "defaultText": "새 기술을 배우려면 많은 훈련이 필요하지만,\n내 도움을 받으면 모두가 훨씬 빨리 한계를 넘을 수 있어..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CDCBE929101A594FEA5B3B98DD1AF495660A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "373CD70048C17645C58922E7BF8C14C69343"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2D087144674662432C4AD9625300C4A927F5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "32F81D17848C234F0C784513666F21B43578"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "93AA7C753C8AC74AE989ADD33C2958712BD0",
                        "defaultText": "귀중한 힘이야. 이 세상에 하나뿐이라고 해도 과언이 아니지.\n현명하게 사용해."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DD5FACB27837434FD66903C1010963B25AE0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "64CB712A497B3341A05B7498BD132D1B0D17"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E52EF2DB9561C24D327B23982A2B3FF99B9B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "404C06672652434E0D78C3B449AC4793C302",
                        "defaultText": "그럴게."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FCF3739C3B88D04C9B3AAB71E99A694B6D1A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BCE19827687006441299EBA4DDBCA9182B5A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "63D44FDF1DE20840E21AF9A6AB8E32D625D6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E974DD5A3FC3884714884C06E5FA41DBC73E",
                        "defaultText": "그 마나로 주문까지 쓸 수 있다면...\n어디까지 높은 경지에 오를 수 있을지 궁금하네."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8FD517296C5D854A688AFC057736A18C8F1A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DF42BCBC1E68784C694A75E9647965CCB2D8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7C52AD550B072840931AEB56E8A1455BCFAB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B454CE8C5572E340C5891B78F9DC9A25AEC1",
                        "defaultText": "거의 무한한 마나라니, 전투에서는 실로 무시무시하겠군."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A5184DDC1B9844436C38F444DD477A3ABA1B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "D7377E715FA48744467BDC482C33D7AAB15F"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "E57CB28E6AF9784EC94BA4F52B7D997F73E2",
                        "defaultText": "안타깝게도 마법 사용법을 기억하지 못합니다."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D465B7B888139545DD985335A96AA4FC8FD7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "only choice",
                            "",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "45065A1B2F6DE547CC7935380A7A56096718"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "08E20D6145283044136B2954668F69828FC6"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "only choice"
                },
                "indent": 0,
                "uid": "C32F699A66C7274B4B1A9FC01FF8688A9262"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            2,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4AEB355900F607456C6982B7E546D0D40260"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2A88AA513B5A12479859F384225733B764E1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FB147D569E186548EB4918A5A76E9FDD6A8F",
                        "defaultText": "이상해. 기본적인 주문도 가르쳐 봤는데,\n네 몸은 모든 종류의 마법과 맞지 않는 것 같았어."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "23DA9DA769E1044CD49A5313839BA0B37F18",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DC769FA08214A74E9D6AFCF4DA50C27720D4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "878EBFB8853A5144706AA685014D83B41A95"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D50D79F03AD1F144EA4997F3AE60863D5039",
                        "defaultText": "하지만 기억을 잃기 전에는 분명 마법을 썼지?\n기억상실과 관련이 있을 거야..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C10F97E213026545988BDD83D2916C69E441",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B32CD9E84D89B343753B761564AC09FBDEB9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            3,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4F2568DE8A78F64BEF8BD0535615688E9BE7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "944801D29FD4C54D64898AC3573FB0ADF588"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F15669043CE1C84C0F2B630719339C2A992F",
                        "defaultText": "아무튼 이제 자러 가자. 규칙적인 수면은 마나 생성에 중요해."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "705702E852F5E7467E1A3297ABC68AEEF989",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "FF4C305B4FFA0348591B8E79D012EB5366A3"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "7FDBB3BD0C74A64D0429B2E277F5D6E8657D",
                        "defaultText": "지도해주셔서 감사합니다, 공주님."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4149B1DB5408A34CEB89BBA471DC346F0787",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "5828E9BF75367942761A28058C82227A75FB",
                        "defaultText": "안녕히 가세요."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "006837EE2AFDA949AC2894F3439AD3856115",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "thank you",
                            "goodbye",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "B164CA6025B7C740B7884FF28CBAD243F6AB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F42E4E162130C8439D2BBF22F48DB9401DB7"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "thank you"
                },
                "indent": 0,
                "uid": "5D9893ED072C05440E896185F4F540E1F983"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "+ aff"
                },
                "indent": 0,
                "uid": "E39E97C38BB418498A2A54C9D07BA39AE79D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0,
                            4,
                            "45918E0E12BBF148635A9360998958409EFE",
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0EEAACF98438764BDE8B798329664DC80B13"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            6,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B4B40E909A64B244AF2B8A54E6D13917471E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "987A601015CE95431F6B51F4B4B4389598EC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "278145B73B5B224BA408CA9739CB0BD176A2",
                        "defaultText": "흥. 나도 즐거웠어."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DD8180439AEFF94A983BA0746F216FD30996",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "50A1DFD512A6F24E4579764443AE498E0A88"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "goodbye"
                },
                "indent": 0,
                "uid": "6C96C43852AA864CFF2B8CD64B07F1478306"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "462D01D9776361406B994A15A38CDAAEE29A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "615848285CEB3841451B81351EF1D85A0FD8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C33ED80816502440769B604309E5AF49C967",
                        "defaultText": "내일 봐. 다시 한번 큰 성과를 기대할게, {LT:1}."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "56B87D962EABB0426489F165B67B8D244CCF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "260589811A71E64F663932939D0E2D93C839"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            5
                        ]
                    }
                },
                "indent": 0,
                "uid": "9DD5066477D465476F4B71F54D682944B611"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1A5E4F7779B1214513280590416141B5D56D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "2078D4A035EDF84CFF1BE3C057008A5449B8"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "90252C7C3DAE46449988AAF57D242AC2D4B2"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 39
                },
                "indent": 0,
                "uid": "94654C511527E646375AF302603B20057B70"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "629A6CDC36A6D5493F7BC9F2232436A89E01"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "AC83BC51041DF54B70395E578B75561F5B6C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F620BF6E24F1154DC46B1D69CF92B8E11D8A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AFC6E9C03631084BA228D6A4EBD62FC0DF4E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0C05DA32069AC3456A0A3E697E6B3F99EFA3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "58A7B7A22FC3D64AD56ACD95A3B72827635E",
                        "defaultText": "‘다시 한번’이라고?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "04077B510B36D64F0668FA95068369720F44",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EE2E989B47C81445052810013FA5B7B2EFBF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C24764344A70644A8B58BE35D5DF0EA12CCF",
                        "defaultText": "리아와 크리스토프가 왜 내 과거를 아는 것 같은지는 여전히 모르겠어.\n하지만 지금은 아무것도 밝힐 생각이 없어 보여."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DE1FE79E6D0A6343126B0F847455FCA49EC4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F09F91D464F1F842351B96B02BCF2F1E6020"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1371395E5992004EA36809136F0159D3F780"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E295D3CB0301344F5819D05871F6DAEF89A7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B40CF99112AE00479B7AB2F8572633B21A34",
                        "defaultText": "우우웃..."
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D4B7CD09728CA8497309E6D9113B7ACC7110",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "642D59F9447CE84906688EE1CEEE51D89600"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "24B6A37B5B6055492C3BE2B08EB2F88D098A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A22B16D923D082437B0BBE71CBABE098D1DF",
                        "defaultText": "피곤해, 루코스?\n천막으로 돌아가기 전에 할 수 있는 일이 있을지도 몰라."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "498FDB7F2379C043684824D140A59A293F8A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "3607A0ED2089F444B66869430C184641D00D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "235F1CFC784046413688AA438C8802150DD4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BD4AFF7267D2554A06383453BED565467F23"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3F06D78C60A7E140A40804A22438482BA93B",
                        "defaultText": "아직 깨어 있는 동료가 있을까?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8AB35C5D4F77294932881DE1B47499E9B476",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "BF7C273851E147405478BE55F3A945563ADF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "86D09C3215740045740BBD6236042CD01F8B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DE4B4A654702F3437788941045933CC0743F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6A1990921B7CA749BB38F492A479AF0B89E6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "DFBBE7F8546546463B79A3A87BDF1EC62B91"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A62669DB7CE0344B8B8A9E57FD3E1A0AD9B0"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "model": {
                        "name": "Luckos.model.live2d",
                        "folderPath": "Live2D",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 706,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 1300,
                        "y": 685,
                        "zoom": {
                            "x": 0.27,
                            "y": 0.27,
                            "d": 0.27
                        },
                        "position": {
                            "zoom": {}
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 36,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B822A06664BC18409E1849B8127A9FC46D29",
                "expanded": false
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -60,
                        "green": -60,
                        "blue": -40,
                        "grey": 30
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6B24E8E24E0D544A9E79A0B2745228DFBC24"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "445DA1B398A2224936186CE3BABF8B0DFF56"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 37.2
                },
                "indent": 0,
                "uid": "68DE71B78D84B24BF4385877D884908170D8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E6230C567FB46248DF3B5A91C2AAD05178C4",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "AE6D254C8DBBA14B011A51043764689FA9AD"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "E0FB0CB122CBB64CDB2914660A8217741C93",
                        "name": "C6-02 Camp exploration (night)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BE87B51A31782242651B66A508EB8DC7598E"
            }
        ],
        "livePreviewDisabled": true,
        "stringVariables": [
            {
                "name": "name",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}