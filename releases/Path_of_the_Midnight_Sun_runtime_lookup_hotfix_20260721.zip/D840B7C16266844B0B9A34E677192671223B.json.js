GS.dataCache['D840B7C16266844B0B9A34E677192671223B'] = {
    "uid": "D840B7C16266844B0B9A34E677192671223B",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C2-02a Bedroom (Exploration)",
        "type": "vn.scene",
        "parentId": "7B50B0BC821C644FE88B60F811C979F7ABA0",
        "chapterUid": "821526CB730C524E8E8AE3E37167B67D0B30",
        "order": 1,
        "livePreviewDisabled": false,
        "commands": [
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "PREVENT LOADING EXPLORATION?",
                        "index": 97,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6F85D7751F9714440B2806E0C4D7F56A3440"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 1,
                "uid": "066B9D1E533B7740C06B7F53980C0ED20A54"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 10001,
                    "blendMode": 0,
                    "zOrder": 0,
                    "duration": 1.2,
                    "origin": 0,
                    "waitForCompletion": 1,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 1,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "sfondo nero.png",
                        "folderPath": "Graphics/Pictures/CG Gallery",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 1,
                "uid": "103B4C4D1F186646583BDF01F52BD735D9C7",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "6A35347F3764D64B3B1B8F643259600BD3A9"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 1,
                "uid": "4D2DAE282E1E7544698BD535665769CA8500"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "141DCB428856E1463A58CAF782973466C975",
                    "parameters": {
                        "values": [
                            20,
                            0,
                            {
                                "name": "coffer event",
                                "index": 6,
                                "scope": 0,
                                "domain": "com.degica.vnm.default"
                            }
                        ]
                    }
                },
                "indent": 1
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Numero Identificativo Suono",
                        "index": 159,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "A358F36A836FB44DCC780C898665DBAD116E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "1EFE085C1293664BE74882747E0FAD965890"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "8CF448593E1847461288A4656379F6E2CCDB"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 10001,
                    "duration": 45,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 2,
                        "movement": 0,
                        "mask": {
                            "graphic": {
                                "name": "9.png",
                                "hue": 0,
                                "opacity": 255,
                                "blending": 0,
                                "tone": {
                                    "red": 0,
                                    "green": 0,
                                    "blue": 0,
                                    "grey": 0
                                },
                                "folderPath": "Graphics/Masks"
                            },
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "1C773AB34BC79545AA8AFAE105D5925A4664",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 15
                },
                "indent": 1,
                "uid": "CE4BB3BA9AC611436B2A94569D61A4FAA168"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Spend time (during travel?)",
                        "index": 96,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "237B22EC9DBCF44E68885CE490DF0D92807D"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Spend time (during travel?)",
                        "index": 96,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "481C06F0613F08493F2A5A7206FAF356BF52"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "03DEA4954ABD5648B72A16630CB12FEB0C7F",
                    "parameters": {
                        "values": [
                            {
                                "name": "Tempo d'attesa",
                                "index": 32,
                                "scope": 1,
                                "domain": "com.degica.vnm.default",
                                "changed": true
                            },
                            250,
                            1,
                            2000,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "EBA5F3C17EF1384D0C2BCBC935273DC2C7BE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "7601D85C3700D2424D6B5E62901196D79FD3",
                    "parameters": {
                        "values": [
                            20
                        ]
                    }
                },
                "indent": 1,
                "uid": "7E3504A72E6CB84E018BB6A099FDB98A8996"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "PREVENT LOADING EXPLORATION?",
                        "index": 97,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BC4FB1762D91B549D6196486DEED3A1CBB34"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "INDICE HOTSPOTS\n1-5 Hotspot pg\n6-15 Elementi di background\n16-20 Monetine"
                },
                "indent": 0,
                "uid": "BCA018737694094EB28991656B1A9117DAAF",
                "expanded": true
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "P\nE\nR\nS\nO\nN\nA\nG  G  I    E SCENE DIALOGHI"
                },
                "indent": 0,
                "uid": "916D48490230424B4A085ED795DF4F48B9EE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A1F3F1D799DDC043B218386049F1B8B86EA2",
                    "parameters": {
                        "values": [
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A7AE610F3BB5144DE22A1DE37441877EC8A6"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "E\nL\nE\nM\nE\nN\nT\nI  C L I C K A B I L I (descrizioni)"
                },
                "indent": 0,
                "uid": "AC248A066762244B8C5AE965556C976CC313",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "B91A2FE514A67748E769D0B36E440EBDFCDF",
                    "parameters": {
                        "values": [
                            "DEDE01F22C1C7447C5886855F98B1F0052B7",
                            "392ACBD705A3D040FD28FC0461CDFB64BD68",
                            "0CF472C532810048033AE2E506D9719DBF90",
                            "A93C5F844F689648C1881697E702D77EB9D2",
                            "3592B02E44C6D64EA97843C7BB9BBAC0C0CB",
                            "4A0D5C3E8F35774404296B37990C0CA20120",
                            "75E29F6B6023D24BC86B22F1C5B2EFE04073",
                            "",
                            "",
                            ""
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "AECC5A3E7977A44BF878FA075D48CBF6DF3A"
            },
            {
                "id": "gs.AddHotspot",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 6,
                    "shape": "rect",
                    "positionType": 0,
                    "actions": {
                        "onClick": {
                            "type": 4,
                            "bindValue": 6,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "AttivaClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onEnter": {
                            "type": 4,
                            "bindValue": 6,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "InfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onSelect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDeselect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onLeave": {
                            "type": 4,
                            "bindValue": 6,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "UnInfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrag": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrop": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDropReceive": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        }
                    },
                    "dragging": {
                        "enabled": 0,
                        "variable": {
                            "scope": 1,
                            "index": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "horizontal": 1,
                        "vertical": 0,
                        "rect": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 200,
                                "height": 50
                            }
                        }
                    },
                    "position": 1,
                    "box": {
                        "x": -8,
                        "y": 200,
                        "angle": 0,
                        "zoom": 1,
                        "data": {},
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 160
                        },
                        "size": {
                            "width": 188,
                            "height": 568
                        }
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "262CF90C9D8F674E8A6A6D94B7CC50A2156D",
                "expanded": false
            },
            {
                "id": "gs.AddHotspot",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 7,
                    "shape": "rect",
                    "positionType": 0,
                    "actions": {
                        "onClick": {
                            "type": 4,
                            "bindValue": 7,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "AttivaClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onEnter": {
                            "type": 4,
                            "bindValue": 7,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "InfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onSelect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDeselect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onLeave": {
                            "type": 4,
                            "bindValue": 7,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "UnInfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrag": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrop": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDropReceive": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        }
                    },
                    "dragging": {
                        "enabled": 0,
                        "variable": {
                            "scope": 1,
                            "index": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "horizontal": 1,
                        "vertical": 0,
                        "rect": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 200,
                                "height": 50
                            }
                        }
                    },
                    "position": 1,
                    "box": {
                        "x": 1526,
                        "y": 610,
                        "angle": 0,
                        "zoom": 1,
                        "data": {},
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 160
                        },
                        "size": {
                            "width": 64,
                            "height": 68
                        }
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5C9753A54F112440100922720D42A37CFD5C",
                "expanded": false
            },
            {
                "id": "gs.AddHotspot",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 8,
                    "shape": "rect",
                    "positionType": 0,
                    "actions": {
                        "onClick": {
                            "type": 4,
                            "bindValue": 8,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "AttivaClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onEnter": {
                            "type": 4,
                            "bindValue": 8,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "InfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onSelect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDeselect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onLeave": {
                            "type": 4,
                            "bindValue": 8,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "UnInfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrag": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrop": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDropReceive": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        }
                    },
                    "dragging": {
                        "enabled": 0,
                        "variable": {
                            "scope": 1,
                            "index": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "horizontal": 1,
                        "vertical": 0,
                        "rect": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 200,
                                "height": 50
                            }
                        }
                    },
                    "position": 1,
                    "box": {
                        "x": 770,
                        "y": 608,
                        "angle": 0,
                        "zoom": 1,
                        "data": {},
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 160
                        },
                        "size": {
                            "width": 172,
                            "height": 80
                        }
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "77680BAD246C624039591F28179760BC3B0E",
                "expanded": false
            },
            {
                "id": "gs.AddHotspot",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 9,
                    "shape": "rect",
                    "positionType": 0,
                    "actions": {
                        "onClick": {
                            "type": 4,
                            "bindValue": 9,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "AttivaClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onEnter": {
                            "type": 4,
                            "bindValue": 9,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "InfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onSelect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDeselect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onLeave": {
                            "type": 4,
                            "bindValue": 9,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "UnInfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrag": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrop": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDropReceive": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        }
                    },
                    "dragging": {
                        "enabled": 0,
                        "variable": {
                            "scope": 1,
                            "index": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "horizontal": 1,
                        "vertical": 0,
                        "rect": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 200,
                                "height": 50
                            }
                        }
                    },
                    "position": 1,
                    "box": {
                        "x": 412,
                        "y": 752,
                        "angle": 0,
                        "zoom": 1,
                        "data": {},
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 160
                        },
                        "size": {
                            "width": 284,
                            "height": 78
                        }
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B6E720271F66064E0D6A1FA3B215A01C5452",
                "expanded": false
            },
            {
                "id": "gs.AddHotspot",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 10,
                    "shape": "rect",
                    "positionType": 0,
                    "actions": {
                        "onClick": {
                            "type": 4,
                            "bindValue": 10,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "AttivaClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onEnter": {
                            "type": 4,
                            "bindValue": 10,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "InfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onSelect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDeselect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onLeave": {
                            "type": 4,
                            "bindValue": 10,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "UnInfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrag": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrop": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDropReceive": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        }
                    },
                    "dragging": {
                        "enabled": 0,
                        "variable": {
                            "scope": 1,
                            "index": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "horizontal": 1,
                        "vertical": 0,
                        "rect": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 200,
                                "height": 50
                            }
                        }
                    },
                    "position": 1,
                    "box": {
                        "x": 370,
                        "y": 534,
                        "angle": 0,
                        "zoom": 1,
                        "data": {},
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 160
                        },
                        "size": {
                            "width": 128,
                            "height": 136
                        }
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "43B1355B1883354D413966160BAE5B63479D",
                "expanded": false
            },
            {
                "id": "gs.AddHotspot",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 11,
                    "shape": "rect",
                    "positionType": 0,
                    "actions": {
                        "onClick": {
                            "type": 4,
                            "bindValue": 11,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "AttivaClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onEnter": {
                            "type": 4,
                            "bindValue": 11,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "InfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onSelect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDeselect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onLeave": {
                            "type": 4,
                            "bindValue": 11,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "UnInfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrag": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrop": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDropReceive": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        }
                    },
                    "dragging": {
                        "enabled": 0,
                        "variable": {
                            "scope": 1,
                            "index": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "horizontal": 1,
                        "vertical": 0,
                        "rect": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 200,
                                "height": 50
                            }
                        }
                    },
                    "position": 1,
                    "box": {
                        "x": 334,
                        "y": 248,
                        "angle": 0,
                        "zoom": 1,
                        "data": {},
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 160
                        },
                        "size": {
                            "width": 152,
                            "height": 194
                        }
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DA60BC1788171746BF09FF01229B82BC0519",
                "expanded": false
            },
            {
                "id": "gs.AddHotspot",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 12,
                    "shape": "rect",
                    "positionType": 0,
                    "actions": {
                        "onClick": {
                            "type": 4,
                            "bindValue": 12,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "AttivaClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onEnter": {
                            "type": 4,
                            "bindValue": 12,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "InfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onSelect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDeselect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onLeave": {
                            "type": 4,
                            "bindValue": 12,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "UnInfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrag": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrop": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDropReceive": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        }
                    },
                    "dragging": {
                        "enabled": 0,
                        "variable": {
                            "scope": 1,
                            "index": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "horizontal": 1,
                        "vertical": 0,
                        "rect": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 200,
                                "height": 50
                            }
                        }
                    },
                    "position": 1,
                    "box": {
                        "x": 1054,
                        "y": 588,
                        "angle": 0,
                        "zoom": 1,
                        "data": {},
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 160
                        },
                        "size": {
                            "width": 292,
                            "height": 130
                        }
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9C06466E2BAA4840702B08B6C1EF6CBCCA26",
                "expanded": false
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Flag locale 2",
                        "index": 161,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7080F0874F3FD9475519B146001EDA7DD7DA"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "Eventi Scena",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "52A77D91514C734C3B1BDBC6BEC81848D27B"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "PIEDINO DI ESPLORAZIONE"
                },
                "indent": 0,
                "uid": "30F5E6228300364623681D1682E2F273958B",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "piedino"
                },
                "indent": 0,
                "uid": "053EEF5D46799242C52BF042DC8A7F831206"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Gerardo's Armory"
                },
                "indent": 0,
                "uid": "2BD1D57D2817E848708A4ED3DD25935F8CAE",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Location SCENE 1",
                        "index": 286,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "070F9DDB38DD624ACD7972A3437DECC12A46",
                        "defaultText": "3CCB903D3DFFA24EA84B7CB74506E9E49DF3"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1D2903E75770564EDF38A48471F86F78A9D1",
                "expanded": true
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Hoikade Halls"
                },
                "indent": 0,
                "uid": "83F6CF887D14844E95481D0230CAD4612A3D",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Location SCENE 2",
                        "index": 287,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "62B6D1AF10AF674D382BE6944208C1B45C50",
                        "defaultText": "4128727E2334D249A98803B18CC6BDB0D6FD"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E3D326242B35464281898FE399549038359C",
                "expanded": true
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Royal Lounge"
                },
                "indent": 0,
                "uid": "554C09D44631A449EF2927C073F400F85F07",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Location SCENE 3",
                        "index": 288,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "4FEA9D044362324CC1892C77900CBF585C92",
                        "defaultText": "D6F3E4527D404848675A1507F2040BB55525"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CC56CDD8409D8845A17954D893D7F2BED1D3",
                "expanded": true
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Flag locale 10",
                        "index": 169,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7F08842C8DC1544C6F995134B1BDA314A5FC"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Location SCENE 4",
                        "index": 289,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "1C54438B3958E7472B8BB112EE7D1016A85E",
                        "defaultText": ""
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "6E4982FB15ADE54B6218FE71A5C36B13742E",
                "expanded": true
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "0D32AA1B64F78749E138DDA1A8CEC6867383"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Throne Room"
                },
                "indent": 1,
                "uid": "12381D662155844B2B895920062D23CCB150",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Location SCENE 4",
                        "index": 289,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "7B9CB41476ECD2438C6AE22410EF5E00C14C",
                        "defaultText": "449E8DDF5C9E80457A494AF9EF243245A427"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "4BBD7A659738D14A1419D3C4C8A9E47CE405",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "86CBAC798809154F145BAB489EC84573234C",
                    "parameters": {
                        "values": [
                            {
                                "lcId": "843B9F4A54438145131944B63CB30400DCA2",
                                "defaultText": "Gerardo's Armory"
                            },
                            {
                                "name": "Location SCENE 1",
                                "index": 286,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            5,
                            3,
                            "Hoikade Halls",
                            {
                                "name": "Location SCENE 2",
                                "index": 287,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            5,
                            3,
                            "Royal Lounge",
                            {
                                "name": "Location SCENE 3",
                                "index": 288,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            5,
                            0,
                            "Throne Room",
                            {
                                "name": "Location SCENE 4",
                                "index": 289,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            5,
                            3,
                            "",
                            0,
                            0,
                            0,
                            "",
                            "",
                            0,
                            0
                        ],
                        "uid": "2CA83D6626309243037AD35184F317ED617B"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "96CE2B307144B14D289866D3827494835A15"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "4445F1AC8A63F745F518340809A7E970C52A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "134C3099331B29483C588CC63CA48ECA249F"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "EVENTI EVENTUALI"
                },
                "indent": 0,
                "uid": "C5D323843A8591457D3A9D13A74D58D27EFA",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "Eventi Scena"
                },
                "indent": 0,
                "uid": "2AC06D8724AE164FAD198488F6939D35B637"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Flag locale 1",
                        "index": 160,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "21E905724E6C9744E71A67892B8D8DB3E3E9"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Flag locale 1",
                        "index": 160,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "F704660B047271407C8BED193E165D40E68A"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Flag locale 2",
                        "index": 161,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "F86AE44A40F1824A6B88E649D713900D1EF0"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "piedino",
                    "target": "activeScene"
                },
                "indent": 1,
                "uid": "97FC2E443EFD9142B44B1A4414AAA9BF8F88"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "15224E583986C649652961F8D83C325E97D6",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "28DE29F4178B1546C03A3B0863A0BCD49B40"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Risultato calcolo %: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E109C40874A8A644BD483C235B9686533A9B"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "C1A5346261393444BE0949A566356D1C714E",
                        "name": "Time's up! (Meeting with Munie)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "BAF3DB9C3951F24D655BA2C1142FB522412B"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Pause allowed bc IN EXPLORATION / CHOICE?",
                        "index": 156,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A879C19F3723D846988B28E6F18D81A0D9B2"
            },
            {
                "id": "gs.Idle",
                "params": {},
                "indent": 0,
                "uid": "0BB50F5144CED6418A18F4C36752DD88DD18"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D7547A96549313459078E4251677136450B5",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1DC236242F1A314ECC4B57D70E10C42E9BE4"
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            },
            {
                "name": "",
                "index": 1,
                "scope": 1
            },
            {
                "name": "",
                "index": 2,
                "scope": 1
            },
            {
                "name": "",
                "index": 3,
                "scope": 1
            },
            {
                "name": "",
                "index": 4,
                "scope": 1
            },
            {
                "name": "",
                "index": 5,
                "scope": 1
            },
            {
                "name": "coffer event",
                "index": 6,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "",
                "index": 7,
                "scope": 1
            },
            {
                "name": "",
                "index": 8,
                "scope": 1
            },
            {
                "name": "",
                "index": 9,
                "scope": 1
            },
            {
                "name": "",
                "index": 10,
                "scope": 1
            },
            {
                "name": "",
                "index": 11,
                "scope": 1
            },
            {
                "name": "",
                "index": 12,
                "scope": 1
            },
            {
                "name": "",
                "index": 13,
                "scope": 1
            },
            {
                "name": "",
                "index": 14,
                "scope": 1
            },
            {
                "name": "",
                "index": 15,
                "scope": 1
            },
            {
                "name": "",
                "index": 16,
                "scope": 1
            },
            {
                "name": "",
                "index": 17,
                "scope": 1
            },
            {
                "name": "",
                "index": 18,
                "scope": 1
            },
            {
                "name": "",
                "index": 19,
                "scope": 1
            },
            {
                "name": "",
                "index": 20,
                "scope": 1
            },
            {
                "name": "",
                "index": 21,
                "scope": 1
            },
            {
                "name": "",
                "index": 22,
                "scope": 1
            },
            {
                "name": "",
                "index": 23,
                "scope": 1
            },
            {
                "name": "",
                "index": 24,
                "scope": 1
            },
            {
                "name": "",
                "index": 25,
                "scope": 1
            },
            {
                "name": "",
                "index": 26,
                "scope": 1
            },
            {
                "name": "",
                "index": 27,
                "scope": 1
            },
            {
                "name": "",
                "index": 28,
                "scope": 1
            },
            {
                "name": "",
                "index": 29,
                "scope": 1
            },
            {
                "name": "",
                "index": 30,
                "scope": 1
            },
            {
                "name": "",
                "index": 31,
                "scope": 1
            },
            {
                "name": "",
                "index": 32,
                "scope": 1
            },
            {
                "name": "",
                "index": 33,
                "scope": 1
            },
            {
                "name": "",
                "index": 34,
                "scope": 1
            },
            {
                "name": "",
                "index": 35,
                "scope": 1
            },
            {
                "name": "",
                "index": 36,
                "scope": 1
            },
            {
                "name": "",
                "index": 37,
                "scope": 1
            },
            {
                "name": "",
                "index": 38,
                "scope": 1
            },
            {
                "name": "",
                "index": 39,
                "scope": 1
            }
        ],
        "localizableStrings": {
            "070F9DDB38DD624ACD7972A3437DECC12A46": {
                "t": "3CCB903D3DFFA24EA84B7CB74506E9E49DF3",
                "d": {
                    "eid": "1D2903E75770564EDF38A48471F86F78A9D1"
                }
            },
            "62B6D1AF10AF674D382BE6944208C1B45C50": {
                "t": "4128727E2334D249A98803B18CC6BDB0D6FD",
                "d": {
                    "eid": "E3D326242B35464281898FE399549038359C"
                }
            },
            "4FEA9D044362324CC1892C77900CBF585C92": {
                "t": "D6F3E4527D404848675A1507F2040BB55525",
                "d": {
                    "eid": "CC56CDD8409D8845A17954D893D7F2BED1D3"
                }
            },
            "1C54438B3958E7472B8BB112EE7D1016A85E": {
                "t": "",
                "d": {
                    "eid": "6E4982FB15ADE54B6218FE71A5C36B13742E"
                }
            },
            "7B9CB41476ECD2438C6AE22410EF5E00C14C": {
                "t": "449E8DDF5C9E80457A494AF9EF243245A427",
                "d": {
                    "eid": "4BBD7A659738D14A1419D3C4C8A9E47CE405"
                }
            },
            "843B9F4A54438145131944B63CB30400DCA2": {
                "t": "Gerardo's Armory",
                "d": {
                    "eid": "2CA83D6626309243037AD35184F317ED617B"
                }
            }
        },
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}