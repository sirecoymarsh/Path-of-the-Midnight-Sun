GS.dataCache['471127BC87A59241054953E330CCEEE2A94C'] = {
    "uid": "471127BC87A59241054953E330CCEEE2A94C",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "Lulu Talk",
        "type": "vn.scene",
        "parentId": "6358EC2282EF344F2338ADC55822848BD4BE",
        "chapterUid": "8F0F11BF32BEA44F8D6871B6601039C7CB03",
        "order": 0,
        "localizableStrings": {
            "A74B920A37520744158862E8261443F476D7": {
                "t": "The croissant... please.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "68D7886E53DFE7424E590801F8223BDADCA5"
                }
            },
            "26CD1926206FC648D859BBE8E1BD5D658AB5": {
                "t": "Haha, a bit impatient, aren't we?",
                "d": {
                    "cid": "B1AF53707075F5461158E434F0E45DF7EA6C",
                    "eid": "BA2733F23F536943313AFF180AD6B5D1C200"
                }
            },
            "857EC6D7712678478E994F8267CEA5E47957": {
                "t": "There you go, Lil' Fa.",
                "d": {
                    "cid": "B1AF53707075F5461158E434F0E45DF7EA6C",
                    "eid": "98ADCD7913CCD44C7E287838585FC77A1E36"
                }
            },
            "5C8485F9226A13479D9A8E03B94CA46941DC": {
                "t": "No need to pay for this one, but I can't give you any more for free. ",
                "d": {
                    "cid": "B1AF53707075F5461158E434F0E45DF7EA6C",
                    "eid": "90228A984E29D94906686E747BAB1FD50E1F"
                }
            },
            "6A9DD3C53F4694420C4AB0615817495E22E8": {
                "t": "Thank you, Lulu. And don't worry, you already do so much for me.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "A0F0CC122A164345D68A9A395FCCF0DB4EF2"
                }
            },
            "66836DB6593E514FB729A9D255D4489936F4": {
                "t": "Now, what are you waiting for? {SP:2}{C:1}Eat it{C:0}, hehe.",
                "d": {
                    "cid": "B1AF53707075F5461158E434F0E45DF7EA6C",
                    "eid": "DBAAD2496A8484447B6A377242A14CAE2D3C"
                }
            },
            "605113894D6F8641C7187BB6539C652550A6": {
                "t": "You don't have to tell me twice.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "810AF1434BF4214EB178C7968545D8DE96A2"
                }
            },
            "03D2C8D86F99D742C01B7A6741032D9BCE55": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "F91481760C8AA448BF88F121AFAEBD5A984F"
                }
            }
        },
        "commands": [
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 39,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 240,
                        "y": 240
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "6D499A636FFDA64F918BB133ADCAC8C4288E"
            },
            {
                "id": "gs.PanScreen",
                "params": {
                    "duration": 39,
                    "waitForCompletion": 0,
                    "position": {
                        "x": -300,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "uid": "7638E4B64AEE9542A50B7485F64EE4EF294F",
                "indent": 0
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "4B8E9FF0167D914046390F75687D84636674",
                    "parameters": {
                        "values": [
                            3,
                            650,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "E3CA44A972137746177B70C7C0852D366F84"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "read?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6866241D6D1D624906780EF690A9F0D4100A"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "E2A7BEA55906B2452B595774517F714F1F96",
                        "name": "Lulu's Shop"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "B8BF582A74F3664F3A6B055465190FDA4A13"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of lulu talk",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "E675CEC88F19C8417F2BC305D375024B0177"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C0BE5C1134DCC54E0B489FA1E5AE10BF1C36"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EB2C42018818354BEF2B1E160C38D25ABAEC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A74B920A37520744158862E8261443F476D7",
                        "defaultText": "크루아상... 부탁해."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "68D7886E53DFE7424E590801F8223BDADCA5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8D385C18271D914FA4696976E13D4CA04C6E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "B1AF53707075F5461158E434F0E45DF7EA6C",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "61AEF85A1853E6470F1977093AC2C5C74851"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "26CD1926206FC648D859BBE8E1BD5D658AB5",
                        "defaultText": "하하, 조금 성급하네?"
                    },
                    "position": 0,
                    "characterId": "B1AF53707075F5461158E434F0E45DF7EA6C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "BA2733F23F536943313AFF180AD6B5D1C200"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "76ED8E308D967543C47882804A2F853B822F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "857EC6D7712678478E994F8267CEA5E47957",
                        "defaultText": "여기 있어, 꼬마 파."
                    },
                    "position": 0,
                    "characterId": "B1AF53707075F5461158E434F0E45DF7EA6C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "98ADCD7913CCD44C7E287838585FC77A1E36"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "E80515972B7E5945C45825677BEB88B5EE60"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "91370431537B834E896BED62B1B1322AE27B"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "7FDCF69630DDC648C58A59D8A6206FF2EE9B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0311BE5092E2034F93688BB62C6E859C7032",
                    "parameters": {
                        "values": [
                            "6816B0198B86F8456C6846F8A08E021D63A1",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "A691DC1E3DD1384D1489E783A8C2377F468F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EEC637476CA0C44DB639DD3814A41B3AF9DE",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "39536759266CC64FFE4BCAE5FE4BAE39AAD2"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "12EF8FF77F90F041412936368FF7A5F05C6E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "949486E652D153467979E4232743263C76B2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "B1AF53707075F5461158E434F0E45DF7EA6C",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "822844A15780D845D9892501EB9E3065A173"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "B1AF53707075F5461158E434F0E45DF7EA6C",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F815DBFA6DA8774B0C48E0270BCD86D22B02"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5C8485F9226A13479D9A8E03B94CA46941DC",
                        "defaultText": "이번 건 돈을 받지 않을게. 하지만 더는 공짜로 줄 수 없어."
                    },
                    "position": 0,
                    "characterId": "B1AF53707075F5461158E434F0E45DF7EA6C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "90228A984E29D94906686E747BAB1FD50E1F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C5A560A09256864BC04A6AB14CFF29F052AE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "682F345566965444AE4801F2621B66D35606"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "03D2C8D86F99D742C01B7A6741032D9BCE55",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "expressions": [],
                    "animations": [],
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "E3-Faratras_line13.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "F91481760C8AA448BF88F121AFAEBD5A984F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "2C866062289C32461E1B7FD170A7297825AD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9B5E545F62C23945523AEB848C192506CBDD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6A9DD3C53F4694420C4AB0615817495E22E8",
                        "defaultText": "고마워, 룰루. 걱정 마. 이미 내게 많은 걸 해 줬잖아."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "A0F0CC122A164345D68A9A395FCCF0DB4EF2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E77255EF2AD5784C8A4B1E629F1274467AD0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "B1AF53707075F5461158E434F0E45DF7EA6C",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5A026002897E024BF64A1FD65EA80F5EB3B7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "66836DB6593E514FB729A9D255D4489936F4",
                        "defaultText": "자, 뭘 기다려? {SP:2}{C:1}먹어 봐{C:0}, 헤헤."
                    },
                    "position": 0,
                    "characterId": "B1AF53707075F5461158E434F0E45DF7EA6C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "DBAAD2496A8484447B6A377242A14CAE2D3C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CBA7FEE85DB9F3466D5973A50EEB5FCE694E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FBD1E40825CA4948E17B84D1F1169316B8BD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "605113894D6F8641C7187BB6539C652550A6",
                        "defaultText": "두 번 말할 필요도 없어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "810AF1434BF4214EB178C7968545D8DE96A2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "E91BABED86EC184CBF18A1C7476408C77A4D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C9F97EC73B415948EC99CD45A90330765FF8"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "697559A6947D23482C58AF21D0BF029B4410"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "422B49CA8A63A04CB338ADD9E56A9BFB25A0",
                    "parameters": {
                        "values": [
                            "",
                            {
                                "lcId": null,
                                "defaultText": "You can now access your {C:1}Inventory{C:0}."
                            },
                            {
                                "lcId": null,
                                "defaultText": ""
                            },
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "942BC4C531FB304E2A2BD0C8F9E2E8E773C2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6FE3C1466BE6D749E93B1A1763C2A8DE2900",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B588036C752CA7411E694A50BC225E4E820F"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "read?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "734D648B1222D546CF18CB1104812A8DEF16"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "read?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "AEBAFE4B87C6A64D780899402694C1CBA4FB"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Flag locale 9",
                        "index": 168,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "3C1A394226B421465569A1F9ECC1DFD3C876"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Prevent Exploration HOTSPOTS from being reformed",
                        "index": 178,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "5552E21710A8484C2F385F5750B54B7D743C"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "end of lulu talk"
                },
                "indent": 0,
                "uid": "56AEC32C57335443B539B7E878B4B335ECD1"
            },
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 39,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 100,
                        "y": 100
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "5F636A3D4E8C384EDB383592BF671AC1013C"
            },
            {
                "id": "gs.PanScreen",
                "params": {
                    "duration": 39,
                    "waitForCompletion": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "uid": "86F4FA9907C7C74D1F8B6D507E8D368C755B",
                "indent": 0
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "4B8E9FF0167D914046390F75687D84636674",
                    "parameters": {
                        "values": [
                            3,
                            650,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "BAD5A4983F8C294FD73B24D546F61E14D42E"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "9B8533E05B642444DD1970A58176312B6733"
            }
        ],
        "livePreviewDisabled": true,
        "booleanVariables": [
            {
                "name": "read?",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}