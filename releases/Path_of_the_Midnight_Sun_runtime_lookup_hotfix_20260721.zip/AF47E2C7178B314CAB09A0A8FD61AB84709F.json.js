GS.dataCache['AF47E2C7178B314CAB09A0A8FD61AB84709F'] = {
    "uid": "AF47E2C7178B314CAB09A0A8FD61AB84709F",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "Names of all Inventory Items {to GT:315}",
        "type": "data_record",
        "order": 5,
        "category": "commonEvents",
        "id": "AF47E2C7178B314CAB09A0A8FD61AB84709F",
        "isFolder": false,
        "parentId": "6ED66A9042ECB3444948D814E41FB327288F",
        "data": {
            "name": "Names of all Inventory Items {to GT:315}",
            "startCondition": 0,
            "conditionEnabled": false,
            "parallel": false,
            "autoPreload": false,
            "singleInstance": false,
            "inline": false,
            "parameters": [
                {
                    "label": "Item",
                    "type": 3,
                    "stringVariable": {
                        "name": "uid comparison",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "stringValueType": "text",
                    "stringValueLocalizable": false
                }
            ],
            "commands": [
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": "",
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "16E279EC76965648138820D4AE82FED75F6D",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "CF2204C51119C14C4B39CCE5A2C0B74CD9D0"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "70AA41FE6966C1421D0998A62DEFEB043887",
                            "defaultText": "선장의 검"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "AB2694E895292847F58B3240EE24AEEE4386",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "2F8D38681005F44D392B1111658909DB7434"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "FE39EED41BEB7046655808019153972819BC",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3C641BA067A9A840191BBF66B784D03E94F5"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0DEDC9158BD19344DC4A6A976D3AC56E4784"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "891C07964578C547D83819838C6E3C4EE3A8",
                            "defaultText": "워프소드"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "9C1387AE9487D848E01942989A84E696BF17",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "CD3E288E8FBAB349354A26C12C8AABB2E2EA"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "25BADC707F4B73415258EA98362E6958770B",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "7216F96412C482448898506115AEC1FEB946"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "214408E050CF17452E8924E864A7E71EE3FA"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "BD855F7D508D1940A739B3257CB7EACCDD65",
                            "defaultText": "청동검"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "AB6C317B89E1524A458BDFC70000D33A652C",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "E55B968913D65146E42A48D52CDF940D89F1"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "FF8A0EF7844876459E8AC032E19770DB2F32",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "DB82131782C2A84FB948C7E3F6888509BCF3"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E57DA0B4500639429D8974F662C2CF45FDB8"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "1D2E828650E99643072B8BE806FD484DCF5E",
                            "defaultText": "브론즈 소드+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "95D3BACE7C581346D25A70B197EF2947A9A9",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "B561A1250695A849B7991022BBFA67CB89FE"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "D91576FA49556245E52B5A44D7C65D29C58F",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "30EEAAD88D70F547AA596CE2F659AA50FBA6"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "7AB6CA4F54FD95424A0B8942F95915F72499"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "F51560A822558140F65A1876588EFD982106",
                            "defaultText": "철검"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "99FCA4806939B94A642A8CA6F1D02DA80CA2",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "27E08B7F4F6A9740848B5FA059E190542F2D"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "6CACFDEF74BF114B595AF7D19FC3EDE625F3",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "710E4A9437ED804BE37B6F27816C1FA3C000"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "6EA0F7BA21EE0449FE380B5160E4A466F848"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "0FE21EA44E613147A24B1087E91EE141714C",
                            "defaultText": "아이언소드+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "CE8BD7641EDAC448262882D3C1C65787574B",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "2DE862E288F9C94437984EE7FAB7689F1734"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "3B0CC1DC3A5686405B19B414D254FE0FB1D1",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F48DA5B52F61C64DBB591EC1C1669EDC1C92"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "00F16878084A824F4498D485EB3A17166075"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "2742E7D520206645336A0412E65621EF78F5",
                            "defaultText": "치명적인 검"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "18600982785EC14C1A884EF2C91AD340F069",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "A6F62D536C4D294DC38884B64A549A905EDA"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "C6D1445F4CA9C34C1C7A6D692C4EDB45AEC8",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A2ADD40B3766F541503930F157F2A0A62AF2"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "25E77E5C1083764B2088C3011D3AF56DD1E0"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "4B2BF68D406BC549D71B7F0595212394BEE7",
                            "defaultText": "치명적인 검+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "6869CDDC52BD674F00694FD8CF369D7D53F8",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "A528C5757F68584CC68A5F02FCA15C091FC9"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "35E7299A287587446A4AD6D2044690237C90",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "FFA91FBF2366274F79393671246FBD3C0C48"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F65710815BC8A743AC7A1373079DD881A2DD"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "D74AAEDD769FD64CF58B3EE16F71BA172C59",
                            "defaultText": "미스릴 검"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "014331B37FBCC9460A8A1E73DC09E09AE373",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "28EF6D98162E2146B21BADB438F70331D6C4"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "61DD9E108F9900450158BDD85229904EDCEF",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F871921887D5A743447966086A1791EE7B1B"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "37F2011D8A5D224DB80877E04686B8069D62"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "A36D41D869351540812A7EE56E2A6F127E9C",
                            "defaultText": "미스릴 검+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "646B9C8A70B6C345612B488580F1CF0E7EF7",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "45A941C7819968481F5A5D6284CA60F6EBE5"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "6BA079671A75924DF2088566F587FCFA8F0D",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "511303A06A498247AF0BD6B01AB19449B3D4"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "AB2B3391687C754D67887B537D55DE80BE5D"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "91093F8F3D4D6245AA8B9379BD99476F0190",
                            "defaultText": "매직 블레이드"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "45908CB526C08842052827F9A17183A23A35",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "E8C1490F93B6B744B978F3F4CC115C16EE86"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "1C6017A3325EB949FF99DEB7AFADE5B35FDD",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0DA3D09227A6A241A6689711BFD0BBA2912B"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F5F523E47696A24D13294BB17E1D0E687B09"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "2522C80562C2F3415E2B9A053547DA661374",
                            "defaultText": "매직블레이드+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "458636AC115944415C3BFD280BAFFA6F900E",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "30C60858674741458259C7329D74187C05FA"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "4013C0C989F33340000AC38796E7C78B71C1",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "FC5F73EA3191D543756BF426B5A06AA2BAE0"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "40F11245591AC540EB893152E507FEA99B13"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "33C64CC84FF727489D39E174F2DA15939ECD",
                            "defaultText": "요술사 검"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "18F727C0562F6141715A5337900328F5BEE6",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "60BDDDB49CC90447CA1A51F234CC0CD10C80"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "9034D21566F44146AD1975725B4786D8DBBD",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "134BE4B1966243435D1A08971D1CB246AB18"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "17929299387D784ADA8896D018E7C4A377DF"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "BC58DDDF428ED740378A66E2CEFBCD411E2A",
                            "defaultText": "컨저러 소드+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "1823FFE96C86084F619B59505212E61B2980",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "7945056A9996274AFC8BF466308932C782EC"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "4FCB47A96252C749A33B86D7CC5578B272E9",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4E083F1536A5C3488B3A59D2C50CBB5E76DA"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8E606BE160733241247B99265B992DCA17AB"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "7BABB33774F5D74B2309371519FD45F5C37C",
                            "defaultText": "스파디아볼로"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "91A0CF282390864E760BD23067E0A0712F46",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "7AF47CE667EBB546191BBD362D22F3506642"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "310925672846014A3B4AFD038A3CCB2DB41B",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "21B6A72F5E01A44A9B89F4E7E59B8166C340"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "DD22C7A11944D540C57BE3B452FBF51D52C4"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "Unlocked Legendary Minerva",
                            "index": 110,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "",
                        "switchValue": 1,
                        "valueType": 1,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "4D394A244FF8D64DBE3B05556D621A0A29D1"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "7821B5EB0F8A8446EC982761F366F2E3F673",
                            "defaultText": "팔키온"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 2,
                    "uid": "76EC192E48F8934D9A497286CDFF93F03A2C",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElse",
                    "params": {},
                    "indent": 1,
                    "uid": "D466A0B931DCD9491B189295460617DBF996"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "06FE537832B7984343985A062139938F5DB3",
                            "defaultText": "팔키온"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 2,
                    "uid": "BF059FB60655A54A734BDB986C3B66EC7B7B",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "72B9C38A350EB6445F496C421B9E6DA80AF7"
                },
                {
                    "id": "gs.Comment",
                    "params": {
                        "text": "Manadrops"
                    },
                    "indent": 0,
                    "uid": "AE42007A3F9A6845E97BBCD7934EB5415E7D",
                    "expanded": true
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "1071395A1B8A804C762BE737B21EC88E3B14",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "021B0A6555E3354B5C8B71B6A6C2E226E5EF"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "32BED3811189074C593954F739727A032396"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "C09641805A0DB34DC07AA0B016D576510EAE",
                            "defaultText": "시오리의 마나드롭"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "8F5D04C66C4114400429D7993B4C385FDAD4",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "1FEAE324749FB74D2A09EF42132156F0ED20"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "E934F43067A12646E57A76B1261B2493D791",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5ED7FCBB60C8644A0C9ADA2597814F88B3AA"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "36DA93963C59824FCF8B9CD8B6A5B6D73CB1"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "E03B30DE0268E74F3E2A02D04470BC6B6690",
                            "defaultText": "파라트라스' 마나드롭"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "CDF5A1271CB544464F5BC07617B68497DE3B",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "02BE0B1449D7E146A44B8FE881CCCBDCF20D"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "4951BBF22CBBE3412328F5A491366AF0EF4C",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8429614B26ED4348C128212816EBA81755FE"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "DEAB6ABA0563954EFF6A36436134ED4842BD"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "D3A9B1681C68D940DF7938E0F59E41B189E1",
                            "defaultText": "마력 깃든 마나드롭"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "885F688811F1F54B9859773196BB9A2BF3EE",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "65F90A8F6612F440259B2028C2D3D30AA79F"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "A97EF95D32D713493C9A023764508F1513CA",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "AE6AF6F690FB53477F29DE96FF278464421A"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "06E29DAF0A578848C11AD7F292B862483248"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "8D427FBA7E34D64C8759093746D50CA40C54",
                            "defaultText": "주입된 마나드롭+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "9BCFD0DB10ABA14E485879E74590C955933C",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "18878E6E8769324D2159E3378E806E968B96"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "0626BDFF7738B64DC17BCD35EC76A2C575F3",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "DB5F573A656F744D759B372322162EFDF7F4"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4DC65B60976B7347813A5E722B33AC78D0E4"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "50117B79939055402E18E3C16930A5BDCBCC",
                            "defaultText": "치명적인 마나드롭"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "BA38B6D51647084F923B76A96D1CA92BC85A",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "F60464F57558154208181C0245FD0039A575"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "2EECAC618F5B574C4E3AFA844431BDD1C3C2",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D1C98AB78C0BD4453D0A7A603AD966793557"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "40FA2D074A799640535834C38935189CDA6A"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "FB77E7191F1E43494F598428D61A3C53C0CB",
                            "defaultText": "치명적인 마나드롭+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "88E6BA254274B3430A29FAF5CBA05BF4E287",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "4F996CCB8C63B24CB268945554DDA64B94BC"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "5C46D4D24728F146756999E4E775FA4E677E",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3B8E5E8E2452474CAE5BD83655FEC213C1B1"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0CA40657868A944F1A8B9193E99113136602"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "ABEAA6A525B3234D0C5869433DCAD141262E",
                            "defaultText": "브라이트 마나드롭"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "801B0FBF2C1176490C5B7A613AA8BBE269F9",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "D432F24A9768B843DD4B6E94272C457B7553"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "4ECA89EB783DD34E66387D445A7F982AFAC6",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "FA1621178D4E174299684897EE0C72FB6B2C"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0F97E81843A592491C494D62AF0EECAE8C64"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "849E8F977AC1A84028797FB39774B11DB484",
                            "defaultText": "브라이트 마나드롭+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "0EC1EBFC8887134F096A6FF2ED062C51BE99",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "E3AF43ED61D0D749D64A22A7074A5BA59B31"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "C30C8CD30B3CC641676A6F682B0A410D1A03",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9E6550D90426184F294B208536A96B80FAB5"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "EDB88CF0312FA340BD1AE7726D9A92FFE6EE"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "1A039D8F5628504C233A0459863CED7D4BE9",
                            "defaultText": "이런 마나드롭"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "B9535CC51C8235422C197BA60CC255DF7844",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "5DF1B74E8750674C098A694232142076F00D"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "AB31C77E709A4248DD497741D6D0074FEF0A",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "031EF9335C40974BC2399826F99D4514BF7D"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "24097DEB518FF145176BA15917214A404A13"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "B6B8C909845645474D2B64A56D1F9E4EA51D",
                            "defaultText": "이런 마나드롭+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "FEED09206316A14FB77BD6926A099D596570",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "C804BAD590A58147970A49E4015091EE108F"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "676322E56D9A9643447B6D4548486774F956",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "ED6F789D839BB64AF67BB7F1BAF68F704947"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C506B22229A7A840E97AF2C86C9C05D7EDF7"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "6CEF6D3035F2754FC48805D855342DD1E466",
                            "defaultText": "으스스한 마나드롭"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "7309E8533373114C6A5BED3989C654C2EA86",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "1765A30817816746145A82464D48FD174CA2"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "86D84F3B2B5CF64891997742E766DE31B5A9",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C7189D1F2E0D8340F249DCC748A3E2F22020"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C49C20219B061249246883B7ADE1B198859D"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "68AD09BF10EFD7437D1BE9E4B6DDF7DDA65B",
                            "defaultText": "으스스한 마나드롭+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "642E878C40DDD34F2D7BE769899EDC7EBFDD",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "688D60185E23F64CAD1991E8AA99277A2927"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "DA989101669CF14A6129A6F6D21AE0F564CE",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F559143560234142009BA3F128E858570544"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "90109E437EFF074E5B28A09147DD8A94D5C3"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "CB014A4071E250402938F5489B4E44F68845",
                            "defaultText": "솔라리스"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "19438CF077BEC143C82B80E53764865FB76F",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "7605AFDF8AC893480859CFB8D079E884BF05"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "CF5B80F28D0C224FFF685F6315A6536D4C32",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2D314FE399E445412C6951D2096590A8E901"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F75F7C1273D6234C1D9B433300F5D1349D80"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "296309A01AA6764488497F89B3435B0C1DE6",
                            "defaultText": "루나리아"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "C2860EE6182C3643D5897C9330F87858E511",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "A4BA0A8C6FEFA3420A4A789295751AB9F8F2"
                },
                {
                    "id": "gs.Comment",
                    "params": {
                        "text": "Axes"
                    },
                    "indent": 0,
                    "uid": "85F2BB826D246543744A3AD53B2754472DF9",
                    "expanded": true
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "77EA9FA214C7C74D5E08F7A253D6ABA6CECB",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "297710F74418454B765BC6169E5F6D57A79F"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "534A709374EFA64E5698FDA3F5C26BF06EA1"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "5C3758E922ACD84D2E39D1C997C935E44EFD",
                            "defaultText": "크리스토프의 도끼"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "2C1B7B2377CB2146A96A5E379058276413E2",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "4375C1EE5D0C57431E9A22766101573147B4"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "9E0B251C287FA74EC14B84D59CC6EED519FC",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "DF8E2CF127FCB14B832ABB5451E7F5C3319E"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "BF3D68667BC3354B051A0581E75336AD75CD"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "51F3D97A7A91D94D1C3A7BF4BC95F519C673",
                            "defaultText": "철 도끼"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "00B6CDF03EA3A44C276A67320A043C31A4BD",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "1279A57F8B7E64477E7A6201D9521DFD09A2"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "B89D72907266F5414039A784B2953CD521AB",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "417665944781074F58281DA193AC5D2D3E5A"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "84720F4C837EE94029482821E4443ADB72F0"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "8CADC0FD7F2DE343AF8A52459B60FBFCEBB2",
                            "defaultText": "아이언액스+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "F856B28E4ABC2148CA1A95A6747088C9737E",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "CD84ABFF6F77484F8C2A1038F2E3FC443611"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "65DCBED348CB784CA06B9CC6E0E6C4FCA9A7",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "64EA2B798ACB0646776BF816B091DC15DC08"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D1B4A8CB826838401A384B753313A3227458"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "D34EE7BE8493764EF27B8F45AF109367632B",
                            "defaultText": "치명적인 도끼"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "896D519325701742AB7B23F714E110282A42",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "7657D1C89CF5E3447D2A39E33DC455AEFA93"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "F82B4D294286A34559693370567542EFB179",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "96D1DB5254F8F64E668AB373E9A12A606ED2"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A4334AEF2F0FD84E395B9F336E0A40278D93"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "0E2A1B0B882F644C640A0EE87E3F667B23E8",
                            "defaultText": "리썰액스+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "85E7DD4E26C3C740171944E0E11354B2912E",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "1FB856BE6E1F874A9758ACC5D74C9A8D1016"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "BCDAC8365427234CAA3B72B5EF7975C59C0B",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F9D4C304604A794D7F5A6DB8F0E89D214259"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A7555D102C1DD644007A34F09D81F066F4F9"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "69A4E68D7F60584CC64923C86F2295BF532E",
                            "defaultText": "미스릴 도끼"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "C2ED95031F74694A2A3B48A75433D22996F0",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "FD57CB233965C647A63AAC8154B08840AF52"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "67CA10947F93B5430E597EC42B27731559D8",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "886E4B0056CD4445E98B41382B13685048CE"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "48DF33D76B4F1545141B1E89109BA1EA5EDF"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "94B7CCE77D3629476F083B982D09AC0320B0",
                            "defaultText": "미스릴 액스+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "97E3BAA0491AC54FF42BDB44E86A0F77D719",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "98869D753B63E74FC6788674D3775A0BC31C"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "2924B1C6786BF7463238F5F4EE22167138A3",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "70D3C47559A0734FD18ABB6830D1D1EBB6E8"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5C1362C27D5AC24EFA0B91577DA46E34D569"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "C6D88992663B1042F5497F92BFCCB05729E1",
                            "defaultText": "마법의 도끼"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "30F8A9B82D34C2446B59B856373E0E2A4152",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "FF44B5E874398448411A70968B1AC23D47BA"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "63772A558702F54F7B4A84E37EA2D38A4BC2",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2F4CB4BD4651B141382B4F70B31F5EEFE688"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C4CDB8268063684E055BC6726E9D5F377737"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "2FF7025E808F3749A80A31B43727B2708ED6",
                            "defaultText": "마법도끼+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "C7B1907B7DAA2540E26BB863B0E44C146320",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "1A2E2E9B7E31D74DF418DE93EF89D1622215"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "324274890E0E5240888BEC16C45885C3F312",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "833FFC5C73612549EC4B1C318608F5BAE49E"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "921E573F4105D246627971814736FFF72AAB"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "6670A24999A66444673AA8B901BB5C97CD72",
                            "defaultText": "요술사 도끼"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "BCA0D26462DBF44D25384B93DDA3A61A92D5",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "32E0A90E541541446548D934DFEDBE062ED7"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "0AE32A521F5D92483F79A4D57C9B194C7B53",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D2C36BEA60C6A5479E891163145C1269F44B"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E96CCC100459C84F3D9B86E9EC717C14CD72"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "62474E39398E624BB96B2B949C1986974A63",
                            "defaultText": "요술사 도끼+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "025B457F36B723462A1BD8A0586B9D9E2D0F",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "F9A547F717D3894E920B6A731C9ED8826660"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "AED1869D8C3DF64DE168122649A88DB8E410",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "81747A3E625BA142E089CE980250D729C45B"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "96B5E9D3768606438728D4356EB2F3C3DCCC"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "471754A7620BE54F3B4B1DB4FE44666FAACC",
                            "defaultText": "가름"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "C46B83742B135246B53B243349785A019060",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "335118982F2DA84FF008E0B4268FCD6CCF19"
                },
                {
                    "id": "gs.Comment",
                    "params": {
                        "text": "Bows"
                    },
                    "indent": 0,
                    "uid": "09126E6D512EC94C59488A878B10B09E4611",
                    "expanded": true
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "FAC2A9DF23F307422C59E67677F611FD6A58",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "78B35C1D4299154D4A9873A716544662B13D"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9C23D06A0CDB58413C6B4B7180CC47D55653"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "5C7F10437F06F744354BC3F3B988623C7C8C",
                            "defaultText": "리아의 활"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "EE372F09939CC347F289FFB19214ADEA5DB0",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "9F7BB03C0A357242E41839B4D21935AEB0E7"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "E94EADBB4545B44C8D980CF6280E816A5E3D",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "89DD85CA998BE9495D89BEC6BBFA5D0FE709"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3B94B3696499754BD928B2A005D5AE6D1FDB"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "D4931E6F0A80A84D510BB102EE637897DE8E",
                            "defaultText": "철 활"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "5B37374E629D30429068D478DA587FB54777",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "E9F18C9A17F54740E17A521915A905B4BC4A"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "35D20DF46ABFA14ED71B35315CBD1B454C55",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "20EEB0C07BDD41484E688EB2612A41C22544"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "592429C97D6FA541CD2889280D003B3A9CD0"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "18A7B80A935F62414208FE584EEF8E85736A",
                            "defaultText": "철궁+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "FFDA33958844584173798045D88A2C172A6F",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "55BB101721AB94453B685A9515CEA2FFBA24"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "3E557AAB51DF1140AD98A7E5FA2032FC439E",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "BF63234C3FBB844D1728F7E8311C54C794A1"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8DC2CF778237624C899975C4EAB534243026"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "AA8C628C5B1B24429509BEB0BAD427CC5E52",
                            "defaultText": "치명적인 활"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "CBF532F716B90244364BE5A0ECDE0F54A4EF",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "B136423764BA5548FC99B848CBE6DD830AF4"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "9C582FD286F84047683938C27C5D30098B5E",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "42A96A1A8CBDA941608B604718011F44B36E"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "06B0016D2A7C27440709D5D7F2A4783DE71F"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "66060C9B24B81341107A7545B4989299FB41",
                            "defaultText": "치명적인 활+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "FE182ADC2DDA424F0A182B71C357C982A239",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "18084D195029B243B40AD892591B2FBA73B8"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "E6B33D9132C988458B89B5E27F874A37B364",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F19194141D0A85497D2A08A8FD39D0A0D12C"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8265A33E879F8841C38A1585BDED5F66B901"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "E5E92737704737488F68874266BC37BCEA28",
                            "defaultText": "미스릴 활"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "14C8967075950042431A0CB6C9835E93936F",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "717781756175F441F8591F50AE6504E1141F"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "EB7A4B8D5111824D129A99050C2C32BA8FC0",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "CB17F1EE71312944574A5C618FCB3503BC06"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "362E5CF89D2921401D2BC7A5C3BB2D26A7B0"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "328B3AB3771CC14F1E1A49C288FFB665023A",
                            "defaultText": "미스릴 활+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "BA7744F13A35144BD908F340A86F7410968C",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "53C82EBC8E95204DC9381696C7D5CAD1DEF9"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "7A591C394BD3C149BD6B52E8110B3E4E0B2E",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "579570C634F0F94B891B66370B94397A8401"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "DD402FB46DDFB54450383FA804857AFAF0E8"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "F32307955F14964E8709B97273BF5BDB1F95",
                            "defaultText": "마법의 활"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "B5FC9FC05523B144874AFF52EDD0BAA6040A",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "F7E0B7AD844DA9433789D6356E745AC521EE"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "7F478DE743A048441988A9C7DE72532ACD31",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "484A07A61C63B54803796295D96EAB7DE0B8"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2C1532374ED0C84A506875F9ECC4A4458A46"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "5F5725869A13874A7E8BDA688586253654EA",
                            "defaultText": "매직보우+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "FFF95DE69B10814EA36AB236F6B00458DF11",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "3C69E9CF2C7EC1456649AF314804FEE8B21D"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "3C4FD83F1EC0284E971B3B13484F9A1C8BEB",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2610DE0D544662439D696483259B98478ECA"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "1EB2AE209398F849CB28EB46C4ACAB173EB2"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "C8CF061232EE2840C19A57E96781D0A9AAA8",
                            "defaultText": "요술사 활"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "B445423626913748F899B1C2C5E3E8F2F36F",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "12FCDA033BBFC14E222AF518EC969D39AF7A"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "EABCDAB25465B540787AB87895C4B8FA896A",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E47DEB5C709047480169658559761608A27C"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0155F2D03CC9334A8598401166F756929559"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "EC70EA5532BDF64E995BD911CB32DF70AFC4",
                            "defaultText": "요술사 활+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "6585FEAD1CDF6246EC68469277E379DB3DB3",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "2112F8ED15D17542472A4DD6AB38B03ED527"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "CE973E8767BB69405248D2952C3DC66DA988",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A060611661B4E24D918BDD2731F9D9605004"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5000EB4D6152364C0468BA9676CC844A368A"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "A491A78F4A72864C1E9973195F7A7B38CF59",
                            "defaultText": "니드호그"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "F61EE698996A8945E04BC9F480A60BF119C3",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "6E6EC2662EDD954FA83BDEA34BD0975CDB33"
                },
                {
                    "id": "gs.Comment",
                    "params": {
                        "text": "Head"
                    },
                    "indent": 0,
                    "uid": "9AFFD3D00F8B374D8E8AEA23A069BF735238",
                    "expanded": true
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "390746640A122841995A59C30AE446502D6A",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "62BAF2741B9E91478519D72438BF312DFEA2"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2072F1CC29F08443207884738368CB826D2D"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "DE5198BB75053943D37AF951A49F1C3F57C2",
                            "defaultText": "가죽 모자"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "4F19A69D1E77264ED92B0824117CF298D0DC",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "DFC55BF05D9142450A1AF5F7CE0D606CA237"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "F9A3F0DF7FB6704F4D18799532C3EB663EF0",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "BD9188121FFF184E79884F176689CC888896"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "EC0971551A117149995A9DD9C158AA369694"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "B32217300A19884AB13AA6A4D694CA7904C0",
                            "defaultText": "가죽캡+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "9630EC589A5EB443AA59A302E4BF1226831C",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "262779763178F74A4A79F249BF33B3724020"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "721E830C9353744919690D29307B0F54C36A",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A4F3D8F62183584EB38AF9808352AD6CD1B7"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "AB887A964194F04FA1596EA3785CA261352C"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "9EA9E1331E1D264E148BFA10ACB8FA8C18D1",
                            "defaultText": "청동 투구"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "95271C51690F4344A02922722F78C7D0E3BB",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "C4CD98024403D14CAA795B93B522624C3FB9"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "648B169553ED6240524A17F208AD521CD38E",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5B3EE22511032840781AA757F9E8318D4608"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "33EA580A6E83D8420F5B07C2C75D0F4AE155"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "3738FD9D808E684A1668174203ABD58F8957",
                            "defaultText": "브론즈 투구+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "F841EF2B4F30674E982A26C866E216D3F7F1",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "9163AD7777B4074F736B30C32D1D49CFF4CA"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "010ECB9D9AA3A640605A21869631386023EE",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9E1544C56431F0422839716476862F294439"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F5D5DE096A8966492A58BB04344640A83F4C"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "0526AB74651A534CEC1A2A159A09D4A2878F",
                            "defaultText": "철 투구"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "8382723975467144676B42F48F8429ABD877",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "262C57156840D44231791B76358C924ECEF4"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "1EAA4B0A1C5ED944054B4759515809347D5D",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B492D0B53E21C149F258F0F1BEE0E987C5E6"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "DEE9D7172552A443FE9A0963B1D9239E5C36"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "D5A2511772D7A2419F29C4D81446D2256230",
                            "defaultText": "철제 투구+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "56C501B973E7A44C4478C278D13B78F51CC3",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "AFE1841C63C79743D92AB1A1C8F097C18DE2"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "6139388D058AC04F07588304327BC8FA9C0C",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "1A675F4F136851420F7A1FD72B908999465B"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "52BCA1D1775CD14FE46AB963356020935B14"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "DEF20C316B704345274AA43869E3B530899E",
                            "defaultText": "폴라캡"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "1B00DE1F30D4A940126B4280EE77D52D208F",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "DB71479E4B60694224986DB87E196C58770B"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "D435EC4A9EB6334EE768A693ED025DEE46EA",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5F8C65779CBE614DB95B96249692952937E1"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C7793852233FA742FA3B616119F345BBEFAB"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "59D638CA6B4D744BA60BFDA8C213F0D7C14D",
                            "defaultText": "폴라캡+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "992E842A4B3095494C98CF686E00FAC1FAB1",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "46FF689954B644485C5B9B07F5D97446E3BF"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "5E4C9C411299E14B6F8AAA144959E2F3853A",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4A42BBF93CB65341339A0EA0C9DA12E6E6E0"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "38F52C7086FD3749C93945C5CFF32A86012F"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "D0C7440E224AC14D6F2A2FE4AD5012E76FB6",
                            "defaultText": "파이로 크라운"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "F434EC77878F134079298ED450E22B3F090E",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "220876D94FD64449F30AA811CCBFFC6B10B2"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "B1BBE1E53E79294EFA5887645FEF3399A54F",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "AA44DEDA9DC1614EEA5983B5579C45D21154"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "CC33E60933170347106913D5E5D13EF5695E"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "29ECB39286CFB3490B095824F8F35530CBD2",
                            "defaultText": "파이로 크라운+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "4F05BE548357864F054BE09817EED447AE01",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "4BCFE16A253F074D73782C73F4B80061DB4B"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "C899E1A64B997741781BAF7544E78EF64D83",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "080526F411863845548BECE738FF367F7930"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F0EADB942CD0F547CA081A637B3E6BB0E6C1"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "47252A389AD2B24AB568838179A966D4332F",
                            "defaultText": "미스릴 투구"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "C94DA2531ED6764B6138CB21FF541B4F42B8",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "1B10A00F502F624E074B7C87447360AD23C4"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "C99CC84A1275D14D511A835375189A8B0111",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "76D75EC04B4B184E092855928F0B16C6BA09"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "78E867307680B942683A1B64756827487F13"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "254BB7CC4B044649842913937FC03F12FB5B",
                            "defaultText": "미스릴 투구+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "C4D2E7A415DC624EF39AF0B6FBE0FFE3E1EC",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "AD4678EA5DC7C342EC2B22F37DBF5568F179"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "BC1D00862243444B317AF930E13585AE854B",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2F350F2C1A0AF74E14299E51BAD451576A68"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E52A8914592F5946642860469753BF3F01E8"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "D556CF2940A51148FF4B1C56D04E43B3AC10",
                            "defaultText": "루미너스 기어"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "3663ADA35F7E7641B279DE35A1DFA959F7B9",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "D8F1E5733D28F24EC94901685AD2E2AFA0EA"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "9A6D21FC2DD63340B36AFCE73847816F9754",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "60DC125784B1074A7108E522560175CA8F4A"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3F881EE167ACB644951A1C04D364E4D3A303"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "31DB4EB633DB5144DD8B7D266C103DD96553",
                            "defaultText": "루미너스 기어+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "64281D7782601741E05811B7F5373D1C55C9",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "C4A9AB8460FC7849909ABFA25E41AA870204"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "5CB7B3C46611D743484A580146DAAE8D246D",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "11B7EB6D7547F142EB5A7FE2FBF51AF94B93"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "85F05B025770E449155BC43854C9E07F1D2C"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "51D72E856BEA73453D3B6E68FF83BB1E81E3",
                            "defaultText": "보석 달린 머리 장식"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "45C0B3A529F93142332B47F8556CE6B8822C",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "1BDD916C2E152040C55AEA05DFDE84B0AE59"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "DD8F635F45D58243025AA7A47A9CD803C2E6",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "51ADDF0C1F373846DA49C8D7343877E450D9"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2189517D6A1FC248BF6B01782A7ADC6F2D2B"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "AD48C8965B92F04C7129B114794AB9C0FF67",
                            "defaultText": "발론 헬름"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "0C38C2352C38F248CA480475127F4E34DE92",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "22FCDC7754C6614BC43BC096202DEEC5831E"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "1F1473C75F57C6416A3A7CA68B763D274C6B",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C45883AB5F17664CEF3AEFF7B4F313153695"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "165106064E74C44CCD6BD3A6B5F509281E3C"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "57FEA6698893484B419A6E767FFB03E30A3B",
                            "defaultText": "타이탄 베일"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "58EDF9ED8444D54A613B20389535D8D7E6B8",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "30E0BAF814E7A34875585795666F696CB82E"
                },
                {
                    "id": "gs.Comment",
                    "params": {
                        "text": "Shield"
                    },
                    "indent": 0,
                    "uid": "AACD9F7D9D6B404AE86BEE79144A10D2C2AA",
                    "expanded": true
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "642F41612F34C94AB22A4AE1BB1EE2597665",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2ADB9A117C49A3481B2B8540D05667E956FE"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "7D9531543CA6C1442D0AA0F63BEC53C7C268"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "F649D7315E6BC34C74896F68B32E6C32BC6C",
                            "defaultText": "뼈 방패"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "A874867F3C93364A573BD77797F67A674C1C",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "E33113421BE4484F770A585510E7B892E3CC"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "3A2AF66B8AE1A2464A5AFC480D95672A3631",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "781F25F16C66564E306B1AC00FD906DFF16A"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "15B87E8311A078433E1A40559B6FE73EA222"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "BDD733DE3C21F6486C89C58711FC4DE9D436",
                            "defaultText": "본 쉴드+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "552C7EE173E9644FC98A26F32BB981729A30",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "6C8B0D845F417449F1693B11A1FC75040F37"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "8F1D1DF88549E447150B41271A7E45C20F40",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2D50B6AD2B7D804C376AF4C69CED26CE4DC9"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "DBC34FD91048604B505A68B0A17AD79B9BC1"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "96123E4C4EED9647B7091C97CE536F951053",
                            "defaultText": "철 방패"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "D5ED330D6A28E840093B781063BF7AAAF78B",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "B5E1053C85DAD44C45697A9549B24481CC55"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "67508A542678C24805790177F720485DD36D",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B2E634F50089294CAF596EC0EE3192AE75D7"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "90A11A96743DC8418D993CD8F6F24266E85E"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "101AC6861529F543CF784463170B9143230C",
                            "defaultText": "아이언쉴드+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "E0DEF6201BDCA14E7B9BF78087644B56F43A",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "3141DAF317161341143A5DD61B55899E9205"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "FA6F16754B18D14DA58A7CA05A22AA84BFB0",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "1CF3BB5E1A15F749561B984747347AAC765F"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A3F05AF13E73E04231690CF5E708C2C922D8"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "93FE197F4A2A68459C59B4D88D6E25E051E0",
                            "defaultText": "폴라 쉴드"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "0D9883A446383446CB8B9AE5DF13D6EC58B3",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "B82B27BB2C5A1644927AB0E1AC7C60D4FFDE"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "2580C24C823377499C3A924213FA07BCE75F",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "265340B372CF204C3D385561D5ACB46CAACB"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3E7B49F970190041F48AA5B83EB8A8CF2798"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "7D1315493438054E4888BE178284FDF448B2",
                            "defaultText": "폴라실드+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "742F04413C0307422D68EFA79F6B9716FD0D",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "C9D1BAB58D85034DF28A10D5C2F713D08A0C"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "C421E92A122DA8424A5ADA84CB93CDD21DA2",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "EDEF6CE94E7EB64F4F3BE1B7E5191BD5C0DB"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2DCF5C4A15565840A3587DD3F24A795D6855"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "1624145974EE96464C18507615D77673F020",
                            "defaultText": "파이로 쉴드"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "AEC03A4F3109C34F71183BB30C9F5A1D9743",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "BCEF7E10795F074CD069DD92A62E90CFC536"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "1B06224D3D992648291B8B965EDCF6B4FE33",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "82AC8BCC80CCF7461C5A9E518044A57D898A"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "DB6626053FD0464DDD4879A992DBA1201B56"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "BC16294C41855347AC0808E7DFE0FD83E1B2",
                            "defaultText": "파이로 쉴드+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "D32EFD783BB5D540C36AA5A750CE5627B2A6",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "5B7E39D12B03B246B56A75A3F3774841D566"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "11C657413052B4460659C8294F74BB2DDA92",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "DB1D1F4D1BDB414DCF485E11AC40678664BC"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "972E03082622B1409F89A124189A2C2C2E13"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "80FE49EF10909343092B0296D07E3726C86C",
                            "defaultText": "미스릴 쉴드"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "A59486DB2B12B84997593DE4F265A8E12226",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "D57B6C70583C964CF26BE219FF1DF75E9994"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "743BE24D11C2A246F7585C82CA0C29BD8A8A",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9ADAD74257BB564FF689B1C4D2D9D8504F43"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "BB4D85588F9614460B7AB7C5580609C8C809"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "9C863F0510310540771BEA3775CDB0CB5562",
                            "defaultText": "미스릴 쉴드+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "856F3FA79C97C5416E2864140A2AD64102AF",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "13DF57B6364F56480B8AB6C556C8DC7A99AD"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "66E3409B4964664D2C1A7DA4C70DA527DEBD",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8C8AD7AB1A4466458E4AADE2413062BDA70F"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3C7152D376D7B84B20592507BE9A9A954A77"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "7791130C32318347872A6650C53899EF8673",
                            "defaultText": "빛나는 방패"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "9262057B121DA843B498EFB47B08F2677E45",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "12E144B3364A5440BF682834B3ED1B4798DF"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "B128666F62B4734462582A675AFAC636C037",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "00041D517A7C24410C3B9DF1C8C1F8ACC8B1"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "AED9D34A2CF5B842078A4804945FAC80FF0E"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "A50D161B7AD5D348CE6B06D9DA2DF2302E9A",
                            "defaultText": "루미너스 쉴드+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "219B3CCC5C16F646BF988E41F93744900CAA",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "AB647C368BE574409D489CC2F0CF834D6F93"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "CC5863A79BA0444BE8788131392C47685E60",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "558793A17DF0F546C98BFC629A1754D35A74"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0A2FA9F41DB37241589804478F8CA64CE087"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "C9FF82E97E2E0146B4881C9383FDF162C231",
                            "defaultText": "황금방패"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "4CA264B8129623490A984936A330F6047541",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "48A20FCB2F8EB44BFA3928224138C85052A6"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "389D15DC1B3E2348E5188AB969C5AE80D697",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5E38E40E681DE748354B2B660D22B5454ECD"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B4636A7224C657469D8AB3B0195A78DFFE7B"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "9A85F4B85901B647383830B920216A9E202C",
                            "defaultText": "발론 쉴드"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "DE8701D7913F924B3108FAC8ABE13227EA49",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "CD6ED0F00DAED749E6782924F857BCF5E76F"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "FC03416580258943652996757ECB52B20F95",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "DBC73B0B319BF5492809C100BE6D7DF5FBFB"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "34BDB9AB3A2E144BC14871E6CF494EA21FAF"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "FCAE415D927AF343503A0344013D4B66BB48",
                            "defaultText": "슈퍼 이지스"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "35510A3B34DA1241222A79748C8A272E26BB",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "1E3D8B4F891F084AF668E9735A1EAE02DCBF"
                },
                {
                    "id": "gs.Comment",
                    "params": {
                        "text": "body"
                    },
                    "indent": 0,
                    "uid": "2DFDFAEF6ECBB5434F196621E58BD699FB2F",
                    "expanded": true
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "977941CF9FD8F1492F4958D0CA16066D236B",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5C661BAB3171A240701A8B13D92F1318BE56"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "514D4A7A8EF0A7416139DA612F55C95B71D0"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "B916DCA59F2EF8411719F044B3BD698A949E",
                            "defaultText": "가죽 조끼"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "152000217AE31349635B8FF9C7BE627F1A6C",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "3E3D7B7460E7F444B17B766552BE345B9C95"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "BBB6015C55217644CD8955D13A015F2F247C",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9ECD58D724A1154B053B7643BEA9DCDDE142"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8178BEC753F570480C888CF6666F29D25D77"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "F54F3ED59ADFD74DB26AB27446B297CA5E4B",
                            "defaultText": "가죽 조끼+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "102CC72B353988407D88BDD197D3F521D154",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "C6BFE01817BBB547DD8B3AB40A5CFD4BB87F"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "ED07A92D1BF738441B792F085F199E68E3D2",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0D6FFBEA7F87E1472D589D23DD83AC817378"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "509D3D0B1C02974857496B7413D7764E2ABB"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "A20C7D223C91A841FD483E07D09EA5EB7CB1",
                            "defaultText": "뼈 갑옷"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "AC6FEC4040C6944D1D3856C52A1F7CDF59BC",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "A9EDD2465AA39642E72981B4454DE27690DB"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "ED7D96C83A440646365913B3BDE4A087C5E1",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D1E1C8E3834C31498B69D9D041E632F80874"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "CC8F2D0A0271F74AFC39E94881F9EFEFC6F2"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "F697D27B5EC1E3492F5B8232D8C8B892D4BB",
                            "defaultText": "뼈 갑옷+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "ACC557A64562F24ABC8A7C381489A12C4065",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "BAFD31BC291560489D5B9B3426BD5F5B148F"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "BD2733609057A14ACD79BBE710968C4E898A",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "1F0D1AFE28A01548A02ACBA4270882450769"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C1F24C794AC553486A5B37758BEA37BE399B"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "4D7D4F3E641D154BD828908579A2B0B8C122",
                            "defaultText": "청동 갑옷"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "A3C242CA5505824ED6881AD4CADC9F1751C5",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "74DF08D07FECC549152956A4CEAF1D056834"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "5FB36869809C4146A26B3B52CC16141F45E5",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "6B78AC476C8CE2453A19B6534BD0A05E5ABA"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F1881E33220BA746699A2544F46B377EA119"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "45983F681AC25945DD196D88ECDE8A5E7F46",
                            "defaultText": "청동갑옷+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "78BCBFB011EA9240751BCE2153BB39BF7D52",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "FC088F0891DF1649579B2EB2A4C6B73B464A"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "9E11144D9E18A146655B993045B86ADBC430",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4D06C0F57AF0A346633A3E6391A72AE05FD1"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5679496B00F5F145B57982369112CD9287C1"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "3C9F5F537EB24147316969C16229F7028E63",
                            "defaultText": "아이언메일"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "873AEDA20913B44BD7899EF21B992E461159",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "DCA8A2901D8AA94A191ABC710C5CF08F73BD"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "3CB934848412F0404639EFA28E35FBDE656D",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3490FAC220A8F44E8E9AFCE2331BE158ABE5"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "653FDA4842E7264CC42BBD7472113906D3C9"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "4E78605F0F3BD941138AD63482DABC379D17",
                            "defaultText": "아이언 메일+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "DD78C0D95405614FF629D34693611984C39B",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "CE0BB1AA081177421568EC251DB845D3400F"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "F8C81C4898DCE843876BC733577752C7889B",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "501FB81D33B10249371B1EE54832F546E47F"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "70B5A127669AE247BF2B48A7CD8215EC3A37"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "63667AA93E2DC347903A96D3F3CDD0B781B5",
                            "defaultText": "파이로 로브"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "31420F5A9E365247B41BB5F9C13357C818AC",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "EA1AC6C6210FA342BF88E7517BDE348BF5FB"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "94F50A453FF4E84ABC2879406036747808B4",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3646600B83C6F14809880DD5DDC274E30D71"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "847F6EC75660D245BF3A80D1F18C5F978B9C"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "91DA4E69837C214AE71BCD239FD0FEF03948",
                            "defaultText": "파이로 로브+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "91D7A98D4280984DFF6B98D7A4CEF515FECB",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "F0DC64E3616AC2470708EB4878A384E014E6"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "FF752B72631AE14C6D680FE28993B7292306",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0F9E7FFD845E884A7D6A8DD76874CC9375EF"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "19E16BEE2DC2654B7E4909572E580989A3A2"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "E4767B4994B3B447B1299083A7B421E92295",
                            "defaultText": "북극 조끼"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "EF63491376BEC943535B9198819C637E5AFE",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "EAB6CBE53AED0545AD9B24940591924A9075"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "2CB12D870B8DB748F44AF9E5FE285D2FE79F",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "337E5224122516428E38AC24878F3CAE721F"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "45EBFEFE6B00D24BB719EE435E06146FA23B"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "AB52249B144C9841285AB5D4B566268CD85D",
                            "defaultText": "북극 조끼+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "85CFE524192EB3492799C45745CDF70A0D91",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "2E4979CC41211749B31A69E6072CAA9A38CA"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "0C2828D75605484A88194940BE3D6A188DFC",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "FF82271D92462040EB3B6D406BAD60DF35F6"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5F1533F12B1BB34E5288A905E98660C064E4"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "B751F8017ADFB84CC16BEDC6FFDF1F323C11",
                            "defaultText": "미스릴 방어구"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "BF9D70B11AE18049F5783228DF25578F3D7B",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "503C136C73A9C044786A0E57E584859AE3BE"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "B38B5FD91AAD444B7B7B03B087A7B5F3C77E",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "1F7FA1E4815355446C88B136B24D51F2C209"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9824B6B327A3C04DE76BB642AA6919EBBE02"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "AA55E4B255E5884EEE493F83071552F70B52",
                            "defaultText": "미스릴 방어구+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "B79FBE9A139BB54B323BD2E5FB969A593D69",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "F47085BB7DEA06454B48A0F1C675140CD234"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "FE52091C103372417B5A2B554F34DF841BA6",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0599132286CF0348D139BDF1745E2032BC9F"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0ABC5E2650B12846534A12C10565E6E9C6C5"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "F3F8988E237C054A5459DF5166146730A973",
                            "defaultText": "빛나는 코트"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "E9623E7F8754C24F0F587A01695359842070",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "542A415150F81349EA6B47D68D41C225264A"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "BEEC715317584849E83919E6573D255023AC",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "31A5F93262CFE14EE11A8EB8DE27D15C1DAE"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "24A350D47D28044C4D4AD650F26FCE23ADC5"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "544FABFA5848734AFD6A34C7683614AC7AC1",
                            "defaultText": "루미너스 코트+"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "86E0B76640B6314B1869031324B6BDBE73F0",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "C58984F9862EB5414C588DF76F3118FFB7F1"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "09DAB5FD82B1C144528AEA61B1E28D2AC3D6",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "DE33CBD78DD2E74F9B197D263D47C02D533C"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "FE76A7022B3C634A862BDD33A71A7C3D3A22"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "2B389D5942708246C139BE2613952307DCC5",
                            "defaultText": "발롱 메일"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "905BEF72495CD144BA5903A828A08E0FF5DD",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "C657A86A13A3864DD93967E43EB8C65AF702"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "93C85E773CB8264AB008F7400D52A2411177",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F9A76E4338B9C44EAD6A3CD55A1F6D135404"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "65D3128531D8D3423698E255C01412475DAB"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "2B02FAFA106C86461A38E06600C7ADFA5D8B",
                            "defaultText": "하이퍼플레이트"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "D5ADB1954505E44DFD885DA7B30A94CB443D",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "F0DE44F15CA9E54A87292D064D3FF04D3C40"
                },
                {
                    "id": "gs.Comment",
                    "params": {
                        "text": "Accessory"
                    },
                    "indent": 0,
                    "uid": "63703F038363514835399AC43E1A51035187",
                    "expanded": true
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "F88DED982D33C645D818DB7949C85DABE5BC",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "031E9B612C75B8457808D0795C9F959CDDAD"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "21D751580F2E6846C1486046549A422766FA"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "5BCEB42B2D7F99468879E1B7730CCF863DE3",
                            "defaultText": "피 묻은 반지"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "68E36D08407B8647AE89CA14BA28CC6A0AE0",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "0E1E423E004E21414969DE262919EBC344A5"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "C47CED5832C23740D9693433F8E861BAA7FC",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "1009DFD071ED2943A55B2BE1E14C380B9A75"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D15240387A12C7476D2AEBC36B226B96F97A"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "5855D83F261CB74413885AC3FB4E2BCAAB48",
                            "defaultText": "가죽 부츠"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "6FD3E1B87637214F2D380AF06455FAA8BF05",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "D4D8C7C81B751644B66AB7F7BCAB7395DAA4"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "DB45A10A241A344EF56916C2A318F223975C",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "257706C9821EF64EFF3A2E800407BBE08AA5"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "1AB1D7457AF03640898A304876FDA59BADA6"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "219E8B4024BB2942750B4AA53C0FCCDFA49C",
                            "defaultText": "철 장화"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "BB68227C6B9B014005094694FDD39A17611B",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "B33954857D89E44C747AAA15CD04AA0A5225"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "44CA6CA92768334191382623E8C51ADBBFBE",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3050CB767182C64053888F3328C11E6CD89D"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0FE21D9F5FCF554FCD4AA044894746092529"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "BD76E2DE7E9A474CA83AC8A8F040F0618F10",
                            "defaultText": "미스릴 부츠"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "D8073574578DD346054B41F516EB22727DFF",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "74E4D2702687764286186A9925553D2C38CD"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "971C11145F39E2448C6AA5A3D74C31D0331C",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3A7364794C0E4743B2587013A508F15F6C42"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "FB45F3ED8602F948527A12D66A4F6CCB2CAB"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "76616E68979F624A6E0897515282DD054102",
                            "defaultText": "마나 펜던트"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "1DE4B45F55A0E8458D99BD95F31F3BC7F10F",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "B96B470C44438443F78AB18244AE4DF775FF"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "FF9675D50F93964B867B6DE381E1E5B9984A",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3768AF28653DD44FD64AE61860090CFCE3D9"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "58A3DDD939B445482A6AF356EB6433DEEC57"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "9341D55497DDA545DC282DE716E91FA05A3A",
                            "defaultText": "예언자의 안경"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "6D21B9CD7F76D54B732AAFA46BCB0C7A88BE",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "4C7B02F175BFF14D713BD7779A3E1478AA45"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "724DBD0E33A298475F1A3DC31FA2AB0F9574",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C0AE52E9215D504D1E59A338FA7A937EA62D"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0957E79E40268544C029451436F49368247D"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "5E1B17FE4D5A384D35881E54912B509BA8B6",
                            "defaultText": "에테르 고글"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "BC89FD0E6CE6574AD18B50F7194596972C5F",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "4337801952582143068AF7581CE8ADD98038"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "98F270FD1362B2491C1A1B879BEE0C59D644",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2502654C170C784C847BB82071B57998530D"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "FD34B71B4CBAE844844A3CF46C2EB559C170"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "F344AAD367CAF84ECB291A059B70359FEE21",
                            "defaultText": "뱀 귀걸이"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "6ADBD17E316CB34781585F17125D87F7AB1F",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "B9D1E25A5B7D33413E1B6E9053BFEAED9E74"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "BB348D9C57359348A1789926F50965950CD7",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5937652F3CD9E746F5686839D939E73C93BF"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "7B65498D2160D74C8F2BA7E5B63F18D05ABC"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "40A453B193FF61495F8843D53E0CEAE562A6",
                            "defaultText": "사막 스카프"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "E9F571D845DAB24008993C4764B970189A89",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "4F2B1748429C364D723917008552BDD61F7E"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "3BD6FE871C51B8479799CE638237B9CC10B7",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A611B5A860F9274C3B4A46F37641A827ADAE"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "357A4F623D01B545EF18504518EF28EFC694"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "DACEF23C59E2044AA46B0A9598606A7289F1",
                            "defaultText": "폭풍 펜던트"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "F887DCF46752F341ED588E27441D2A21A865",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "C9330AB07D010941B649AA945AAB7D07E6A3"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "873C5AA060C4B748B57A7AC2E563C0CDF90E",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0AEEEF92289F954EE32977229E3A6EE3316E"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2D43C3FC8BC1C9431E380211422212B5C9B5"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "ED31C73A61507547811BA3E73886A09BC3D7",
                            "defaultText": "고무줄"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "1C67C80B2D414547BD1818A50CD6AE3511BC",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "1C7B5E7C6F46C74B921AED137E592F90EBDC"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "C9A68185578608408C39E1750FFA19469660",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8AF545531CF6F647091B94A83366F7431C94"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "37B49E0F354252485A0BCC81522B993770BD"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "DD1FACE14C037245188BE8C7D7866083E82E",
                            "defaultText": "마나 귀걸이"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "A24C798981BAE047F939A185977D2EAF7813",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "E3A7B01B54D2C442213BFB981FA5F2AF1C7D"
                },
                {
                    "id": "gs.Comment",
                    "params": {
                        "text": "Item"
                    },
                    "indent": 0,
                    "uid": "A6097B3A4503414D4029883705F65431511C",
                    "expanded": true
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "7FF18EB084AD054B434B622321F85E2DDABF",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4DA735742EDA90496F98C916B4FD63D2D5A3"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "FD9140A419EA2042C178BEB27CA0C7CC7802"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "0D445B3593FEF04F8648AC78B51613D18D19",
                            "defaultText": "약초"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "CEE5EC754E962247321AF5831470D1C4A72A",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "B94DEAC50E8CB44EBF2B72B8F3A15AEC1833"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "DBCC07963EC0714BE4591A10760592A3B968",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A415193746BF064AB14A2FE664975001128E"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D48481E58F324346C22A27C3BF564E6AE0B3"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "18307873189E3340566B5046BB1FCB08262C",
                            "defaultText": "상처약"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "D2AB01D57FA9834D350A2844AED174F72C5E",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "3AC9FF908448E34C007A3880DDA17930F79D"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "7BAEC95A702D664CF74AB71248751A8C1B8F",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B7ECB24D93E48947882B5D4492BF0A2564B2"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3F45381F05E76942688B775732CCFD942CDA"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "5FE7D50E6354A242A80A6C586115ACD9D86B",
                            "defaultText": "물약"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "5DBBC38D5A536847F55804D612D8EA74D358",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "A36783D34C19314C52891133C909E330932A"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "63F262B52FCFD04E551880581164251D1E82",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "083A57D2380DF24DA77AC424C0634BA9A461"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "ECE0225272AB384252587B20C2630831E9B5"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "EFFDF2DB83D0A240F93958083208F819640D",
                            "defaultText": "엘릭서"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "E3CD821B628A644A0A28087071B15D680195",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "2C8CCC83175256488C28031279EFCD847F05"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "6F747AD74DF472472C8B97C7FEB7656449C2",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "570B109A397CF643206B4D3579206B3DBDB5"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "74B5E7FC8E22A74F622ACFC698C85C308984"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "C563B6298B68D14CA03B32731F1018EF273C",
                            "defaultText": "만병 통치약"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "F7A09B9D5AF2414CE53A37537BA9479995EF",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "20F86D1D68BDE8496E1B54133CC9119B7C2F"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "6A82BF015BC832417C5AA855058D56A1FB3D",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B5EC199299FBE24DD53B8342243BB07B4636"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4AD5CEB1740DC0495959006108C02243B308"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "1F2E07CB2F76044B434A2EA2829911079252",
                            "defaultText": "피닉스 눈물"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "76F67BF648D1704ADC3AC674B2DC90E110C8",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "D10DF8B579A9B34BC14AB8E1062118BE66EC"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "462E2AE2781EB74A602B4633098D0AF27133",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "FA88256B47DAF34EA219B6A7EFE4FE3FF6B9"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "334B9DBB8D3EC34BCE2A9181F261B1EFF877"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "7A76203259CB384DC5180353EB3702FA07F3",
                            "defaultText": "요정 향"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "7F8D01EA8CCC1046868A44A7F33E4963F81C",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "44663B6E4DA6C34E1D199CD00EDF908CF48A"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "7B74D6697DDED34A48891CC833E2504473C3",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "953F8DFD2B57424F5D2A4DF2EC52222AF81E"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D7CA364F500DF34F316A613548CD0C3430FA"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "612BFA4C5B36D544508954C2CD36BFE0BB39",
                            "defaultText": "픽시 향"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "5278D76864B0D84C93383286D9DA6E2352FE",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "7C2FCEAD8DEC07485518EBF97E1F28E0F65E"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "44DDF3464802E44FBF583F80B9D99D7376C7",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5F63EF0D0327074B161BF8B394840AE60197"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "1E59D8FB58DE9544D24BA0647034945897AC"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "D344D49F2BEAE34B9D5B6E67EC39C268A8C5",
                            "defaultText": "디저트"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "AB3EF1A73AB0C7417219D6E83C9B0DE6E4EF",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "71E1A67741E56147494988293A7277C35280"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "CFE674B75CB1034CFD2827E3A2DF2D5B588A",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "03A9AC2A869A63491628449770FEB3355331"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5B40C8CA84AB7347AC18A1F28EA30E84B808"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "A26D4F1806E6C7411688A014E8ABC141C75D",
                            "defaultText": "상처약"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "E343A3127369394D231ABBE0B124898FB2C3",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "3C7A49C45FEA9542BB3AD6071549B1860BAA"
                },
                {
                    "id": "gs.Comment",
                    "params": {
                        "text": "Food"
                    },
                    "indent": 0,
                    "uid": "DF773EDC102C954E4E291774E25A28DFAF80",
                    "expanded": true
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "0A829B2443B61240B8892E20FF3C3AAB8967",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "98670EA26212354A5A7B09B6A720D2807113"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "795A394F752FC54EEA587ED11D0609D77A68"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "F4370BC339373042D27821D58FF0370EA139",
                            "defaultText": "생고기(S)"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "BFE49292048E664D181AAD4445FFD6C0928C",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "89D948A58C94D745BC1B4CC55563E2A824AE"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "73803BF9902CB14DD51977859A9E6F7DF889",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E522B6FA71E770422048D184379C83F6A0FD"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9602ADBC447FD34C746AA6A5DADDF8278455"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "7B6171A24E5AC247781B7D8128E1831023D8",
                            "defaultText": "생고기(M)"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "63D78F3361F084408A78B2C8CC9CFA281C6B",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "AD25959A514F4748141B49B4B3342C6DC9B6"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "196E20BC01A9524CA189B2235672858EBE92",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F3999A645539A04BCA6A3DE4189F5EAF50FA"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "17FD289A2603E74ED00BCB96A5D484546746"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "292BDA09196DC54B56890558D3B7935C27A8",
                            "defaultText": "생고기 (L)"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "06B4528A367E524FFE3BF5A01F6BDE55EF7A",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "5C930012843F924A220BCC68784E562F38C7"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "FBACF4665AA01841DD2A1072C15F3DEA67A1",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4221096988F6C544514A1F84E328BDD732A7"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "92799E742BD2414DEC89F9C483B74976EE7F"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "7E93B47528AA9545EE4A5B458689E714FB14",
                            "defaultText": "생선"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "3DA436D864EA354C527A34515E7BDE03FDC6",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "A9915F2C66E985413B6B8EB815EBFB19E82D"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "449B6B5620D59440636874E641C4B2A1DEFF",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "CC2781C18F9D07458B2A46B38AD8E73A4A20"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "22E133C44B512043B5480AA2881124DF2C36"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "86A55099389C514D4239EBC0EC9410C5545E",
                            "defaultText": "주황색"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "5D49650132B1D8470F2A0929277EB4DE382B",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "8C5ABCCF3ED3A641BA483FC42F342BDAC29B"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "FA2240BD1D542244542939D2A97D88F19D5E",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F38A9A4B05E3C24063585FF3C88AD4DB6A03"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "FE756951888E1549CA99C7B70135F0557407"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "3622E22E56E0A34E604965074A4575DC241F",
                            "defaultText": "사과"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "0CCA2CE906BF784E14198D0873F1747B595F",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "DD39D7F613A88241BE19EE59FBA7A292FD48"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "69E149733BC7074F828827A1D8C6CFC03A2C",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "976F94D92FB1684B8D1B3786D44D2B57DB55"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "95AF98F613D5054CE4692F68C13BEC89EF29"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "D3685A6D78A1914D569AEB628C4CC66E3E79",
                            "defaultText": "토마토"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "B8AF990A5190F145B69998F53F30141D5C0C",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "4DCD2B340748C0471D29E196F0E696271530"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "71A6CF5D20B6E342F76BE388F9370E6FF6C6",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8B3D606C694DC2482F1B9F23DA3FFBE10DED"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D00574CE63A0C248E20983F0DBA096FE1B09"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "0831071846E82541BC1BD4867AFA702FA0FE",
                            "defaultText": "버섯"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "1CCA44C35FA2F24BA74A6E02CE17035FF131",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "5B0A4C5E5590E44D568B89C5845437E5CB99"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "840920F309DB994F211BC2C8C1B24FB6174B",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F362CB5851972440394ADA69DB5794B00F24"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3E82EA580D886849072A6E81A04C4C70A16D"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "64C1CE8342BE0640FE1A4987AC0FC47EDF93",
                            "defaultText": "무화과나무 열매"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "AC796A6C4952D34A7C3882C82E7477109D33",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "C664A19E3B1C68446A9A8154CB60A035D0DA"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "31904BFC210994450B98E9562207710B9F2F",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5D528A044EAF6544CE5B6FD4885167C84BAC"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "775DE538594C064EE46936C2D3959D55C5BF"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "97CA7D1C466CB744062AD8E4FB6C395D5EF6",
                            "defaultText": "망고"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "1EB80CCC43E65249B0592AA47715661A5B96",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "EFDBB9579827464A8D5B57F314209CAE2BE3"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "E6C151254391704CFE4AF263C4D51DAD7754",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "7365FC8A4D5B0843AA6B6BC4AE3B147C8A9B"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "95D161EF40D433419A299F205F795325694A"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "2BAF43CA8AAED24E089B8943A8FEBE384AA9",
                            "defaultText": "밀"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "385A53E345F945420C5B33A2E9D653607EF3",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "FDF33971808C324D520B9525BF3F5A8988C0"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "568D125A4A68C64E5D4AD1C0C56CC516846D",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "991DFC645C973348CD6926585A40F841BA71"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "52E2C3186D1D6447D7394141C7E5FE40FD4D"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "D81A30B6231EE847006BD7B86248BEC8D117",
                            "defaultText": "쌀"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "67F3DB4D6DE32043451BD3B1E996E8E00AA7",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "76A3ED605190734C5469B233009954933B67"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "FFD534A9961777498C18E222452B542B6E53",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "115CB57C3ADD9246D119C158956315B42AB8"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D631AF324F45A74FCD6A0E745E0F7355667B"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "D37F6D5C701922442599B8C64674FF772FAE",
                            "defaultText": "감자"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "CCB02A9649BC37461D4AF535E85C890F3185",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "F1AD94DB26EB1047D52B0551B1B64A34E446"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "BD59A0AF1918304F4279093591261A6C66CB",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "44994B6A59332545295B2D13BC9A1512DAB9"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8701F3F97129A14BC58BDD173EC21A50220A"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "77243BB0726D154D0B5AE164EBCC7C833F79",
                            "defaultText": "상추"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "056A994B6FD0544C7B9BEF85930F82F2E435",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "B11AC78364C88144F61A507727877E9B60CE"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "BFFF48AF1209E7417F2A0F29C05B97D3B7CA",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8A713C096D3B214120383BF4C788F6DB9753"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F5ED0F881A1800439D0B31D4CA8CA24EAE40"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "B2123F135BAF174ECB6B738904A38096F728",
                            "defaultText": "우유"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "D10AE5361B23F7414C69BEA31D377DFEAC45",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "09EE297D88F59349A54BBEF21925BE5DE65F"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "DDB6BB3C12F91942FF59BF881A925916AD48",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "96654C9921D0B743A65B2F26F866BE2F101F"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "08A838BF5FE3B544AD4A347657E3FF316CB1"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "1FF875CA1F1B184AE078AA28AB4F55779C05",
                            "defaultText": "커피"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "9D5AE1534EC4844BF41A3735DE569F70D3ED",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "BADB2C1514C0594AE45BB28030CCF37360D1"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "C4AA150854E4A24D9D1A114627289DF0AA5A",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "28C251D93F42C442228ABEA4B8EE39AA76D0"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "459AA6701D611442D4791C57684C32C20781"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "6403B15270C5F044DE1B79F7C51736901ED2",
                            "defaultText": "카푸치노"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "A8C68B115ADAC5432A88D4049C1DF186D84F",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "D401EB3165916747788835015A287B40916D"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "6816B0198B86F8456C6846F8A08E021D63A1",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "BDDBF20828A3174D5E991091DEBE0A156565"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5CCD20AD47637748D46B83651A45042C7B93"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "4C761EBF9427734D395985C1ABEAB295750A",
                            "defaultText": "크로와상"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "D4D1FBC827E39249D69BFD3543C1AA7D27C2",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "14E6A4662833A946CC592FC94283DC91DEA1"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "A61006745779B54F95583F031E23AAF3B85A",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5F9F511D77BC17455719ADF41087778EDDEB"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "97180962063FE642BB2B83382F45131AE9F7"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "36E0337D48AC1142103A7132F0BE1265A927",
                            "defaultText": "게 스프"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "80EDEB572E5C914FC38AA56661C1D4CBC2E8",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "383E08B053F268440D1994E555F13475FB66"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "F93B23EE2C30854DCC5B1C70CDBAA49A2A9A",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "51A62CC71594A046524B64B3290EFCE102A2"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3400976370B402461E9968E44556E28DD4B9"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "96F8FF40418EB544D55B60636ECE67B972A8",
                            "defaultText": "스테이크 앤 칩스"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "893F963104EEA64DE11A2EB77F01306F8D78",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "642732C526617543C60836A71E0267E81AF7"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "4BE0921B0375824E39486375D29E6D610E31",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F0FE734C6EB1E84785888858E62D7308E591"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "545748D86A3A56414B6B7A035288FF0646BC"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "61374A300958D54C89897491981205EB4B19",
                            "defaultText": "민물"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "D65D24AD7A823844A88ABB042330B5CB1F42",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "A7C72F9F39337540B43B9913CE97E40FF0D1"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "9CD432E8076BF34ECA4887B30B4A24F40A7A",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "1E0C06DC7E8AE34E227A0FA33CAEDD5E9BE2"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3759BF4312C8254539787A445459D4A73C8A"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "87A7C59A8302074D947BA0F275F3285CE873",
                            "defaultText": "맥주"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "4FB56DF43CEFE94DBF3BEDD6B7B4CFFAF76C",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "ED0F92A815F42141943866400A7F8E17FB2C"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "3A6470303809F6402069BCA779DE051805FA",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8EBF48F1523C2741BB68E065DF4DCBA1C513"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "651EEEE12F05E742273979B8756D22C4495B"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "799FE2F38D1EC14EAF8A7088634FECE90616",
                            "defaultText": "크리미 샐러드"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "C181B0E02351C4490F585177976DB927ABBE",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "E94D689F4EF78542291871E09BF55290E4F5"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "676733150C7A184BC488AB97C468CBE0A128",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "7D23B59A812B1346E91B3D3103AA05179CC1"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "087C01C23CBAF84B0B3AED4295DE5F7CCEFA"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "9E41A6584EDE134DF38A0171217B79275734",
                            "defaultText": "단단한 치즈"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "7AE670B7745CD34B593892E210EA3F85212C",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "8F295DF972A0954EBC586E7850C66C3C0D4C"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "91B4FD6F4DE6A24F7E592BC938E666CAC51E",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "CE30A8A94CD0A141AA7841B164817082DB13"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "25C318432D1FE0496B286E382BAB4B39A665"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "BFD49C5A3F0F364DAF3BE0C417CA707A895D",
                            "defaultText": "블루 치즈"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "4EF4846A9882F348421B3518269127BF8840",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "5BF44B702478A64172886B1576A17F72F8EC"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "D099EDDA3E2B3446FD2835580A8561A44551",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5D80215A48C4E74F3F8B2FA51C7CC58AF721"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E205B2BC84D63046293853F1F357BA744723"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "C68FA85B8F75A442EC2BB166D0CA4A0A7F03",
                            "defaultText": "생선구이"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "C27BFADC1BDB2645BF4BA9277B7EE4BBB833",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "AEEC9A7B99CD3547A67BAB104E0036C9AE3D"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "EBA214B73A7445455719E0E9E91057954732",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F361BF9D42C4B549E8495085E73F88D31213"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "611C8119090A1147AB8AAE423C879F9B18E3"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "6568417070DBC545F52A235314749B18F8CC",
                            "defaultText": "아이스크림"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "5AAD17847ED49446E28AA0C22B5396B34E7A",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "F4D70B326441644D9C8AFEE8D3B96AB18F90"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "A22335E58B019145941B83457E31F119B83F",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "99727DDE80E8A4459F88AD462244AEAC438C"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4BF403E2617FA943FB3B7B96ED820626BA7A"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "FB9659D53AC2574EF508341876C16E4B8783",
                            "defaultText": "스파게티"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "D7C900AC1A50D740BF28D1F459D5F09CDC12",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "2C801DAE54250149358BA6E8FE86E4E646C1"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "0DD3AFDA93801640D11AA788CDFB0E37FFA8",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A5D489A4395E084C4A599BD2E002E515E3BA"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8A7489B016AF17455E8B97B9C65251E5AAA4"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "6F2006122F49C14945593088045EDA3BB1F6",
                            "defaultText": "와인"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "B57077883E730943E63803F7A4AE261C485B",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "F33D4C7216D9A540555907F7B7CF0E230F1D"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "0D82AB962B80954BDC586098B4C1AFD3957D",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B009B0AE70A4E449287B1BB8895E2F3F8FE1"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3C52297F76FB294BBC8AC547B6F594C94083"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "8957BB3B905F17441B79120454087D5CA32D",
                            "defaultText": "채식 피자"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "432235FD2F42444AAD38A0B62595989D1CF4",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "1C34375B9353C643903BA6C3B7F698186B2A"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "DD0ACDC6894B11470778ECE1D02DF106E798",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2FDFB58472252445305A10426E84CA0478D1"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "1F7F0308875D3448B4294A4498B64F53B9A5"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "7389AC9C2BA2554A0C79B758185DE6091AA2",
                            "defaultText": "파의 스페셜"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "9F2BC05673C2A34C698BC591FF81DDDF4D06",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "9D947F35494CC64CD67B7C63DBB89EC6C021"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "DEE7AAAD1574144D1B4BE211A16A8D562887",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "58D0072F8C4D854DAB6AC2E89DD2A0E57EA9"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0B14F72D7E1A1540C9482504ACE594B9C5E6"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "ACB32DD55975474F848B3628906842CBB94D",
                            "defaultText": "쿠샤리"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "FCC320FD3753C64BF13A14273A3CB3C95414",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "97438B3930449349309B93A80135668E4436"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "C98688CB0047C441801A40F66BE04850B37E",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "835A6C6223320845CC1AFE339D797C828F8B"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F14C809336AF414C6168DD451D9485E2B1B7"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "34596DC075A1574579581198A719F488BC1A",
                            "defaultText": "사야디에"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "574529DF2AB3F14E691B4914C22C0587E3C7",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "CB20B274231963428D59C4759417F3C77163"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "FA57CD1788ACF74D66095834719FD0FDE24C",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "1DE922A470F27848D529CCB1F59F3BAABF57"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3CDA2CEC55144242337869C9B1DC32B003F6"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "E3CBE49F05C56142E35A40E0654E73AD2614",
                            "defaultText": "스시 믹스"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "C0DCFFF466013046DC49A74475055DA03BF7",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "5C314249145D0042511A9288DF0C8BE35C98"
                },
                {
                    "id": "gs.Comment",
                    "params": {
                        "text": "Materials"
                    },
                    "indent": 0,
                    "uid": "B9E8937D72F015472D2917031E381D70BD1B",
                    "expanded": true
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "068C192F4928D344FE18C855DD44B8793560",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "80E909D93958B6453B7BEC27ADDDB9E1853A"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "880726315CC0F742410830670E31B1540A28"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "39D4A2F040A1D74C1A4AD012383CE8AE4C52",
                            "defaultText": "청동"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "03D1652A25774349609929E296632B47DD96",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "B14344FB9EEA964E1758CF06DFCA78CF3661"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "BE1D701275C1954B9B195B4821C640159088",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A45F40182EFB4340EF6A2EC817E69C9B37C7"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "BD27754D76E9524AF63A20F2804A79F28D80"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "275E2C0C4F49174DBC6A74A29683A03E9C6F",
                            "defaultText": "철"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "7FE6A4BA502A16430068B884759F27E1DF0C",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "6141CD5D2A10154B8A192C49E5BE1E1CFA3B"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "AC3DAF707C7EA340A22B4AF7441187B2DD25",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "6AE4A56850CC854E6819593347EA0AB54607"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "497C71C99AD3A6483D19E3570E5BC180E606"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "2505293A2664C947B51B5E7590555553024A",
                            "defaultText": "미스릴"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "02BB7C3E1FF1B646201A2C616D4F9BBD8FA2",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "FE4CFFA54E98C640965A9150EFC7C3E1A4B0"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "B1E127DD2260F1470A38EE07C008135E5203",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F492EE5699F89342CB680A627E9D2266FB47"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "201CECA5694B454EB9584002477E2AE9F652"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "9A7140567B6FA64580185ED8AF14515C64BC",
                            "defaultText": "아다만티움"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "2BC78C3254E40746059A90F8C1E360410F56",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "2C436ECC704E5449BD18D69102B7356E0810"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "4A9095A39FDDF14F180BE8756612262A4AE6",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F9D5546E2424A2404218BE33C8A930DEC1F3"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A3C632572394534548481B58BB9FB5BF310D"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "796F0BCE626DF44B282A06526A1666897C8D",
                            "defaultText": "마법의 가루"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "5000D53B5D4FF74914994B785985247CE983",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "A9DDBF7F5A38A34FA1290E01C1D6650548C5"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "7AF652131CA6A04D35882C780401D7C913E1",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A22F974B705AC7481B7A99E74A246049228F"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "7DD078446A6A964CC87883A3E7C8A4D03452"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "3362525E5910984DBB584F93D907921D5B75",
                            "defaultText": "신비한 먼지"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "BA1F62483ABCE14619098A337FDD6E2E12F3",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "AC67D90B24B81842AC3AD482839173969404"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "DF115EE88C906444958B97A5616A05593052",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "137AF7B04B21884D507BE9C846DF1A95DD02"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E83AEB7B2D2AE44CEB5A10323700A42653B9"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "2C54828C3910F946B26A8023FB6AEB29602D",
                            "defaultText": "영혼 가루"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "1F3D907D80DCB741A83867610FF64E07F8F9",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "77E25A1B627F6840EA9A0DE7A5A13138BA53"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "7A99D4253C96484E193816750EB3DBA90E3E",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "197358AD3F794744969B3151E5C26DD968E2"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4AB01D884851684CA19905C52D610135C740"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "06531AE371DAE64A0E88284470CCA8652816",
                            "defaultText": "신성한 먼지"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "3D277F6F23F90443B43BA4A9B4C63386ED6B",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "7E2C951E0CF66148C888E10252F1FA259FC4"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "1C825C9787E6784A301B41952757E5578E1E",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8735E2EA57B582429799B3197B906DFB98B1"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "FD5AC7CD719A5440B78A73853B693CE14140"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "8E823CA17B6118444C893B741164ABFD5BFD",
                            "defaultText": "작은 뼈"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "4923357911892749D7096AD42745C8EA15F6",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "28AE5DDE86EDB748BB4B4F878F7FCC0276A2"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "81C0ED134077094A962B03F7DF9AFAFE4C8B",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "11BEC02F5A99C64813788B448D18B229EFD2"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "CCACC2C634F4C8407C1AB4B82E4FB6F82B68"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "B56250071BFB9748F3489C45A9D02A4EDF36",
                            "defaultText": "중간 뼈"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "EA8889401F0F2640E46B3377A03D885A2C9D",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "B17B7E1E81F1E0418E3B3204C8E977477DDC"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "7A2640DA856A5648655ADB42A81E11DF3371",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "7CA0923425E8C547AC8837780059D5A28F9F"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C8BA48298913C5419F49674777BD2B8FD7B7"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "C3A95EDD3B9DF9464419FFB828763278C02B",
                            "defaultText": "큰 뼈"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "987D6F2477BC67405E793656EDB3261490FE",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "FD749D0768C9E740C42994C8A6AF590CA447"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "C3D1422647DBD14D440985D9DF95EF7265B8",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "80A9E73249614140C019C0622EFC73B70185"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4FE1C3DF0152B242614AB635A04B26B713B9"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "E3532EBB44D5774B6B5826A3BBD19D6CFFF4",
                            "defaultText": "거친 가죽"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "464D75906BA251483998B438934C821AED34",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "7B62E79046EE9143DD3AEAB2F79AAD5A0411"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "DE6F2D7154AA604764080744A7951DD01B1D",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "33B8B8E339CB81497D492418F857A0B5EFFA"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8110BE4127F93440C579CD779C2A7E969DD0"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "AA069A2F67DEB148894B4C16A83C871D2C76",
                            "defaultText": "괜찮은 펠트"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "C5327C47982E724276196485493AEE686E3B",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "DB2220F862422140795A988882D5B92A15F0"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "F87D774C1A0E8948014ADBC98038E8FCEBB1",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9B8F270B7AECD245D84AA0D8EC069A842693"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "37969FCD7CAC4947315BDC0252C2EF47D804"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "8093A28B332CD74AE5699C048D623E597018",
                            "defaultText": "비싼 모피"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "C5631F202C4C574B0119CB80E54FAF7BBA99",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "730A7F663D197149ED695D531F015E44DFC3"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "8B09B20D85DAC340D65864F737523AAC7899",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "AFA2735F749A4348B38A0577AE3CD8315463"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3DB6C8039F18774D2E49AB38B1C04DFE11C8"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "E758A7359E08444D2D788497C5BCCD822DF7",
                            "defaultText": "라이트 우드"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "0121955B8539754B222A28D727C87FD649D5",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "12A463AF1F1F024A0A29CF35F60BA3A588D0"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "14B17D4B28B2314EB628B0123EF31D8D1F8A",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0D5F3BAA3D4E4647B07837E36E7B2D6E40DD"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3366304318FAA543F41974F4305CB071CF70"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "2D9B80C24D659441BE4A5B66E02EF19DE368",
                            "defaultText": "단단한 나무"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "5C6D8D9B641C5042FF79D2378AAA4A8733F0",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "522A6F3867F250474599A83919F0A80227E1"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "B16DDAB7047F5743662A1CE5AB9B7A687A75",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4DF2CF282CD22340B549DE2887D349BD8EC2"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0CCB56E54FC5B0410F4BF7E2F0F50266D0FB"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "2D1F1C2469FAA9474A59B05155C33D544097",
                            "defaultText": "독액"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "197F348F679C124EC68BC1234D774A651014",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "4EF692646D9F6848B87949A355F6766DDBF5"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "96E75C357588624215597679212778272D6B",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3AEB3FAD376DE74452998B4723F323B282B0"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "FB59FC10588F8443B05A9E2249F400B51CC4"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "6CA7B67258A2D641975AD7E591934AEE5A21",
                            "defaultText": "아이스 블록"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "15B7865445F4A342083AB9E6BC09CBB9F4E4",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "EB04D28D747B9749545A9AA597AD158DEA73"
                },
                {
                    "id": "gs.Comment",
                    "params": {
                        "text": "Key Items"
                    },
                    "indent": 0,
                    "uid": "5713FB3C3F98D64D0D695EB5F6DB46CA5BF5",
                    "expanded": true
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "AF156FD61C1BB6478E8AC202FCDDB7047CAA",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "551FF55A5B8D75438708FED1C85A2112B4CD"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E5F088768A9FF1429F4B0E2214F1DF384001"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "CHAPTER NUMBER",
                            "index": 80,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 5,
                        "textValue": "",
                        "switchValue": 0,
                        "valueType": 0,
                        "operation": 3,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "49E6E07B1314A84C941B46F7A1355B091B0C"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "2E6396F16CCB14439D89E06372239BA53373",
                            "defaultText": "고대 지도"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 2,
                    "uid": "7B7EAEBF1811A044DA394EC6046FBB2C79E8",
                    "expanded": true
                },
                {
                    "id": "gs.ConditionElse",
                    "params": {},
                    "indent": 1,
                    "uid": "D8563CEB8E65A24B706A63463BA85E187FF7"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "24B9787A69FC76485D187D13DAE433E55020",
                            "defaultText": "오래된 편지"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 2,
                    "uid": "D376FE9D99940641755A26578939E2068D3D",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "0BDECA73366CB14FC528CA99225063720AA4"
                },
                {
                    "id": "vn.GetObjectData",
                    "params": {
                        "objectType": 4,
                        "number": 0,
                        "numberDomain": "com.degica.vnm.default",
                        "layer": 0,
                        "characterId": "3418E1FB8BD7C845011A20C0C7D686BDF59E",
                        "field": 0,
                        "targetVariable": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D1BA6E6E6CF90648276B48E33A73A2583505"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "uid comparison",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "current uid",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A9936F4A1D04824D6A1918236B28D892B52E"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Text Output for Translations",
                            "index": 314,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "8DDE40621BF43749BC9BD1D2A700A88A89E8",
                            "defaultText": "오래된 열쇠"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "B66B27650D15C54697788A0718D61336C848",
                    "expanded": true
                },
                {
                    "id": "gs.JumpToLabel",
                    "params": {
                        "name": "end of invnames",
                        "target": "activeContext"
                    },
                    "indent": 1,
                    "uid": "0A204E3759A14445824A3C55DF247818FE9A"
                },
                {
                    "id": "gs.Label",
                    "params": {
                        "name": "end of invnames"
                    },
                    "indent": 0,
                    "uid": "A0FE41218CB4334E312BC485652E9D79AAD1"
                }
            ],
            "index": "AF47E2C7178B314CAB09A0A8FD61AB84709F",
            "booleanVariables": [
                {
                    "name": "",
                    "index": 0,
                    "scope": 0
                }
            ],
            "numberVariables": [
                {
                    "name": "",
                    "index": 0,
                    "scope": 0
                }
            ],
            "stringVariables": [
                {
                    "name": "uid comparison",
                    "index": 0,
                    "scope": 0,
                    "domain": "com.degica.vnm.default"
                },
                {
                    "name": "current uid",
                    "index": 1,
                    "scope": 0,
                    "domain": "com.degica.vnm.default"
                }
            ],
            "listVariables": [
                {
                    "name": "",
                    "index": 0,
                    "scope": 0
                }
            ]
        },
        "localizableStrings": {
            "70AA41FE6966C1421D0998A62DEFEB043887": {
                "t": "Captain's Sword",
                "d": {
                    "eid": "AB2694E895292847F58B3240EE24AEEE4386"
                }
            },
            "891C07964578C547D83819838C6E3C4EE3A8": {
                "t": "Warp Sword",
                "d": {
                    "eid": "9C1387AE9487D848E01942989A84E696BF17"
                }
            },
            "BD855F7D508D1940A739B3257CB7EACCDD65": {
                "t": "Bronze Sword",
                "d": {
                    "eid": "AB6C317B89E1524A458BDFC70000D33A652C"
                }
            },
            "1D2E828650E99643072B8BE806FD484DCF5E": {
                "t": "Bronze Sword+",
                "d": {
                    "eid": "95D3BACE7C581346D25A70B197EF2947A9A9"
                }
            },
            "F51560A822558140F65A1876588EFD982106": {
                "t": "Iron Sword",
                "d": {
                    "eid": "99FCA4806939B94A642A8CA6F1D02DA80CA2"
                }
            },
            "0FE21EA44E613147A24B1087E91EE141714C": {
                "t": "Iron Sword+",
                "d": {
                    "eid": "CE8BD7641EDAC448262882D3C1C65787574B"
                }
            },
            "2742E7D520206645336A0412E65621EF78F5": {
                "t": "Lethal Sword",
                "d": {
                    "eid": "18600982785EC14C1A884EF2C91AD340F069"
                }
            },
            "4B2BF68D406BC549D71B7F0595212394BEE7": {
                "t": "Lethal Sword+",
                "d": {
                    "eid": "6869CDDC52BD674F00694FD8CF369D7D53F8"
                }
            },
            "D74AAEDD769FD64CF58B3EE16F71BA172C59": {
                "t": "Mythril Sword",
                "d": {
                    "eid": "014331B37FBCC9460A8A1E73DC09E09AE373"
                }
            },
            "A36D41D869351540812A7EE56E2A6F127E9C": {
                "t": "Mythril Sword+",
                "d": {
                    "eid": "646B9C8A70B6C345612B488580F1CF0E7EF7"
                }
            },
            "91093F8F3D4D6245AA8B9379BD99476F0190": {
                "t": "Magic Blade",
                "d": {
                    "eid": "45908CB526C08842052827F9A17183A23A35"
                }
            },
            "2522C80562C2F3415E2B9A053547DA661374": {
                "t": "Magic Blade+",
                "d": {
                    "eid": "458636AC115944415C3BFD280BAFFA6F900E"
                }
            },
            "33C64CC84FF727489D39E174F2DA15939ECD": {
                "t": "Conjurer Sword",
                "d": {
                    "eid": "18F727C0562F6141715A5337900328F5BEE6"
                }
            },
            "BC58DDDF428ED740378A66E2CEFBCD411E2A": {
                "t": "Conjurer Sword+",
                "d": {
                    "eid": "1823FFE96C86084F619B59505212E61B2980"
                }
            },
            "7BABB33774F5D74B2309371519FD45F5C37C": {
                "t": "Spadiavolo",
                "d": {
                    "eid": "91A0CF282390864E760BD23067E0A0712F46"
                }
            },
            "06FE537832B7984343985A062139938F5DB3": {
                "t": "FALKION",
                "d": {
                    "eid": "BF059FB60655A54A734BDB986C3B66EC7B7B"
                }
            },
            "C09641805A0DB34DC07AA0B016D576510EAE": {
                "t": "Shiori's Manadrop",
                "d": {
                    "eid": "8F5D04C66C4114400429D7993B4C385FDAD4"
                }
            },
            "E03B30DE0268E74F3E2A02D04470BC6B6690": {
                "t": "Faratras' Manadrop",
                "d": {
                    "eid": "CDF5A1271CB544464F5BC07617B68497DE3B"
                }
            },
            "D3A9B1681C68D940DF7938E0F59E41B189E1": {
                "t": "Imbued Manadrop",
                "d": {
                    "eid": "885F688811F1F54B9859773196BB9A2BF3EE"
                }
            },
            "8D427FBA7E34D64C8759093746D50CA40C54": {
                "t": "Imbued Manadrop+",
                "d": {
                    "eid": "9BCFD0DB10ABA14E485879E74590C955933C"
                }
            },
            "50117B79939055402E18E3C16930A5BDCBCC": {
                "t": "Lethal Manadrop",
                "d": {
                    "eid": "BA38B6D51647084F923B76A96D1CA92BC85A"
                }
            },
            "FB77E7191F1E43494F598428D61A3C53C0CB": {
                "t": "Lethal Manadrop+",
                "d": {
                    "eid": "88E6BA254274B3430A29FAF5CBA05BF4E287"
                }
            },
            "ABEAA6A525B3234D0C5869433DCAD141262E": {
                "t": "Bright Manadrop",
                "d": {
                    "eid": "801B0FBF2C1176490C5B7A613AA8BBE269F9"
                }
            },
            "849E8F977AC1A84028797FB39774B11DB484": {
                "t": "Bright Manadrop+",
                "d": {
                    "eid": "0EC1EBFC8887134F096A6FF2ED062C51BE99"
                }
            },
            "1A039D8F5628504C233A0459863CED7D4BE9": {
                "t": "Holy Manadrop",
                "d": {
                    "eid": "B9535CC51C8235422C197BA60CC255DF7844"
                }
            },
            "B6B8C909845645474D2B64A56D1F9E4EA51D": {
                "t": "Holy Manadrop+",
                "d": {
                    "eid": "FEED09206316A14FB77BD6926A099D596570"
                }
            },
            "6CEF6D3035F2754FC48805D855342DD1E466": {
                "t": "Eerie Manadrop",
                "d": {
                    "eid": "7309E8533373114C6A5BED3989C654C2EA86"
                }
            },
            "68AD09BF10EFD7437D1BE9E4B6DDF7DDA65B": {
                "t": "Eerie Manadrop+",
                "d": {
                    "eid": "642E878C40DDD34F2D7BE769899EDC7EBFDD"
                }
            },
            "CB014A4071E250402938F5489B4E44F68845": {
                "t": "Solaris",
                "d": {
                    "eid": "19438CF077BEC143C82B80E53764865FB76F"
                }
            },
            "296309A01AA6764488497F89B3435B0C1DE6": {
                "t": "Lunaria",
                "d": {
                    "eid": "C2860EE6182C3643D5897C9330F87858E511"
                }
            },
            "5C3758E922ACD84D2E39D1C997C935E44EFD": {
                "t": "Cristoph's Axe",
                "d": {
                    "eid": "2C1B7B2377CB2146A96A5E379058276413E2"
                }
            },
            "51F3D97A7A91D94D1C3A7BF4BC95F519C673": {
                "t": "Iron Axe",
                "d": {
                    "eid": "00B6CDF03EA3A44C276A67320A043C31A4BD"
                }
            },
            "8CADC0FD7F2DE343AF8A52459B60FBFCEBB2": {
                "t": "Iron Axe+",
                "d": {
                    "eid": "F856B28E4ABC2148CA1A95A6747088C9737E"
                }
            },
            "D34EE7BE8493764EF27B8F45AF109367632B": {
                "t": "Lethal Axe",
                "d": {
                    "eid": "896D519325701742AB7B23F714E110282A42"
                }
            },
            "0E2A1B0B882F644C640A0EE87E3F667B23E8": {
                "t": "Lethal Axe+",
                "d": {
                    "eid": "85E7DD4E26C3C740171944E0E11354B2912E"
                }
            },
            "69A4E68D7F60584CC64923C86F2295BF532E": {
                "t": "Mythril Axe",
                "d": {
                    "eid": "C2ED95031F74694A2A3B48A75433D22996F0"
                }
            },
            "94B7CCE77D3629476F083B982D09AC0320B0": {
                "t": "Mythril Axe+",
                "d": {
                    "eid": "97E3BAA0491AC54FF42BDB44E86A0F77D719"
                }
            },
            "C6D88992663B1042F5497F92BFCCB05729E1": {
                "t": "Magic Axe",
                "d": {
                    "eid": "30F8A9B82D34C2446B59B856373E0E2A4152"
                }
            },
            "2FF7025E808F3749A80A31B43727B2708ED6": {
                "t": "Magic Axe+",
                "d": {
                    "eid": "C7B1907B7DAA2540E26BB863B0E44C146320"
                }
            },
            "6670A24999A66444673AA8B901BB5C97CD72": {
                "t": "Conjurer Axe",
                "d": {
                    "eid": "BCA0D26462DBF44D25384B93DDA3A61A92D5"
                }
            },
            "62474E39398E624BB96B2B949C1986974A63": {
                "t": "Conjurer Axe+",
                "d": {
                    "eid": "025B457F36B723462A1BD8A0586B9D9E2D0F"
                }
            },
            "471754A7620BE54F3B4B1DB4FE44666FAACC": {
                "t": "Garm",
                "d": {
                    "eid": "C46B83742B135246B53B243349785A019060"
                }
            },
            "5C7F10437F06F744354BC3F3B988623C7C8C": {
                "t": "Rya's Bow",
                "d": {
                    "eid": "EE372F09939CC347F289FFB19214ADEA5DB0"
                }
            },
            "D4931E6F0A80A84D510BB102EE637897DE8E": {
                "t": "Iron Bow",
                "d": {
                    "eid": "5B37374E629D30429068D478DA587FB54777"
                }
            },
            "18A7B80A935F62414208FE584EEF8E85736A": {
                "t": "Iron Bow+",
                "d": {
                    "eid": "FFDA33958844584173798045D88A2C172A6F"
                }
            },
            "AA8C628C5B1B24429509BEB0BAD427CC5E52": {
                "t": "Lethal Bow",
                "d": {
                    "eid": "CBF532F716B90244364BE5A0ECDE0F54A4EF"
                }
            },
            "66060C9B24B81341107A7545B4989299FB41": {
                "t": "Lethal Bow+",
                "d": {
                    "eid": "FE182ADC2DDA424F0A182B71C357C982A239"
                }
            },
            "E5E92737704737488F68874266BC37BCEA28": {
                "t": "Mythril Bow",
                "d": {
                    "eid": "14C8967075950042431A0CB6C9835E93936F"
                }
            },
            "328B3AB3771CC14F1E1A49C288FFB665023A": {
                "t": "Mythril Bow+",
                "d": {
                    "eid": "BA7744F13A35144BD908F340A86F7410968C"
                }
            },
            "F32307955F14964E8709B97273BF5BDB1F95": {
                "t": "Magic Bow",
                "d": {
                    "eid": "B5FC9FC05523B144874AFF52EDD0BAA6040A"
                }
            },
            "5F5725869A13874A7E8BDA688586253654EA": {
                "t": "Magic Bow+",
                "d": {
                    "eid": "FFF95DE69B10814EA36AB236F6B00458DF11"
                }
            },
            "C8CF061232EE2840C19A57E96781D0A9AAA8": {
                "t": "Conjurer Bow",
                "d": {
                    "eid": "B445423626913748F899B1C2C5E3E8F2F36F"
                }
            },
            "EC70EA5532BDF64E995BD911CB32DF70AFC4": {
                "t": "Conjurer Bow+",
                "d": {
                    "eid": "6585FEAD1CDF6246EC68469277E379DB3DB3"
                }
            },
            "A491A78F4A72864C1E9973195F7A7B38CF59": {
                "t": "Nidhogg",
                "d": {
                    "eid": "F61EE698996A8945E04BC9F480A60BF119C3"
                }
            },
            "DE5198BB75053943D37AF951A49F1C3F57C2": {
                "t": "Leather Cap",
                "d": {
                    "eid": "4F19A69D1E77264ED92B0824117CF298D0DC"
                }
            },
            "B32217300A19884AB13AA6A4D694CA7904C0": {
                "t": "Leather Cap+",
                "d": {
                    "eid": "9630EC589A5EB443AA59A302E4BF1226831C"
                }
            },
            "9EA9E1331E1D264E148BFA10ACB8FA8C18D1": {
                "t": "Bronze Helm",
                "d": {
                    "eid": "95271C51690F4344A02922722F78C7D0E3BB"
                }
            },
            "3738FD9D808E684A1668174203ABD58F8957": {
                "t": "Bronze Helm+",
                "d": {
                    "eid": "F841EF2B4F30674E982A26C866E216D3F7F1"
                }
            },
            "0526AB74651A534CEC1A2A159A09D4A2878F": {
                "t": "Iron Helm",
                "d": {
                    "eid": "8382723975467144676B42F48F8429ABD877"
                }
            },
            "D5A2511772D7A2419F29C4D81446D2256230": {
                "t": "Iron Helm+",
                "d": {
                    "eid": "56C501B973E7A44C4478C278D13B78F51CC3"
                }
            },
            "DEF20C316B704345274AA43869E3B530899E": {
                "t": "Polar Cap",
                "d": {
                    "eid": "1B00DE1F30D4A940126B4280EE77D52D208F"
                }
            },
            "59D638CA6B4D744BA60BFDA8C213F0D7C14D": {
                "t": "Polar Cap+",
                "d": {
                    "eid": "992E842A4B3095494C98CF686E00FAC1FAB1"
                }
            },
            "D0C7440E224AC14D6F2A2FE4AD5012E76FB6": {
                "t": "Pyro Crown",
                "d": {
                    "eid": "F434EC77878F134079298ED450E22B3F090E"
                }
            },
            "29ECB39286CFB3490B095824F8F35530CBD2": {
                "t": "Pyro Crown+",
                "d": {
                    "eid": "4F05BE548357864F054BE09817EED447AE01"
                }
            },
            "47252A389AD2B24AB568838179A966D4332F": {
                "t": "Mythril Helm",
                "d": {
                    "eid": "C94DA2531ED6764B6138CB21FF541B4F42B8"
                }
            },
            "254BB7CC4B044649842913937FC03F12FB5B": {
                "t": "Mythril Helm+",
                "d": {
                    "eid": "C4D2E7A415DC624EF39AF0B6FBE0FFE3E1EC"
                }
            },
            "D556CF2940A51148FF4B1C56D04E43B3AC10": {
                "t": "Luminous Gear",
                "d": {
                    "eid": "3663ADA35F7E7641B279DE35A1DFA959F7B9"
                }
            },
            "31DB4EB633DB5144DD8B7D266C103DD96553": {
                "t": "Luminous Gear+",
                "d": {
                    "eid": "64281D7782601741E05811B7F5373D1C55C9"
                }
            },
            "51D72E856BEA73453D3B6E68FF83BB1E81E3": {
                "t": "Tiara",
                "d": {
                    "eid": "45C0B3A529F93142332B47F8556CE6B8822C"
                }
            },
            "AD48C8965B92F04C7129B114794AB9C0FF67": {
                "t": "Valon Helm",
                "d": {
                    "eid": "0C38C2352C38F248CA480475127F4E34DE92"
                }
            },
            "57FEA6698893484B419A6E767FFB03E30A3B": {
                "t": "TITAN VEIL",
                "d": {
                    "eid": "58EDF9ED8444D54A613B20389535D8D7E6B8"
                }
            },
            "F649D7315E6BC34C74896F68B32E6C32BC6C": {
                "t": "Bone Shield",
                "d": {
                    "eid": "A874867F3C93364A573BD77797F67A674C1C"
                }
            },
            "BDD733DE3C21F6486C89C58711FC4DE9D436": {
                "t": "Bone Shield+",
                "d": {
                    "eid": "552C7EE173E9644FC98A26F32BB981729A30"
                }
            },
            "96123E4C4EED9647B7091C97CE536F951053": {
                "t": "Iron Shield",
                "d": {
                    "eid": "D5ED330D6A28E840093B781063BF7AAAF78B"
                }
            },
            "101AC6861529F543CF784463170B9143230C": {
                "t": "Iron Shield+",
                "d": {
                    "eid": "E0DEF6201BDCA14E7B9BF78087644B56F43A"
                }
            },
            "93FE197F4A2A68459C59B4D88D6E25E051E0": {
                "t": "Polar Shield",
                "d": {
                    "eid": "0D9883A446383446CB8B9AE5DF13D6EC58B3"
                }
            },
            "7D1315493438054E4888BE178284FDF448B2": {
                "t": "Polar Shield+",
                "d": {
                    "eid": "742F04413C0307422D68EFA79F6B9716FD0D"
                }
            },
            "1624145974EE96464C18507615D77673F020": {
                "t": "Pyro Shield",
                "d": {
                    "eid": "AEC03A4F3109C34F71183BB30C9F5A1D9743"
                }
            },
            "BC16294C41855347AC0808E7DFE0FD83E1B2": {
                "t": "Pyro Shield+",
                "d": {
                    "eid": "D32EFD783BB5D540C36AA5A750CE5627B2A6"
                }
            },
            "80FE49EF10909343092B0296D07E3726C86C": {
                "t": "Mythril Shield",
                "d": {
                    "eid": "A59486DB2B12B84997593DE4F265A8E12226"
                }
            },
            "9C863F0510310540771BEA3775CDB0CB5562": {
                "t": "Mythril Shield+",
                "d": {
                    "eid": "856F3FA79C97C5416E2864140A2AD64102AF"
                }
            },
            "7791130C32318347872A6650C53899EF8673": {
                "t": "Luminous Shield",
                "d": {
                    "eid": "9262057B121DA843B498EFB47B08F2677E45"
                }
            },
            "A50D161B7AD5D348CE6B06D9DA2DF2302E9A": {
                "t": "Luminous Shield+",
                "d": {
                    "eid": "219B3CCC5C16F646BF988E41F93744900CAA"
                }
            },
            "C9FF82E97E2E0146B4881C9383FDF162C231": {
                "t": "Golden Shield",
                "d": {
                    "eid": "4CA264B8129623490A984936A330F6047541"
                }
            },
            "9A85F4B85901B647383830B920216A9E202C": {
                "t": "Valon Shield",
                "d": {
                    "eid": "DE8701D7913F924B3108FAC8ABE13227EA49"
                }
            },
            "FCAE415D927AF343503A0344013D4B66BB48": {
                "t": "SUPER AEGIS",
                "d": {
                    "eid": "35510A3B34DA1241222A79748C8A272E26BB"
                }
            },
            "B916DCA59F2EF8411719F044B3BD698A949E": {
                "t": "Leather Vest",
                "d": {
                    "eid": "152000217AE31349635B8FF9C7BE627F1A6C"
                }
            },
            "F54F3ED59ADFD74DB26AB27446B297CA5E4B": {
                "t": "Leather Vest+",
                "d": {
                    "eid": "102CC72B353988407D88BDD197D3F521D154"
                }
            },
            "A20C7D223C91A841FD483E07D09EA5EB7CB1": {
                "t": "Bone Armor",
                "d": {
                    "eid": "AC6FEC4040C6944D1D3856C52A1F7CDF59BC"
                }
            },
            "F697D27B5EC1E3492F5B8232D8C8B892D4BB": {
                "t": "Bone Armor+",
                "d": {
                    "eid": "ACC557A64562F24ABC8A7C381489A12C4065"
                }
            },
            "4D7D4F3E641D154BD828908579A2B0B8C122": {
                "t": "Bronze Armor",
                "d": {
                    "eid": "A3C242CA5505824ED6881AD4CADC9F1751C5"
                }
            },
            "45983F681AC25945DD196D88ECDE8A5E7F46": {
                "t": "Bronze Armor+",
                "d": {
                    "eid": "78BCBFB011EA9240751BCE2153BB39BF7D52"
                }
            },
            "3C9F5F537EB24147316969C16229F7028E63": {
                "t": "Iron Mail",
                "d": {
                    "eid": "873AEDA20913B44BD7899EF21B992E461159"
                }
            },
            "4E78605F0F3BD941138AD63482DABC379D17": {
                "t": "Iron Mail+",
                "d": {
                    "eid": "DD78C0D95405614FF629D34693611984C39B"
                }
            },
            "63667AA93E2DC347903A96D3F3CDD0B781B5": {
                "t": "Pyro Robe",
                "d": {
                    "eid": "31420F5A9E365247B41BB5F9C13357C818AC"
                }
            },
            "91DA4E69837C214AE71BCD239FD0FEF03948": {
                "t": "Pyro Robe+",
                "d": {
                    "eid": "91D7A98D4280984DFF6B98D7A4CEF515FECB"
                }
            },
            "E4767B4994B3B447B1299083A7B421E92295": {
                "t": "Polar Vest",
                "d": {
                    "eid": "EF63491376BEC943535B9198819C637E5AFE"
                }
            },
            "AB52249B144C9841285AB5D4B566268CD85D": {
                "t": "Polar Vest+",
                "d": {
                    "eid": "85CFE524192EB3492799C45745CDF70A0D91"
                }
            },
            "B751F8017ADFB84CC16BEDC6FFDF1F323C11": {
                "t": "Mythril Armor",
                "d": {
                    "eid": "BF9D70B11AE18049F5783228DF25578F3D7B"
                }
            },
            "AA55E4B255E5884EEE493F83071552F70B52": {
                "t": "Mythril Armor+",
                "d": {
                    "eid": "B79FBE9A139BB54B323BD2E5FB969A593D69"
                }
            },
            "F3F8988E237C054A5459DF5166146730A973": {
                "t": "Luminous Coat",
                "d": {
                    "eid": "E9623E7F8754C24F0F587A01695359842070"
                }
            },
            "544FABFA5848734AFD6A34C7683614AC7AC1": {
                "t": "Luminous Coat+",
                "d": {
                    "eid": "86E0B76640B6314B1869031324B6BDBE73F0"
                }
            },
            "2B389D5942708246C139BE2613952307DCC5": {
                "t": "Valon Mail",
                "d": {
                    "eid": "905BEF72495CD144BA5903A828A08E0FF5DD"
                }
            },
            "2B02FAFA106C86461A38E06600C7ADFA5D8B": {
                "t": "HYPERPLATE",
                "d": {
                    "eid": "D5ADB1954505E44DFD885DA7B30A94CB443D"
                }
            },
            "5BCEB42B2D7F99468879E1B7730CCF863DE3": {
                "t": "Bloodied Ring",
                "d": {
                    "eid": "68E36D08407B8647AE89CA14BA28CC6A0AE0"
                }
            },
            "5855D83F261CB74413885AC3FB4E2BCAAB48": {
                "t": "Leather Boots",
                "d": {
                    "eid": "6FD3E1B87637214F2D380AF06455FAA8BF05"
                }
            },
            "219E8B4024BB2942750B4AA53C0FCCDFA49C": {
                "t": "Iron Boots",
                "d": {
                    "eid": "BB68227C6B9B014005094694FDD39A17611B"
                }
            },
            "BD76E2DE7E9A474CA83AC8A8F040F0618F10": {
                "t": "Mythril Boots",
                "d": {
                    "eid": "D8073574578DD346054B41F516EB22727DFF"
                }
            },
            "76616E68979F624A6E0897515282DD054102": {
                "t": "Mana Pendant",
                "d": {
                    "eid": "1DE4B45F55A0E8458D99BD95F31F3BC7F10F"
                }
            },
            "9341D55497DDA545DC282DE716E91FA05A3A": {
                "t": "Seer Glasses",
                "d": {
                    "eid": "6D21B9CD7F76D54B732AAFA46BCB0C7A88BE"
                }
            },
            "5E1B17FE4D5A384D35881E54912B509BA8B6": {
                "t": "Aether Goggles",
                "d": {
                    "eid": "BC89FD0E6CE6574AD18B50F7194596972C5F"
                }
            },
            "F344AAD367CAF84ECB291A059B70359FEE21": {
                "t": "Snake Earring",
                "d": {
                    "eid": "6ADBD17E316CB34781585F17125D87F7AB1F"
                }
            },
            "40A453B193FF61495F8843D53E0CEAE562A6": {
                "t": "Desert Scarf",
                "d": {
                    "eid": "E9F571D845DAB24008993C4764B970189A89"
                }
            },
            "DACEF23C59E2044AA46B0A9598606A7289F1": {
                "t": "Storm Pendant",
                "d": {
                    "eid": "F887DCF46752F341ED588E27441D2A21A865"
                }
            },
            "ED31C73A61507547811BA3E73886A09BC3D7": {
                "t": "Rubber Band",
                "d": {
                    "eid": "1C67C80B2D414547BD1818A50CD6AE3511BC"
                }
            },
            "DD1FACE14C037245188BE8C7D7866083E82E": {
                "t": "Mana Earrings",
                "d": {
                    "eid": "A24C798981BAE047F939A185977D2EAF7813"
                }
            },
            "0D445B3593FEF04F8648AC78B51613D18D19": {
                "t": "Medicinal Herb",
                "d": {
                    "eid": "CEE5EC754E962247321AF5831470D1C4A72A"
                }
            },
            "18307873189E3340566B5046BB1FCB08262C": {
                "t": "Vulnerary",
                "d": {
                    "eid": "D2AB01D57FA9834D350A2844AED174F72C5E"
                }
            },
            "5FE7D50E6354A242A80A6C586115ACD9D86B": {
                "t": "Potion",
                "d": {
                    "eid": "5DBBC38D5A536847F55804D612D8EA74D358"
                }
            },
            "EFFDF2DB83D0A240F93958083208F819640D": {
                "t": "Elixir",
                "d": {
                    "eid": "E3CD821B628A644A0A28087071B15D680195"
                }
            },
            "C563B6298B68D14CA03B32731F1018EF273C": {
                "t": "Panacea",
                "d": {
                    "eid": "F7A09B9D5AF2414CE53A37537BA9479995EF"
                }
            },
            "1F2E07CB2F76044B434A2EA2829911079252": {
                "t": "Phoenix Tears",
                "d": {
                    "eid": "76F67BF648D1704ADC3AC674B2DC90E110C8"
                }
            },
            "7A76203259CB384DC5180353EB3702FA07F3": {
                "t": "Fairy Incense",
                "d": {
                    "eid": "7F8D01EA8CCC1046868A44A7F33E4963F81C"
                }
            },
            "612BFA4C5B36D544508954C2CD36BFE0BB39": {
                "t": "Pixie Incense",
                "d": {
                    "eid": "5278D76864B0D84C93383286D9DA6E2352FE"
                }
            },
            "D344D49F2BEAE34B9D5B6E67EC39C268A8C5": {
                "t": "Ambrosia",
                "d": {
                    "eid": "AB3EF1A73AB0C7417219D6E83C9B0DE6E4EF"
                }
            },
            "A26D4F1806E6C7411688A014E8ABC141C75D": {
                "t": "VULNERARY",
                "d": {
                    "eid": "E343A3127369394D231ABBE0B124898FB2C3"
                }
            },
            "F4370BC339373042D27821D58FF0370EA139": {
                "t": "Raw Meat (S)",
                "d": {
                    "eid": "BFE49292048E664D181AAD4445FFD6C0928C"
                }
            },
            "7B6171A24E5AC247781B7D8128E1831023D8": {
                "t": "Raw Meat (M)",
                "d": {
                    "eid": "63D78F3361F084408A78B2C8CC9CFA281C6B"
                }
            },
            "292BDA09196DC54B56890558D3B7935C27A8": {
                "t": "Raw Meat (L)",
                "d": {
                    "eid": "06B4528A367E524FFE3BF5A01F6BDE55EF7A"
                }
            },
            "7E93B47528AA9545EE4A5B458689E714FB14": {
                "t": "Raw Fish",
                "d": {
                    "eid": "3DA436D864EA354C527A34515E7BDE03FDC6"
                }
            },
            "86A55099389C514D4239EBC0EC9410C5545E": {
                "t": "Orange",
                "d": {
                    "eid": "5D49650132B1D8470F2A0929277EB4DE382B"
                }
            },
            "3622E22E56E0A34E604965074A4575DC241F": {
                "t": "Apple",
                "d": {
                    "eid": "0CCA2CE906BF784E14198D0873F1747B595F"
                }
            },
            "D3685A6D78A1914D569AEB628C4CC66E3E79": {
                "t": "Tomato",
                "d": {
                    "eid": "B8AF990A5190F145B69998F53F30141D5C0C"
                }
            },
            "0831071846E82541BC1BD4867AFA702FA0FE": {
                "t": "Mushrooms",
                "d": {
                    "eid": "1CCA44C35FA2F24BA74A6E02CE17035FF131"
                }
            },
            "64C1CE8342BE0640FE1A4987AC0FC47EDF93": {
                "t": "Ficus Fruit",
                "d": {
                    "eid": "AC796A6C4952D34A7C3882C82E7477109D33"
                }
            },
            "97CA7D1C466CB744062AD8E4FB6C395D5EF6": {
                "t": "Mango",
                "d": {
                    "eid": "1EB80CCC43E65249B0592AA47715661A5B96"
                }
            },
            "2BAF43CA8AAED24E089B8943A8FEBE384AA9": {
                "t": "Wheat",
                "d": {
                    "eid": "385A53E345F945420C5B33A2E9D653607EF3"
                }
            },
            "D81A30B6231EE847006BD7B86248BEC8D117": {
                "t": "Rice",
                "d": {
                    "eid": "67F3DB4D6DE32043451BD3B1E996E8E00AA7"
                }
            },
            "D37F6D5C701922442599B8C64674FF772FAE": {
                "t": "Potato",
                "d": {
                    "eid": "CCB02A9649BC37461D4AF535E85C890F3185"
                }
            },
            "77243BB0726D154D0B5AE164EBCC7C833F79": {
                "t": "Lettuce",
                "d": {
                    "eid": "056A994B6FD0544C7B9BEF85930F82F2E435"
                }
            },
            "B2123F135BAF174ECB6B738904A38096F728": {
                "t": "Milk",
                "d": {
                    "eid": "D10AE5361B23F7414C69BEA31D377DFEAC45"
                }
            },
            "1FF875CA1F1B184AE078AA28AB4F55779C05": {
                "t": "Coffee",
                "d": {
                    "eid": "9D5AE1534EC4844BF41A3735DE569F70D3ED"
                }
            },
            "6403B15270C5F044DE1B79F7C51736901ED2": {
                "t": "Cappuccino",
                "d": {
                    "eid": "A8C68B115ADAC5432A88D4049C1DF186D84F"
                }
            },
            "4C761EBF9427734D395985C1ABEAB295750A": {
                "t": "Croissant",
                "d": {
                    "eid": "D4D1FBC827E39249D69BFD3543C1AA7D27C2"
                }
            },
            "36E0337D48AC1142103A7132F0BE1265A927": {
                "t": "Crab Soup",
                "d": {
                    "eid": "80EDEB572E5C914FC38AA56661C1D4CBC2E8"
                }
            },
            "96F8FF40418EB544D55B60636ECE67B972A8": {
                "t": "Steak & Chips",
                "d": {
                    "eid": "893F963104EEA64DE11A2EB77F01306F8D78"
                }
            },
            "61374A300958D54C89897491981205EB4B19": {
                "t": "Fresh Water",
                "d": {
                    "eid": "D65D24AD7A823844A88ABB042330B5CB1F42"
                }
            },
            "87A7C59A8302074D947BA0F275F3285CE873": {
                "t": "Beer",
                "d": {
                    "eid": "4FB56DF43CEFE94DBF3BEDD6B7B4CFFAF76C"
                }
            },
            "799FE2F38D1EC14EAF8A7088634FECE90616": {
                "t": "Creamy Salad",
                "d": {
                    "eid": "C181B0E02351C4490F585177976DB927ABBE"
                }
            },
            "9E41A6584EDE134DF38A0171217B79275734": {
                "t": "Hard Cheese",
                "d": {
                    "eid": "7AE670B7745CD34B593892E210EA3F85212C"
                }
            },
            "BFD49C5A3F0F364DAF3BE0C417CA707A895D": {
                "t": "Blue Cheese",
                "d": {
                    "eid": "4EF4846A9882F348421B3518269127BF8840"
                }
            },
            "C68FA85B8F75A442EC2BB166D0CA4A0A7F03": {
                "t": "Grilled Fish",
                "d": {
                    "eid": "C27BFADC1BDB2645BF4BA9277B7EE4BBB833"
                }
            },
            "6568417070DBC545F52A235314749B18F8CC": {
                "t": "Ice Cream",
                "d": {
                    "eid": "5AAD17847ED49446E28AA0C22B5396B34E7A"
                }
            },
            "FB9659D53AC2574EF508341876C16E4B8783": {
                "t": "Spaghetti",
                "d": {
                    "eid": "D7C900AC1A50D740BF28D1F459D5F09CDC12"
                }
            },
            "6F2006122F49C14945593088045EDA3BB1F6": {
                "t": "Wine",
                "d": {
                    "eid": "B57077883E730943E63803F7A4AE261C485B"
                }
            },
            "8957BB3B905F17441B79120454087D5CA32D": {
                "t": "Veggie Pizza",
                "d": {
                    "eid": "432235FD2F42444AAD38A0B62595989D1CF4"
                }
            },
            "7389AC9C2BA2554A0C79B758185DE6091AA2": {
                "t": "Fa's Special",
                "d": {
                    "eid": "9F2BC05673C2A34C698BC591FF81DDDF4D06"
                }
            },
            "ACB32DD55975474F848B3628906842CBB94D": {
                "t": "Kushari",
                "d": {
                    "eid": "FCC320FD3753C64BF13A14273A3CB3C95414"
                }
            },
            "34596DC075A1574579581198A719F488BC1A": {
                "t": "Sayadieh",
                "d": {
                    "eid": "574529DF2AB3F14E691B4914C22C0587E3C7"
                }
            },
            "E3CBE49F05C56142E35A40E0654E73AD2614": {
                "t": "Sushi Mix",
                "d": {
                    "eid": "C0DCFFF466013046DC49A74475055DA03BF7"
                }
            },
            "39D4A2F040A1D74C1A4AD012383CE8AE4C52": {
                "t": "Bronze",
                "d": {
                    "eid": "03D1652A25774349609929E296632B47DD96"
                }
            },
            "275E2C0C4F49174DBC6A74A29683A03E9C6F": {
                "t": "Iron",
                "d": {
                    "eid": "7FE6A4BA502A16430068B884759F27E1DF0C"
                }
            },
            "2505293A2664C947B51B5E7590555553024A": {
                "t": "Mythril",
                "d": {
                    "eid": "02BB7C3E1FF1B646201A2C616D4F9BBD8FA2"
                }
            },
            "9A7140567B6FA64580185ED8AF14515C64BC": {
                "t": "Adamantium",
                "d": {
                    "eid": "2BC78C3254E40746059A90F8C1E360410F56"
                }
            },
            "796F0BCE626DF44B282A06526A1666897C8D": {
                "t": "Magic Dust",
                "d": {
                    "eid": "5000D53B5D4FF74914994B785985247CE983"
                }
            },
            "3362525E5910984DBB584F93D907921D5B75": {
                "t": "Mystic Dust",
                "d": {
                    "eid": "BA1F62483ABCE14619098A337FDD6E2E12F3"
                }
            },
            "2C54828C3910F946B26A8023FB6AEB29602D": {
                "t": "Soul Dust",
                "d": {
                    "eid": "1F3D907D80DCB741A83867610FF64E07F8F9"
                }
            },
            "06531AE371DAE64A0E88284470CCA8652816": {
                "t": "Divine Dust",
                "d": {
                    "eid": "3D277F6F23F90443B43BA4A9B4C63386ED6B"
                }
            },
            "8E823CA17B6118444C893B741164ABFD5BFD": {
                "t": "Small Bone",
                "d": {
                    "eid": "4923357911892749D7096AD42745C8EA15F6"
                }
            },
            "B56250071BFB9748F3489C45A9D02A4EDF36": {
                "t": "Medium Bone",
                "d": {
                    "eid": "EA8889401F0F2640E46B3377A03D885A2C9D"
                }
            },
            "C3A95EDD3B9DF9464419FFB828763278C02B": {
                "t": "Large Bone",
                "d": {
                    "eid": "987D6F2477BC67405E793656EDB3261490FE"
                }
            },
            "E3532EBB44D5774B6B5826A3BBD19D6CFFF4": {
                "t": "Rough Pelt",
                "d": {
                    "eid": "464D75906BA251483998B438934C821AED34"
                }
            },
            "AA069A2F67DEB148894B4C16A83C871D2C76": {
                "t": "Decent Pelt",
                "d": {
                    "eid": "C5327C47982E724276196485493AEE686E3B"
                }
            },
            "8093A28B332CD74AE5699C048D623E597018": {
                "t": "Expensive Pelt",
                "d": {
                    "eid": "C5631F202C4C574B0119CB80E54FAF7BBA99"
                }
            },
            "E758A7359E08444D2D788497C5BCCD822DF7": {
                "t": "Light Wood",
                "d": {
                    "eid": "0121955B8539754B222A28D727C87FD649D5"
                }
            },
            "2D9B80C24D659441BE4A5B66E02EF19DE368": {
                "t": "Hard Wood",
                "d": {
                    "eid": "5C6D8D9B641C5042FF79D2378AAA4A8733F0"
                }
            },
            "2D1F1C2469FAA9474A59B05155C33D544097": {
                "t": "Venom",
                "d": {
                    "eid": "197F348F679C124EC68BC1234D774A651014"
                }
            },
            "6CA7B67258A2D641975AD7E591934AEE5A21": {
                "t": "Ice Block",
                "d": {
                    "eid": "15B7865445F4A342083AB9E6BC09CBB9F4E4"
                }
            },
            "24B9787A69FC76485D187D13DAE433E55020": {
                "t": "Old Letter",
                "d": {
                    "eid": "D376FE9D99940641755A26578939E2068D3D"
                }
            },
            "8DDE40621BF43749BC9BD1D2A700A88A89E8": {
                "t": "Old Keys",
                "d": {
                    "eid": "B66B27650D15C54697788A0718D61336C848"
                }
            },
            "7821B5EB0F8A8446EC982761F366F2E3F673": {
                "t": "Falkion",
                "d": {
                    "eid": "76EC192E48F8934D9A497286CDFF93F03A2C"
                }
            },
            "2E6396F16CCB14439D89E06372239BA53373": {
                "t": "Ancient Map",
                "d": {
                    "eid": "7B7EAEBF1811A044DA394EC6046FBB2C79E8"
                }
            }
        }
    },
    "summary": [
        "name",
        "type",
        "order"
    ],
    "externalItems": []
}
