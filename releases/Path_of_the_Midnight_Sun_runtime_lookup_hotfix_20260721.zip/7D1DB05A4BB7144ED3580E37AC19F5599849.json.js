GS.dataCache['7D1DB05A4BB7144ED3580E37AC19F5599849'] = {
    "uid": "7D1DB05A4BB7144ED3580E37AC19F5599849",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C11B-4 Meet with everyone",
        "type": "vn.scene",
        "parentId": "04D12A924ED7E240E4793325D061E98BB345",
        "chapterUid": "8A78B92E5A59F446F05823F4DB00C78A28B3",
        "order": 5,
        "localizableStrings": {
            "7B8E9A5158E8014FF899B6B1A91893AD7709": {
                "t": "It'd appear that they have not yet returned.",
                "d": {
                    "cid": 0,
                    "eid": "2E2BDE4A085B634AD50B9EA716ECDD4A4D1E"
                }
            },
            "E203EB7C957A4742B949B6B116FF6FA3B790": {
                "t": "Let's just hope that their research was more fruitful than ours.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "026E87730D33C243C118AE7755CA5D3DAABA"
                }
            },
            "462DC19861A2324AC09A4D18FDE85A573B9A": {
                "t": "I wouldn't say it was completely useless though, right?",
                "d": {
                    "cid": 0,
                    "eid": "CB5D1FA1809A11453A4992050BE6E4084721"
                }
            },
            "4FA59E839A3BD64965898881E6AE4D11B025": {
                "t": "We now know that there is an Archdemon nearby! And that years ago, a researcher with an atypical love affair lived in this country.",
                "d": {
                    "cid": 0,
                    "eid": "0441FB383F6E6541FB8864493A5E62816FEB"
                }
            },
            "CA629FA560F33040612991A6238A3A531B48": {
                "t": "Exactly. Completely useless or redundant information.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "0D298CC25E18134DE26A69E7C20BBF0A32C8"
                }
            },
            "2CCF6FDA53795348EA2AE4A96BCA4EEE890B": {
                "t": "Don't ruin my enthusiasm like that now...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "097A89804B04A54A962A91E0CAAECFFCDDED"
                }
            },
            "33112C718F227542B76BBB22B5007203F291": {
                "t": "Are you alright, Rya? You seem... colder than usual.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "09B18DCC152E1445B21803C12E0AEE877094"
                }
            },
            "E96C0061059BE442A3698912F6DEDB98E2A3": {
                "t": "I feel uncomfortable in this country. That's all.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "CFBA6DEF938AA84350191C835C946B8F58E0"
                }
            },
            "7907497082E8F24A6B1B78A5C9C80A9724DB": {
                "t": "Shouldn't you be more concerned about your feelings, Faratras? This past month you have done nothing but hide your pain.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "A785BD7A5621A74F2A39BC87451E0A5F0666"
                }
            },
            "B9CDCD7F4551E445973BEDE4559CCF6DB64E": {
                "t": "... ... ...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "ADC30A6A3253174C6F6B62D560910B3EE120"
                }
            },
            "A03689322EBEF847BC2AFEC36C113A0753B5": {
                "t": "It's not like Rya to keep having these mood swings. What's up with her?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "6451C4591B24864AA05A73010F70949C4588"
                }
            },
            "6DD964C05DD95240E98B2255091BABE922A0": {
                "t": "If she treats Faratras poorly, this should play in my favor in winning her heart, but...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "4EB4345729DE8649B95B89E794762D150617"
                }
            },
            "E558361C40E0674C998ADE89A76E60A47300": {
                "t": "... I can't help but worry about our tactician.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "B464320D060BD748367B9D596513FDB41D88"
                }
            },
            "3AAE44EE7267964D2A5990F5A7F07C769680": {
                "t": "Heeey!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "730FAA05110FD544519899D2C9EEB1570505"
                }
            },
            "93A425911D51E443466868B2E8D8AB786427": {
                "t": "They're here.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "8E034D3E56AF2744F37B49C228DB84C0C830"
                }
            },
            "3DE531F1943F684E8D9BE4A4ED1F007BFE0F": {
                "t": "That much I could tell. What's happening? And where are the others?",
                "d": {
                    "cid": 0,
                    "eid": "0028977A116B1245D859AE536F4FADD070DF"
                }
            },
            "B3B8F03F7700984D41986F731C2DC362645F": {
                "t": "MAAAAN, for such a stunner, you have such a temper!",
                "d": {
                    "cid": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "eid": "609B6544799E694A477820B725CA94C4AFD5"
                }
            },
            "65380C484AEFA84EC9293B2648A5C21398C1": {
                "t": "Hey c'mon miss, would you please let us go?",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "24C2520116BB2542EF7977951D4A061B63D9"
                }
            },
            "221BC56B92F83149B6599916CCB2AC65BF58": {
                "t": "Come back here, you two!!",
                "d": {
                    "cid": "3CD19F896B1D21481949421516198BCE68C8",
                    "eid": "368C973A76175245672B90813DE59386CC03"
                }
            },
            "7E497E3E4D3F7548C21AD8B323695FA099B8": {
                "t": "She seems... quite angry.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "3448674B1B156644823B7465001FC3020400"
                }
            },
            "F03469962168484AA0486338548CB706D594": {
                "t": "And why are those two hiding behind me, by the way? Whelp!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "7A85C53B7FACB548EF1A97B39149B7E64AB1"
                }
            },
            "2F41173F4C2FE94B571869537D82B7A53B4A": {
                "t": "And who would you be?",
                "d": {
                    "eid": "D9974D4832D22043A0790658948B34B7DC54"
                }
            },
            "3DE0FC6A4BAB7745555822268E25245AA7FD": {
                "t": "Would you please explain what happened?",
                "d": {
                    "eid": "B8FC2FC94D3CD544397AD448A5CBD73A1CFE"
                }
            },
            "7AC48DF33D97E845EB2B2607E576F0B2C8FF": {
                "t": "Oh, yes. Punish me.",
                "d": {
                    "eid": "905CB99922D489462E698A304348BF676C7A"
                }
            },
            "A1374B6816E8B946176ACBB6CD43C4888998": {
                "t": "Okay, so maybe that wasn't the smartest move ever...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "0583FF223FDAC44C8108FFC16A02A364774C"
                }
            },
            "25D47FF643C55448DA1911F6BFE4EFAE4249": {
                "t": "We collected as much information as we could.\nLet's wait for the others.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "3175F518847501483F49765337EC220B3E42"
                }
            },
            "0AB4ADD912FA1748BD4A5C40F856B2C645B2": {
                "t": "She seemed normal until a few moments ago...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "91C89E4427D8634CB84977033DD789D9BBAB"
                }
            },
            "A0BA874050A8C542E4096A15352F70DEEFF3": {
                "t": "Umh... I think we have a problem!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "5739957498886744C449C048609E9A3ECD17"
                }
            },
            "3B01ADFB1F85884920095CA79FB1601C59A1": {
                "t": "Cristoph and Azurite are--",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "FF62F7DB65ADE5412F5BE6152A2BE1AF2EF4"
                }
            },
            "3838DF99446F894B6B1A748607C11ADA05A7": {
                "t": "What the...?",
                "d": {
                    "cid": 0,
                    "eid": "51DEE3B527B065489B5A7F88207D7E660AD9"
                }
            },
            "C7F9051487329645EF18A1F7441E904B3F39": {
                "t": "I can see the others, Cristoph. In my opinion we should just...",
                "d": {
                    "cid": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "eid": "4B2DF0F961D178419D0989E1EF280092CFB5"
                }
            },
            "E46185C09E68F947807AA69907B5EE0CA442": {
                "t": "You don't have to tell me twice, buddy. RUUUUN!!",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "672338F54C203846EB59DFB645B0FC30D325"
                }
            },
            "D08777DE700023409189DF50B481471160B3": {
                "t": "???",
                "d": {
                    "eid": "FAAE4787919C51423D8934181B538D4F43A8"
                }
            },
            "41425B196CE44643973AFD920879439F524F": {
                "t": "Ah! Come back here, you scoundrels!",
                "d": {
                    "cid": "3CD19F896B1D21481949421516198BCE68C8",
                    "eid": "D16DCED834914545EA4AEC27BA45F92B7E53"
                }
            },
            "23B30C7573F6374A093992F574D06018E9E9": {
                "t": "Umh, right! You're a Holy Knight! This is your time to shine!",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "D437BDFC7D2AE341C64864331EB9003DE0FF"
                }
            },
            "B09B24299F54434A956807E6209C64F64C3B": {
                "t": "That's genius! If we leave everything in your hands, we'll be safe!",
                "d": {
                    "cid": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "eid": "1D48455F166EB340986A3C462DB6894B1FEA"
                }
            },
            "57FC5BD6585BC9461B7B5EB3EE37D45BB7C6": {
                "t": "Huh... What's happening?",
                "d": {
                    "cid": 0,
                    "eid": "F0CC688D61C9B2427E3BA7851F8EC6773213"
                }
            },
            "53F479A556098140CE0B2E21727267EC888F": {
                "t": "Greetings... young lady...",
                "d": {
                    "cid": 0,
                    "eid": "B70E26CE1B58064EB15AE8F83288880A6B7D"
                }
            },
            "788BA79C12E4184B1E0ABA489FD724630C5B": {
                "t": "You! Step aside if you don't want to suffer the same fate as them!",
                "d": {
                    "cid": "3CD19F896B1D21481949421516198BCE68C8",
                    "eid": "6E3D277C94B9264293796230DB2479C4BE8B"
                }
            },
            "EA3D38734D87E547911AF494C63563330715": {
                "t": "Finally, someone who's polite and doesn't run away!",
                "d": {
                    "cid": "3CD19F896B1D21481949421516198BCE68C8",
                    "eid": "5D012ED57CD6E5494A3BC7F04001025569CA"
                }
            },
            "AE8D78D27838A64F637B39565108CB5F618E": {
                "t": "Tch, with extreme pleasure!",
                "d": {
                    "cid": "3CD19F896B1D21481949421516198BCE68C8",
                    "eid": "8E7AB59625A63547E52A3BF82C823DD1A1F9"
                }
            },
            "BC13F4113950F24F4118B9B405F5885601F0": {
                "t": "You. Are you another disgusting one like them? I hate you foreigners and your perversions!",
                "d": {
                    "cid": "3CD19F896B1D21481949421516198BCE68C8",
                    "eid": "BB11073D362CE343AD1BF5D4110FF804CADE"
                }
            },
            "3E1493932999C148E52873E2DF555468349A": {
                "t": "Sae'rah",
                "d": {
                    "eid": "C68CC2386DC5B24EC569352796B47F47BCCE"
                }
            },
            "C374730512D07242DB5903A118B6AF52863A": {
                "t": "The name's Sae'rah! Make sure to listen to the whole story!",
                "d": {
                    "cid": "3CD19F896B1D21481949421516198BCE68C8",
                    "eid": "C72EA1FE7E4427453908D6965741B375C0A1"
                }
            },
            "3BF89C982ADEC34C15182493592CE2FEAE48": {
                "t": "I listen to all of Sae'rah's complaints, and they're not too different from what I imagined.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "6418BBBC5385074EE2387DB2129D4C217AD9"
                }
            },
            "B1D5C2927C35B9481B3AF871FC5E3D0BCADB": {
                "t": "Sigh. Those two...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "A7DC13CC22C3214BB71AE53460CC7302FE42"
                }
            },
            "7749031275066342ED2BBB9994224E23A968": {
                "t": "So... yeah! These wretches were going around, approaching all the women in the citadel suspiciously.",
                "d": {
                    "cid": "3CD19F896B1D21481949421516198BCE68C8",
                    "eid": "24A888462A4B8144461A58D1EBF2B257406D"
                }
            },
            "E12945DF3B0C524FD96B0DE09C7EE02E2AD7": {
                "t": "MAAN! And what should I do? I see a nice lady, I try to talk to her!",
                "d": {
                    "cid": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "eid": "DF3241EC4B62544A7E1A9735960655D82952"
                }
            },
            "31403CFC5BB4F34BA759519057F11057EADE": {
                "t": "I tried to say it was inappropriate for Midbarnese customs, but you were far too... optimistic.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "363E29943A5C644CA02BD8B8E3CA47E01F49"
                }
            },
            "D9A52B006FA6544A7C2BD061C06231E57986": {
                "t": "It is my job to protect the city! And especially the WOMEN of the city!",
                "d": {
                    "cid": "3CD19F896B1D21481949421516198BCE68C8",
                    "eid": "9A8336585D6A334AAC8956C2BFDEE5541400"
                }
            },
            "765BA5780656384059599282CB6D6A5B6081": {
                "t": "I received a report regarding {SP:2}{C:1}a man{C:0} going around asking weird questions in Han'naje. Imagine my surprise when I found as many as two of 'em!",
                "d": {
                    "cid": "3CD19F896B1D21481949421516198BCE68C8",
                    "eid": "4AC1FE8D5F65774266883F83178AE68F461F"
                }
            },
            "4BBDF004498C87446A2ADA13C6F830AB620A": {
                "t": "About that...",
                "d": {
                    "eid": "B6C6BFCF36F0B344AD5B4C8778380AEFE410"
                }
            },
            "A39EA1B33ADF6549913834732283607A6C22": {
                "t": "Maybe they aren't the wrongdoers...",
                "d": {
                    "eid": "20355E374F3BC44A47786BA0C073A7EA9967"
                }
            },
            "D7B53F4D4307534A467BAB180A9648836074": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "6D67297029B9F040DC3BBD532B714F17170A"
                }
            },
            "4CE4BA4C5F9A0346202B2E67AD350D673B93": {
                "t": "Huh? What do you mean? These two definitely look suspicious.",
                "d": {
                    "cid": "3CD19F896B1D21481949421516198BCE68C8",
                    "eid": "9AB4F17C7D09C545AD990751463943761CB5"
                }
            },
            "62F255281E4A1243E91B78D1F87A07436810": {
                "t": "And as their comrades, you're definitely trying to shield them from their imminent execution.",
                "d": {
                    "cid": "3CD19F896B1D21481949421516198BCE68C8",
                    "eid": "A35B610F39067045C859F9C5FB88F3350EB9"
                }
            },
            "29A326412E6B7444C9484215732AA0C52E33": {
                "t": "E-Execution!? Please, Lord Valonja, save my soul!",
                "d": {
                    "cid": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "eid": "B3E555AD7DDFC542857B3C37C5D1B73E130F"
                }
            },
            "BB0ECC4F67910948DB0B4DA9C6AE1D3C787B": {
                "t": "... Or at least it's what I'd personally do. But our government is a bit too lenient at times. Unfortunately.",
                "d": {
                    "cid": "3CD19F896B1D21481949421516198BCE68C8",
                    "eid": "AACDA315263D474D9E1B27D40C32D469EC46"
                }
            },
            "A306D45B195A1149194B10B40DBA164C0AA8": {
                "t": "No punishment will be necessary, actually. As I said, these guys don't have anything to do with that report.",
                "d": {
                    "cid": 0,
                    "eid": "0C43CC10497AB745546BC687267A28AFE3BA"
                }
            },
            "F6E644CD31CF7346F42B62B60782FC2F3488": {
                "t": "We tell Sae'rah everything we know about the Archdemons and our mission...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "FF62E5A10141754BAD79D716AA8200EF1BAF"
                }
            },
            "BB2C0F496D115246680807672201BCF76FB7": {
                "t": "...and that suspicious man we met before, of course.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "31E5037675D9F9400E183CE2473967315184"
                }
            },
            "D2F3C83C3286D6460E79FFD66ADD358A91C9": {
                "t": "So... you were just searching for clues about this \"Archdemon\".",
                "d": {
                    "cid": "3CD19F896B1D21481949421516198BCE68C8",
                    "eid": "150E1E669791A4446E5B787495F304B09F9F"
                }
            },
            "8D3805905852E748BF8B91213373D410BFA6": {
                "t": "And the man you met in that house is the one who actually matches the description in my report.",
                "d": {
                    "cid": "3CD19F896B1D21481949421516198BCE68C8",
                    "eid": "5FB76F6918FEB54BB38854515558BE6DC134"
                }
            },
            "82D95B9D384A7347F26A9DF6CABB49060F6D": {
                "t": "Thank goodness... That means these two are no longer suspects, correct?",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "9012C43A52C4A643B18A0D02DADBEF58271D"
                }
            },
            "47C52D820BB1504651984DA55AF11A447CAD": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "4A2767E02C05744A957A9448342101CA4EB4"
                }
            },
            "0EA998CD4E6BD642125A1775572F6744C90E": {
                "t": "They may not be suspects, but they're so rude! If you were looking for information, you could have done so in a more modest way!",
                "d": {
                    "cid": "3CD19F896B1D21481949421516198BCE68C8",
                    "eid": "D77BC0F8820FB24557781DC46BEF4B1A919D"
                }
            },
            "1FD585286BCB3143CD38677740660EB3BC2C": {
                "t": "Aye! Forgive us, miss!!",
                "d": {
                    "cid": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "eid": "D6DA423B3DF4D34AFA49B2B5902CD217CF3F"
                }
            },
            "C72210DE1E1538446F18AEB7F954AEF560EC": {
                "t": "Tsk. I suppose there isn't much else I can do about it.",
                "d": {
                    "cid": "3CD19F896B1D21481949421516198BCE68C8",
                    "eid": "2F725E5784429842325B6946F27EC584872E"
                }
            },
            "E30133202160654B478B63B981FCF47D1D41": {
                "t": "And now I also have to resume the search for that suspect... It couldn't get any worse.",
                "d": {
                    "cid": "3CD19F896B1D21481949421516198BCE68C8",
                    "eid": "068C0B662BDC68403E6BEDF53287FDB2EFC7"
                }
            },
            "32C7DECA8C1C924FC27AA6B737BD26B0DC6C": {
                "t": "Any idea about his whereabouts?",
                "d": {
                    "eid": "F48FCD2023922945B83B70F48863BB47AD06"
                }
            },
            "5B9B98733647B44A609911360EBB67A8ABE8": {
                "t": "Can we help you?",
                "d": {
                    "eid": "330475060A49904F33297664795ED2C39184"
                }
            },
            "E8A4411157616148E7592B95857F7330D0A1": {
                "t": "I have a lead, actually.",
                "d": {
                    "cid": "3CD19F896B1D21481949421516198BCE68C8",
                    "eid": "51F74B002A7FA74E73391496959BED182B9E"
                }
            },
            "1125EE502B8E3248C52BBC80C5A84117F9CD": {
                "t": "Well, that's not a bad idea. If I'm right about where he went, I'm going to need some help...",
                "d": {
                    "cid": "3CD19F896B1D21481949421516198BCE68C8",
                    "eid": "0C00AC8834E9E64DB03B22B25CC1F11F7689"
                }
            },
            "0FC152F1651FE441B33A69B75691D6A42B49": {
                "t": "I didn't pay much attention to it at the time, but now that you've told me what he looked like, I remember seeing that man walk out the southern gate.",
                "d": {
                    "cid": "3CD19F896B1D21481949421516198BCE68C8",
                    "eid": "D8721DE87088F744DC2AA9F113C154DD15B7"
                }
            },
            "E10D526A45115347686BD2A0541C3CC4936A": {
                "t": "Sae'rah... I'm Faratras, nice to meet you.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "F6968B01315EC7493328DB4659346EC948B0"
                }
            },
            "DF9F9CD5060D23455E0B7997AF30888F2EAA": {
                "t": "Our goal is the same, we need to investigate that man. However, we are not familiar with the area.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "2561B16012E5F142205848A6AF42B53C6138"
                }
            },
            "ABD61CFF49DF64436C3A5D252D81ADE04ABB": {
                "t": "Would you mind lending us your support?",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "E31348324CEDB24454786BC38F254D0B9CD7"
                }
            },
            "8971EDBC9E6315437E8AB4F5FF77A8D103DD": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "E180859C5C60B4453268AC6134EB4B457A7C"
                }
            },
            "FBB08EEB56503749C778BD8973497EAB0C31": {
                "t": "Hah! A polite girl! You do have someone with some salt in their noggin in your group, then!",
                "d": {
                    "cid": "3CD19F896B1D21481949421516198BCE68C8",
                    "eid": "9F25F8E2172E9849DB5B6E084F42300CB781"
                }
            },
            "7391258A9A07B046F96B71253108DF9E7B9E": {
                "t": "Count me in! I don't have time to be particular about my teammates. I just need to get this task done.",
                "d": {
                    "cid": "3CD19F896B1D21481949421516198BCE68C8",
                    "eid": "50AA34A268D9A543FA5AAD9518ADAEE70F80"
                }
            },
            "F6AEF71135BF964A69988B29BF7CB9DA3D49": {
                "t": "A young woman with a distinct focus on pragmatism, I see. You and I are going to get along just fine.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "4093A00C11E5E645456BBCD497949F8BB71E"
                }
            },
            "DE0C43D61597254F0A287D24AEBFC12C6FD5": {
                "t": "I think so too. Welcome on board, Sae'rah.",
                "d": {
                    "cid": 0,
                    "eid": "FF88202128C1C347274999B880EA17C96846"
                }
            },
            "FA8759C239475641371B87F994491DBDF2F0": {
                "t": "I look forward to getting to know you better, kind ladies from afar.",
                "d": {
                    "cid": "3CD19F896B1D21481949421516198BCE68C8",
                    "eid": "564F501586990942191A5346CD1E8F7A0B40"
                }
            },
            "BA3098B36C9B9345842AE2418B00768B873F": {
                "t": "I'm surrounded by damsels with a temper... and they're all ignoring me!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "82679FB809E1E4439428927878C870B76CE4"
                }
            },
            "4B1146345B565445184A2105C43DEC4F6DD3": {
                "t": "Great. Let's head back to the encampment then.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "CD4080A7411FD74C1C183F326A1ACB649F63"
                }
            },
            "41D273275DFAF0444588B3828F67A94F62F6": {
                "t": "The desert is my second home. I will help you follow that man's trail.",
                "d": {
                    "cid": "3CD19F896B1D21481949421516198BCE68C8",
                    "eid": "2E2710A72BC33748F97A01B427CE5089739F"
                }
            },
            "A507B42A4F4DE444381B0F316E8A7E96888D": {
                "t": "We're counting on you.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "8BB5443E1380E444126B3903F0759247FAAE"
                }
            }
        },
        "commands": [
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "EF5F15C31F7F76465B8BB043CEC5E4BBA36C"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "FORCE SIDE MENU OFF?",
                        "index": 146,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "63C7C818937186436F89887549DBFFCF224B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "46EAACA0915D9440D859E0E54957D855F363"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E25415DF1761924D2649075979714BD38FF2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "25D47FF643C55448DA1911F6BFE4EFAE4249",
                        "defaultText": "가능한 한 많은 정보를 모았어.\n다른 사람들을 기다리자."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3175F518847501483F49765337EC220B3E42",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "5CF2D719080BB340E66B6EA27984CD524504"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "004A253D2E6D1540843A2671E908660F013F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            5
                        ]
                    }
                },
                "indent": 0,
                "uid": "2454B5A539AF11487A1AE8347B4869A65506"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "64BC03305879F0451B79D651DAA559F14912"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            900,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F3ACC1F57D446742F938D4F5AAEAF7F7D2E8"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 84
                },
                "indent": 0,
                "uid": "EF89D2957161A24D1A6ADDF01B19F51BC3F9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "03DEA4954ABD5648B72A16630CB12FEB0C7F",
                    "parameters": {
                        "values": [
                            10,
                            200,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D92722DC75A7564CD749B495B2E66A5F9184"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 96
                },
                "indent": 0,
                "uid": "62C0CCF49B7E774A7F6BA8C298969F9E09A6"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 54,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "719143414A832745044A0E758595821B0250"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "B0633D46544EB445A908EA6975E8A172A911"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "DD16E36579CE1142445BB034B8DC2D4ED58E"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "19CFF27948CBC54CC51960328277F037A54A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "07F1B4F346EE0049DF790C74E184517F4AF3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2B059120214E9546497B41F73CD3AF87534D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7B8E9A5158E8014FF899B6B1A91893AD7709",
                        "defaultText": "아직 돌아오지 않은 모양이군."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2E2BDE4A085B634AD50B9EA716ECDD4A4D1E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7116D1813068F44BF169613719FB63E2453B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0D8AF9B83FD6D744644993697DB0A8F01280"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6F47AFF3520CC6403A0BE6500C561F7334E3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E203EB7C957A4742B949B6B116FF6FA3B790",
                        "defaultText": "저들의 조사가 우리보다 더 성과가 있었기를 바랄 뿐이야."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "026E87730D33C243C118AE7755CA5D3DAABA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "155813E77AA2C24BDA3AF3831B4AC79A4CF3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E477E67E1109334D53286FD048CEBF566AC2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "462DC19861A2324AC09A4D18FDE85A573B9A",
                        "defaultText": "그래도 완전히 쓸모없지는 않았지?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CB5D1FA1809A11453A4992050BE6E4084721",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5BE5AA6634EBD84B0E79B3360785C78FC968"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4FA59E839A3BD64965898881E6AE4D11B025",
                        "defaultText": "이제 근처에 대악마가 있다는 걸 알잖아! 그리고 오래전\n특이한 연애를 한 연구원이 이 나라에 살았다는 것도."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0441FB383F6E6541FB8864493A5E62816FEB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "302F49AB724B814D4B2893D3900400B5FECF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "233FE68155F01440BB6A6942B1296F6A6EA5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CA629FA560F33040612991A6238A3A531B48",
                        "defaultText": "맞아. 완전히 쓸모없거나 이미 알고 있던 정보야."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0D298CC25E18134DE26A69E7C20BBF0A32C8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "793372B77BFCD64B9F19365535C159B534F2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4C368B247661D14F980B3F877B8510893195"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2CCF6FDA53795348EA2AE4A96BCA4EEE890B",
                        "defaultText": "내 열정을 그렇게 꺾지는 말아 줘..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "097A89804B04A54A962A91E0CAAECFFCDDED",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3FF4A9D35A60E54AD95ACBF6B8FCA5494EF7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AF995FAB9C93A04D642A6EE11A9CB4B95B22"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D71BAA896779F647DC3B0B66120DBC0FC20F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "33112C718F227542B76BBB22B5007203F291",
                        "defaultText": "괜찮아, 리아? 평소보다... 더 차가워 보여."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "09B18DCC152E1445B21803C12E0AEE877094",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AF5845095835E846625BD51382955CABEF59"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BB167EBB024459495B899308DD8C72F2B5EE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E96C0061059BE442A3698912F6DEDB98E2A3",
                        "defaultText": "이 나라에 있으면 불편해. 그게 다야."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CFBA6DEF938AA84350191C835C946B8F58E0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "46A6657C35BA30464C0888C4C7345E511DD7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7907497082E8F24A6B1B78A5C9C80A9724DB",
                        "defaultText": "네 감정이나 더 걱정해야 하는 것 아니야, 파라트라스?\n지난 한 달 내내 고통을 숨기기만 했잖아."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A785BD7A5621A74F2A39BC87451E0A5F0666",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5E38D7B8654FF94A2A7A0AC113C2EBC20A9D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "40C1B0242C10E84A6A1B5037FD9418254272"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B9CDCD7F4551E445973BEDE4559CCF6DB64E",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "ADC30A6A3253174C6F6B62D560910B3EE120",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "78DFAEB78DE1A2470A4A5C6280AF3A930638"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "871D1D511EA5234A988870C007AA3802922E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A03689322EBEF847BC2AFEC36C113A0753B5",
                        "defaultText": "리아답지 않게 감정 기복이 계속되네. 무슨 일이지?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6451C4591B24864AA05A73010F70949C4588",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E57959867930B34B9D585D90E5D92D3D48D2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0AB4ADD912FA1748BD4A5C40F856B2C645B2",
                        "defaultText": "불과 몇 분 전까지만 해도 평소 같았는데..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "91C89E4427D8634CB84977033DD789D9BBAB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0C72A4737D1667488B4BC6455EA6FE9BD7D2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "7249ACD474B43047891B2C42CE4422E2F2DC",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B1C072B68F381448F198517639E50881DE90"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D468D3DD056811441F888A18D226A003F4E9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2560B4898EB4204AEB1B1E57C9BA3BECF74C",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "1B2386425D06C840C38A233893505B3E72BE"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "BD82D74B5ED0134399898C8731DE5CE4F269"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "if fa x rya"
                },
                "indent": 2,
                "uid": "7173E3E121DAF442282A6EA84D583898804C",
                "expanded": true
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "if fa x nini"
                },
                "indent": 2,
                "uid": "D9A7412489CCB3411018B0658584959EAA23",
                "expanded": true
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6DD964C05DD95240E98B2255091BABE922A0",
                        "defaultText": "파라트라스를 나쁘게 대하면 그녀의 마음을 얻는 데\n내게 유리하겠지만..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "4EB4345729DE8649B95B89E794762D150617",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "C41EFE738353A14D923A16B5CE310FE58624"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E558361C40E0674C998ADE89A76E60A47300",
                        "defaultText": "...그래도 우리 전략가가 걱정되는 건 어쩔 수 없어."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "B464320D060BD748367B9D596513FDB41D88",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "E8A78BC81B18E14D924A03B11CEA06B7C5FB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "C943AC1A49D3B5402E4B31F84A8DAA596276"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5C56DFA59B0E1642BF3A86A2022E5AE0B1BC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3AAE44EE7267964D2A5990F5A7F07C769680",
                        "defaultText": "이봐아아!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C11B-4_line1414.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "730FAA05110FD544519899D2C9EEB1570505",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7D3445631CB1804F0F5A4AC13B3E676AA902"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2DD4E1D494D47347A25BFE85994952F65EC2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "93A425911D51E443466868B2E8D8AB786427",
                        "defaultText": "왔군."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Rya",
                        "name": "C11B-4_line15.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "8E034D3E56AF2744F37B49C228DB84C0C830",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "BE7742118494E64C708ABF090F545A60F609"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "D5C4A0C82DBEF8417129CA228397BE6ACDB9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D8752681137663459A5BC29168A59A326772"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "DC5BBD146ACCE24BA97A75C7F20ACEB95C49",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "46F8712F73F96549F218F74392DAFD144856"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            5,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2C82C3DF54FC3942467AF527F8CE951EC1C2"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "close;reopen. Focus on the other group"
                },
                "indent": 0,
                "uid": "3E07597F8A21014C887ACB938E00F2507706",
                "expanded": true
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 90
                },
                "indent": 0,
                "uid": "62BCDCF9885EE54B453A3151FB6D51BEA500"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "A5CD3C3B352843410338B9731325131A7FD8"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "07EA9C61256C994DAF9B12460FF61A641454"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "duration": 33,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "05644F6D7900094DDE388A050BF72F90B13E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8EC927E92A66F043834B95853C3696F8D1FE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "146CC3C84CA72048187AE6F7B407F466AD65"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A0BA874050A8C542E4096A15352F70DEEFF3",
                        "defaultText": "음... 문제가 생긴 것 같아!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C11B-4_line16.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "5739957498886744C449C048609E9A3ECD17",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CCABE8D245C5A445947937F157AF92DF27F2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9875853E17712347C11919F6647707E4EEB5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3DE531F1943F684E8D9BE4A4ED1F007BFE0F",
                        "defaultText": "그 정도는 알겠어. 무슨 일이지? 다른 사람들은 어디 있고?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C11B-4_line17.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "0028977A116B1245D859AE536F4FADD070DF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "32F00CE62B8CC24B6A7A1E323D5CBC428968"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            6,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A73762E129067344E32AD8F4D09419450DFB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            14,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8DF299DC7FC4C3477D4B3F0384F89E064BCA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "05BCFED62AF4744FAC699324D736BC6805C4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3B01ADFB1F85884920095CA79FB1601C59A1",
                        "defaultText": "크리스토프와 아주라이트가--"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C11B-4_line18.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "FF62F7DB65ADE5412F5BE6152A2BE1AF2EF4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4B5FD35A638EF84E5F395BE58A2F41E389D0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CA654C6739936843485AC223A4793981A9AD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B3B8F03F7700984D41986F731C2DC362645F",
                        "defaultText": "이봐아, 그렇게 예쁜데 성질은 정말 대단하네!"
                    },
                    "position": 0,
                    "characterId": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Azurite",
                        "name": "C11B-4_line19.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "609B6544799E694A477820B725CA94C4AFD5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2681B33721525143198915044E66CC5B2F99"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "915EC54C8586C74CCF08418150E19B146963"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "65380C484AEFA84EC9293B2648A5C21398C1",
                        "defaultText": "이봐요, 아가씨. 제발 좀 보내 주실래요?"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cristoph",
                        "name": "C11B-4_line20.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "24C2520116BB2542EF7977951D4A061B63D9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "09B13D747813D54C2E6B4A85E200141164A4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EF327B803275E14E2928420478AB5A602CAF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3838DF99446F894B6B1A748607C11ADA05A7",
                        "defaultText": "뭐야...?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C11B-4_line21.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "51DEE3B527B065489B5A7F88207D7E660AD9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "247F41CC5A636347D52A78649F6A4BB82C9A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7177BA332C7D8343F129F7336F4D0D78FEBA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C7F9051487329645EF18A1F7441E904B3F39",
                        "defaultText": "다른 사람들이 보여, 크리스토프. 내 생각에는 그냥..."
                    },
                    "position": 0,
                    "characterId": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Azurite",
                        "name": "C11B-4_line22.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "4B2DF0F961D178419D0989E1EF280092CFB5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0C4093CB65D9744A9279AB850A1499091A4A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FF27FBE01688F5496A3812B7322AC28B36A1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E46185C09E68F947807AA69907B5EE0CA442",
                        "defaultText": "두 번 말할 필요도 없어, 친구. 도망쳐어어!!"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cristoph",
                        "name": "C11B-4_line23.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "672338F54C203846EB59DFB645B0FC30D325",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CC2085906D4E4948898870C1053A89948EF7"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "D08777DE700023409189DF50B481471160B3",
                        "defaultText": "???"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "FAAE4787919C51423D8934181B538D4F43A8",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "3CD19F896B1D21481949421516198BCE68C8",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Sae'rah"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "63A7C64A64B0A045C72B8B94B7718069AE76"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "3CD19F896B1D21481949421516198BCE68C8",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CB77EEE222F6B34803281212DC2139C08E3E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "41425B196CE44643973AFD920879439F524F",
                        "defaultText": "아! 거기 서, 이 악당들아!"
                    },
                    "position": 0,
                    "characterId": "3CD19F896B1D21481949421516198BCE68C8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "C11B-4_line24.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "D16DCED834914545EA4AEC27BA45F92B7E53",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "F2437C07543D3445132A28985485CBF3CF73"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0B7F27006073E34901894B07FD4BFF7DB8B5"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "duration": 30,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "78674AC82097584F503BB0F7114595BB16DF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "601965023B979749E05A20B15B0848CFE086",
                    "parameters": {
                        "values": [
                            0,
                            1,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "FE20608D654E6842153A1D982368C3DA041C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1B3DE48E1D83C34F267855A28DEA6164DEFC"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "46632A2D3CFE604A6C28CDB2D687D2B95102"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 13.2,
                    "waitForCompletion": 1,
                    "range": {
                        "y": 18,
                        "x": 5
                    },
                    "speed": 180,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "372F5D183403C14BC44BB9E73AA116E1DEEE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "4B8E9FF0167D914046390F75687D84636674",
                    "parameters": {
                        "values": [
                            9,
                            1500,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "AADFB59A55DE25465A9909A42FA8A92B2726"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 13.2,
                    "waitForCompletion": 1,
                    "range": {
                        "y": 18,
                        "x": 5
                    },
                    "speed": 180,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "2C1C58C11D6FC244D808CCE6727FB77C9EFC"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "7FACAA5B3075734D815B8E21E8867E748C38"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "model": {
                        "name": "Azurite.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 800,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 752,
                        "y": 38,
                        "zoom": {
                            "x": 1.6,
                            "y": 1.6,
                            "d": 1.6
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 33,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "E2223E4030F2B64068890B47B24035F9A5B2",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "426221C1892545468B19B81767C711B345C4"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "298450C046F49547416BE4C0209EE04868AF"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "duration": 33,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "B5EEAD4C7C9AF147546B48B079E200E18936"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "they appear"
                },
                "indent": 0,
                "uid": "936659AB56C82745E26B6241DD8F17B6A5A2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "987E21D87E19C24D949A3F46113DE1474B59"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1BE63D413EF6074A7F7ACEB754A8D6DB0D3C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "23B30C7573F6374A093992F574D06018E9E9",
                        "defaultText": "음, 맞다! 당신은 성기사잖아요! 활약할 때예요!"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cristoph",
                        "name": "C11B-4_line25.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "D437BDFC7D2AE341C64864331EB9003DE0FF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FCB24C0652AFB849644B6CE3F619EFEBB48A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "59353FC03298C74DDC8B30E353052049D449"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B09B24299F54434A956807E6209C64F64C3B",
                        "defaultText": "천재적인 생각이야! 전부 맡기면 우린 안전하겠지!"
                    },
                    "position": 0,
                    "characterId": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Azurite",
                        "name": "C11B-4_line26.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "1D48455F166EB340986A3C462DB6894B1FEA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D0DACE9E1D930843C58A9554E08F7BAFD9F7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "136E92CC4DC3B645A749F1C40DAB4F3D753B",
                    "parameters": {
                        "values": [
                            9,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AFC1DA2627B2B54905481717D2E3CB83C203"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "3CD19F896B1D21481949421516198BCE68C8",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1534CF1220AB074FCC0B4910AB64415F7008"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "221BC56B92F83149B6599916CCB2AC65BF58",
                        "defaultText": "너희 둘, 거기 서!!"
                    },
                    "position": 0,
                    "characterId": "3CD19F896B1D21481949421516198BCE68C8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "C11B-4_line27.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "368C973A76175245672B90813DE59386CC03",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DB9149A2683565462C39F8055FC1B49D8437"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AC0138455076574B4C7B30B6B0B0C1192A1C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "57FC5BD6585BC9461B7B5EB3EE37D45BB7C6",
                        "defaultText": "어... 무슨 일이지?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C11B-4_line28.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "F0CC688D61C9B2427E3BA7851F8EC6773213",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "C666149B04CC324A444BEC43D480164866CF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2883DBA108E43145F51ABC9693811B549979"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "DEDABCCC6A8D174F0588CF52866FE829909E"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Sae'rah appears"
                },
                "indent": 0,
                "uid": "BE468FC5294D2647CA39D3D8DFCFB4D59CAD",
                "expanded": true
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "duration": 27,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "162065396F9B1546D68A2995655EB524EED2"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "duration": 27,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "FAD122C75F2A324BD18AE027A021C7E3D713"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 13.2,
                    "waitForCompletion": 1,
                    "range": {
                        "y": 18,
                        "x": 5
                    },
                    "speed": 180,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "09D7CE647F5B674E4F1B8CF5A697103DD150"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "4B8E9FF0167D914046390F75687D84636674",
                    "parameters": {
                        "values": [
                            9,
                            1500,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "90F15B5A7AD13243CE38BFA27AB15D863251"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 13.2,
                    "waitForCompletion": 1,
                    "range": {
                        "y": 18,
                        "x": 5
                    },
                    "speed": 180,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "7202683E5A556046DC4A53856FD09D786A42"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "B4666B5667A856448E19FE844BB7131163B0"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "3CD19F896B1D21481949421516198BCE68C8",
                    "model": {
                        "name": "sae.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 800,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 205,
                        "y": -16,
                        "zoom": {
                            "x": 1.8,
                            "y": 1.8,
                            "d": 1.8
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 36,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "CAC1B89516CA874EB05A0791FCD51401C5EF",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "3CD19F896B1D21481949421516198BCE68C8",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "28545E3079A5824AD91BCD621C977B09B0F3"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 66
                },
                "indent": 0,
                "uid": "72D9F7DD3C62F244CD6A7D463F637BD18413"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0057B46777AC3546F56B7018F969F3D19965"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FE4F120520EA424A144B3894ECC8E735452F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "53F479A556098140CE0B2E21727267EC888F",
                        "defaultText": "안녕하십니까... 아가씨..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C11B-4_line29.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "B70E26CE1B58064EB15AE8F83288880A6B7D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2F0A19446DEAC1481D581458CED99461B50E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "41024B0888254243AD693F4269ECAFD47F16"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7E497E3E4D3F7548C21AD8B323695FA099B8",
                        "defaultText": "상당히... 화가 난 것 같아."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3448674B1B156644823B7465001FC3020400",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4F3941D354C954461038DFD2A76587945936"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F03469962168484AA0486338548CB706D594",
                        "defaultText": "그런데 저 둘은 왜 내 뒤에 숨는 거야? 이런!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7A85C53B7FACB548EF1A97B39149B7E64AB1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C201F6C537EF4149697BABD2FB113B8E6865"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "3CD19F896B1D21481949421516198BCE68C8",
                            7
                        ]
                    }
                },
                "indent": 0,
                "uid": "A72435D588F42345A8395EE80A777FCE16E0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "3CD19F896B1D21481949421516198BCE68C8",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AC8C208186DE6846B95B21874D219B6DD755"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "788BA79C12E4184B1E0ABA489FD724630C5B",
                        "defaultText": "너! 같은 꼴이 되기 싫으면 비켜!"
                    },
                    "position": 0,
                    "characterId": "3CD19F896B1D21481949421516198BCE68C8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "C11B-4_line32.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "6E3D277C94B9264293796230DB2479C4BE8B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "D84F0E753736E7496E699D172BB794188093"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "2F41173F4C2FE94B571869537D82B7A53B4A",
                        "defaultText": "그리고 당신은 누구일까요?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D9974D4832D22043A0790658948B34B7DC54",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "3DE0FC6A4BAB7745555822268E25245AA7FD",
                        "defaultText": "무슨 일이 일어났는지 설명해 주시겠어요?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B8FC2FC94D3CD544397AD448A5CBD73A1CFE",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "7AC48DF33D97E845EB2B2607E576F0B2C8FF",
                        "defaultText": "아, 그렇죠.나를 처벌하십시오."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "905CB99922D489462E698A304348BF676C7A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "who",
                            "explain",
                            "punish",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "75E1DE4C68A39441893BC527A8BDA34723E3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A597203734FCB14F677937382BBC11F8D037"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "who"
                },
                "indent": 0,
                "uid": "E863CF132A1796485068FA236D399B4A6E9E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "3CD19F896B1D21481949421516198BCE68C8",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "497EFE0F5888664B933A9C856DE8D741AB90"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EA3D38734D87E547911AF494C63563330715",
                        "defaultText": "드디어 예의 바르고 도망치지 않는 사람이 있네!"
                    },
                    "position": 0,
                    "characterId": "3CD19F896B1D21481949421516198BCE68C8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "C11B-4_line36.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "5D012ED57CD6E5494A3BC7F04001025569CA",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after choice",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "39F5D6A4548A734A59187742781BCADD3E99"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "explain"
                },
                "indent": 0,
                "uid": "ED42FA640058354F025BCFF778FD347B4870"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "3CD19F896B1D21481949421516198BCE68C8",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "769FDB229F0FF145204A31B1D0F31796FCD8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AE8D78D27838A64F637B39565108CB5F618E",
                        "defaultText": "쳇, 기꺼이 비켜 주지!"
                    },
                    "position": 0,
                    "characterId": "3CD19F896B1D21481949421516198BCE68C8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "C11B-4_line37.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "8E7AB59625A63547E52A3BF82C823DD1A1F9",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after choice",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "9816122C3B73B347467990908A5D6EC66DE1"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "punish"
                },
                "indent": 0,
                "uid": "487B3AD25AF1A2463F1AAA57F82F45F1590E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "3CD19F896B1D21481949421516198BCE68C8",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3507B6263115334D0C492349A9632BC97AFA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BC13F4113950F24F4118B9B405F5885601F0",
                        "defaultText": "너. 저들과 같은 역겨운 인간이야?\n난 외지인과 그 변태 같은 취향이 싫어!"
                    },
                    "position": 0,
                    "characterId": "3CD19F896B1D21481949421516198BCE68C8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "C11B-4_line38.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "BB11073D362CE343AD1BF5D4110FF804CADE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EE07B061947F864A7E3888D515BBCF3B1522"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "-sanity +sarc"
                },
                "indent": 0,
                "uid": "9BBF490F0BF82844002A60A25E775460871E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "21D506806A1C914CB918E4C2791E0ACC16A2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A1374B6816E8B946176ACBB6CD43C4888998",
                        "defaultText": "좋아, 어쩌면 최선의 선택은 아니었을지도..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0583FF223FDAC44C8108FFC16A02A364774C",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after choice"
                },
                "indent": 0,
                "uid": "37BDBE705D9B64455E2ABEB1483488CEC20F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0AE0389B88256741BB794BD329AA5B02E23C"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "3E1493932999C148E52873E2DF555468349A",
                        "defaultText": "사에라"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C68CC2386DC5B24EC569352796B47F47BCCE",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "3CD19F896B1D21481949421516198BCE68C8",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Sae'rah"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "EC0E0F2B6A9C33440D49C382CC48AC362413"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "3CD19F896B1D21481949421516198BCE68C8",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "21A3C2DE4026A7475A6B19E5B6BCB867023A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "3CD19F896B1D21481949421516198BCE68C8",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "01ADAC0F9CA2E74AAB3BA2015AF97609E2E9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C374730512D07242DB5903A118B6AF52863A",
                        "defaultText": "내 이름은 사에라야! 이야기 전부를 똑똑히 들어!"
                    },
                    "position": 0,
                    "characterId": "3CD19F896B1D21481949421516198BCE68C8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "C11B-4_line40.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "C72EA1FE7E4427453908D6965741B375C0A1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "F71F50BD0C50804FED19FF1813FFE7065061"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "F8461BC280DD38488E18F91941CB819F3B85"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0A3E8B2410D99347735B863351EB563EB5B3"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 54
                },
                "indent": 0,
                "uid": "076D51DB0E29B24499799068794E2D361FC1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8F53EA026870F4499D29E8243EF07895B8D1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            900,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "438CF46D7C335741603A9510FE994B77D15C"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "B271D33E35DED749365901949AA0F464ADEC"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "end of voiced lines"
                },
                "indent": 0,
                "uid": "2F6BA66F34544844464866A9A9B0B49CDF89",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "195D0F6471AC72438C193490F241D7D658A6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0581E34437DA474E1A2A967443AAD15EFDD8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3BF89C982ADEC34C15182493592CE2FEAE48",
                        "defaultText": "사에라의 불평을 모두 들었다.\n내가 상상했던 것과 크게 다르지 않았다."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6418BBBC5385074EE2387DB2129D4C217AD9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "0F64E45F62BCD74160596985A1744DEE4D32"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "500027EB1989F0417B3ADAE668A67B153560"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "AA2A3C246E2A6949F489F4E4BF9F6E68DA5C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "03DEA4954ABD5648B72A16630CB12FEB0C7F",
                    "parameters": {
                        "values": [
                            5,
                            200,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "726A1A7B859993493949B8A7CE0F981FD2FA"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 84
                },
                "indent": 0,
                "uid": "137583222F8A474D8C4841C180AC9C41ACEE"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 54,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "61C29B102921404B4728F1561ED06C9434A1"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 54
                },
                "indent": 0,
                "uid": "976250365D1C3043CB387CF5B13ED621E51E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6DED3EAD51BEC147C69B7DE9E6503E98B189"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "64E205EB85C9014F4C49FBB6716862268615"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B1D5C2927C35B9481B3AF871FC5E3D0BCADB",
                        "defaultText": "하아. 저 두 사람..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A7DC13CC22C3214BB71AE53460CC7302FE42",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F79D1DEF0B9F0443CB3ADFB27BF227477AAA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "9CAC19643E6F654C2C8942852CFEE75B8AE4"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0822EAD71687D241341AF5B42A7414C777CA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "3CD19F896B1D21481949421516198BCE68C8",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1EE9CBEA80BB27477969CA544A7DC4B6C266"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7749031275066342ED2BBB9994224E23A968",
                        "defaultText": "그러니까... 그래! 저 악당들이 성채의 여자들에게\n수상하게 접근하고 다녔다고."
                    },
                    "position": 0,
                    "characterId": "3CD19F896B1D21481949421516198BCE68C8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "24A888462A4B8144461A58D1EBF2B257406D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "846B67930A656346698AD874CF6CFB780178"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A5A1255E7D67D148678804A1D97999F3B3D2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "8B668D3E5D6BC440D4795D58A740CE655D73"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "49FD85C66DD8204C79299D6720F339CCB196"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E12945DF3B0C524FD96B0DE09C7EE02E2AD7",
                        "defaultText": "이봐! 예쁜 아가씨가 보이면 말을 걸어 봐야지!"
                    },
                    "position": 0,
                    "characterId": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DF3241EC4B62544A7E1A9735960655D82952",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2C89CF77538D524BE44962261AF86B6F23A9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DCC68F6B3CBC5141C08A328202FA76232781"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "72CA34E64F6A194F341B3274C54B63E05E4E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A7F2ABE77754B141102BCF48CA89120BB310"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "3885F0DE90FCD14ED4481866EF6A63BAEF8F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "26093E0A265D024D283A20150BB394D21BD1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "31403CFC5BB4F34BA759519057F11057EADE",
                        "defaultText": "미드바르인의 관습에는 맞지 않는다고 말했지만\n넌 지나치게... 낙관적이었어."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "363E29943A5C644CA02BD8B8E3CA47E01F49",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "214A36024DA1B646371B739898EEAD2D660F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "3CD19F896B1D21481949421516198BCE68C8",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4DAEBF012261964D3C78EE012B5A9807B5AA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D9A52B006FA6544A7C2BD061C06231E57986",
                        "defaultText": "도시를 지키는 게 내 일이야! 특히 도시의 여자들을!"
                    },
                    "position": 0,
                    "characterId": "3CD19F896B1D21481949421516198BCE68C8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9A8336585D6A334AAC8956C2BFDEE5541400",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C647BA3361AE5247F83A7C14EB382B89EC55"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "3CD19F896B1D21481949421516198BCE68C8",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "78591C4099065043C5599C637889C5BD1AAE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "765BA5780656384059599282CB6D6A5B6081",
                        "defaultText": "한나제에서 이상한 질문을 하고 다니는 {SP:2}{C:1}남자{C:0}에 관한\n신고를 받았어. 두 명이나 찾았을 때 얼마나 놀랐겠어!"
                    },
                    "position": 0,
                    "characterId": "3CD19F896B1D21481949421516198BCE68C8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4AC1FE8D5F65774266883F83178AE68F461F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "7BEAC4167BB8344BCB9961C2CF9637147146"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "4BBDF004498C87446A2ADA13C6F830AB620A",
                        "defaultText": "그 얘긴데..."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B6C6BFCF36F0B344AD5B4C8778380AEFE410",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "A39EA1B33ADF6549913834732283607A6C22",
                        "defaultText": "어쩌면 그 사람들이 범인은 아닐 수도 있겠네요..."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "20355E374F3BC44A47786BA0C073A7EA9967",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "same",
                            "same",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "3F96AF9B120B56431288E0A728AE6B432409"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "DDC95F7A069B5541CE193824579D95E45219"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "same"
                },
                "indent": 0,
                "uid": "934F9745062D6342C14A1EC49094AAD41700"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "3CD19F896B1D21481949421516198BCE68C8",
                            7
                        ]
                    }
                },
                "indent": 0,
                "uid": "3D8E4B623D5F4441D29BF16567CF2003CC8D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "28B77CEF1993D34029494BC88ACCC0D43685"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D7B53F4D4307534A467BAB180A9648836074",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Saerah_line3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6D67297029B9F040DC3BBD532B714F17170A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "947DE98646112843D41AAFB7B3A725820961"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "3CD19F896B1D21481949421516198BCE68C8",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D8B58EDE102CB14545494485D8B172538B4D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4CE4BA4C5F9A0346202B2E67AD350D673B93",
                        "defaultText": "뭐? 무슨 말이야? 이 둘은 분명 수상해 보이는데."
                    },
                    "position": 0,
                    "characterId": "3CD19F896B1D21481949421516198BCE68C8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9AB4F17C7D09C545AD990751463943761CB5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DEEF11BA151C024B5D4983860E8B260D2545"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "62F255281E4A1243E91B78D1F87A07436810",
                        "defaultText": "그리고 동료인 너희는 곧 처형될 저들을 감싸려는 게 분명해."
                    },
                    "position": 0,
                    "characterId": "3CD19F896B1D21481949421516198BCE68C8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A35B610F39067045C859F9C5FB88F3350EB9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AFCC9F3B6378654B6F69DC98F09A754282CF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "11E51FF45F23244ACB5B66B783A4619C9B5F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "2327C82C41EFB24F274A2BE06A3AB660CB46"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8825460F5925E740DB4B9B767128D287C71A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "29A326412E6B7444C9484215732AA0C52E33",
                        "defaultText": "처, 처형이라고!? 발론자 님, 제 영혼을 구해 주소서!"
                    },
                    "position": 0,
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B3E555AD7DDFC542857B3C37C5D1B73E130F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "07349549774C6440A9087F3786238B79804F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "3CD19F896B1D21481949421516198BCE68C8",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C639EFBC692A614FB598B2D368CC3B0FA4E4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BB0ECC4F67910948DB0B4DA9C6AE1D3C787B",
                        "defaultText": "...적어도 나라면 그렇게 했겠지.\n우리 정부는 가끔 너무 관대해서 문제야. 유감스럽게도."
                    },
                    "position": 0,
                    "characterId": "3CD19F896B1D21481949421516198BCE68C8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AACDA315263D474D9E1B27D40C32D469EC46",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1E00D3CB22F7334EEE0AA9316590492715DA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "23DF9CA84ED0034653389191711F1902AA40"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A306D45B195A1149194B10B40DBA164C0AA8",
                        "defaultText": "사실 처벌은 필요 없어. 말했듯이 이 사람들은\n그 신고와 아무 관련이 없으니까."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0C43CC10497AB745546BC687267A28AFE3BA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "DF83CBA5389CF04EE97B5B267D765B3891B2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "770014BB815481484B1883C77CB4E462468D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 54
                },
                "indent": 0,
                "uid": "65FC84C788FF1249DB88D3A80B7AB7C080FA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            900,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8147A341455C074E309BEA87322E8BBD79DB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "3CD19F896B1D21481949421516198BCE68C8",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "085EDE435A9E324CF37AD341F8A61EE357DA"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "622E6F416015924F59184195B8DAB1B5A25B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "670E12949EF9E14DD68B4F63045810DA4886"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "547AADFA6743484DEA28447139929A5CE635"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F6E644CD31CF7346F42B62B60782FC2F3488",
                        "defaultText": "우리는 대악마와 임무에 관해 아는 것을 사에라에게 모두 말했다..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FF62E5A10141754BAD79D716AA8200EF1BAF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "47EEB3EE6B00C348AD8B6A04B43887E467D6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BB2C0F496D115246680807672201BCF76FB7",
                        "defaultText": "...물론 전에 만난 수상한 남자에 관해서도."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "31E5037675D9F9400E183CE2473967315184",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "D9092051403DD343123B2554C5FA84DB3D2A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "38FBA6466B097748075BD520817F74EB0EC2"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "5EBB2F787C2011434688B722757BE627FCCE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "03DEA4954ABD5648B72A16630CB12FEB0C7F",
                    "parameters": {
                        "values": [
                            5,
                            200,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "118E5C47404F0744582AFB4697081E3DCFDF"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 84
                },
                "indent": 0,
                "uid": "38298CA39996844DFB6B6DA2BD4343942499"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 54,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "43B38E035B98034AE1693012982BBC551914"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "A6D30E6E236E244E522816E3EA1CE05796BE"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "black screen, text of \"You tell Sae'rah about the mysterious man you met before.\""
                },
                "indent": 0,
                "uid": "5BB7B2C1703F5041DF9BB495ECC38F01D6DB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "63974FC3200726401B185EA97B9A4D2B3027"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "3CD19F896B1D21481949421516198BCE68C8",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "559B39061940D743D09BAFD3272BF64B0B00"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D2F3C83C3286D6460E79FFD66ADD358A91C9",
                        "defaultText": "그러니까... 너희는 그 “대악마”의 단서를 찾던 것뿐이구나."
                    },
                    "position": 0,
                    "characterId": "3CD19F896B1D21481949421516198BCE68C8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "150E1E669791A4446E5B787495F304B09F9F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "58530AEA9592844703397FE13BC293686188"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8D3805905852E748BF8B91213373D410BFA6",
                        "defaultText": "그 집에서 만난 남자가 내 신고의 인상착의와 정확히 일치해."
                    },
                    "position": 0,
                    "characterId": "3CD19F896B1D21481949421516198BCE68C8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5FB76F6918FEB54BB38854515558BE6DC134",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7EA58E5308F0F34E191923142583BF0C76C5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "15F9576C8F796048BA49DAB2F1188AD9CD67"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7DC8A8411C75E5494548DC67A922B21748BE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "82D95B9D384A7347F26A9DF6CABB49060F6D",
                        "defaultText": "다행이군... 그럼 이 둘은 이제 용의자가 아닌 거지?"
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9012C43A52C4A643B18A0D02DADBEF58271D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "765AD5EB7746B34DDA4A05E94E616CB2B78D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "3CD19F896B1D21481949421516198BCE68C8",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "12E35467196285433B48B075BCF94425ED60"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "BF9ED3CA101B124DFE2B4B07892E65577662"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "47C52D820BB1504651984DA55AF11A447CAD",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Saerah_line1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4A2767E02C05744A957A9448342101CA4EB4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "8454CD3303F4784A0859717782D09B0AE295"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "3CD19F896B1D21481949421516198BCE68C8",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FA2C0FE445B7A44CA928C8820D4B9F2C98AD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0EA998CD4E6BD642125A1775572F6744C90E",
                        "defaultText": "용의자는 아니어도 너무 무례해! 정보를 찾는 거였다면\n좀 더 점잖게 할 수도 있었잖아!"
                    },
                    "position": 0,
                    "characterId": "3CD19F896B1D21481949421516198BCE68C8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D77BC0F8820FB24557781DC46BEF4B1A919D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9F57C146518FE542805BA8D7895BA1EE248B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "314814B07444E244BF493A2131466891AD4D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "291080847D7E9249244873F95123C76E8464"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6B56AA80859B574FF75B81744FABF42F83A6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1FD585286BCB3143CD38677740660EB3BC2C",
                        "defaultText": "네! 용서해 주십시오, 아가씨!!"
                    },
                    "position": 0,
                    "characterId": "6F4C8FF19D5B764D603A33744FB11F2547C7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D6DA423B3DF4D34AFA49B2B5902CD217CF3F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B1CB8CB779FC884978898DD4DF43E25DEFCA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "3CD19F896B1D21481949421516198BCE68C8",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FE6F86F47D038149D1296901E56EC826E6DB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C72210DE1E1538446F18AEB7F954AEF560EC",
                        "defaultText": "쳇. 이제 내가 더 할 수 있는 건 별로 없겠네."
                    },
                    "position": 0,
                    "characterId": "3CD19F896B1D21481949421516198BCE68C8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2F725E5784429842325B6946F27EC584872E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "13F005C23B63A1476F48558605EF01500C80"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "3CD19F896B1D21481949421516198BCE68C8",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "644791AE5FBA05485E293C461DF960190D17"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "3CD19F896B1D21481949421516198BCE68C8",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B7EEB4BD1D26A1457669D1414D85BD579D2D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E30133202160654B478B63B981FCF47D1D41",
                        "defaultText": "이제 그 용의자 수색도 다시 시작해야 해...\n이보다 나쁠 수는 없겠어."
                    },
                    "position": 0,
                    "characterId": "3CD19F896B1D21481949421516198BCE68C8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "068C0B662BDC68403E6BEDF53287FDB2EFC7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "94A7E1CB13A8364A4A7B97193A3D0397E0F6"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "32C7DECA8C1C924FC27AA6B737BD26B0DC6C",
                        "defaultText": "그의 행방에 대해 아는 게 있나요?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F48FCD2023922945B83B70F48863BB47AD06",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "5B9B98733647B44A609911360EBB67A8ABE8",
                        "defaultText": "도와드릴까요?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "330475060A49904F33297664795ED2C39184",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "idea",
                            "help",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "3B9FFBE73E54934FDB288E555FF88805DCE7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "FF3CAC4B9585A24E6C7AB1A7B2125DE3ADD0"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "idea"
                },
                "indent": 0,
                "uid": "A823F3D16167054844294033353FE1B0600B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "3CD19F896B1D21481949421516198BCE68C8",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D20C89E6420A9345BB3B3EC6E944BB74BEA2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E8A4411157616148E7592B95857F7330D0A1",
                        "defaultText": "사실 단서가 있어."
                    },
                    "position": 0,
                    "characterId": "3CD19F896B1D21481949421516198BCE68C8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "51F74B002A7FA74E73391496959BED182B9E",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after final",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "903EA7CD6078174E6D7910005E888B9F9C20"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "help"
                },
                "indent": 0,
                "uid": "EBA5EABD3750D6488E0AAF19EFA617B01C23"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "3CD19F896B1D21481949421516198BCE68C8",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DBFD02C02C031142660883F4A742D2C97FCD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1125EE502B8E3248C52BBC80C5A84117F9CD",
                        "defaultText": "나쁘지 않은 생각이네. 내가 짐작한 곳으로 갔다면\n도움이 좀 필요할 테니까..."
                    },
                    "position": 0,
                    "characterId": "3CD19F896B1D21481949421516198BCE68C8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0C00AC8834E9E64DB03B22B25CC1F11F7689",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after final"
                },
                "indent": 0,
                "uid": "0C5D09F0848D5943E35851158D91DBF4161F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "698F8354421A0247F85A3FB30D1DF37BE51C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0FC152F1651FE441B33A69B75691D6A42B49",
                        "defaultText": "그때는 신경 쓰지 않았지만 인상착의를 듣고 보니 기억나.\n그 남자가 남쪽 문으로 나가는 걸 봤어."
                    },
                    "position": 0,
                    "characterId": "3CD19F896B1D21481949421516198BCE68C8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D8721DE87088F744DC2AA9F113C154DD15B7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "346F9B3E5208B846E3582119715C078A2FBC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "7BF6AA9B7C38474B5C88620700841E3BB657"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "6F4C8FF19D5B764D603A33744FB11F2547C7",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2DAAEDCD5313434B742AF158336E1107FF92"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "E0CFED0C27E88742A13B9B430CF13D5FBBCE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8C2AAE7983CB744529790391D9D8123F8078"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FED874DF44FE0548809A81296F6B5B1FE846"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E10D526A45115347686BD2A0541C3CC4936A",
                        "defaultText": "사에라... 나는 파라트라스야. 만나서 반가워."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F6968B01315EC7493328DB4659346EC948B0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8DCC0E3D4C181442A85B80C387E918D60D4D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DF9F9CD5060D23455E0B7997AF30888F2EAA",
                        "defaultText": "우리의 목표는 같아. 그 남자를 조사해야 하지만\n우리는 이 지역에 익숙하지 않아."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2561B16012E5F142205848A6AF42B53C6138",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0A2FF0F17CB85546415BDEB6DA0E74983F75"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "ABD61CFF49DF64436C3A5D252D81ADE04ABB",
                        "defaultText": "우리를 좀 도와줄 수 있을까?"
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E31348324CEDB24454786BC38F254D0B9CD7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B8B93E1767F27640B339120622CC93F87D36"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F5E0BDED3ABC4347C45B92566DD56B05B7A4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8971EDBC9E6315437E8AB4F5FF77A8D103DD",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Saerah_line7_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E180859C5C60B4453268AC6134EB4B457A7C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "D6ED27257742C4488979AE0105A1CA6A204D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "3CD19F896B1D21481949421516198BCE68C8",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "97D71BCD829C6943F829E6A1027A469873A1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FBB08EEB56503749C778BD8973497EAB0C31",
                        "defaultText": "하! 예의 바른 아가씨네!\n너희 일행에도 머리가 제대로 든 사람이 있기는 하구나!"
                    },
                    "position": 0,
                    "characterId": "3CD19F896B1D21481949421516198BCE68C8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9F25F8E2172E9849DB5B6E084F42300CB781",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DA6F1B098479004A7F58D0B933D069A97F1B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "BF1AC4BF73F6344E6F68F7D231733F6F948C"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "EF3C011F60C9E44DD49974768900E462D0A6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7391258A9A07B046F96B71253108DF9E7B9E",
                        "defaultText": "나도 끼겠어! 동료를 가릴 시간은 없어.\n이 일을 끝내기만 하면 돼."
                    },
                    "position": 0,
                    "characterId": "3CD19F896B1D21481949421516198BCE68C8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "50AA34A268D9A543FA5AAD9518ADAEE70F80",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6AF6ECD689F5F74CCE4936B74AB154AA5D55"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "56B274DF72D3A8405F38F2750027B29A9E21"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "5BE77C1E37532847E16BB4F340622BB06A96"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "04FAC0CC780741461D08EB9488765DF338C5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F06391F08D96D44B7129A6C835EC98CBB751"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F6AEF71135BF964A69988B29BF7CB9DA3D49",
                        "defaultText": "실용성에만 확실히 집중하는 젊은 여성이군.\n우리 둘은 아주 잘 맞겠어."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4093A00C11E5E645456BBCD497949F8BB71E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B78485458601D84D2E3AAE9674BE1A7BBE1D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9A26D4C78C8E5740FB286F45495F6AA6E591"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DE0C43D61597254F0A287D24AEBFC12C6FD5",
                        "defaultText": "나도 그렇게 생각해. 함께하게 돼서 반가워, 사에라."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FF88202128C1C347274999B880EA17C96846",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DC4FF36101D1104D5128D405E456351FE09D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "3CD19F896B1D21481949421516198BCE68C8",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B88C45DB57B77640754B8054C752FEAF7BD8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FA8759C239475641371B87F994491DBDF2F0",
                        "defaultText": "먼 곳에서 온 친절한 아가씨들과 더 가까워지길 기대할게."
                    },
                    "position": 0,
                    "characterId": "3CD19F896B1D21481949421516198BCE68C8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "564F501586990942191A5346CD1E8F7A0B40",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D6CC0C681577B549B9781A713B316CEEACBE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CE5BB7BD79F97844CB8A7E3554C5AAA179DB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BA3098B36C9B9345842AE2418B00768B873F",
                        "defaultText": "성질 있는 아가씨들에게 둘러싸였는데... 다들 날 무시해!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "82679FB809E1E4439428927878C870B76CE4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1DC38A9F16BDC9455E2B03772C79BBFC287A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E9C9E3FE1B58144A4D9A13C18BE32EA003B9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4B1146345B565445184A2105C43DEC4F6DD3",
                        "defaultText": "좋아. 그럼 야영지로 돌아가자."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CD4080A7411FD74C1C183F326A1ACB649F63",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "976CC45C413F44474F8AD658A2E5BD1A91F4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0284EF3F3349004B059B20C0AE631E089869"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "DF1C98832F741140AC1A3E21081E254F8320"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1BD8725E0D9E344CE22BA0F8C56A41689C28",
                    "parameters": {
                        "values": [
                            "Encampment"
                        ]
                    }
                },
                "indent": 0,
                "uid": "988B2F8454F1F2459299AA26331B2B4B961C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D1D322CB2E2602402C88D2428C77C01E35E6",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F23FB60D2479B149EC1B0841B3F94885EDB1"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "030F79B425338743DF6BAF50DDB656D20442"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "you can now go to the camp"
                },
                "indent": 0,
                "uid": "6EEE2D6608DAA240BF39796836F2FDC02833",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7741E7DA652A31432E986611847737FA2442"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "3CD19F896B1D21481949421516198BCE68C8",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E6BF660E9610944911787803EC3CE0E8DC5D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "41D273275DFAF0444588B3828F67A94F62F6",
                        "defaultText": "사막은 내 두 번째 고향이야. 그 남자의 흔적을 쫓도록 도와줄게."
                    },
                    "position": 0,
                    "characterId": "3CD19F896B1D21481949421516198BCE68C8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2E2710A72BC33748F97A01B427CE5089739F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "408659FB1A202846045876B6527C3F937FE7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C6B475F81DF4984EF01B4826D9527E21341D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A507B42A4F4DE444381B0F316E8A7E96888D",
                        "defaultText": "믿을게."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8BB5443E1380E444126B3903F0759247FAAE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "7C8FDEC674E54345718B4132AB0DCCA0821A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B50645E28706784AC699B9B1FA898485A68D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "26DD1C5739A02441208A6186D92430CB449C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "B153D2291649B7460E3B95098FC31B34C4A4",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            8
                        ]
                    }
                },
                "indent": 0,
                "uid": "9A258A8A76054747C77965E19F6689D70765"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "B153D2291649B7460E3B95098FC31B34C4A4",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            8
                        ]
                    }
                },
                "indent": 0,
                "uid": "9F647FFD6430184E1508CA6038AE2F61E72C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3E7ABEE4570156422B8B3A3685CBDFFB688C",
                    "parameters": {
                        "values": [
                            "3CD19F896B1D21481949421516198BCE68C8"
                        ]
                    }
                },
                "indent": 0,
                "uid": "FAEB1F953088774F013B63E7CA8FF89F6E72"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "422B49CA8A63A04CB338ADD9E56A9BFB25A0",
                    "parameters": {
                        "values": [
                            "",
                            {
                                "lcId": null,
                                "defaultText": "{C:1}Sae'rah{C:0} joins as a {C:2}Temp. Adjutant{C:0} for this chapter."
                            },
                            "",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "FC979FF32C644241363B6D0388FEE4A7E63A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6FE3C1466BE6D749E93B1A1763C2A8DE2900",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E95021F81626A84D9F495212888DEFE63D65"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "28AC36A65C8B774B336A0E41DEA5B64459CD"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 42
                },
                "indent": 0,
                "uid": "B5AE89FF3F7B17433289C867DEC30023E071"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "3CD19F896B1D21481949421516198BCE68C8",
                    "duration": 36,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "C6FEDEE40777C64ACB689A57A8CB60EA2E30"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "6A018C7C1A521444BC5A6B46419376CCDF14"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "97743A035EE7D14DC52943F03C3AA43EE1C5"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E40FEC8463B8294674486AC16893A3756B36"
            }
        ],
        "livePreviewDisabled": true,
        "stringVariables": [
            {
                "name": "name",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}