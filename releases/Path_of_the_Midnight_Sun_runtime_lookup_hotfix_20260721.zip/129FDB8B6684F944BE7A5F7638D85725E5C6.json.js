GS.dataCache['129FDB8B6684F944BE7A5F7638D85725E5C6'] = {
    "uid": "129FDB8B6684F944BE7A5F7638D85725E5C6",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C5-02 P1 Luckos",
        "type": "vn.scene",
        "parentId": "BBA9AB897A85D344FD782BD01FE902FC14EF",
        "chapterUid": "27B6E8FB2921364C12682182E915B49DA958",
        "order": 1,
        "localizableStrings": {
            "F4B453F15636804CB15872D5725C109D1035": {
                "t": "Oh, I see you've found a good spot.",
                "d": {
                    "cid": 0,
                    "eid": "DED41C12067B634010194E45FCF442239080"
                }
            },
            "5228FC382F1321412F2952A3D8656742F7EE": {
                "t": "Wooot!! Woot!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "0823F5D8546F7740436B6A975D4A58A9B1F1"
                }
            },
            "CC7AE17C831335437F493AB2471EBD312483": {
                "t": "... Luckos. Is that a bag of coins you have hidden under the pillow?",
                "d": {
                    "cid": 0,
                    "eid": "FE25C5EC263D044CEA0AB7E3ED2836203B5A"
                }
            },
            "463095956725B845EF7888B141949EB11F76": {
                "t": "... W-W-Wooooot!?",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "909959587CF6F643F78883E5064947450F35"
                }
            },
            "840F20714B3B574B743919E0F179B6C5BAE6": {
                "t": "Give it back to whoever you stole that from! Bad boy!",
                "d": {
                    "cid": 0,
                    "eid": "4A57EF974A0FF841466B3E83E6B73919074D"
                }
            },
            "022A9237534A464D0379C456B65F57EDD0E4": {
                "t": "Woooot...",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "96ED99612156954C968AC50548C16A07A6FA"
                }
            },
            "B850529E7DD8B1414889A329240DFD3CC348": {
                "t": "Sigh, this dwarf wolf is such a hassle sometimes...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "03D167928B2C774B338932D65552E1649282"
                }
            },
            "08E504DC3A5B15450A88222696D7BBDF722D": {
                "t": "Okay, okay. I will give you some Gold every once in a while.",
                "d": {
                    "cid": 0,
                    "eid": "EF22C7607DE4744FEA3A4535DB1FF61DE934"
                }
            },
            "81E2593C45A6884082293D96AA55D4DAA1A7": {
                "t": "But don't go stealing money from anyone in the camp, alright?",
                "d": {
                    "cid": 0,
                    "eid": "4EAAC3F435ECC6483C6932D73E9C316A1686"
                }
            },
            "EE6C23C15E18A146548BD06790B173643EA9": {
                "t": "Woot!!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "9A21BF991CC5A24DFD1AF6575CB84B229184"
                }
            },
            "23FEEC5A76C1E942D7383671D2C2D22E35FC": {
                "t": "Woot woot.",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "A28317FD727B1443A8691BC876BA17011B9D"
                }
            },
            "7C5182790637C54F2A590C7538AC4B0B4237": {
                "t": "Woot?",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "00A1CE6504C2B544496ABBF726205FE68AED"
                }
            },
            "D953A1598BE1C7471B5B58773FC45B5549FD": {
                "t": "Wooooot!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "4B455DED6F1B714B225B91B4375404A02635"
                }
            },
            "EE998D46565D154A5C89A16519C6A3608E42": {
                "t": "{C:1}(I'm ready for battle!){C:0}",
                "d": {
                    "eid": "CFCF44684C6F2546EF397406E28095BA044C"
                }
            },
            "FEC1A4C82147B2482F69104752AEA7C1FF39": {
                "t": "(Pet Luckos.)",
                "d": {
                    "eid": "BCAC8D127B6B94458F5821D5429AA629BB57"
                }
            },
            "6A84DA6235207743AB0B72246A639EACD827": {
                "t": "(Donate Gold to Luckos.)",
                "d": {
                    "eid": "1D3AD2CE35FE96416A58C0B7D6195991D0F5"
                }
            },
            "A7FC64D9695EE4474E691530731AF9E4CD4F": {
                "t": "(Nothing.)",
                "d": {
                    "eid": "98904A838FA05246831B61821F76105003D8"
                }
            },
            "B761BF4477F6F74AC82B72869237C8DCA672": {
                "t": "I believe I'm done here, for now. The battle could start at any time.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "D83B0CDD07A2B44BF17B1116633DC4ED9A70"
                }
            },
            "AE06C53F4557834BB128F855280E4225EEBA": {
                "t": "I wonder how well Lady Faratras is going to hold up?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "2F808D528720C14A065963305D20E342D3A7"
                }
            },
            "DF88097C6739E24872597F87A3074E9DE5DD": {
                "t": "And Shiori... how are you doing? Where are you now?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "97D5387B68C57047B38B02B31021EA95EC77"
                }
            },
            "664835D12CC67749A3385CA80114755F7038": {
                "t": "You entrusted me with this mission, but the Vassal's behavior is still a mystery to me...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "66651D2012D7F646229A8E10E047994297D9"
                }
            },
            "225D38DA571E344DB16A8BC69E3F08FB170A": {
                "t": "donate",
                "d": {
                    "eid": "210FBE7D9F370249EA9ACF8869477382FC9A"
                }
            },
            "93F388D17DA4A5467A8A62A32C98630467D3": {
                "t": "cancel",
                "d": {
                    "eid": "66CEDEE961548848144B3762C5A4EE915447"
                }
            },
            "1C68333934FFA94F843873827EDE39595FC6": {
                "t": "(Nothing.)",
                "d": {
                    "eid": "3B2DC3672A70344E2018D207A3D1119E0FA8"
                }
            },
            "F2E9BB6B1208394BE198F9A34DADACBD619A": {
                "t": "cancel",
                "d": {
                    "eid": "D86B75645AAEE14CD0684FB8E822862AD60B"
                }
            },
            "D1B9E3035A6901457D8AD9161388DFC5D41A": {
                "t": "",
                "d": {
                    "eid": "DD5BB3BA15D6284FB7781DC6262DDBB2A0F7"
                }
            },
            "99F2C7211F3A554A707AFC3792C6374F892D": {
                "t": "",
                "d": {
                    "eid": "B82555C249FF954D210A8D155C77EA0A3D23"
                }
            },
            "DA1116955744824A98691CB888C5EA3DA6A8": {
                "t": "Go to the next scene?",
                "d": {
                    "eid": "EB4B3DDA51AE8345D149499761324C11C9B9"
                }
            }
        },
        "livePreviewDisabled": true,
        "commands": [
            {
                "id": "gs.Comment",
                "params": {
                    "text": "@@@@@@ always change the encampment re-set in Wealth area down below"
                },
                "indent": 0,
                "expanded": true
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "FEEB28CE186A3342E70A634062AF25688319",
                        "name": "1 - Luckos"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 7,
                "uid": "B3B0CD755D14674D3F3A0A11DFBA6F291432"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "04904E84155C964CC0586DC67D4751F692AF"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "read?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E75D337F5BA1C1497788EF72C2CF0336D4B9"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "read?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "625AEE3C248B7744AA88FE45A0C6384B4676"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "1EDF40B960691540E349AE47E216F9908DB3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "BB95A0D30E53C544AB1A4C35A800AEFB6A78"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F4B453F15636804CB15872D5725C109D1035",
                        "defaultText": "오, 좋은 자리를 찾았구나."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "DED41C12067B634010194E45FCF442239080",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "181157459905F04D498A65742EF4AF5771E1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E332C32A0AA1E045078BFAB085FBEFBA176B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "448DA1770E586248DD294974080AE28C76BD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5228FC382F1321412F2952A3D8656742F7EE",
                        "defaultText": "우우웃!! 우웃!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "0823F5D8546F7740436B6A975D4A58A9B1F1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "4C29D7ED6055A4440B79D5E9E4E9A40A76B1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "2529FFAF6721F44CB0392E950B390FD5F80A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CC7AE17C831335437F493AB2471EBD312483",
                        "defaultText": "... 루코스. 베개 밑에 숨긴 건 금화 자루야?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "FE25C5EC263D044CEA0AB7E3ED2836203B5A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "645643F6145707442789ED17E196FE915CE2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            3
                        ]
                    }
                },
                "indent": 1,
                "uid": "9A884E394B51D840BC4AE707311055B0F881"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "DA90EA6A3A08164D8739C894E688C52277A7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "463095956725B845EF7888B141949EB11F76",
                        "defaultText": "... 우-우-우우웃!?"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "909959587CF6F643F78883E5064947450F35",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "0B01F1C680D3A64F517BEFE45929343401F2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E5CE76789FE74647DD3ADF34071A398F11D8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "840F20714B3B574B743919E0F179B6C5BAE6",
                        "defaultText": "훔친 사람에게 돌려줘! 나쁜 녀석!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "4A57EF974A0FF841466B3E83E6B73919074D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "210210D181981647610846B945CCC9D84ADB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            2
                        ]
                    }
                },
                "indent": 1,
                "uid": "2096E94B134CC540B12A3983A567244F5750"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E2A0B37F7A2EF14384591AF7E24EF3835AC2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "022A9237534A464D0379C456B65F57EDD0E4",
                        "defaultText": "우우웃..."
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "96ED99612156954C968AC50548C16A07A6FA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "B9E34F4865C14646C76A5887AAEE266008F4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "38CA081F2AF2C249278A7A67EE333812672B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B850529E7DD8B1414889A329240DFD3CC348",
                        "defaultText": "하아, 이 난쟁이늑대는 가끔 정말 골칫거리라니까..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "03D167928B2C774B338932D65552E1649282",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "414CDEEA62BB7940F84AF5E4E68AB3482F33"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "32CB376C0BB3C84AFC8A33B184DF130A3FD8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "08E504DC3A5B15450A88222696D7BBDF722D",
                        "defaultText": "알았어, 알았어. 가끔 골드를 조금씩 줄게."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "EF22C7607DE4744FEA3A4535DB1FF61DE934",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "26C514B5285A9647721BBBA2E056ACEBA41E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "81E2593C45A6884082293D96AA55D4DAA1A7",
                        "defaultText": "하지만 야영지에서 다른 사람의 돈을 훔치면 안 돼. 알겠지?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "4EAAC3F435ECC6483C6932D73E9C316A1686",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "74A0238F6FE1C64EE449B55260C019D84BCA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "27A7095D5D232040E228E164B0207FB62F7C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "D78007D642FE8742018B7D267FA9F0DC1210"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EE6C23C15E18A146548BD06790B173643EA9",
                        "defaultText": "우웃!!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "9A21BF991CC5A24DFD1AF6575CB84B229184",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "FB2D7FA07D0A084A3F0B94A1ADC7587B952D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E52B4F432C8A894BB9892DD9A81CB48810BA"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 1,
                "uid": "F33B9F8C8323344DFB7BBF964BAD8EFE34F6"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "Gold donated to Luckos",
                        "index": 434,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 0,
                    "source": 0,
                    "sourceValue": 0,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "0483B3205D1C974C0E894A031C48E8ED312C"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "0029B9F363551647D2985B929A5E684ED0D3",
                        "name": "[Tutorial] Luckos' blessing"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "04FD890D1CDCE1471C993FF55063C7353122"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 1,
                "uid": "17C4EC016A0A194DFB1BC9332667F22A96F6"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Luckos menu"
                },
                "indent": 0,
                "uid": "180B7B704D50734D433A696116EE85798062",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "choice loop"
                },
                "indent": 0,
                "uid": "7583C3FF08C2F74D4568D5D922FDBE6B37D6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D4AC39D57DE9354D974908C749CC4E55246E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8D0BD345649F0943858ABE4597CDBC6B942B"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "Luckos greeting",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 0,
                    "source": 1,
                    "sourceValue": 0,
                    "sourceRandom": {
                        "start": 1,
                        "end": 3
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6B88AFEB41FE664BF71ACA01318492B92CD2"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Luckos greeting",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 1,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BAAE965E97CB9744267B70826FFB6C9BDA1F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "9869A6A922BA8247592A25A88F1BCE093E1B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "23FEEC5A76C1E942D7383671D2C2D22E35FC",
                        "defaultText": "우웃 우웃."
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "A28317FD727B1443A8691BC876BA17011B9D",
                "expanded": true
            },
            {
                "id": "gs.ConditionElseIf",
                "params": {
                    "variable": {
                        "name": "Luckos greeting",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 2,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7A90805C6B6330419D9B4367B3CA3B172181"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            5
                        ]
                    }
                },
                "indent": 1,
                "uid": "B3DB54D32D49E54A9E68693321849DEB0818"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "AF337A39185BF8478A59DC15729656D51B71"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7C5182790637C54F2A590C7538AC4B0B4237",
                        "defaultText": "우웃?"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "00A1CE6504C2B544496ABBF726205FE68AED",
                "expanded": true
            },
            {
                "id": "gs.ConditionElseIf",
                "params": {
                    "variable": {
                        "name": "Luckos greeting",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 3,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "AA7D48454AE3A84BB50A28062485CC61C1F3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "6F25AA868635934D0A78663875AF4722ADA3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "A8DF078552B50848401A91144D63E3921B74"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D953A1598BE1C7471B5B58773FC45B5549FD",
                        "defaultText": "우우우웃!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "4B455DED6F1B714B225B91B4375404A02635",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "537817C197FB6541AA48AF928A8CE1C4BC93"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "EE998D46565D154A5C89A16519C6A3608E42",
                        "defaultText": "{C:1}(전투 준비 완료!){C:0}"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CFCF44684C6F2546EF397406E28095BA044C",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "FEC1A4C82147B2482F69104752AEA7C1FF39",
                        "defaultText": "(애완동물 루코스.)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BCAC8D127B6B94458F5821D5429AA629BB57",
                "expanded": true
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "donated?",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D29A29BB774E254E351858A4EA61922FF75C"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "6A84DA6235207743AB0B72246A639EACD827",
                        "defaultText": "(골드를 루코스에 기부하세요.)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "1D3AD2CE35FE96416A58C0B7D6195991D0F5",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Label scelta 3",
                        "index": 246,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "225D38DA571E344DB16A8BC69E3F08FB170A",
                        "defaultText": "donate"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "210FBE7D9F370249EA9ACF8869477382FC9A",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 4",
                        "index": 243,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "A7FC64D9695EE4474E691530731AF9E4CD4F",
                        "defaultText": "(아무것도 아님.)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "98904A838FA05246831B61821F76105003D8",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Label scelta 4",
                        "index": 247,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "93F388D17DA4A5467A8A62A32C98630467D3",
                        "defaultText": "cancel"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "66CEDEE961548848144B3762C5A4EE915447",
                "expanded": true
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "F2CE11546C57284643080F45B6552221D7A3"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "1C68333934FFA94F843873827EDE39595FC6",
                        "defaultText": "(아무것도 아님.)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "3B2DC3672A70344E2018D207A3D1119E0FA8",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Label scelta 3",
                        "index": 246,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "F2E9BB6B1208394BE198F9A34DADACBD619A",
                        "defaultText": "cancel"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "D86B75645AAEE14CD0684FB8E822862AD60B",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 4",
                        "index": 243,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "D1B9E3035A6901457D8AD9161388DFC5D41A",
                        "defaultText": ""
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "DD5BB3BA15D6284FB7781DC6262DDBB2A0F7",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Label scelta 4",
                        "index": 247,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "99F2C7211F3A554A707AFC3792C6374F892D",
                        "defaultText": ""
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "B82555C249FF954D210A8D155C77EA0A3D23",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "battle",
                            "pet",
                            {
                                "name": "Label scelta 3",
                                "index": 246,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            {
                                "name": "Label scelta 4",
                                "index": 247,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            }
                        ]
                    }
                },
                "indent": 0,
                "uid": "AB4B89554886C6423D79C165D9D8A8ACFD66"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "8F3C04FE58458847F67A3935032A1DBF01BD"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "battle"
                },
                "indent": 0,
                "uid": "244917C45D54E448888AFE19DDDB9DDC5DA0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "A383CDDD6A2E0742089BB8B72E91D89898FD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "016ABE933ABE1346E06AF8C985770932C8A2"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo del messaggio",
                        "index": 19,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "DA1116955744824A98691CB888C5EA3DA6A8",
                        "defaultText": "다음 장면으로 가볼까요?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "EB4B3DDA51AE8345D149499761324C11C9B9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "B66ECF95405857448D4BDDD38DBABD1B66D8",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "AAAC15694879F24A944884E49489D30EEB56"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C00D731A1E4FE546098AE8C4EC7268B1C212"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "choice loop",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "3BC191541527074CD4684E34E35A4AEFD39B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "736DF3DA0E3A2443DC19FA49DF751CC2D326"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9EABE4736CD4E348C189E671D65C52EFDF6F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B761BF4477F6F74AC82B72869237C8DCA672",
                        "defaultText": "지금은 이 정도면 됐어. 언제든 전투가 시작될 수 있으니까."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D83B0CDD07A2B44BF17B1116633DC4ED9A70",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6901B9B47F2AD946035BCDA262F055B53565"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AE06C53F4557834BB128F855280E4225EEBA",
                        "defaultText": "파라트라스 님이 얼마나 잘 버텨 줄까?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2F808D528720C14A065963305D20E342D3A7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CE8F10F776DA724AAA193774E535D7FF5597"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            5
                        ]
                    }
                },
                "indent": 0,
                "uid": "4F8C9A7C07778146D81A32950E6DD9310B7C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DF88097C6739E24872597F87A3074E9DE5DD",
                        "defaultText": "그리고 시오리... 잘 지내고 있어? 지금 어디에 있는 거야?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "97D5387B68C57047B38B02B31021EA95EC77",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DCDFC25D8DE32643693925A34778E742A784"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "664835D12CC67749A3385CA80114755F7038",
                        "defaultText": "내게 이 임무를 맡겼지만, 그릇의 행동은 아직도 수수께끼야..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "66651D2012D7F646229A8E10E047994297D9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "87E10BEB9D131643812AAE13F730C60F998A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C37E229824CFC34BE80808A3848B111C83BC"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "2FD9490B2414E7484B8859E2749E7DEF3596"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E1C2DDF44DB69042D25836920C7767268DDB"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "E02A771D556AF24C112B9C88971F7B6A68D6"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "4679B0766767D442548A49E4A4342B2F5BB5",
                    "param": {
                        "name": "Livello",
                        "type": 0,
                        "value": 0
                    },
                    "numberValue": 2,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "DE40BFD62987164EEE08A5F248BD27EC6A40"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "14799A476F7DF34924596E438C45CDBBCF4C",
                    "param": {
                        "name": "Livello",
                        "type": 0,
                        "value": 0
                    },
                    "numberValue": 1,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "C4080BF6772901480E296E168A132AB24508"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "0E7A8E6E5C685840932A35887C55179DC1DD",
                    "param": {
                        "name": "Livello",
                        "type": 0,
                        "value": 0
                    },
                    "numberValue": 1,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "629DF99526C5F64603487293F4552F9DE9C1"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "AD9C47B372680846D248E0E7B35B4C12ACAA",
                    "param": {
                        "name": "Livello",
                        "type": 0,
                        "value": 0
                    },
                    "numberValue": 1,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "3064017D78D507420F7AD723E104578E2220"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "E77E9F07414DD7407F2B59388981EE06898D",
                    "param": {
                        "name": "Livello",
                        "type": 0,
                        "value": 0
                    },
                    "numberValue": 2,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "DA55775B22ADF243F02B822503F7BA690BDA"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "5B83BA704434824B0B6B1A455A118B3CE49D",
                    "param": {
                        "name": "Livello",
                        "type": 0,
                        "value": 0
                    },
                    "numberValue": 1,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "6C75377D3C96F04F696B92D42B88BF3D643E"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "BADFDBD75ED5334DAC8B9F451D18B28E3D24",
                    "param": {
                        "name": "Livello",
                        "type": 0,
                        "value": 0
                    },
                    "numberValue": 1,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "4F7C4EE31C49E143D298D91900F7E7BD74D6"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "200DED0865BFD241827AB3C13029EED62120",
                    "param": {
                        "name": "Livello",
                        "type": 0,
                        "value": 0
                    },
                    "numberValue": 2,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "D2D0420391409440DC99162513973086CC53"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "2FE3E82C8B0F0546DE99AB20C7A211EAAACA",
                    "param": {
                        "name": "Livello",
                        "type": 0,
                        "value": 0
                    },
                    "numberValue": 1,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "ECA393068311E5405469A487FA3F7C969955"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "A4732C551E30984BF2897F63E731C297E560",
                    "param": {
                        "name": "Livello",
                        "type": 0,
                        "value": 0
                    },
                    "numberValue": 1,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "1FE384579F9841470F385BD7A9BAFE7F1B4A"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "9E2174DE2E4F394B485AE5426EE3F6450E65",
                    "param": {
                        "name": "Livello",
                        "type": 0,
                        "value": 0
                    },
                    "numberValue": 2,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "A2AE1F304571A746A8988E83C2FCE1649F24"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "F7CCEA104A31924AA41899F550ED1206DC66",
                    "param": {
                        "name": "Livello",
                        "type": 0,
                        "value": 0
                    },
                    "numberValue": 1,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "65BAC48D4A66D34B1189C1E74CD2E16621B3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "422B49CA8A63A04CB338ADD9E56A9BFB25A0",
                    "parameters": {
                        "values": [
                            "",
                            {
                                "lcId": null,
                                "defaultText": "Your allies prepared for combat and learnt {C:2}new skills{C:0}."
                            },
                            "",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "72296B6A2EE124461148F9439A1C9294B244"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6FE3C1466BE6D749E93B1A1763C2A8DE2900",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "0BA2FAF87721454C8158C11454DFA5E4670C"
            },
            {
                "id": "gs.FreezeScreen",
                "params": {},
                "indent": 0,
                "uid": "D32107A2219BA144FE7A27526E6BF5827CE5"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "F1EE12770854A4480B0A8471CE855C4FE030"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "IN EXPLORATION INTERACTION?",
                        "index": 176,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A52C5BD022C3A643FB3872455D2903243E32"
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "66FA996B4922B04B263AE6A5428E66945592",
                        "name": "C5-03 Before the battle (VN)"
                    },
                    "savePrevious": 0,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F25D5DAE351A024A8F98F1C8ABD54CD6C1A1",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FFDD57B59BF4194995283FF7BD48E1CBA9A3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "EBC128254F61E846A02A9961BEB08C949AC9"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "cancel2"
                },
                "indent": 0,
                "uid": "221FACE12990F14B259BE1013D0854892356"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "FD1DE084676BF34A4B5B05B567AF7526EFA7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BCF4A86780EB824F686882B68AC1F588D5DE"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "920548D124ECC74DAF488956C8977EDF7DA7",
                        "name": "C05-02 extra Verify Luckos Wealth"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D5626A346B484745131A85A6146FC648C4FA"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5CB4F1AD5212C8438B6BC778A8F9F58E9DEB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            500,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "82E6A8AC0CDCD345488885F8EFC313CF0108"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1BFC3132455D2444EC2936029888561B32EB",
                    "parameters": {
                        "values": [
                            1,
                            20,
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "053991C68B3DA94F638A6CB42BB2C0EC5631"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 1,
                "uid": "9F35204B67D8E840DA397EE587D98FD1F3A5"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "D76DB9008206594ECA1B6BA44DDE21DC0D4A"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "23FB4E568F6DE14FC36B437681D57A5BF654"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "8BC0A8D976416741365B2DA79579DC284DB3"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "choice loop",
                    "target": "activeScene"
                },
                "indent": 0,
                "uid": "B67E3A591604D4464A1B019726E03D012034"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "cancel"
                },
                "indent": 0,
                "uid": "AB8DC28A475F8446E529F3021B30C29AAC69"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1148036754E2994C210B6749EEFEAC16E090",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "593B23413BD5254E7579ADF708D9F3779F55"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "DD16EC93249177496B892034677F858C91D9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D347050B84DD644D021880A1C8A0A6CDD38B"
            }
        ],
        "numberVariables": [
            {
                "name": "Luckos greeting",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "petting answer",
                "index": 1,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "booleanVariables": [
            {
                "name": "read?",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "donated?",
                "index": 1,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}