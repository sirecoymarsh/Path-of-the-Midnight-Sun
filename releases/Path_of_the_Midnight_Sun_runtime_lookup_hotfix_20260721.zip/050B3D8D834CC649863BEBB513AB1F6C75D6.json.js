GS.dataCache['050B3D8D834CC649863BEBB513AB1F6C75D6'] = {
    "uid": "050B3D8D834CC649863BEBB513AB1F6C75D6",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C1-05b Save luckos",
        "type": "vn.scene",
        "parentId": "F7F581B17D00D5435868B5C374116B4EBEE3",
        "chapterUid": "CF7E3CE62FB82749AB7B39C1990AC623D042",
        "order": 12,
        "livePreviewDisabled": true,
        "localizableStrings": {
            "BA9A2D487121D44B6C6A4E59D832ED36732C": {
                "t": "So, why's everyone raising a ruckus here?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "78B459994F0A9443B64BDF668558D1BB7AFD"
                }
            },
            "FDDEB0915104D345D8881DD8CBC5081FFC70": {
                "t": "Woooot... {W:200}wooooot...",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "1C027378235A164C992875E8197D073863D8"
                }
            },
            "ACEE266B27D3B349292BFA072E3C93AEDE4E": {
                "t": "... I should've guessed that the ruckus was due to the luckos.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "E3DE785E1C2E474B7E69CD049C133369B230"
                }
            },
            "D6DB224317537540C928E968F0B9E26F6A7E": {
                "t": "Woooot... {W:200}Woot, woot!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "805AE19157EBD1405C580DE8516C5BDFAE3E"
                }
            },
            "A612BDCE12257249D81B0A149DDD19A6B836": {
                "t": "It's darting from side to side, but always finding itself in front of some big man who tries to catch it...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "865CB9C2032A8945084AD501058D4DB75B3C"
                }
            },
            "1B01492A16975647F09BA7D8D7A4E2552BC4": {
                "t": "Sigh, I guess I should do something.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "6A2284D2878D214FB07B99376A02FC58C1D7"
                }
            },
            "5272E56B74C5924A4F888BC8A25849CDECEC": {
                "t": "Jump in the middle of the chaos.",
                "d": {
                    "eid": "61B603753C3AD840E11B73457AB188B4C78A"
                }
            },
            "D4854F0D9DFC06449F78BAB546CBB7F087D6": {
                "t": "Crack a joke and hope it works.",
                "d": {
                    "eid": "2A8988927060124EC68A0D32A2C6534C36CC"
                }
            },
            "78975AD0375888494E9949146D5665FC1DFC": {
                "t": "I don't have time to think twice about it.{W:200} I have to save it!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "2868BB8311D7144EC158669541FBBA48B3DC"
                }
            },
            "6F2593AD5D72074A37894985DEB574CE96C1": {
                "t": "First, I need to attract their attention...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "ADC81DA337118346804A679326504A17A188"
                }
            },
            "7350FE132DB6904575397884CC853ED88BED": {
                "t": "Let's see, I could tap my armor with the sword...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "995A327252E8974E77688A1544E6894BA12E"
                }
            },
            "1A827B2C3D863749C939CCE06AF9D9E872CF": {
                "t": "Good, all eyes are on me. {W:150}It's working!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "4769DA9593D6434CCA7B4908615B66FE73E2"
                }
            },
            "4E669F307688F9457F791C879F28BFF09A46": {
                "t": "What the hell, man?",
                "d": {
                    "cid": "2D8B72093B48784781181937BEFAA8D95AAC",
                    "eid": "7B320FF366981640E0899625B59AEE5BCF8F"
                }
            },
            "CCE7378341A1604E719B3E62020A438759E2": {
                "t": "Ahem, you should probably say \"woot the hell\", {W:100}since you're chasing a luckos... {W:200}Haha?",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "E081BDE52B5CF647313A344118BD3FFD2AE9"
                }
            },
            "A80E798C2140E644CC18C1E91C8A4D6B8C24": {
                "t": "... ... ...",
                "d": {
                    "cid": "2D8B72093B48784781181937BEFAA8D95AAC",
                    "eid": "61F573C2381A574E463BC9713D25EABE3A5A"
                }
            },
            "A5F1A3EA89E2F740F14AA148618FE0290AD3": {
                "t": "This guy's an idiot. {W:200}Let's break his bones.",
                "d": {
                    "cid": "C668D157625D50483C1A59E3F777C24F275E",
                    "eid": "032E0F968BADD549673A39763C23B3161637"
                }
            },
            "AF1B98B819733342DD6A0F225CF2A45B50E8": {
                "t": "Damn, it didn't work! {W:200}Quite the opposite, they seem more violent than ever...{W:200}\nI should've practiced my sarcasm a bit more...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "1FF5CD1719E3D64E299901B275B6708BDE4A"
                }
            },
            "0A7BB2F5158F6741F87888825FE236AF5C91": {
                "t": "So, what are we doing here, gentlemen?{W:150} Mischievous activities? {W:150}Violence against animals?{W:150} Or perhaps both?",
                "d": {
                    "cid": 0,
                    "eid": "D2287D020DBA744FDA594DA0D78464FD408E"
                }
            },
            "88FA56088D20C74BAF6B2A13D1527A9B2CC7": {
                "t": "I wouldn't like to cut you in half, you know?{W:150} Even if there'd still be a fifty-percent chance of you being 'all right'...{W:200} Literally.",
                "d": {
                    "cid": 0,
                    "eid": "95101708712FA14344286567B0DA4D69052B"
                }
            },
            "F229CC0542C1924E1E2834D3EBFCD22FA0C4": {
                "t": "... ... ...{W:200} Pffft.",
                "d": {
                    "cid": "2D8B72093B48784781181937BEFAA8D95AAC",
                    "eid": "FFC83CA7186BD24C6C8BE2739D04C83402F4"
                }
            },
            "B6BE8D2F23848844B508D6331E6891DDA87B": {
                "t": "What are ya laughing for!?",
                "d": {
                    "cid": "C668D157625D50483C1A59E3F777C24F275E",
                    "eid": "34D8204D721B634C90996C51FCB7BD5F14E0"
                }
            },
            "D3B2D71A3E7691422A78FAC148F69D2EC47E": {
                "t": "It seems my... {W:200}er, tactics are making them feel disoriented.{W:200}\nGood thing that I practiced my sarcasm!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "80A64EB27CC8034B103995388D979154894F"
                }
            },
            "31D7718A78BDA84812391511E5BFE46D28C0": {
                "t": "Woot woot woot!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "6F7FF74D782BF6480E290788CAFC4211214F"
                }
            },
            "BA35BF2A024B91433198B201503EE53C9B1E": {
                "t": "You look particularly relieved, huh? {W:150}Don't worry, I won't let them hurt you.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "C62244158ABFF14CC1082C97548C38BE1E6B"
                }
            },
            "C46EC79A7CE325416F78B9C9EC8C726AF2D2": {
                "t": "Woot!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "00A661BD89942848647935A2C2ADCF0D2063"
                }
            },
            "D82FA9C0568C0848191997F6F543EB575DC3": {
                "t": "Are you looking for trouble!?{W:150} That wolf's ours!",
                "d": {
                    "cid": "2D8B72093B48784781181937BEFAA8D95AAC",
                    "eid": "E1738AC75DE694491D3A6AD12F89D2339056"
                }
            },
            "C22724C555825444AC8908B02320047BBAEE": {
                "t": "Yeah, outta the way! {W:200}That thing stole our gold and buried it somewhere!",
                "d": {
                    "cid": "C668D157625D50483C1A59E3F777C24F275E",
                    "eid": "E355C6F7296C344673292903610F38A720C2"
                }
            },
            "853BFBFE8994434AB11B7846C8F86F9AD5FD": {
                "t": "I hate to admit it, but they heavily outnumber me. {W:200}And Shiori isn't here to support me...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "2C126E090D833748E72AB77828C7255513CA"
                }
            },
            "86F8D5583930E64A9D48C662B6C0486B61FB": {
                "t": "Argh... no! {W:200}What am I thinking!?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "7DB537387100F14D2129F3459A3F0CA03C20"
                }
            },
            "C018537D7E99A445BD0AE67705A7ACE107C4": {
                "t": "But... {W:150}for some reason, that vision made me remember a sword technique I had forgotten...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "63DAA90A18E0444C9598E68124F6815FA79E"
                }
            },
            "7D14B10A40648643D54B7BF5272E0172C24E": {
                "t": "I fear I'll have to teach you some good manners, gentlemen.{W:200} Come!",
                "d": {
                    "cid": 0,
                    "eid": "38B2A5642C14024DAA18D27329AF92C87E5F"
                }
            },
            "FD6D246B060C3841B85B47E2E26477AB0E66": {
                "t": "Y-You may be a funny guy, but we won't go easy on you!",
                "d": {
                    "cid": "2D8B72093B48784781181937BEFAA8D95AAC",
                    "eid": "187FADDF7442C74DB96B80426274E42AAE2B"
                }
            },
            "293CD234453C074D92785F19D5F707083063": {
                "t": "... ... ...{W:300}You did what!?",
                "d": {
                    "cid": 0,
                    "eid": "C886C0E747B5D642BE28F3C1DED5536CDB4B"
                }
            },
            "567413E053C904410B3A8AE796BFC15D2FCB": {
                "t": "Woot.",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "F24874D98EA9664003098591CD7BDC4A282B"
                }
            },
            "3E7079092D7B70487E09F89120E720E732F4": {
                "t": "There's no other choice. {W:150}I have to--",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "0566720016399640AA69DB436858A3F77962"
                }
            },
            "6D13318E3A35734B1D69F0317038D1DE2FA1": {
                "t": "I have to...{W:200} kill them all...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "B1E1E1DE56F5254DFC19ACB7B6908591ACCE"
                }
            },
            "49808C758CF3964D5E6BD8D4144FFBAC5587": {
                "t": "That fool is acting like he's already dead!{W:200} Get him!!",
                "d": {
                    "cid": "C668D157625D50483C1A59E3F777C24F275E",
                    "eid": "9D65A11916E3F544121B4D24B1FBE87106FF"
                }
            },
            "6B90648230ED154EC128B6481A3AE177CE88": {
                "t": "Sir, if you're about to fight, take these!",
                "d": {
                    "cid": "FA72429357D43349B2781CC7A1E2818C5673",
                    "eid": "BF20D8514C4CB748586BC124F026D560B682"
                }
            },
            "B8147072216CD74180580EC5090E655A7E36": {
                "t": "Based on my perfect assessment of this situation, I'm sure you'll need them.",
                "d": {
                    "cid": "FA72429357D43349B2781CC7A1E2818C5673",
                    "eid": "42E69BFB164A374AAD1BDA53E17389E86B81"
                }
            },
            "E533F7891CEE14463F3858E34FA913B29485": {
                "t": "Huh... {W:200}Thanks?",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "F0E4316214EDE34414387BF8BFD652A283A5"
                }
            },
            "E77156CA6AF5D94ACB1B53655F1BD9770E3C": {
                "t": "32CC41207FE1934C696B6F58CCE56CC74B18",
                "d": {
                    "eid": "4AE56A823B02E449B98B52E5251AECBDB661"
                }
            },
            "79C2A9B14940D249E86AC3D0C3EFA3914FD6": {
                "t": "41A72FC066D381405D48FA1251543766AF13",
                "d": {
                    "eid": "97516A675611D3476B4B5403766F42916F5F"
                }
            },
            "99EB5F912D07F4478B588A62A91E0D4ED193": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "D2829A974DDDA3420578C86351B4B2D6A2E8"
                }
            },
            "7BF8479C2071E84ACF9B875077AF25E5DAF2": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "57A1EA935F99F5451E3A34845BFCE48D6910"
                }
            },
            "3797AB864084C140CA4BDA21AA727ACA7585": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "429AE2511DABC84C4C79E9F30D925847FA72"
                }
            },
            "BF4181E3759F31453A399FD466554E584648": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "CDBEAA8A68645344F908F53517B4BD978393"
                }
            },
            "FFC1544B69C9F349EF59ABF45F49A6D34B75": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "2A3A2763865C034A242A4662767536B938CA"
                }
            },
            "B5B76BE247D18843646B1C269FDEA17F736A": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "F520A1710A7A9240D98A64A453BB0ED4A065"
                }
            },
            "A7AA91E61DDFA64DCA7999D06880E581B6B8": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "CA0A8A94688776487F290DC6B6E36179262C"
                }
            },
            "7B1228C352751944EE898B8738219BA39002": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "845EC031187E764A772B24C6981F4887ADCC"
                }
            },
            "9D01EC240EE6854DE138A4D40A403E06A4BE": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "A3939F8881F7534A365806A63D9E48A8C78C"
                }
            },
            "DD44E6BB555E1642357AD0565458BE151EB2": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "6EE0B70368BD7449F77BE7F5E56BCA53E779"
                }
            }
        },
        "commands": [
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "51F99BB74E9FF643D32B80B3B118E9C226A1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "7F54801182461841BF1AE288919808F16C62"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "16F690D66B82844FA7788411D64EDA5E0422"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Location SCENE 1",
                        "index": 286,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "E77156CA6AF5D94ACB1B53655F1BD9770E3C",
                        "defaultText": "32CC41207FE1934C696B6F58CCE56CC74B18"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4AE56A823B02E449B98B52E5251AECBDB661",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "491D626C40FA144C1B4832E147AEC0586E74",
                    "parameters": {
                        "values": [
                            1,
                            {
                                "name": "Location SCENE 1",
                                "index": 286,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            }
                        ]
                    }
                },
                "indent": 0,
                "uid": "B2379A2B80DEF54978388C75168D2EDB7CBC"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Location SCENE 1",
                        "index": 286,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "79C2A9B14940D249E86AC3D0C3EFA3914FD6",
                        "defaultText": "41A72FC066D381405D48FA1251543766AF13"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "97516A675611D3476B4B5403766F42916F5F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "491D626C40FA144C1B4832E147AEC0586E74",
                    "parameters": {
                        "values": [
                            0,
                            {
                                "name": "Location SCENE 1",
                                "index": 286,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            }
                        ]
                    }
                },
                "indent": 0,
                "uid": "E2A87FEF76EE9243592963F74C4D5B47F528"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            20,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "17EFF67E661E6249B31BF3982ACF4036DBFF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "F6E433B061534144A08BFFB67AD10A0553A9",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FC045A6E36BB3647AE6A07A86151FAB9CE9B"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "962DE3876747E844D249504113679C066587"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E26E9FE1033A5146B34AFE822D3A48BB2871"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "B254ADA574A32349566B273723679EDAB440"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 45,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 2,
                        "movement": 0,
                        "mask": {
                            "graphic": {
                                "name": "9.png",
                                "hue": 0,
                                "opacity": 255,
                                "blending": 0,
                                "tone": {
                                    "red": 0,
                                    "green": 0,
                                    "blue": 0,
                                    "grey": 0
                                },
                                "folderPath": "Graphics/Masks"
                            },
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "466201297E10C249BF3854E7F09B0ABAB8E5",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 15
                },
                "indent": 0,
                "uid": "05AF9A44820F814921685F53F0793393B1BB"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Spend time (during travel?)",
                        "index": 96,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2C36B9862D34314AA8390EF60E4BB0C44711"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Spend time (during travel?)",
                        "index": 96,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "1C65460C3B24A74DD46871B4BF4C27A4F35F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "03DEA4954ABD5648B72A16630CB12FEB0C7F",
                    "parameters": {
                        "values": [
                            {
                                "name": "Tempo d'attesa",
                                "index": 32,
                                "scope": 1,
                                "domain": "com.degica.vnm.default",
                                "changed": true
                            },
                            250,
                            1,
                            2000,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "89D68D5A7C096641347BA7043978AFCA9AD4"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "D1E32B3B3168A942C219E9B597D0CACB0B82"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "21CB77C16DEB404FA26A8F35BFB39B2FD0D7",
                    "parameters": {
                        "values": [
                            "FEEB28CE186A3342E70A634062AF25688319",
                            "9D3C3D6637F65744F149E014515F3D164D87",
                            "48EB76266BD1B445353AF51234E45534D991",
                            "25447C1F211006463E788226B211EE1CF42D",
                            "F95BF6B5675E67473A7832A21588DC464CD2",
                            "6B6F05DA0BA4C4473828C6D4AC0A8DAC989C",
                            "8120DCCE7C10C34B0A9B87E5872F4E53823E"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5E1664162CD804450029D425F6A1969CF513"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "DCA9B94A20CD0940BA3B7C11584C3864218E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BC9D6F528402E34E8368E3355E6EAF18C53D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7524DB46181D674B108AC590F5B535763EEF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BA9A2D487121D44B6C6A4E59D832ED36732C",
                        "defaultText": "그런데 여기서 왜 다들 소란을 피우는 거지?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "78B459994F0A9443B64BDF668558D1BB7AFD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "06DE01835A2155460E88B1C01674387AAE8A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "60ADBACA8058C347A65B0B930F37F2E67006"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8F750BDD7EC1A8485D2973A2F309502FEAE7"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "loop": 1,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Luckos.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "sad.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6D3B905B253E664AED6B2C224B1D60F1AC03"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "BB0E730138D574442F6AD084B8383E72EC08"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "99EB5F912D07F4478B588A62A91E0D4ED193",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "LUCKOS_SAD_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D2829A974DDDA3420578C86351B4B2D6A2E8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "68E554788D8AB4473B283D2012028A03C7FC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6C9A1778585AB4418C5AF62352E92E229B78"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FDDEB0915104D345D8881DD8CBC5081FFC70",
                        "defaultText": "우우웃... {W:200}우우웃..."
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1C027378235A164C992875E8197D073863D8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "763702C768563249E189DA97BE27C75CE4A8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "A5CD3C3B352843410338B9731325131A7FD8"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5C328AF780E4B542DD787A942D265748754C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E4D44A268CBFC744227B8125D83843912B7F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5B688CF48AEC354DBB18BAA5CC1FD8595B2E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "ACEE266B27D3B349292BFA072E3C93AEDE4E",
                        "defaultText": "...소란의 원인이 루코스일 거라고 예상했어야 했네."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E3DE785E1C2E474B7E69CD049C133369B230",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "61728DF847BC7440C97A6BE48727586B8DAB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5E2563D23AD5E64C95591AF5BEAB4938754E"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "loop": 1,
                    "fadeInTime": 0,
                    "data": {
                        "model": {
                            "name": "Luckos.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "sad.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "49A38C2B6415C24FF82B49E8A46E416A8D16"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "649F045E29BC914A837BC7F382639F44BAAF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7BF8479C2071E84ACF9B875077AF25E5DAF2",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "LUCKOS_GROWL_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "57A1EA935F99F5451E3A34845BFCE48D6910",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E45690CA386E124EBE2BB66200490CBF0871"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E2A958B17EB3F848113958535C84C00A414F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D6DB224317537540C928E968F0B9E26F6A7E",
                        "defaultText": "우우웃... {W:200}우웃, 우웃!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "805AE19157EBD1405C580DE8516C5BDFAE3E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "17B781BC4ECA2943B149ECE7F921FCDB726D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "28884C0D830810429A3BA5D358F1837D1095"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A612BDCE12257249D81B0A149DDD19A6B836",
                        "defaultText": "이리저리 재빨리 달아나지만, 잡으려는 덩치 큰 남자 앞에\n자꾸 가로막히고 있어..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "865CB9C2032A8945084AD501058D4DB75B3C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FC3B92162C7557402C5B9821A61E41BC0591"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0FCBA75C370AF24614385CC41273BFE1F242"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1B01492A16975647F09BA7D8D7A4E2552BC4",
                        "defaultText": "하아, 내가 뭔가 해야겠네."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6A2284D2878D214FB07B99376A02FC58C1D7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3CE97C067E4BD74CAC693D44870DCCC75C87"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "5272E56B74C5924A4F888BC8A25849CDECEC",
                        "defaultText": "혼돈의 한가운데로 뛰어들라."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "61B603753C3AD840E11B73457AB188B4C78A",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "D4854F0D9DFC06449F78BAB546CBB7F087D6",
                        "defaultText": "농담을 하고 그것이 효과가 있기를 바랍니다."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2A8988927060124EC68A0D32A2C6534C36CC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "in chaos",
                            "joke time",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "88BA21541CEB1649448A9DF928C8E4271871"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "7D7BFE997FFEF7415A79ABF4A9D55EC3F0A9"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "in chaos"
                },
                "indent": 0,
                "uid": "6E1FA52B60BD104F2A9AFF94EF95F4ABA46E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6A1620FB55D2B64AB719FEB09BC71E97D0E1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "78975AD0375888494E9949146D5665FC1DFC",
                        "defaultText": "두 번 생각할 시간이 없어.{W:200} 구해야 해!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2868BB8311D7144EC158669541FBBA48B3DC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A6D2340B27238549F6191E7923770DA48E82"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "522BF8FB761DC245AC695BD407E43EDF67D8"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "5D25F47E2C5857469A28BA68F8206FA0264F"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "battletime",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "3F7B94A25211B648F96B73E7403CE95B694B"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "joke time"
                },
                "indent": 0,
                "uid": "CE5F4D0895BCF6448D9AF4C25F0A94B17DD2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EEC4444379160542268A7EB697D61ECB9205"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C1F68D77342FD04BE338A402CB4DB3661593"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6F2593AD5D72074A37894985DEB574CE96C1",
                        "defaultText": "우선 저들의 시선을 끌어야겠어..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "ADC81DA337118346804A679326504A17A188",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1F61FBE352B1664EBF6B5554F03F4D7234D6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "261003207DB494448E5970E49BE547282548"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7350FE132DB6904575397884CC853ED88BED",
                        "defaultText": "어디 보자, 검으로 갑옷을 두드리면..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "995A327252E8974E77688A1544E6894BA12E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D7F1CE9538FFA541CD6A3F15C6BD654D7B35"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "38BA97A94DBEC84F897B2796773D6280C805"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Others",
                        "name": "Unsheathe Sword.ogg",
                        "volume": 100,
                        "playbackRate": "114"
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7123BA8C6FCE954BA22A44493D472C68447D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "A92C7BC470041140636B4A213BC6C15EE0C7"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Others",
                        "name": "Ornieres_Armor_Unequip.ogg",
                        "volume": 100,
                        "playbackRate": "150"
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2F1B539C37F2474C5C2A421280CA83D45F95"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "BF4145117BAFD04626893518C909F38D08E3"
            },
            {
                "id": "gs.StopSound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Others",
                        "name": "Ornieres_Armor_Unequip.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "592F2BEB46DDB34F695B6C063216B7047E0A"
            },
            {
                "id": "gs.StopSound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Others",
                        "name": "Unsheathe Sword.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "742AA9A377A6C5426F5B36858F20026A76B5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "2191626D72224147C64B6D34E770EBB1E343"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A2B1471863FC624ECD886961C4B25162167A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "23A819A70FFC34417C3AB820E49DEF72256C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1A827B2C3D863749C939CCE06AF9D9E872CF",
                        "defaultText": "좋아, 모두 나를 쳐다보고 있어. {W:150}통했어!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4769DA9593D6434CCA7B4908615B66FE73E2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0B4042F3581ED4446C4915E3EA8D63642E0D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "2D8B72093B48784781181937BEFAA8D95AAC",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "80509BF09BD9B14D6B89F510FC6B50931057"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "2D8B72093B48784781181937BEFAA8D95AAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "30B82E2C68CE11438A2BCD218E1AC03030F0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4E669F307688F9457F791C879F28BFF09A46",
                        "defaultText": "뭐야, 이 자식아?"
                    },
                    "position": 0,
                    "characterId": "2D8B72093B48784781181937BEFAA8D95AAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7B320FF366981640E0899625B59AEE5BCF8F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "775ACF770C6B91436558CC76EED6A56685C7"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "Sarcasm",
                        "type": 0,
                        "value": 50
                    },
                    "targetVariable": {
                        "name": "sarcasm",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DC8B9A5B130E264B3E4B42D40EED5D71751D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "4614F4C36FC14449CF1887A58B4829485F93"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3797AB864084C140CA4BDA21AA727ACA7585",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E3-Ornieres_line19.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "429AE2511DABC84C4C79E9F30D925847FA72",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "46A0BC718125C64D2A1BE83243C460EBA25E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3AA06C90855E024F1548D47380ED70B4DD9F"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "sarcasm",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 60,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 4,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1FA874604CD15543987A17134F270395E213"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CCE7378341A1604E719B3E62020A438759E2",
                        "defaultText": "흠흠, 루코스를 쫓고 있으니 \"우웃 같은 자식\"이라고\n해야 하지 않을까... {W:100}{W:200}하하?"
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "E081BDE52B5CF647313A344118BD3FFD2AE9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "134C55203F64F1472D39F8C355BF46CA5EF0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "2D8B72093B48784781181937BEFAA8D95AAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "C993889A049BD045F7286027C3FB291DDD71"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A80E798C2140E644CC18C1E91C8A4D6B8C24",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "2D8B72093B48784781181937BEFAA8D95AAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "61F573C2381A574E463BC9713D25EABE3A5A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "DF8BD9F91C3FA74B583904B73DCB006F09F3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "C668D157625D50483C1A59E3F777C24F275E",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "4D877DBD102D684CB479F5E98845AB7DC43E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C668D157625D50483C1A59E3F777C24F275E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "5CD2BDCE51E3B54F2E9B7934B49D2A655103"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A5F1A3EA89E2F740F14AA148618FE0290AD3",
                        "defaultText": "이 자식 바보네. {W:200}뼈를 부러뜨려 주자."
                    },
                    "position": 0,
                    "characterId": "C668D157625D50483C1A59E3F777C24F275E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "032E0F968BADD549673A39763C23B3161637",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "801F9A437285624B560A9A03AADD6A6EC043"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "2EF3D1B46141C2400238F1F63879BBB45016"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "5640059378D62541B4281122154792A0F5BA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AF1B98B819733342DD6A0F225CF2A45B50E8",
                        "defaultText": "젠장, 안 통했어! {W:200}오히려 아까보다 더 난폭해진 것 같은데...{W:200}\n빈정거리는 연습을 좀 더 할걸..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "1FF5CD1719E3D64E299901B275B6708BDE4A",
                "expanded": true
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "le funny",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "8872D48E714B6148DF59A53353FC99E92EEF"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "C71F85D080B5F6455E588641A62A248496DC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0A7BB2F5158F6741F87888825FE236AF5C91",
                        "defaultText": "신사 여러분, 여기서 뭘 하는 겁니까?{W:150} 못된 장난? {W:150}동물 학대?{W:150} 아니면 둘 다?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "D2287D020DBA744FDA594DA0D78464FD408E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "AD42DB6F79C868496D983DA51D599C4555DD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "88FA56088D20C74BAF6B2A13D1527A9B2CC7",
                        "defaultText": "당신들을 반으로 베고 싶진 않습니다.{W:150}\n그래도 50퍼센트쯤은 \"멀쩡\"할지도 모르지만요...{W:200} 말 그대로."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "95101708712FA14344286567B0DA4D69052B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "5CDA49563C52834FB96A6BD8C817F9F57661"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "2D8B72093B48784781181937BEFAA8D95AAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "A212D8805FE9C64DED8AA784213CC7CD5FEE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F229CC0542C1924E1E2834D3EBFCD22FA0C4",
                        "defaultText": "... ... ...{W:200} 푸훗."
                    },
                    "position": 0,
                    "characterId": "2D8B72093B48784781181937BEFAA8D95AAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "FFC83CA7186BD24C6C8BE2739D04C83402F4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E139338E618742480228F976007AA1166322"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "C668D157625D50483C1A59E3F777C24F275E",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "4B7E3E328395F34C348A113252F618D96A10"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C668D157625D50483C1A59E3F777C24F275E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "C7046CBE8B8CA246E3790031025383E6C065"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B6BE8D2F23848844B508D6331E6891DDA87B",
                        "defaultText": "뭘 웃는 거야!?"
                    },
                    "position": 0,
                    "characterId": "C668D157625D50483C1A59E3F777C24F275E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "34D8204D721B634C90996C51FCB7BD5F14E0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "3B37E40037B1B149821AE51313DFF5BF7F59"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "063E15850514424EEF38CC25BF6765644887"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "50F4AEBA20F1844BEF898C7301D9AFD47D61"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D3B2D71A3E7691422A78FAC148F69D2EC47E",
                        "defaultText": "내... {W:200}그러니까, 전술 때문에 혼란스러워하는 모양이군.{W:200}\n빈정거리는 연습을 해 둬서 다행이야!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "80A64EB27CC8034B103995388D979154894F",
                "expanded": true
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "le funny",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "1463C81E554CF14D320B18427D51937B648C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E2FA6FC24F2D4649D17B0E231E979EFB00BC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "813EAD41874A274F51594BF8FFE767A3AA6B"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "2201A3A019275648C268E662BA3981EDF136"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "battletime"
                },
                "indent": 0,
                "uid": "E526ED4210A8684AE06A13532169DB8821D4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1AF9D8003716234CC628C72862C0A860D152"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BA678C4D92D3D3424C8921B562714FB1A18C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "04A05D4F9028D84D44393CC75C045F4FF230"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "8E049A6763063848E11927D2FC6CD43CCD19"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "20A4973734E2734E035A8E859400A3964B52"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BF4181E3759F31453A399FD466554E584648",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Nana_line7_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CDBEAA8A68645344F908F53517B4BD978393",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B46667DB566863464258B9D7B15C5C13D4B0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C6252E2090B5654CE66A138332752875F41C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6B90648230ED154EC128B6481A3AE177CE88",
                        "defaultText": "손님, 싸울 거라면 이걸 가져가세요!"
                    },
                    "position": 0,
                    "characterId": "FA72429357D43349B2781CC7A1E2818C5673",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BF20D8514C4CB748586BC124F026D560B682",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "79209BE631D12945661972D6BCC55BA2DE31"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B8147072216CD74180580EC5090E655A7E36",
                        "defaultText": "상황을 완벽하게 분석한 결과, 분명 필요할 겁니다."
                    },
                    "position": 0,
                    "characterId": "FA72429357D43349B2781CC7A1E2818C5673",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "42E69BFB164A374AAD1BDA53E17389E86B81",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8E560C192A2BE64BCD4A0E27DCC3BD498A9E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "62D2973997C4224BBC4ACE13372BE4EF793A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "94A70D8375BE2147235A60F41F735D53BBFE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E533F7891CEE14463F3858E34FA913B29485",
                        "defaultText": "어... {W:200}고맙습니다?"
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F0E4316214EDE34414387BF8BFD652A283A5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A2EEA3C536D50549DD4A191838C80FAD3D72"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "48F5342A34F8564BF34A548850BC2A071831"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "825871143120B74EF14A1216312D4A328F9E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0311BE5092E2034F93688BB62C6E859C7032",
                    "parameters": {
                        "values": [
                            "DBCC07963EC0714BE4591A10760592A3B968",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "DF5F961D47C2E8467D29C0E32C3E83E74283"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EEC637476CA0C44DB639DD3814A41B3AF9DE",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C58FD7F55852844A4B5A6EB2E9486FEE4F36"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "DE116176372678433958D762B8901BA0166B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "4EBAE4782D3960403E8851D3E7C4EF1EB98D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AF7645FB69BD8641768BA405B639CBEAF747"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0EC4BB445C0D924A863ADE2573586A26FF84"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "3DAE9BA11EE721461C2A5AC9A08F707A51AB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FFC1544B69C9F349EF59ABF45F49A6D34B75",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "LUCKOS_BARK_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2A3A2763865C034A242A4662767536B938CA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "7F6272060D66824DDC3B26D5F4035593F375"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AE1536393E244941DE7A37B58451519C08A0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "31D7718A78BDA84812391511E5BFE46D28C0",
                        "defaultText": "우웃 우웃 우웃!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6F7FF74D782BF6480E290788CAFC4211214F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8EA248AC3082034D0638E5625F466FFE8F78"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "77A82DE585C5754F2E5AD30641DD451F3151"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B5B76BE247D18843646B1C269FDEA17F736A",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E2-Ornieres_line12.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F520A1710A7A9240D98A64A453BB0ED4A065",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "FD0878D3506C6442987B7F87E97026CB9D7B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "066D47516953D3416C28FA664601928994D0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BA35BF2A024B91433198B201503EE53C9B1E",
                        "defaultText": "아주 안도한 표정이네? {W:150}걱정 마. 저들이 널 해치게 두지 않을게."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C62244158ABFF14CC1082C97548C38BE1E6B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5C7E9107281B7949523B5F138B317C21DDA3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "00E9834F8A5C3446B19AD78714881111C0B1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A7AA91E61DDFA64DCA7999D06880E581B6B8",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "LUCKOS_BARK_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CA0A8A94688776487F290DC6B6E36179262C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "450BA5BC15DDC84DB63A86925CDE8ECAC02F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "405F2C6150EB85484019DA15F5F129963AC2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C46EC79A7CE325416F78B9C9EC8C726AF2D2",
                        "defaultText": "우웃!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "00A661BD89942848647935A2C2ADCF0D2063",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "08E89C3686D25749140B86742AA197DAFCF6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "2D8B72093B48784781181937BEFAA8D95AAC",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "89E6B5EB1C815046347AE616C3804C00E11C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "2D8B72093B48784781181937BEFAA8D95AAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2C2FB4038E65A24AD9598039705830A34717"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "le funny",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2EF77E5C2A0078483C5A93345AA382C3E1A4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D82FA9C0568C0848191997F6F543EB575DC3",
                        "defaultText": "시비 걸러 온 거냐!?{W:150} 저 늑대는 우리 거야!"
                    },
                    "position": 0,
                    "characterId": "2D8B72093B48784781181937BEFAA8D95AAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "E1738AC75DE694491D3A6AD12F89D2339056",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "D20963B051F1B8404F2AA57695C436C832D6"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "388BA8579879B442F54B9EB3D7A2D5CC46FE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FD6D246B060C3841B85B47E2E26477AB0E66",
                        "defaultText": "재, 재미있는 자식이지만 봐주지는 않겠다!"
                    },
                    "position": 0,
                    "characterId": "2D8B72093B48784781181937BEFAA8D95AAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "187FADDF7442C74DB96B80426274E42AAE2B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "1EB2AC53933D02474C089143DA3713DC38F1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "2D8B72093B48784781181937BEFAA8D95AAC",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F4C1135A44958543258A26289880DDCDE166"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "E15FC7117CEA964955283F14D303C51A3E54"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "C668D157625D50483C1A59E3F777C24F275E",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FA0300475F76934DE77A34D739580AFDBBF4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C668D157625D50483C1A59E3F777C24F275E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B584EBDE3D02B5437F7882C5B994C03B7037"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C22724C555825444AC8908B02320047BBAEE",
                        "defaultText": "그래, 비켜! {W:200}저게 우리 골드를 훔쳐서 어딘가에 묻었어!"
                    },
                    "position": 0,
                    "characterId": "C668D157625D50483C1A59E3F777C24F275E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E355C6F7296C344673292903610F38A720C2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2FA67F511A89D1405E681645D90DE6380F35"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "88485997226FE84D485A98564B2B937332AA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7B1228C352751944EE898B8738219BA39002",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E3-Ornieres_line26_3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "845EC031187E764A772B24C6981F4887ADCC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E1F50A9F2384884E0189118581F6E5326C85"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "749BD58E28DDF24565392E00FEA03D458ED4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "293CD234453C074D92785F19D5F707083063",
                        "defaultText": "... ... ...{W:300}네가 뭘 했다고!?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C886C0E747B5D642BE28F3C1DED5536CDB4B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0CDC3EFB75D7914FE629FD9126DB1B3535C5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "765BB0A9370F264D1D59C515813A064AD024"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9D01EC240EE6854DE138A4D40A403E06A4BE",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "LUCKOS_BARK_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A3939F8881F7534A365806A63D9E48A8C78C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "7074B6E344E8124FD72B97C3E4681DE5C331"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3E051AD27D0DA6431E38FAA3DDE63E26166E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            5
                        ]
                    }
                },
                "indent": 0,
                "uid": "072DD49C03FBF84CA99B35D77F054DACD730"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "567413E053C904410B3A8AE796BFC15D2FCB",
                        "defaultText": "우웃."
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F24874D98EA9664003098591CD7BDC4A282B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "376124BF625C744F9A6BABA2617026DB9664"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DEDE86C07E55814FE57BC7104A81068CEA99"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "853BFBFE8994434AB11B7846C8F86F9AD5FD",
                        "defaultText": "인정하기 싫지만 수적으로 크게 밀려. {W:200}시오리도 도와주러 오지 않았고..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2C126E090D833748E72AB77828C7255513CA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3D9C7E4F0039A045A52822D1F89176A4E994"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E01EE2DB22F87145D97A4F6236700C67D52F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3E7079092D7B70487E09F89120E720E732F4",
                        "defaultText": "다른 방법은 없어. {W:150}내가--"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0566720016399640AA69DB436858A3F77962",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BE4548372463234D9F18E2A8E8C0D44EF2B0"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "REMEMBRANCE SHORT.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7CE9C81163EEC542CD3878F05237F1A5E665"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255,
                                "color": {}
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 80,
                    "blendMode": 0,
                    "zOrder": 5010,
                    "duration": 12,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "sfondo nero.png",
                        "folderPath": "Graphics/Pictures/CG Gallery",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "7CBAAC96897E754BCB1895A4759C2DAC9169",
                "expanded": false
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255,
                                "color": {}
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 86,
                    "blendMode": 0,
                    "zOrder": 5010,
                    "duration": 12,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "2) sword and corpses memory.png",
                        "folderPath": "Graphics/Pictures/Memories/Bloody sword",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "E02675DD7B1E0148231B8465CF68007F7FBD",
                "expanded": false
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255,
                                "color": {}
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 87,
                    "blendMode": 0,
                    "zOrder": 5010,
                    "duration": 12,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "3) sword and corpses memory low opacity 1.png",
                        "folderPath": "Graphics/Pictures/Memories/Bloody sword",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "D94E084F45FC404E3D3BC4B5BAD09DE23623",
                "expanded": false
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255,
                                "color": {}
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 88,
                    "blendMode": 0,
                    "zOrder": 5010,
                    "duration": 12,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "4) sword and corpses memory low opacity 2.png",
                        "folderPath": "Graphics/Pictures/Memories/Bloody sword",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "DB7BC5EB852B9040F34B32E4798CB1D4CE42",
                "expanded": false
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255,
                                "color": {}
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 89,
                    "blendMode": 0,
                    "zOrder": 5010,
                    "duration": 12,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "5) sword and corpses memory texture.png",
                        "folderPath": "Graphics/Pictures/Memories/Bloody sword",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "C3F3D0B9958F254A5B1AB1A502BC2756CE4F",
                "expanded": false
            },
            {
                "id": "gs.PictureEffect",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 86,
                    "duration": 0,
                    "pixelate": {
                        "enabled": false,
                        "size": {
                            "width": 10,
                            "height": 10
                        }
                    },
                    "blur": {
                        "enabled": false,
                        "power": 0
                    },
                    "wobble": {
                        "power": 80,
                        "speed": 45,
                        "orientation": 2
                    },
                    "waitForCompletion": 0,
                    "type": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "D3A084989F896045AF48F7A34CDF0B533EB5"
            },
            {
                "id": "gs.PictureEffect",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 87,
                    "duration": 0,
                    "pixelate": {
                        "enabled": false,
                        "size": {
                            "width": 10,
                            "height": 10
                        }
                    },
                    "blur": {
                        "enabled": false,
                        "power": 0
                    },
                    "wobble": {
                        "power": 100,
                        "speed": 30,
                        "orientation": 1
                    },
                    "waitForCompletion": 0,
                    "type": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "5FF4CB7D24BA834EE43915A2FF4FF7D3096D"
            },
            {
                "id": "gs.PictureEffect",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 88,
                    "duration": 0,
                    "pixelate": {
                        "enabled": false,
                        "size": {
                            "width": 10,
                            "height": 10
                        }
                    },
                    "blur": {
                        "enabled": false,
                        "power": 0
                    },
                    "wobble": {
                        "power": 90,
                        "speed": 50,
                        "orientation": 2
                    },
                    "waitForCompletion": 0,
                    "type": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "A666512B77D1A742E41800B759DA10BDC36E"
            },
            {
                "id": "gs.PictureEffect",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 89,
                    "duration": 0,
                    "pixelate": {
                        "enabled": false,
                        "size": {
                            "width": 10,
                            "height": 10
                        }
                    },
                    "blur": {
                        "enabled": false,
                        "power": 0
                    },
                    "wobble": {
                        "power": 100,
                        "speed": 50,
                        "orientation": 2
                    },
                    "waitForCompletion": 0,
                    "type": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "DC4181969CCF4746461A42053AFB756AF681"
            },
            {
                "id": "gs.PlayPictureAnimation",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 90,
                    "animationId": "A71EE67348E3324C434BCA454F52B8FB0CF3",
                    "predefinedPositionId": 0,
                    "blendMode": 0,
                    "zOrder": 5011,
                    "duration": 12,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 1,
                    "position": {
                        "x": -94,
                        "y": -58,
                        "angle": 0,
                        "zoom": 2,
                        "horizontalFlip": false,
                        "data": {
                            "zoom": 2.3449521149208192
                        },
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 0
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4C16E50D959A1848D929A275724E42CE96D3",
                "expanded": false
            },
            {
                "id": "gs.TintPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 90,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": 175,
                        "green": 65,
                        "blue": 175,
                        "grey": 62,
                        "tone": {}
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5F328BC12CCFA743837B541958C11EF326B0"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "FFCA01092BEDB2420E38B0E6EE3EBB635AD2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            1,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "4A6208656D5BE54E1C58CE66574B6B37FBD7"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "4F618432824F944749697E636462C90328F1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            500,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "18A7CBDF6D5A404BE5599C413C6EE599E077"
            },
            {
                "id": "vn.SetObjectData",
                "params": {
                    "objectType": 0,
                    "number": 80,
                    "numberDomain": "com.degica.vnm.default",
                    "layer": 0,
                    "characterId": null,
                    "field": 7,
                    "numberValue": 720,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0
                },
                "indent": 0,
                "uid": "455D17FE87650240463A9E32AFFACA68694D"
            },
            {
                "id": "vn.SetObjectData",
                "params": {
                    "objectType": 0,
                    "number": 85,
                    "numberDomain": "com.degica.vnm.default",
                    "layer": 0,
                    "characterId": null,
                    "field": 7,
                    "numberValue": 721,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0
                },
                "indent": 0,
                "uid": "68C5D94B4EF74746803877082A07C27A200D"
            },
            {
                "id": "vn.SetObjectData",
                "params": {
                    "objectType": 0,
                    "number": 86,
                    "numberDomain": "com.degica.vnm.default",
                    "layer": 0,
                    "characterId": null,
                    "field": 7,
                    "numberValue": 722,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0
                },
                "indent": 0,
                "uid": "5BF35F47638BC14BEC49A9E65836A75E4755"
            },
            {
                "id": "vn.SetObjectData",
                "params": {
                    "objectType": 0,
                    "number": 87,
                    "numberDomain": "com.degica.vnm.default",
                    "layer": 0,
                    "characterId": null,
                    "field": 7,
                    "numberValue": 723,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0
                },
                "indent": 0,
                "uid": "0CA786132E6C6446B66A6CB90F7A96243876"
            },
            {
                "id": "vn.SetObjectData",
                "params": {
                    "objectType": 0,
                    "number": 88,
                    "numberDomain": "com.degica.vnm.default",
                    "layer": 0,
                    "characterId": null,
                    "field": 7,
                    "numberValue": 724,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0
                },
                "indent": 0,
                "uid": "7169B2E73BCFF2446F38D8041048D9B548E1"
            },
            {
                "id": "vn.SetObjectData",
                "params": {
                    "objectType": 0,
                    "number": 89,
                    "numberDomain": "com.degica.vnm.default",
                    "layer": 0,
                    "characterId": null,
                    "field": 7,
                    "numberValue": 725,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0
                },
                "indent": 0,
                "uid": "4B819D622AA6974BE47A61E6CD4C6CC3F28F"
            },
            {
                "id": "vn.SetObjectData",
                "params": {
                    "objectType": 0,
                    "number": 90,
                    "numberDomain": "com.degica.vnm.default",
                    "layer": 0,
                    "characterId": null,
                    "field": 7,
                    "numberValue": 726,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0
                },
                "indent": 0,
                "uid": "D5CB9ECD39AF87453B3AB025CACA04AE5C8D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "D806B8CE51EA324421191A01258C30E6CE47"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D9408CCF5331654DD94828D7D18EE1D23B41"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "62C815822EA80947693AB112263E84C79395"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "94B688D57E76C942FF7ADAD23EDC6749CB90"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6D13318E3A35734B1D69F0317038D1DE2FA1",
                        "defaultText": "내가...{W:200} 전부 죽여야 해..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B1E1E1DE56F5254DFC19ACB7B6908591ACCE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9A4B755C6D2DA5489D5AD944424B76CA40D2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "07C13896230D964D2C7AFDA0E5CCF2503D3C"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 80,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "8C0A277F355148483F8A2A48E8AE9496CCC6"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 86,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "96BCA07C1A48354E8C2B55724054EA44B213"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 87,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "C854E9C912463242EF1AA40399D97CE5AB20"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 88,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "DC57F1D10F17954FEE189386B33ED935486A"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 89,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "50E1A6C81D61D248903B6ED231275AB029E7"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 90,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "8E04DCE53F20D84F185AA00877C972B0F4E9"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "39044BD312122443F72B8801C2A7A496C9C7"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "99C1C4A37414D144082BD4090B87C0DC29E3",
                    "param": {
                        "name": "Livello",
                        "type": 0,
                        "value": 0
                    },
                    "numberValue": 1,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "DAFBAF601642E14F6C5B65C608589175AD2D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "422B49CA8A63A04CB338ADD9E56A9BFB25A0",
                    "parameters": {
                        "values": [
                            "",
                            {
                                "lcId": null,
                                "defaultText": "{C:1}Suzaku{C:0} can now use {C:2}Stella Triplet{C:0}."
                            },
                            "",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "452AFDA28B3F6441738B7540F48AB7F4C9A2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6FE3C1466BE6D749E93B1A1763C2A8DE2900",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "0025A0A24B490245E37899F1556D1555279B"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "998350F56BEE364A538AA5C3D675454B62C4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "68EA875F252F254CB3794C07A8C659523359"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2FCA3061490D034368389A24F2F2C5502A2A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "CA7270777929F747C76BA2C3C5ED50AF7682"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DD44E6BB555E1642357AD0565458BE151EB2",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E2-Ornieres_line4_3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6EE0B70368BD7449F77BE7F5E56BCA53E779",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "CAA738E0182306460939ACE548E4CCF2008B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DCAC08941E1150421A8AA695D7DB9B1AFF33"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "86F8D5583930E64A9D48C662B6C0486B61FB",
                        "defaultText": "으윽... 안 돼! {W:200}내가 무슨 생각을 하는 거야!?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7DB537387100F14D2129F3459A3F0CA03C20",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "742D357254B1554D0F783BF603DD314EEDF5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C018537D7E99A445BD0AE67705A7ACE107C4",
                        "defaultText": "하지만... {W:150}왠지 그 환영 덕분에 잊고 있던 검술을 떠올렸어..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "63DAA90A18E0444C9598E68124F6815FA79E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B951D25214AC064B4E1B4AF86ADEEF462C18"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "C668D157625D50483C1A59E3F777C24F275E",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "34C0EFE88E3E904EF91A7978CE231F083A57"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C668D157625D50483C1A59E3F777C24F275E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "35E3B56A3E908444871B52D90A33DA463FDE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "49808C758CF3964D5E6BD8D4144FFBAC5587",
                        "defaultText": "저 바보, 벌써 죽기라도 한 것처럼 구는군!{W:200} 잡아!!"
                    },
                    "position": 0,
                    "characterId": "C668D157625D50483C1A59E3F777C24F275E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9D65A11916E3F544121B4D24B1FBE87106FF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F18402A408E0D1431B6A3AA858AEE0849BC5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FE144E959FCD8345094AA7029827ECCF2918"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D47D8FF269F85446FF2A8393913B55738AA0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7D14B10A40648643D54B7BF5272E0172C24E",
                        "defaultText": "신사 여러분께 예절을 좀 가르쳐 드려야겠군요.{W:200} 오십시오!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "38B2A5642C14024DAA18D27329AF92C87E5F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "96E8865C46A6744AF298785563F5D69BB4F3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "AA64B49E2B5564462B5A6212137B495A4F29"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C06F84CA22AE644F064907E51BA4B46DE478"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6ED53D5F469F90423B6B7488BDF81B695A0D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "42A1404366CF654160787A017D7EDE580113"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5E213A5F881AC2485109DFB622DF4EE32E23"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Map",
                        "name": "Black_Transition.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "177116FD02462445377B3622DB794552B12A",
                "expanded": false
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255,
                                "color": {}
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 1300,
                    "blendMode": 0,
                    "zOrder": 0,
                    "duration": 75,
                    "origin": 0,
                    "waitForCompletion": 1,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 2,
                        "movement": 0,
                        "mask": {
                            "graphic": {
                                "name": "19.png",
                                "folderPath": "Graphics/Masks",
                                "hue": 0,
                                "opacity": 255,
                                "blending": 0,
                                "tone": {
                                    "red": 0,
                                    "green": 0,
                                    "blue": 0,
                                    "grey": 0
                                }
                            },
                            "vague": 50
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 0,
                        "zOrder": 1,
                        "blendMode": 0,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "sfondo nero.png",
                        "folderPath": "Graphics/Pictures/CG Gallery",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "1996F04560F0A2468C3B722414C30DDF24AE",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "B8327CDC5C57C1491078E3D1B12DA412BC4D",
                    "parameters": {
                        "values": [
                            2,
                            2,
                            0,
                            0,
                            "19942F589EB79743595929F6FE3D6B1EDDA8",
                            1,
                            1,
                            "D97BF8962BA4F645521A0BC31C6F946DD645",
                            1,
                            2,
                            "19942F589EB79743595929F6FE3D6B1EDDA8",
                            1,
                            2,
                            "C0AD3BF87D39C446994829924FA714A0531C",
                            2,
                            4,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "D6F767E57EBE46449E895730A110B50B6065",
                            "Graphics/Avey's Battle Backgrounds/Tarmen Plaza.jpg",
                            "0130AF490DF5934612891A4097CDBEC27118",
                            5,
                            {
                                "name": "le funny",
                                "index": 0,
                                "scope": 0,
                                "domain": "com.degica.vnm.default"
                            }
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C9456E04210A124C933869098C02DCD074B5"
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "D6F767E57EBE46449E895730A110B50B6065",
                        "name": "NORMAL BATTLE"
                    },
                    "savePrevious": 1,
                    "erasePictures": 0,
                    "eraseTexts": 0,
                    "eraseVideos": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "28037EE32ECC55463B688014F9D1700833B9",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "B9875E352C32F445CE2B75D3A797A3F94215"
            },
            {
                "id": "gs.FreezeScreen",
                "params": {},
                "indent": 0,
                "uid": "51B708615035A2486F8946141B406F03F198"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "368AF5B15E7F364B1B0B0BD21AEFDEC920ED"
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "08F2DF355D64E44CEA883C770B7A9E8F66BD",
                        "name": "C1-05c After saving Luckos"
                    },
                    "savePrevious": 0,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "286BE31123B3764D565B97874A58CDB87C24",
                "expanded": false
            }
        ],
        "booleanVariables": [
            {
                "name": "le funny",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "numberVariables": [
            {
                "name": "sarcasm",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "stringVariables": [
            {
                "name": "name",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "stella name",
                "index": 1,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "stella desc",
                "index": 2,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "listVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}