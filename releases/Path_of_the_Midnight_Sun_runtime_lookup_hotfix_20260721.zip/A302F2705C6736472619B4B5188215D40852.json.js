GS.dataCache['A302F2705C6736472619B4B5188215D40852'] = {
    "uid": "A302F2705C6736472619B4B5188215D40852",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C2-06 (event3) Pre-battle Hellios join",
        "type": "vn.scene",
        "parentId": "99DA0EDB61147349907BFA1749D8565E8571",
        "chapterUid": "821526CB730C524E8E8AE3E37167B67D0B30",
        "order": 4,
        "localizableStrings": {
            "474BDA11786FC74838585AA1EE0B9A82707E": {
                "t": "Just what's going on? I must talk to them! T-There must be some sort of misunderstanding!",
                "d": {
                    "cid": "B29C753D58E5974A8B3A68575D84136FE572",
                    "eid": "E3927E0D8F7AC64E4A2A6C00EA39D0F0F699"
                }
            },
            "6F6FFA5078E468492719E57859D82B87716A": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "BF9D447F151649429628C957C72F74AF3703"
                }
            },
            "A4D6F9337048934F917AA7E708D7ED1E3730": {
                "t": "Clear your mind!",
                "d": {
                    "cid": "AF4010B54C32274CE79A6849136238271A16",
                    "eid": "0AEF505285631341F39A65847DC854EDBF40"
                }
            },
            "C5A81FB943A0C24AB0691528ED41A3C95220": {
                "t": "These soldiers want to kill you, don't you realize that? You should at least fight back!",
                "d": {
                    "cid": "AF4010B54C32274CE79A6849136238271A16",
                    "eid": "1CB112708DD8C7412F5A83C4FC2895007E12"
                }
            },
            "06B986B48C58A6414A8A2D65E0CF23934514": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "5509CA0F9FD393411359E48152135831F8AC"
                }
            },
            "0C298D5510C32149CA0A8401D8ABFB796D9C": {
                "t": "Are you mad!? These are my people!",
                "d": {
                    "cid": "B29C753D58E5974A8B3A68575D84136FE572",
                    "eid": "9E4FD32881EDE44DB52B3C788517652A90D4"
                }
            },
            "F070B1AF489AF74D6258EB35514A62B3F899": {
                "t": "Trust me, this isn't the time to think about ethics!",
                "d": {
                    "cid": "AF4010B54C32274CE79A6849136238271A16",
                    "eid": "ACC9FB4259FC544D248AB406C02C6BE42A36"
                }
            },
            "AD16960E1DF32141105815746EDE8F35D009": {
                "t": "The elite soldiers will be here in no time.",
                "d": {
                    "cid": "AF4010B54C32274CE79A6849136238271A16",
                    "eid": "E115BBC941DF6440384879089F74960DD5ED"
                }
            },
            "BA5956FD0158664E9398EFA82B2996833D71": {
                "t": "Before that happens, we go to your \"Master\" and have a nice little chat with him.",
                "d": {
                    "cid": "AF4010B54C32274CE79A6849136238271A16",
                    "eid": "E0EC741B877E254305087443FBA92EB03ABC"
                }
            },
            "F4CAD4F03914D34B5A49DF97D944F5348B64": {
                "t": "But...!",
                "d": {
                    "cid": "B29C753D58E5974A8B3A68575D84136FE572",
                    "eid": "CFA99F282A5CA641683A4536B018A7677706"
                }
            },
            "3932B89948714446ED88911841F08A622258": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "C50196191C53814BBF7B7EC4EDDD478DC9C1"
                }
            },
            "81D5849258EFB341716A3B8870B2E8B32137": {
                "t": "No buts! Now fight back or get killed, it's up to you!",
                "d": {
                    "cid": "AF4010B54C32274CE79A6849136238271A16",
                    "eid": "C5420B6048A3154A21491884D871CA554C74"
                }
            },
            "608E67FA76D1E94D60498676FE7665F8F524": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "7DA9D2266ABF9243049B32E42D3B845109FD"
                }
            },
            "D5FFD8DD55A875452E1AAD317166C96153AC": {
                "t": "Gods... do I...\nDo I really have to do this?",
                "d": {
                    "cid": "B29C753D58E5974A8B3A68575D84136FE572",
                    "eid": "FDEBF4683D85124C7B8AF6E2E6F88D307F37"
                }
            }
        },
        "commands": [
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "B489319D82D2154E241899E2470204A48F5D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0A5394441DFE9942C23BB1177D61A379F547",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6A8CC1211202F647AE68B3F112C663F2DD63"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "02EF21C36393B4496049B238D012488E0ACE",
                    "parameters": {
                        "values": [
                            "B29C753D58E5974A8B3A68575D84136FE572",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ABCC08375665874F6E492597C2CA86E94A1F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "02EF21C36393B4496049B238D012488E0ACE",
                    "parameters": {
                        "values": [
                            "AF4010B54C32274CE79A6849136238271A16",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "745CE5C09B52654C2619F4D30034CF73E016"
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "B29C753D58E5974A8B3A68575D84136FE572",
                    "eyeBlink": {
                        "enabled": 0,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 1,
                    "idleIntensity": 1,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 1,
                        "idleIntensity": 1,
                        "lipSyncSensitivity": 1,
                        "eyeBlink.enabled": 0,
                        "eyeBlink.interval": 1,
                        "eyeBlink.closedMotionTime": 1,
                        "eyeBlink.closingMotionTime": 1,
                        "eyeBlink.openingMotionTime": 1
                    }
                },
                "indent": 0,
                "uid": "823DC4472959A64C98695325B7BD032C761A",
                "expanded": false
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "B29C753D58E5974A8B3A68575D84136FE572",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Faratras Overworld.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "03_Dying.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A8C903152D196647B48BE054241EEEE823DD"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "ECE6A7E84E435749A99A0B21E9326B1E10B7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D007E02518D24249142A32F1FBFB0EC659E0",
                    "parameters": {
                        "values": [
                            "B29C753D58E5974A8B3A68575D84136FE572",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E921B92473CEB24866684C5531C4B837F23A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D007E02518D24249142A32F1FBFB0EC659E0",
                    "parameters": {
                        "values": [
                            "AF4010B54C32274CE79A6849136238271A16",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "F08076E00943D649763ADC67AE2B3A148556"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "B4849383158B3246AA386AA319C6740CC794"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "B29C753D58E5974A8B3A68575D84136FE572",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3A0D58FC8CBE334A803ABFF3A5C5CCD2E2CF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "474BDA11786FC74838585AA1EE0B9A82707E",
                        "defaultText": "대체 무슨 일이지? 저들과 이야기해야 해! ㅁ-뭔가 오해가 있는 게 분명해!"
                    },
                    "position": 0,
                    "characterId": "B29C753D58E5974A8B3A68575D84136FE572",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E3927E0D8F7AC64E4A2A6C00EA39D0F0F699",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "FAE3FEAB3D285343B918D704E4567D05B360"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "AF4010B54C32274CE79A6849136238271A16",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Hellios Overworld.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "01_Resolute.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "91F1C09E3A093740D1188B9284B278E01217"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C5633DCE2D3CA142A47B6FA5AC3132944C8C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6F6FFA5078E468492719E57859D82B87716A",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "E3-Hellios_line25_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BF9D447F151649429628C957C72F74AF3703",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E53829B05922644C5668E7D99661EC1B2EC1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "AF4010B54C32274CE79A6849136238271A16",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CA45B6D581727242652AEE216DBC80AE5196"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A4D6F9337048934F917AA7E708D7ED1E3730",
                        "defaultText": "정신 차려!"
                    },
                    "position": 0,
                    "characterId": "AF4010B54C32274CE79A6849136238271A16",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0AEF505285631341F39A65847DC854EDBF40",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "64AB04191A6891420D490C386192640081B0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C5A81FB943A0C24AB0691528ED41A3C95220",
                        "defaultText": "이 병사들이 널 죽이려는 걸 모르겠어? 적어도 반격은 해야지!"
                    },
                    "position": 0,
                    "characterId": "AF4010B54C32274CE79A6849136238271A16",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1CB112708DD8C7412F5A83C4FC2895007E12",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "7AA6E9F17CA24941BE7A44018025AFBA51D6"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "B29C753D58E5974A8B3A68575D84136FE572",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Faratras Overworld.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "04_Resolute.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BA5C76B0877CC74D5309697297082539DDC9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C0B88BDF62B9C449661BCEF904076BCB7CD4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "06B986B48C58A6414A8A2D65E0CF23934514",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C02-05_line4.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5509CA0F9FD393411359E48152135831F8AC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "0F5B14962ABCE84CDA497A85E747FEDC98E2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "B29C753D58E5974A8B3A68575D84136FE572",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "99924FE1388DC7401288D167C786D13A1EFD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0C298D5510C32149CA0A8401D8ABFB796D9C",
                        "defaultText": "미쳤어!? 이들은 내 백성이야!"
                    },
                    "position": 0,
                    "characterId": "B29C753D58E5974A8B3A68575D84136FE572",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9E4FD32881EDE44DB52B3C788517652A90D4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "A3D98E942108A6478C8BC7C168BB72B918ED"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "AF4010B54C32274CE79A6849136238271A16",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C25CC727804E534A96097168A69897DD99CB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F070B1AF489AF74D6258EB35514A62B3F899",
                        "defaultText": "날 믿어. 지금은 윤리를 따질 때가 아니야!"
                    },
                    "position": 0,
                    "characterId": "AF4010B54C32274CE79A6849136238271A16",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "ACC9FB4259FC544D248AB406C02C6BE42A36",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B816519341039244D97BE32376C59068B023"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "AF4010B54C32274CE79A6849136238271A16",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Hellios Overworld.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "00_Default.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B97C4F987DB5554CFE5B89B321FAE79FEFF7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AD16960E1DF32141105815746EDE8F35D009",
                        "defaultText": "정예병들이 금방 들이닥칠 거야."
                    },
                    "position": 0,
                    "characterId": "AF4010B54C32274CE79A6849136238271A16",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E115BBC941DF6440384879089F74960DD5ED",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AAC2DFAA13809049B94B99C6C6E9422184D3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BA5956FD0158664E9398EFA82B2996833D71",
                        "defaultText": "그 전에 네 ‘스승’에게 가서 차분히 이야기 좀 나누자고."
                    },
                    "position": 0,
                    "characterId": "AF4010B54C32274CE79A6849136238271A16",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E0EC741B877E254305087443FBA92EB03ABC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "5C0DFCFB43E6384E102930C10371F969D048"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "B29C753D58E5974A8B3A68575D84136FE572",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Faratras Overworld.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "02_Troubled.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "76554C789C0FD84D777806E34D4F67B7848B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "B29C753D58E5974A8B3A68575D84136FE572",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6E2178CF2E5A71416249097519681065F68C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F4CAD4F03914D34B5A49DF97D944F5348B64",
                        "defaultText": "하지만...!"
                    },
                    "position": 0,
                    "characterId": "B29C753D58E5974A8B3A68575D84136FE572",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CFA99F282A5CA641683A4536B018A7677706",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "A7BFC50735FC114C0F29A9788C7727240A84"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "AF4010B54C32274CE79A6849136238271A16",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Hellios Overworld.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "01_Resolute.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DA9D81B7180B5345022B32B87B2C822B3AEF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "2394FA0D7B2E1441157AB9A4276DAF5D9DAF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3932B89948714446ED88911841F08A622258",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "E3-Hellios_line21.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C50196191C53814BBF7B7EC4EDDD478DC9C1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B96605744D9D98457B4A18E1D43F0045BAC4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "AF4010B54C32274CE79A6849136238271A16",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7E738ABF28D0C346016B5BE751C8D978A1B3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "81D5849258EFB341716A3B8870B2E8B32137",
                        "defaultText": "토 달지 마! 반격할지 죽을지, 네가 선택해!"
                    },
                    "position": 0,
                    "characterId": "AF4010B54C32274CE79A6849136238271A16",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C5420B6048A3154A21491884D871CA554C74",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "12B29BEF6746B94C212BF056082ED0259164"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "212458D23DAD504CDE488802C2A4609E69F4",
                    "parameters": {
                        "values": [
                            "AF4010B54C32274CE79A6849136238271A16",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "02C3010C7BE0C5414D5A36B49A48358F7BD6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "212458D23DAD504CDE488802C2A4609E69F4",
                    "parameters": {
                        "values": [
                            "B29C753D58E5974A8B3A68575D84136FE572",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6B8807907C6E68439B9A1F30273BE6BC2D10"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "A294689E2827324DD429BBB0C5E843F3CEAD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0A5394441DFE9942C23BB1177D61A379F547",
                    "parameters": {
                        "values": [
                            0,
                            1,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "78BA45322FD5F841F65963F12F0CF93D56FD"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "507135FF1A30844CEB98B607CBC33E82773B"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "BE6449BC9031144F8749FD15583C1785CF42",
                    "loop": 1,
                    "fadeInTime": 1,
                    "data": {
                        "model": {
                            "name": "HelliosChibi.model.live2d",
                            "folderPath": "Live2D/Z3 - Chibis",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "side run R.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7758517A4869474B1759D4847F90B85E5C19"
            },
            {
                "id": "vn.L2DMove",
                "params": {
                    "predefinedPositionId": 0,
                    "characterId": "BE6449BC9031144F8749FD15583C1785CF42",
                    "model": {
                        "name": "HelliosChibi.model.live2d",
                        "folderPath": "Live2D/Z3 - Chibis",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 1470,
                        "y": 390,
                        "zoom": {
                            "x": 1,
                            "y": 1,
                            "d": 1
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 36,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "96EDA69055AF86478D6A1972D9EB82C12FA2"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "FDD11F9A5663D54BCB186CC1AB2B1992862E"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "BE6449BC9031144F8749FD15583C1785CF42",
                    "duration": 12,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "CD977925178F5843CE482BC421CB41BF1663"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "55A4D6C24B782440B07AF2E74BD6EE05981F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08B6930722F90640139BB772D8B05FFAE61F",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            10
                        ]
                    }
                },
                "indent": 0,
                "uid": "9FF11F1610F2424A929A6E7561FBB09EE449"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "B153D2291649B7460E3B95098FC31B34C4A4",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "75283E479424B847D328FDE22495FF9117C0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "7F032ED40BBD344D8E48EA4634631B75AA85",
                    "parameters": {
                        "values": [
                            9,
                            100,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C49A91AA6B4482444C4AB175805F3D6C4E35"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "422B49CA8A63A04CB338ADD9E56A9BFB25A0",
                    "parameters": {
                        "values": [
                            "",
                            {
                                "lcId": null,
                                "defaultText": "New party member: {C:1}Hooded man{C:0}."
                            },
                            {
                                "lcId": null,
                                "defaultText": ""
                            },
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2A75391A2704C344C80A7A7011417329AA40"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6FE3C1466BE6D749E93B1A1763C2A8DE2900",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E81AA3835245B04F93582E62F04DCABD1490"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "5C5975BA3CF4E1474C99BF777617DD967471"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0311BE5092E2034F93688BB62C6E859C7032",
                    "parameters": {
                        "values": [
                            "DBCC07963EC0714BE4591A10760592A3B968",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "A0E8CB678E1EA14BAC4AC8866C8E4AA36219"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EEC637476CA0C44DB639DD3814A41B3AF9DE",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "ADF26ED177B2454A1D39BC34D4D4A9A38C8B"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "0A9C9F2F5FCF7444B16B36109A0655E4C087"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0311BE5092E2034F93688BB62C6E859C7032",
                    "parameters": {
                        "values": [
                            "6A82BF015BC832417C5AA855058D56A1FB3D",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "B86C6B314A1FA24E9D28D703F6CA27C82B44"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EEC637476CA0C44DB639DD3814A41B3AF9DE",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "5F5C404E37B6C548F32980C69F913D8580FC"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "4B7580C31D5A3143FB7B2EB5C8E135C35F80"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "SOLDI ATTUALI",
                        "index": 247,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 1,
                    "source": 0,
                    "sourceValue": 3000,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "45690BA780113848213AD1F23E50EABFD584"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "422B49CA8A63A04CB338ADD9E56A9BFB25A0",
                    "parameters": {
                        "values": [
                            "",
                            {
                                "lcId": null,
                                "defaultText": "You also obtain {C:3}3000 G{C:0}."
                            },
                            "",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "46A9CBC19E68C5492889D0D305671378C646"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6FE3C1466BE6D749E93B1A1763C2A8DE2900",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "4BE3135A365AC1492A5906D106F891F0839A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 72
                },
                "indent": 0,
                "uid": "1C9499DA2425A5407F1B1F2609BD01D7D542"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0A5394441DFE9942C23BB1177D61A379F547",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "245AC4A45AE0B5416D997BC2E23BB4232C68"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "02EF21C36393B4496049B238D012488E0ACE",
                    "parameters": {
                        "values": [
                            "B29C753D58E5974A8B3A68575D84136FE572",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2AD419549D52F449244B7CA74DB058803723"
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "B29C753D58E5974A8B3A68575D84136FE572",
                    "eyeBlink": {
                        "enabled": 0,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.9,
                    "idleIntensity": 0.9,
                    "lipSyncSensitivity": 0.75,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 0,
                        "eyeBlink.enabled": 0,
                        "eyeBlink.interval": 1,
                        "eyeBlink.closedMotionTime": 1,
                        "eyeBlink.closingMotionTime": 1,
                        "eyeBlink.openingMotionTime": 1
                    }
                },
                "indent": 0,
                "uid": "2D66689A7EB3E140BD58B3D949CFF646722E",
                "expanded": false
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "B29C753D58E5974A8B3A68575D84136FE572",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Faratras Overworld.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "02_Troubled.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0F30403F8DC34241702813C9562F547A9E75"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "1F10D09C8860764577999006098F4CF79B53"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D007E02518D24249142A32F1FBFB0EC659E0",
                    "parameters": {
                        "values": [
                            "B29C753D58E5974A8B3A68575D84136FE572",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "89B0B7DF7601B848DA9B5007243BFD407FE6"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "AC3AB5840F52A44C8F1AA8C7517D5ADC5F96"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "60E897092ECEE84F362AEA421F084E5EF519"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "608E67FA76D1E94D60498676FE7665F8F524",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C02-04b_line6.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7DA9D2266ABF9243049B32E42D3B845109FD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "317F08257E67B1425A8A06E1196F84E747F7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A4CBB87D5E17E54319199244B32862D2C7E5",
                    "parameters": {
                        "values": [
                            "B29C753D58E5974A8B3A68575D84136FE572",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "11F40A356EBB2743F17BE5613637D1FA7E6C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D5FFD8DD55A875452E1AAD317166C96153AC",
                        "defaultText": "신들이시여... 내가...\n정말 이래야만 하는 걸까?"
                    },
                    "position": 0,
                    "characterId": "B29C753D58E5974A8B3A68575D84136FE572",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FDEBF4683D85124C7B8AF6E2E6F88D307F37",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "A1A20B203F8EC344866979167A79A005B3C0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "212458D23DAD504CDE488802C2A4609E69F4",
                    "parameters": {
                        "values": [
                            "B29C753D58E5974A8B3A68575D84136FE572",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "010784511E5AC349E02872E10AEF224A2925"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "DA3CA367309A31414869E735D70FCF4978DB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0A5394441DFE9942C23BB1177D61A379F547",
                    "parameters": {
                        "values": [
                            0,
                            1,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8EB65C2E6D4DF049AC4AD165EF313A2CDDA8"
            }
        ],
        "livePreviewDisabled": true,
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}