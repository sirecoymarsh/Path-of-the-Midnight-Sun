GS.dataCache['014A27FE8F69D8484129D6B3D0B4FE799676'] = {
    "uid": "014A27FE8F69D8484129D6B3D0B4FE799676",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C8-08 P1 Ceapana (quest done)",
        "type": "vn.scene",
        "parentId": "34E5663D2CE7424868294E5543760B07A696",
        "chapterUid": "823DFD145789F24D466B6858151B6EA2F9AB",
        "order": 0,
        "localizableStrings": {
            "7EB1CE31326CD4411C88C988393C53DD1FF5": {
                "t": "By the way, we've completed your assignment. Here's the incense and the ingredients you requested.",
                "d": {
                    "cid": 0,
                    "eid": "9A0863CD71C9F9463159A914FC12E375E105"
                }
            },
            "A02345CC0F07C949E43A99C1E32AA62E232B": {
                "t": "Oh! As efficient as ever, I see. Thank you for these.",
                "d": {
                    "cid": "03D7AE0458BC67425098A7F4F5CB31E27595",
                    "eid": "DF0477A54F2D774B2148B5B0A6F36BA30610"
                }
            },
            "442AACD31176C14B013BA00262AB7F69A569": {
                "t": "Are you sure it's safe for you to handle such dangerous ingredients? No offense, of course, but given your young age...",
                "d": {
                    "cid": 0,
                    "eid": "9EE3862C445076463688C8C7380009DEE5C2"
                }
            },
            "1D3158151536484EEB5B04062529BDE45A1E": {
                "t": "Why do I suddenly get a sense of deja vu?",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "69094F797A0B72428B19C63238871BCD6681"
                }
            },
            "D1A65E710489B9427E6ABE86B1BADC0D6A5D": {
                "t": "Er, Nini, she's...",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "AB4AEFB68EE9A547001B7DB05266683A5B1D"
                }
            },
            "80F0373A1C68A54A611808F4C5C4B1F1A294": {
                "t": "Why do they look so scared?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "BB6A35C03662784E282AE106BCC600B7931B"
                }
            },
            "4635D9D46A6CA7406B8AC9F078F4FB191670": {
                "t": "... Sigh. Fine, I've made up my mind.",
                "d": {
                    "cid": "03D7AE0458BC67425098A7F4F5CB31E27595",
                    "eid": "0DB025CA2858D5415E1A90086820D5163950"
                }
            },
            "3FC84C9A8373E1400C8A72B39A78AD538583": {
                "t": "I'm joining your group.",
                "d": {
                    "cid": "03D7AE0458BC67425098A7F4F5CB31E27595",
                    "eid": "39502E8C5760374C8319E3B2746583C7B527"
                }
            },
            "7E16DFD5547A9648611A7353E031C2B63EAB": {
                "t": "Huh... How is that even related to what we were talking about?",
                "d": {
                    "cid": 0,
                    "eid": "66F45AFE1AB9D743C02AABA541268FDFE34C"
                }
            },
            "CE29A11E88A401471899C818E2049FC5A31C": {
                "t": "Because...! This way I can show you my skills and make you remember how much you used to WORSHIP me, Nini.",
                "d": {
                    "cid": "03D7AE0458BC67425098A7F4F5CB31E27595",
                    "eid": "21A2C37A64C3714938081E741FA1F6311767"
                }
            },
            "A399EBF38DCB904DDF1AF474187ACA90997D": {
                "t": "W-Worship!? That's a big word now...",
                "d": {
                    "cid": 0,
                    "eid": "157D17E788A66542835834B8A73BF3AD7A3F"
                }
            },
            "DDB6C8584C729047BC1B44921970BCA31413": {
                "t": "She... isn't that wrong, though...",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "37530E8C3885D74ACB49D686F455B647F3EB"
                }
            },
            "6EF396EB8704C7462879E0D58A8D152C1B7B": {
                "t": "And most importantly, you will stop treating a lady in her thirties like a teenager!",
                "d": {
                    "cid": "03D7AE0458BC67425098A7F4F5CB31E27595",
                    "eid": "DD9893489D9A12472F6968D641DAE74121A3"
                }
            },
            "26C17E096DC117468C082533E2C487580978": {
                "t": "A lady in her... thirties? Oh my. I can suddenly see why 'past me' worshipped her.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "BCD1BE5F122891414998721068B4B72C5BCC"
                }
            },
            "8E3DD1D11C2AB64BCF69CE55A4F0B9B88488": {
                "t": "Are you sure about this, Ceapana? Our path will be fraught with danger around every corner.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "D95B81B30F813845E13AE307BDD5C75AA956"
                }
            },
            "51904EC10CE1C440EA58FB500493E477FB1B": {
                "t": "Hey, I should be the one worried about YOU, being the older one here!",
                "d": {
                    "cid": "03D7AE0458BC67425098A7F4F5CB31E27595",
                    "eid": "9AC868066D6192434F8AEBB231D39BB872D1"
                }
            },
            "E8FC87745D4E354930588984C3A6007CA273": {
                "t": "Moreover, you'd surely appreciate an extra healer in your group, right? AND... I have to further research Nini's Manacrest, since mine broke.",
                "d": {
                    "cid": "03D7AE0458BC67425098A7F4F5CB31E27595",
                    "eid": "23BA1FF010547547326A7216A293090B88DF"
                }
            },
            "EB601BB9761FD4416D1B5DF4B23F43AC7330": {
                "t": "Well, you have some valid points. Welcome on board, Ceapana.",
                "d": {
                    "cid": 0,
                    "eid": "F43C63AD3FAD9343973A7D161BDE910BC3FF"
                }
            },
            "5B50E8EF63492145C57BDF926C590316A499": {
                "t": "I'm sure we'll get along!\n... And don't make me angry.",
                "d": {
                    "cid": "03D7AE0458BC67425098A7F4F5CB31E27595",
                    "eid": "74FF0995237694429A2BD7682A86FEC2516D"
                }
            },
            "CA6009E72420424924798C81A398AD46F434": {
                "t": "Don't make her angry.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "0CA8A9F91AB21544788888654577964D1226"
                }
            },
            "C8C6A53A2263334AE51879E20F914471E9E0": {
                "t": "Just don't. Please.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "0481CA335DCA574A7689E6A87F7534AD7796"
                }
            }
        },
        "commands": [
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "19B4F096045B584A2E284042F8BAA26B9D45"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "r",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BDB437F57C85404C023B32A742CEAB393419"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "03D7AE0458BC67425098A7F4F5CB31E27595",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "8B8AD59A408C214B29696A553D38043B9793"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "8DE5614B7253184EB18A4BB3CB48C806409D"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "jump here",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "8726399626A35049BE3807025668C2F61FB7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "00067E4F5B942542CE4891754C45215D3D1B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7EB1CE31326CD4411C88C988393C53DD1FF5",
                        "defaultText": "그런데 부탁한 일을 끝냈어.\n여기 요청한 향과 재료가 있어."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "9A0863CD71C9F9463159A914FC12E375E105"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7415706911B80440398A04F15BA0DF599B76"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "03D7AE0458BC67425098A7F4F5CB31E27595",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "707A8CCA46F0C64F3449FD348751BF9A863A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "03D7AE0458BC67425098A7F4F5CB31E27595",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "F6E5D5406DC69741B8787895343B950AEAC9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "03D7AE0458BC67425098A7F4F5CB31E27595",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9578EE4A25A3514F513B67B7298097CB531A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A02345CC0F07C949E43A99C1E32AA62E232B",
                        "defaultText": "어머! 여전히 일 처리가 빠르네. 고마워."
                    },
                    "position": 0,
                    "characterId": "03D7AE0458BC67425098A7F4F5CB31E27595",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DF0477A54F2D774B2148B5B0A6F36BA30610",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "342C8E185A302940A53964671EB64BE736B6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7C5670D780B9E64CC27B7C781EEE8053D7EC"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "quest completed\nyou also get the recipe to make Pixie Incense"
                },
                "indent": 0,
                "uid": "7857D9790545674CE94B6316D447876B2824",
                "expanded": true
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "7190D01C28870249186BA7314BF9E38B6610"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "16BEA919453249461948D4029C18A41D46B5",
                    "parameters": {
                        "values": [
                            "DF115EE88C906444958B97A5616A05593052",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "522A9BD3794CF440593930F5D36301CD8DBA"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Unlocked Pixie Incense",
                        "index": 189,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E16B949E377BD64B737AEBC3E7BA13290740"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "BB1C08930EA5014D2D6BE5D7FA7BDA4C43D8",
                    "parameters": {
                        "values": [
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "0F31DAA424E949425C1B84990164F16C0F40"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "102645D47997A64D7B383459426E123BB79C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "422B49CA8A63A04CB338ADD9E56A9BFB25A0",
                    "parameters": {
                        "values": [
                            "",
                            {
                                "lcId": null,
                                "defaultText": "Pietro'll make {C:1}Pixie Incense{C:0} at the camp from now on."
                            },
                            "",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "05C912D312D88749D84A9F44463F09F01CE3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6FE3C1466BE6D749E93B1A1763C2A8DE2900",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "544B4BE27A49B148F86A06559AAAFD5DE2AC"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "E859389F6F1234455D6852E780802A8683C8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AE517B3B2499154AF458BBA8038ABB3E4B23"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "58F359AC1EC8214BFC48F130A297CC2CC20D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "442AACD31176C14B013BA00262AB7F69A569",
                        "defaultText": "그런 위험한 재료를 다뤄도 정말 괜찮겠어?\n기분 나쁘게 듣지는 마. 하지만 네 나이를 생각하면..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "9EE3862C445076463688C8C7380009DEE5C2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "274C188E55CAC14F187943A1C3FC0E9C07E3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E7D9D783251FD442B948CF28D11CE4C9DC57"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "CB6AFD02436A584A4B3898938FEDA97AFAF2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "00AE01BD8FA2444A175985D445262E580C26"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1D3158151536484EEB5B04062529BDE45A1E",
                        "defaultText": "왜 갑자기 기시감이 들지?"
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "69094F797A0B72428B19C63238871BCD6681",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F271201E0A72A14E3C08F5240E254293BEB8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "61FA6A2645640742C2283003D6E59F223F68"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "524D78B633A8D340D949BAB47DE253FF3792"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "F4ACE606424743401368151907B5E8AC79D2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "75D6E8718EA6F742D3791B31236ADC786FD7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D1A65E710489B9427E6ABE86B1BADC0D6A5D",
                        "defaultText": "저기, 니니. 이 사람은..."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AB4AEFB68EE9A547001B7DB05266683A5B1D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9DA046D24368744F1A8BD7240896FB032C71"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F5D9D1D15427A144C559E4C5567B727BE107"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "80F0373A1C68A54A611808F4C5C4B1F1A294",
                        "defaultText": "다들 왜 그렇게 겁먹은 얼굴이지?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BB6A35C03662784E282AE106BCC600B7931B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "718F03EF21FF564A117A2BE455CF1B57A653"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B3AF2CD23A8450418F586DC62C1E48553435"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "20253A685E61C847973BAF83DF8238212889"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "03D7AE0458BC67425098A7F4F5CB31E27595",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CF3689841550684B1C4AA1A55AAD4E9D8716"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "312A44D65FB8C2443C8AD5045CBC1C1DD10E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": null,
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ceapana",
                        "name": "E3-Ceapana_line13_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2B3AAA6B2576814B56388BC8F25931C71997",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "D530C7624B65F4415F9AA5A8436843C20816"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "03D7AE0458BC67425098A7F4F5CB31E27595",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2799C73E6F52424E0F88AC08E774EEA1E58C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4635D9D46A6CA7406B8AC9F078F4FB191670",
                        "defaultText": "...하아. 좋아, 결심했어."
                    },
                    "position": 0,
                    "characterId": "03D7AE0458BC67425098A7F4F5CB31E27595",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0DB025CA2858D5415E1A90086820D5163950",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "83DB7BC8549CF8463D7A62510426D558EE71"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "BF1AC4BF73F6344E6F68F7D231733F6F948C"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2AC1256D7652C24E1939AF16A1D91ED442CF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3FC84C9A8373E1400C8A72B39A78AD538583",
                        "defaultText": "너희 일행에 합류할게."
                    },
                    "position": 0,
                    "characterId": "03D7AE0458BC67425098A7F4F5CB31E27595",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "39502E8C5760374C8319E3B2746583C7B527",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5EDCF20D22AF2248994984B65D5820B1A751"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "88FF17899E3EA2401A2AAE263CE66E013B4B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7E16DFD5547A9648611A7353E031C2B63EAB",
                        "defaultText": "응...? 그게 지금 이야기와 무슨 상관이야?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "66F45AFE1AB9D743C02AABA541268FDFE34C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "73D0A592648AF54B988938D5E5A374D77881"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "03D7AE0458BC67425098A7F4F5CB31E27595",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "045F501371A4624AB04A5435E451A626CAB2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "03D7AE0458BC67425098A7F4F5CB31E27595",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5FD88D4470D524435D8ACA92FBAF2034CBE2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CE29A11E88A401471899C818E2049FC5A31C",
                        "defaultText": "왜냐하면...! 내 실력을 보여 주면\n예전에 네가 나를 얼마나 숭배했는지\n떠올릴 테니까, 니니."
                    },
                    "position": 0,
                    "characterId": "03D7AE0458BC67425098A7F4F5CB31E27595",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "21A2C37A64C3714938081E741FA1F6311767",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "08E50EDF0EBA9147895A72400C0545AE7BAE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "44327AA7460C084316895F50EC1B29DF4799"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": null,
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E3-Ornieres_line25_3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "568C01EB50DF98434D2851387804917F2C81",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "397424955E4D634F313887A01BE0E2352820"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F62965C49805844A0A3B4A112474C2C8651F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A399EBF38DCB904DDF1AF474187ACA90997D",
                        "defaultText": "수, 숭배!? 표현이 너무 거창한데..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "157D17E788A66542835834B8A73BF3AD7A3F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BB0E61F08A7282415C1BC854B2726320D01F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "05CE202D4671F24EA64A66D245382253750F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D3EEE08141EB464F537870087DB1D8080D8E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DDB6C8584C729047BC1B44921970BCA31413",
                        "defaultText": "그게... 틀린 말은 아니지만..."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "37530E8C3885D74ACB49D686F455B647F3EB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "46383392563F454321882F13915218DF09FF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "6371BA9A527291483128BE8327EE720C11E6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": null,
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ceapana",
                        "name": "E3-Ceapana_line1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0D0F30474758734F8A6BC636351342F93F38",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B97A34AF46F5E146C9381B473726B9687AB3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "03D7AE0458BC67425098A7F4F5CB31E27595",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0BE6E73825ABA1482C2830258035895BE0DD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6EF396EB8704C7462879E0D58A8D152C1B7B",
                        "defaultText": "그리고 무엇보다, 서른 넘은 숙녀를\n십 대처럼 대하는 짓은 그만둬!"
                    },
                    "position": 0,
                    "characterId": "03D7AE0458BC67425098A7F4F5CB31E27595",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DD9893489D9A12472F6968D641DAE74121A3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F62B9F0E40D29943BB78C4760B3315F61982"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "095E343A1B2B5640927B2C178F712920D2F7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "26C17E096DC117468C082533E2C487580978",
                        "defaultText": "서른이... 넘었다고? 세상에.\n과거의 내가 왜 숭배했는지 알 것 같네."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BCD1BE5F122891414998721068B4B72C5BCC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "69118B2248A090430388F2D172C6ED29F933"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CF9507DF8EF1C644491B05870DCEBA491F5A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "56BBC3232886C24BF279106629D9959F83E1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "30D20EEC897E134C885B3E001A1D00FCE095"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "169F3F8217C4624E8F4841633C4F630BB271"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8E3DD1D11C2AB64BCF69CE55A4F0B9B88488",
                        "defaultText": "정말 괜찮겠어, 체아파나?\n우리 앞길에는 곳곳에 위험이 도사리고 있어."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D95B81B30F813845E13AE307BDD5C75AA956",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B010D67B04CAB348422962E3FD72A845B1E4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "03D7AE0458BC67425098A7F4F5CB31E27595",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "39F2FB8D83937244870AB328443F2CD63FAE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "03D7AE0458BC67425098A7F4F5CB31E27595",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3485CE495DD99447BC69FE38423A6A811633"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "51904EC10CE1C440EA58FB500493E477FB1B",
                        "defaultText": "이봐, 여기서 나이가 더 많은 내가\n너희를 걱정해야 하는 거 아니야!"
                    },
                    "position": 0,
                    "characterId": "03D7AE0458BC67425098A7F4F5CB31E27595",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9AC868066D6192434F8AEBB231D39BB872D1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D13A418A847354487F29356836BCB8108E9F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E8FC87745D4E354930588984C3A6007CA273",
                        "defaultText": "게다가 치유사가 한 명 더 있으면 좋잖아?\n그리고... 부서진 내 것 대신\n니니의 마나크레스트도 더 연구해야 해."
                    },
                    "position": 0,
                    "characterId": "03D7AE0458BC67425098A7F4F5CB31E27595",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "23BA1FF010547547326A7216A293090B88DF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "91B29FC2777C574E7C395D67FFB43C113656"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DE65F0428999024E29387677A5C8F4CF5B1B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EB601BB9761FD4416D1B5DF4B23F43AC7330",
                        "defaultText": "일리 있는 말이네. 우리 일행이 된 걸 환영해, 체아파나."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F43C63AD3FAD9343973A7D161BDE910BC3FF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "75C8690478B395427F4A9F93C48FEA2BF405"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "jump here"
                },
                "indent": 0,
                "uid": "92F61F9E433BF14A1E9AD9223CB674C3BC12"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "03D7AE0458BC67425098A7F4F5CB31E27595",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "CB678E4C657DF140C439F1B22307AA263996"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "483ADAC2734AA644F00A1197BFA206722B51"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": null,
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ceapana",
                        "name": "E3-Ceapana_line11_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0F02E16402C4E84CD36B3747E3CE6AB02228",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "28609E96517A114A843A111624C2CEBF56A1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "03D7AE0458BC67425098A7F4F5CB31E27595",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DE10D8E1718E354F8639BF91308A579EDB27"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5B50E8EF63492145C57BDF926C590316A499",
                        "defaultText": "분명 잘 지낼 수 있을 거야!\n...그리고 날 화나게 하지 마."
                    },
                    "position": 0,
                    "characterId": "03D7AE0458BC67425098A7F4F5CB31E27595",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "74FF0995237694429A2BD7682A86FEC2516D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "04D957111660E24C9B495DC15E804A9DF6BE"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "r",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "52968C5E59B7A6430C9BBBA1340FA42F0CD1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "FA8F59EF2212A549B388FFE1505B8F3A23AF"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 1,
                "uid": "BAD45D7725361849E51994F73E5EEF9B244C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "6EF4B3F12291B944128A423166117100623B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BF8A4C818244294A0989A29823650F63A9EB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CA6009E72420424924798C81A398AD46F434",
                        "defaultText": "저 사람을 화나게 하지 마."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0CA8A9F91AB21544788888654577964D1226",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4BF3B2CC6EFD514EEA498D05CE2AF2FCBCB9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "14D96C53158918443179F271BACD8833AB38"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "946DD76E7581A648505936C34E1712B35DCE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AC796E2314E57749BC2918F81317262BE038"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "91AED78342333940770A1A93CF44528D649A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C8C6A53A2263334AE51879E20F914471E9E0",
                        "defaultText": "그냥 하지 마. 제발."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0481CA335DCA574A7689E6A87F7534AD7796",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "4CC5331B46D63245AD4B0C42AFAECD2ECC65"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "01FD11D22126744EF25BAB331EBD9E581D00"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "r",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "592773C5312FF64BF31902546ABE164A1846"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Ceapana joins the group"
                },
                "indent": 1,
                "uid": "2612580E6AB6584D026BE4E4D7B30AA2A2B1",
                "expanded": true
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "r",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "D02F79DF1F0E5243286A6DF523045585C986"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            4
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "78A945424F8C9148473A7B16EBD65D1A52BF"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 1,
                "uid": "09F91CBF4997B14B532AF045EFFB038A30A9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "DA048C7E6697C7481188AF30A50BC2CCAA55",
                    "parameters": {
                        "values": [
                            "03D7AE0458BC67425098A7F4F5CB31E27595"
                        ]
                    }
                },
                "indent": 1,
                "uid": "72C4A9E520F1A6442B7AB538741B21849620"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "7DEFA4E056B0424037680879F6D7F754DF58",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "57F8DC3271C6D449582BE0017B759EEBB4E2"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "9778F94260ABD64AD44971E979FD9A9B61E4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D86A0B755C3931407F0ABD74F73B1E1241A9",
                    "parameters": {
                        "values": [
                            "03D7AE0458BC67425098A7F4F5CB31E27595",
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "F612B7EC8766A14D350984F8D815D35722C9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "422B49CA8A63A04CB338ADD9E56A9BFB25A0",
                    "parameters": {
                        "values": [
                            "",
                            {
                                "lcId": null,
                                "defaultText": "{C:1}Ceapana{C:0} joins as an Adjutant."
                            },
                            "",
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "2693A7137D21D64F717B1A26A61AF1648113"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6FE3C1466BE6D749E93B1A1763C2A8DE2900",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "85E9E5582533254B7C19FDE0DB0BF8C77F8B"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 1,
                "uid": "3E19F8AD294CE84FA83842251607ADDA22F9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "AA2D923F867E704FC648D0D955CA3428098B"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "A724F0954B5FE04BAD88A622B77D3F670E4F"
            }
        ],
        "livePreviewDisabled": true,
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "r",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}