GS.dataCache['5638704700A1F946E47BB0B23F3B393CB375'] = {
    "uid": "5638704700A1F946E47BB0B23F3B393CB375",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C4-02b Viborera Plaza (Exploration)",
        "type": "vn.scene",
        "parentId": "8D381E7C10471941382A2AC92CD7DB63FF30",
        "chapterUid": "6FC0AF36453CA744B128EAF83314DDE5F897",
        "order": 2,
        "livePreviewDisabled": true,
        "localizableStrings": {
            "6BA295427DC7124FB02ACBA30CC46D8F52C2": {
                "t": "1ED502916856C948A0693432B19D9B1101B0",
                "d": {
                    "eid": "B04E82302F2E244287588D92BCBB24DD861D"
                }
            },
            "ED59A7D63652254D9089ABE7716BCF75251C": {
                "t": "C7B7879217357646400B56F7CA19AB8B41B7",
                "d": {
                    "eid": "EBCC8C7276569949C88BA0F1C42C6CF47AAC"
                }
            },
            "7350710C52DDD541805B0074BF544111E474": {
                "t": "",
                "d": {
                    "eid": "E8F7694499D5004D654ABB74873ACC861D39"
                }
            },
            "0D3EDA294D49D6482D396728DB2F3126111A": {
                "t": "",
                "d": {
                    "eid": "2F2DCC817949C14CCD6A7D25D678E81953B9"
                }
            },
            "9ECF26D343EB1744BD89EC51F1C125CFEEEE": {
                "t": "4BFE9FD5211FF249BD1A5645E45BA12B10ED",
                "d": {
                    "eid": "18FEE5619015064CDF7A4F00BA2C0023C5D0"
                }
            },
            "F469414D2D3713440A194491B8ED2D4EF7F1": {
                "t": "FAF5553D4BE3D248885B6F58A00197A898C3",
                "d": {
                    "eid": "9368524F17585145036846583FF32DE53E46"
                }
            },
            "B8E9B32E27B2D74E613ADD236D19AC9B37AE": {
                "t": "",
                "d": {
                    "eid": "F948D1764140354D5D588692225EA0EE24B5"
                }
            },
            "FED667D27F9C704F4E1B98F7E900790113F2": {
                "t": "9DA4B9C4809FB54D9A8A03B1172C93FEE803",
                "d": {
                    "eid": "B441FAF329586349C98BDB9994B44BA8474C"
                }
            },
            "3CA94AF78551E841993AB546FD1BDCDEC5EC": {
                "t": "Magnolia Palace",
                "d": {
                    "eid": "31D16C2524E8A34A727B4983BF2D3732A844"
                }
            }
        },
        "commands": [
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "PREVENT LOADING EXPLORATION?",
                        "index": 97,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "EB58136D87FF984EBD7A1572BA3A253ABDEE"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 1,
                "uid": "A1DA375900C9024A21286E55E46C555E896E"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 10001,
                    "blendMode": 0,
                    "zOrder": 0,
                    "duration": 1.2,
                    "origin": 0,
                    "waitForCompletion": 1,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 1,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "sfondo nero.png",
                        "folderPath": "Graphics/Pictures/CG Gallery",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 1,
                "uid": "A95494B49088E84FE01B17B2E517113E7743",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "462939745E0ED848AB48BE16B0689978C90B"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 1,
                "uid": "F3F46F278B9C9443F2392AB4EE0108C29B06"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "463721847663D24C5E8B27F74D3E487F90C0",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "D89BA9F23354E3403F4ADE753713B4301151"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "",
                        "index": 39,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "26A951EC8F6A0140FE28CB9691B425C985D8"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "model": {
                        "name": "Kelavala.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 800,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 153,
                        "y": 594,
                        "zoom": {
                            "x": 0.5,
                            "y": 0.5,
                            "d": 0.5
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 0.06,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 2,
                "uid": "B8D64ACC34FE4741AF7B4E53938D66B84DCF",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            6
                        ]
                    }
                },
                "indent": 1,
                "uid": "3F15CAC935120547651AACA2AD343EDAC42D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 1,
                "uid": "0D74475052EA34446618070944A81021C7D2"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Numero Identificativo Suono",
                        "index": 159,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "47CA9452313128442318AE63B928F74919FB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "6A2AC46D47CF55422B0BDFA266DFDAE00D44"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "723C71C920FEF84AAE7BCEA0AD7CB84703A8"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 10001,
                    "duration": 45,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 2,
                        "movement": 0,
                        "mask": {
                            "graphic": {
                                "name": "9.png",
                                "hue": 0,
                                "opacity": 255,
                                "blending": 0,
                                "tone": {
                                    "red": 0,
                                    "green": 0,
                                    "blue": 0,
                                    "grey": 0
                                },
                                "folderPath": "Graphics/Masks"
                            },
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "5E52B3D58E0B40454F58DC180A4F6D49134C",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 15
                },
                "indent": 1,
                "uid": "280D2527212F90421A18790486CE7A9E48F0"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Spend time (during travel?)",
                        "index": 96,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "D87B224C18EF90473A08EFF53E0696EC5A99"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Spend time (during travel?)",
                        "index": 96,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "0C24FC942853654EB1181220B333899C61CB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "03DEA4954ABD5648B72A16630CB12FEB0C7F",
                    "parameters": {
                        "values": [
                            {
                                "name": "Tempo d'attesa",
                                "index": 32,
                                "scope": 1,
                                "domain": "com.degica.vnm.default",
                                "changed": true
                            },
                            250,
                            1,
                            2000,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "D00C8B351E206246531A6A131F2CC1B4EEB8"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Flag locale 10",
                        "index": 169,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "933A90AA3043D3459819A6A6CDF6EC5EEACB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "66EA46F64E04E449993AEF277ECF57AF0CE9",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "5DBB4384759A72471D195D380F53DB6E3E23"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "DFA47E6463DD3841D679A659CD1FF8272735"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 2,
                "uid": "9DE66DC692C90743427B9CB909E01AA9534E"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 2,
                "uid": "4C0A87D0299A09481B397994EF7E08800F5B"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "IN EXPLORATION INTERACTION?",
                        "index": 176,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "B0D96E17354C32469C8959920961518C55D5"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "5BE7321C39587549166B6336941CC235C025",
                        "name": "C4-02b P1 Kalevala"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "EF35980E7099324265697504AB7F13D99892"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "IN EXPLORATION INTERACTION?",
                        "index": 176,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "2B31CCA85AB85740379A3662E6EEF1018521"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "PREVENT LOADING EXPLORATION?",
                        "index": 97,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "08D4509A6E6F73421A88FA72EB27237E3F2C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "7601D85C3700D2424D6B5E62901196D79FD3",
                    "parameters": {
                        "values": [
                            20
                        ]
                    }
                },
                "indent": 1,
                "uid": "B67B986E005CC14FB71A962775ED52062473"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "PREVENT LOADING EXPLORATION?",
                        "index": 97,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "140D0DFB8251414D7D690910D06E90EF68DB"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "INDICE HOTSPOTS\n1-5 Hotspot pg\n6-15 Elementi di background\n16-20 Monetine"
                },
                "indent": 0,
                "uid": "4FC233CB4EF62442B0990E9291A44EDFEE87",
                "expanded": true
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "P\nE\nR\nS\nO\nN\nA\nG  G  I    E SCENE DIALOGHI"
                },
                "indent": 0,
                "uid": "D44D0E9C3D68E841295A1A35907B900D2992",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "21CB77C16DEB404FA26A8F35BFB39B2FD0D7",
                    "parameters": {
                        "values": [
                            "23B7EE9828E8C547098A4EE0B85CC1DFAE38",
                            "2B96228807C91543086AF8734CBB0AD4A6B9",
                            "51FE568238DE384B4F8A0356581EC6A54FA8",
                            "567F1E3489D91446CF4A0ED6AF508D6BB339",
                            "FEEB28CE186A3342E70A634062AF25688319",
                            "",
                            ""
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "743E915087DBD2438B89B9A898295E4167CD"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "",
                        "index": 39,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1080B15044C1754B9A9910945542A531BF0A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A1F3F1D799DDC043B218386049F1B8B86EA2",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            "",
                            "",
                            "",
                            "",
                            "5BE7321C39587549166B6336941CC235C025",
                            "",
                            "",
                            "",
                            "",
                            0,
                            0
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "572CF46F2E6AC5419C19270285A2E375B015"
            },
            {
                "id": "gs.AddHotspot",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1,
                    "shape": "rect",
                    "positionType": 0,
                    "actions": {
                        "onClick": {
                            "type": 4,
                            "bindValue": 1,
                            "bindValueVariable": {
                                "name": "Numero ID pg EXPLORE",
                                "index": 255,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "TalktoNPC",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onEnter": {
                            "type": 4,
                            "bindValue": 1,
                            "bindValueVariable": {
                                "name": "Numero ID pg EXPLORE",
                                "index": 255,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "Info",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onSelect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDeselect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onLeave": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "UnInfo",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrag": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrop": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDropReceive": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        }
                    },
                    "dragging": {
                        "enabled": 0,
                        "variable": {
                            "scope": 1,
                            "index": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "horizontal": 1,
                        "vertical": 0,
                        "rect": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 200,
                                "height": 50
                            }
                        }
                    },
                    "position": 1,
                    "box": {
                        "x": 238,
                        "y": 602,
                        "angle": 0,
                        "zoom": 1,
                        "horizontalFlip": false,
                        "data": {
                            "x": 589,
                            "y": 237,
                            "width": 166,
                            "height": 426,
                            "horizontalFlip": false,
                            "zoom": 1,
                            "angle": 0
                        },
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 160
                        },
                        "size": {
                            "width": 234,
                            "height": 478
                        }
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "B2467ACF855F66455B793C44ACA46E06B03F",
                "expanded": false
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "E\nL\nE\nM\nE\nN\nT\nI  C L I C K A B I L I (descrizioni)"
                },
                "indent": 0,
                "uid": "611FC7C03AC1A74F6109D807BAD055D5E64C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "B91A2FE514A67748E769D0B36E440EBDFCDF",
                    "parameters": {
                        "values": [
                            "E54107EB2331114F3D09CB22652B337A20F8",
                            "B90791A15EA2A54AF76959865764CDF9DE44",
                            "0B5547567220114ABC9904150B765731C1F7",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            ""
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7346426F4384454D3F6AD7234CFB6274B8A8"
            },
            {
                "id": "gs.AddHotspot",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 6,
                    "shape": "rect",
                    "positionType": 0,
                    "actions": {
                        "onClick": {
                            "type": 4,
                            "bindValue": 6,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "AttivaClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onEnter": {
                            "type": 4,
                            "bindValue": 6,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "InfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onSelect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDeselect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onLeave": {
                            "type": 4,
                            "bindValue": 6,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "UnInfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrag": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrop": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDropReceive": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        }
                    },
                    "dragging": {
                        "enabled": 0,
                        "variable": {
                            "scope": 1,
                            "index": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "horizontal": 1,
                        "vertical": 0,
                        "rect": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 200,
                                "height": 50
                            }
                        }
                    },
                    "position": 1,
                    "box": {
                        "x": 1282,
                        "y": 354,
                        "angle": 0,
                        "zoom": 1,
                        "data": {},
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 160
                        },
                        "size": {
                            "width": 446,
                            "height": 464
                        }
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CD3EFBAF37C4D44FF878BE27390AB7CA26A6",
                "expanded": false
            },
            {
                "id": "gs.AddHotspot",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 7,
                    "shape": "rect",
                    "positionType": 0,
                    "actions": {
                        "onClick": {
                            "type": 4,
                            "bindValue": 7,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "AttivaClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onEnter": {
                            "type": 4,
                            "bindValue": 7,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "InfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onSelect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDeselect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onLeave": {
                            "type": 4,
                            "bindValue": 7,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "UnInfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrag": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrop": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDropReceive": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        }
                    },
                    "dragging": {
                        "enabled": 0,
                        "variable": {
                            "scope": 1,
                            "index": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "horizontal": 1,
                        "vertical": 0,
                        "rect": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 200,
                                "height": 50
                            }
                        }
                    },
                    "position": 1,
                    "box": {
                        "x": 654,
                        "y": 696,
                        "angle": 0,
                        "zoom": 1,
                        "data": {},
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 160
                        },
                        "size": {
                            "width": 236,
                            "height": 196
                        }
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B3CB318A469FF7478C1A68A07FAD43EBA043",
                "expanded": false
            },
            {
                "id": "gs.AddHotspot",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 8,
                    "shape": "rect",
                    "positionType": 0,
                    "actions": {
                        "onClick": {
                            "type": 4,
                            "bindValue": 8,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "AttivaClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onEnter": {
                            "type": 4,
                            "bindValue": 8,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "InfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onSelect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDeselect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onLeave": {
                            "type": 4,
                            "bindValue": 8,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "UnInfoClickable",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrag": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrop": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDropReceive": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        }
                    },
                    "dragging": {
                        "enabled": 0,
                        "variable": {
                            "scope": 1,
                            "index": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "horizontal": 1,
                        "vertical": 0,
                        "rect": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 200,
                                "height": 50
                            }
                        }
                    },
                    "position": 1,
                    "box": {
                        "x": 532,
                        "y": 246,
                        "angle": 0,
                        "zoom": 1,
                        "data": {},
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 160
                        },
                        "size": {
                            "width": 354,
                            "height": 280
                        }
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "92D35BC645EC6843DF28AE48F3B13ADB3672",
                "expanded": false
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "C\n  O\n     I\n       N\n          S"
                },
                "indent": 0,
                "uid": "29FD6ED9990C7747DF9AC208388A4409414D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2BB01B9A8522474499180AA87EFC414D3CC7",
                    "parameters": {
                        "values": [
                            "CD45361918E8A243893A34118083FE60B578",
                            "B892212C5D23C346F31AE2F1F5D00F38EFD6",
                            "A903C2FC03C44340B939E6E5D71151FB3688",
                            "",
                            ""
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BE09F4078AA3B34E623AA05780D7230AF53F"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "",
                        "index": 15,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "028A606B8455C4410F3A35844A75D10D13DF"
            },
            {
                "id": "gs.AddHotspot",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 16,
                    "shape": "rect",
                    "positionType": 0,
                    "actions": {
                        "onClick": {
                            "type": 4,
                            "bindValue": 16,
                            "bindValueVariable": {
                                "name": "Numero ID Coin EXPLORE",
                                "index": 256,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "OttieniCoin",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onEnter": {
                            "type": 0,
                            "bindValue": 16,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "InfoCoin",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onSelect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDeselect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onLeave": {
                            "type": 0,
                            "bindValue": 16,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "UnInfoCoin",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrag": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrop": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDropReceive": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        }
                    },
                    "dragging": {
                        "enabled": 0,
                        "variable": {
                            "scope": 1,
                            "index": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "horizontal": 1,
                        "vertical": 0,
                        "rect": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 200,
                                "height": 50
                            }
                        }
                    },
                    "position": 1,
                    "box": {
                        "x": 1048,
                        "y": 754,
                        "angle": 0,
                        "zoom": 1,
                        "data": {},
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 160
                        },
                        "size": {
                            "width": 60,
                            "height": 60
                        }
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "E6A06B4D2E7B664E8699F793760A0F00097C",
                "expanded": false
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "",
                        "index": 16,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F317D07A41E4764AC62814960C6B18E36D3A"
            },
            {
                "id": "gs.AddHotspot",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 17,
                    "shape": "rect",
                    "positionType": 0,
                    "actions": {
                        "onClick": {
                            "type": 4,
                            "bindValue": 17,
                            "bindValueVariable": {
                                "name": "Numero ID Coin EXPLORE",
                                "index": 256,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "OttieniCoin",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onEnter": {
                            "type": 0,
                            "bindValue": 16,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "InfoCoin",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onSelect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDeselect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onLeave": {
                            "type": 0,
                            "bindValue": 16,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "UnInfoCoin",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrag": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrop": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDropReceive": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        }
                    },
                    "dragging": {
                        "enabled": 0,
                        "variable": {
                            "scope": 1,
                            "index": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "horizontal": 1,
                        "vertical": 0,
                        "rect": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 200,
                                "height": 50
                            }
                        }
                    },
                    "position": 1,
                    "box": {
                        "x": 1128,
                        "y": 186,
                        "angle": 0,
                        "zoom": 1,
                        "data": {},
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 160
                        },
                        "size": {
                            "width": 60,
                            "height": 60
                        }
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "10C113C03006924F764899E14ED32F855E48",
                "expanded": false
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "",
                        "index": 17,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DCAC6B101E943146028A49910F2516C5C759"
            },
            {
                "id": "gs.AddHotspot",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 18,
                    "shape": "rect",
                    "positionType": 0,
                    "actions": {
                        "onClick": {
                            "type": 4,
                            "bindValue": 18,
                            "bindValueVariable": {
                                "name": "Numero ID Coin EXPLORE",
                                "index": 256,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "OttieniCoin",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onEnter": {
                            "type": 0,
                            "bindValue": 16,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "InfoCoin",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onSelect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDeselect": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onLeave": {
                            "type": 0,
                            "bindValue": 16,
                            "bindValueVariable": {
                                "name": "Numero ID Click EXPLORE",
                                "index": 257,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            "commonEventId": 0,
                            "label": "UnInfoCoin",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrag": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDrop": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        },
                        "onDropReceive": {
                            "type": 0,
                            "bindValue": 0,
                            "bindValueVariable": {
                                "scope": 0,
                                "index": 0
                            },
                            "commonEventId": 0,
                            "label": "",
                            "switch": {
                                "scope": 1,
                                "index": 0
                            },
                            "scene": null
                        }
                    },
                    "dragging": {
                        "enabled": 0,
                        "variable": {
                            "scope": 1,
                            "index": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "horizontal": 1,
                        "vertical": 0,
                        "rect": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 200,
                                "height": 50
                            }
                        }
                    },
                    "position": 1,
                    "box": {
                        "x": 90,
                        "y": 94,
                        "angle": 0,
                        "zoom": 1,
                        "data": {},
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 160
                        },
                        "size": {
                            "width": 60,
                            "height": 60
                        }
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "84F7938E395365442D18BBB83279A006C6F8",
                "expanded": false
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "PIEDINO DI ESPLORAZIONE"
                },
                "indent": 0,
                "uid": "E367109813CC33427329F851FEA8310FC7CC",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "piedino"
                },
                "indent": 0,
                "uid": "BADB5DF41ED5564555682093142035BCD6EF"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Magnolia Palace"
                },
                "indent": 0,
                "uid": "F0DF2E68946E374EE96882E8218B1CD20695",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Location SCENE 1",
                        "index": 286,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "6BA295427DC7124FB02ACBA30CC46D8F52C2",
                        "defaultText": "1ED502916856C948A0693432B19D9B1101B0"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B04E82302F2E244287588D92BCBB24DD861D",
                "expanded": true
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Marketplace"
                },
                "indent": 0,
                "uid": "C3433A768BFF354CE739B236EAA62D783A30",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Location SCENE 2",
                        "index": 287,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "ED59A7D63652254D9089ABE7716BCF75251C",
                        "defaultText": "C7B7879217357646400B56F7CA19AB8B41B7"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "EBCC8C7276569949C88BA0F1C42C6CF47AAC",
                "expanded": true
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Flag locale 3",
                        "index": 162,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4B13371D10F4784E55390EC3AC7E952DC558"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "House 1"
                },
                "indent": 1,
                "uid": "092C100A3FE7D746D238574576C8A972F546",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Location SCENE 3",
                        "index": 288,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "7350710C52DDD541805B0074BF544111E474",
                        "defaultText": ""
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "E8F7694499D5004D654ABB74873ACC861D39",
                "expanded": true
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "House 2"
                },
                "indent": 1,
                "uid": "7A4BF6FA8585C9410A79AAA3E1BB4B66FC11",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Location SCENE 4",
                        "index": 289,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "0D3EDA294D49D6482D396728DB2F3126111A",
                        "defaultText": ""
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "2F2DCC817949C14CCD6A7D25D678E81953B9",
                "expanded": true
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "3C96A5D61929334C32184941AD7DCE7FD25E"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "House 1"
                },
                "indent": 1,
                "uid": "F051CD895811B846FA8BC6F390AE585061E5",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Location SCENE 3",
                        "index": 288,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "9ECF26D343EB1744BD89EC51F1C125CFEEEE",
                        "defaultText": "4BFE9FD5211FF249BD1A5645E45BA12B10ED"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "18FEE5619015064CDF7A4F00BA2C0023C5D0",
                "expanded": true
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "House 2"
                },
                "indent": 1,
                "uid": "012D52D189A773403F0BE025131257007C83",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Location SCENE 4",
                        "index": 289,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "F469414D2D3713440A194491B8ED2D4EF7F1",
                        "defaultText": "FAF5553D4BE3D248885B6F58A00197A898C3"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "9368524F17585145036846583FF32DE53E46",
                "expanded": true
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Flag locale 4",
                        "index": 163,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CD6E9CF75B0DF542717BA7318694082702AE"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Forest Map"
                },
                "indent": 1,
                "uid": "1BB352E378D083486A3B55827604EE69BC9F",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Location SCENE 5",
                        "index": 290,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "B8E9B32E27B2D74E613ADD236D19AC9B37AE",
                        "defaultText": ""
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "F948D1764140354D5D588692225EA0EE24B5",
                "expanded": true
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "A9532DC66A68384EAA5B54A336AB3381F0A4"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Forest Map"
                },
                "indent": 1,
                "uid": "A8DA1DE54730D144542BC7055AACBB1A77B5",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Location SCENE 5",
                        "index": 290,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "FED667D27F9C704F4E1B98F7E900790113F2",
                        "defaultText": "9DA4B9C4809FB54D9A8A03B1172C93FEE803"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "B441FAF329586349C98BDB9994B44BA8474C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "86CBAC798809154F145BAB489EC84573234C",
                    "parameters": {
                        "values": [
                            {
                                "lcId": "3CA94AF78551E841993AB546FD1BDCDEC5EC",
                                "defaultText": "Magnolia Palace"
                            },
                            {
                                "name": "Location SCENE 1",
                                "index": 286,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            5,
                            3,
                            "Viborera Mall",
                            {
                                "name": "Location SCENE 2",
                                "index": 287,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            5,
                            3,
                            "Magnolian House 1",
                            {
                                "name": "Location SCENE 3",
                                "index": 288,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            5,
                            3,
                            "Magnolian House 2",
                            {
                                "name": "Location SCENE 4",
                                "index": 289,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            5,
                            3,
                            "Tanaba Forest",
                            {
                                "name": "Location SCENE 5",
                                "index": 290,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            -5,
                            0,
                            "",
                            "",
                            0,
                            0
                        ],
                        "uid": "31D16C2524E8A34A727B4983BF2D3732A844"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "06B2B44F3E3FC84F48588A0147624E941173"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "4445F1AC8A63F745F518340809A7E970C52A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C352C99817CE744B2B4A5254C026001D2877"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "EVENTI EVENTUALI"
                },
                "indent": 0,
                "uid": "D3811DD22C6CA141243BE9E5B77691CE9D9F",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "Eventi Scena"
                },
                "indent": 0,
                "uid": "152ACDA335737043A02BA91310A06F1A6309"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Special debug for Kalevala ch4",
                        "index": 275,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "517A7061053DA24DEE389F81E88BE4D49617"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "",
                        "index": 39,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "8FD6AB391D3E9047233A1DF7ADCA277B997A"
            },
            {
                "id": "gs.EraseHotspot",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1
                },
                "indent": 2,
                "uid": "6329B56554077147A15A55F0AC16BD99FF69"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "4A329A96986EA6411A3B0A7592C82687917A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 2,
                "uid": "51FEB452009060409C6835666EEFAB2B85A6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "96E8865C46A6744AF298785563F5D69BB4F3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 2,
                "uid": "678ABAEA7AFE0242FD8A1522AC2794C70110"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A1F3F1D799DDC043B218386049F1B8B86EA2",
                    "parameters": {
                        "values": [
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            "",
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "EF2B2CD54DFA74464889B10862B039C50264"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 2,
                "uid": "B5BD7C2729D8714556583B380BB059806DCA"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "",
                        "index": 39,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "7978A1503319B54315690333A28DD6C0F0F3"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Special debug for Kalevala ch4",
                        "index": 275,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "045304AE4B403644CC5A70162BB1414D5FDD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "7601D85C3700D2424D6B5E62901196D79FD3",
                    "parameters": {
                        "values": [
                            20
                        ]
                    }
                },
                "indent": 2,
                "uid": "7754490C26C849432A9AB375D393185CD4B5"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "RiformaHotspots",
                    "target": "activeScene"
                },
                "indent": 2,
                "uid": "A0AB1E449E89324AB4693EE8A999DA689940"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Flag locale 5",
                        "index": 164,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E76AF83813E7F24EC63B3AC10D243AFB1F7C"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Flag locale 5",
                        "index": 164,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "FA03610D55879742BB0BFFD6C172BD38E055"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "piedino",
                    "target": "activeScene"
                },
                "indent": 1,
                "uid": "AC78446C8BF7154DAA2AFFF286F9D9D5BB5C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "15224E583986C649652961F8D83C325E97D6",
                    "parameters": {
                        "values": [
                            2,
                            30,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "C1A8743028652043C04ACA956D76AEECE070"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Risultato calcolo %: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E80530893C04A045AD3892766BDD09AE9526"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "7E1C46E045C0544AA9882DF2D022C33FABDD",
                        "name": "C4-03 passage - To ending (time's up)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "57A0A3175B9F1447D05AFB96AE50976ED4CB"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Pause allowed bc IN EXPLORATION / CHOICE?",
                        "index": 156,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7338FBD468ACF844D06BCCC2EBD7B939A8A6"
            },
            {
                "id": "gs.Idle",
                "params": {},
                "indent": 0,
                "uid": "46ACC513774287460E98FEA28F9DDFA9919D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D7547A96549313459078E4251677136450B5",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F9175A221545F64463198C8579F733397DF3"
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            },
            {
                "name": "",
                "index": 1,
                "scope": 1
            },
            {
                "name": "",
                "index": 2,
                "scope": 1
            },
            {
                "name": "",
                "index": 3,
                "scope": 1
            },
            {
                "name": "",
                "index": 4,
                "scope": 1
            },
            {
                "name": "",
                "index": 5,
                "scope": 1
            },
            {
                "name": "",
                "index": 6,
                "scope": 1
            },
            {
                "name": "",
                "index": 7,
                "scope": 1
            },
            {
                "name": "",
                "index": 8,
                "scope": 1
            },
            {
                "name": "",
                "index": 9,
                "scope": 1
            },
            {
                "name": "",
                "index": 10,
                "scope": 1
            },
            {
                "name": "",
                "index": 11,
                "scope": 1
            },
            {
                "name": "",
                "index": 12,
                "scope": 1
            },
            {
                "name": "",
                "index": 13,
                "scope": 1
            },
            {
                "name": "",
                "index": 14,
                "scope": 1
            },
            {
                "name": "",
                "index": 15,
                "scope": 1
            },
            {
                "name": "",
                "index": 16,
                "scope": 1
            },
            {
                "name": "",
                "index": 17,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "",
                "index": 18,
                "scope": 1
            },
            {
                "name": "",
                "index": 19,
                "scope": 1
            },
            {
                "name": "",
                "index": 20,
                "scope": 1
            },
            {
                "name": "",
                "index": 21,
                "scope": 1
            },
            {
                "name": "",
                "index": 22,
                "scope": 1
            },
            {
                "name": "",
                "index": 23,
                "scope": 1
            },
            {
                "name": "",
                "index": 24,
                "scope": 1
            },
            {
                "name": "",
                "index": 25,
                "scope": 1
            },
            {
                "name": "",
                "index": 26,
                "scope": 1
            },
            {
                "name": "",
                "index": 27,
                "scope": 1
            },
            {
                "name": "",
                "index": 28,
                "scope": 1
            },
            {
                "name": "",
                "index": 29,
                "scope": 1
            },
            {
                "name": "",
                "index": 30,
                "scope": 1
            },
            {
                "name": "",
                "index": 31,
                "scope": 1
            },
            {
                "name": "",
                "index": 32,
                "scope": 1
            },
            {
                "name": "",
                "index": 33,
                "scope": 1
            },
            {
                "name": "",
                "index": 34,
                "scope": 1
            },
            {
                "name": "",
                "index": 35,
                "scope": 1
            },
            {
                "name": "",
                "index": 36,
                "scope": 1
            },
            {
                "name": "",
                "index": 37,
                "scope": 1
            },
            {
                "name": "",
                "index": 38,
                "scope": 1
            },
            {
                "name": "",
                "index": 39,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}