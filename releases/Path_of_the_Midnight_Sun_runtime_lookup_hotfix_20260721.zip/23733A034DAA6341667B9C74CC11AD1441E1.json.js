GS.dataCache['23733A034DAA6341667B9C74CC11AD1441E1'] = {
    "uid": "23733A034DAA6341667B9C74CC11AD1441E1",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C4-02d P1 (after quest) Elegant lady",
        "type": "vn.scene",
        "parentId": "87FD145703BB844E776AD18916F72FE2AC53",
        "chapterUid": "6FC0AF36453CA744B128EAF83314DDE5F897",
        "order": 0,
        "livePreviewDisabled": true,
        "commands": [
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FD5669205DF3A4456C3B494138FDE78D41A7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "35E727C13235A34BB2484CE15852F7648C48",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C223B6B2748B85472089D041D56285C19C01"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "66EA46F64E04E449993AEF277ECF57AF0CE9",
                    "parameters": {
                        "values": [
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "47BD79ED8D68B34CF39A08E7A615EF0059D6"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "71FCA53984E2694A286ACF6773A0186539F0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35E727C13235A34BB2484CE15852F7648C48",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "D6E1119F60228545EB39B1859B61FFE616F3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "79CB007C8EDF8840705AA0D21000ED83779C",
                        "defaultText": "부탁한 물건은 가져왔나?"
                    },
                    "position": 0,
                    "characterId": "35E727C13235A34BB2484CE15852F7648C48",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "expanded": true,
                "uid": "853D8A3C305C7840D1994A345D470BFE447F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E5BB06081E7AE048A13A8EC02482EF75F9E5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "54AA42AA7A187645C02954E54D258A5084B2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4E47A8EA72544143D588D3E72AEF5C74B2EF",
                        "defaultText": "여기 있습니다."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "D34994CE8089E8427119A5037EB6FAA4A6C4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "C12ED46B48F30145D65874F665236996795B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "2738208B9A4897481F0B8172FE322E876A70"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 1,
                "uid": "D741A0C920FE9442473BDF721FE0BC983F7C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "16BEA919453249461948D4029C18A41D46B5",
                    "parameters": {
                        "values": [
                            "FFD534A9961777498C18E222452B542B6E53",
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "8F1015865DCD4340922A5170C98672CFC7AD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "422B49CA8A63A04CB338ADD9E56A9BFB25A0",
                    "parameters": {
                        "values": [
                            "",
                            {
                                "lcId": null,
                                "defaultText": "You delivered: {C:1}Potato x1{C:0}."
                            },
                            {
                                "lcId": null,
                                "defaultText": ""
                            },
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "BCE038C82AE80742D7986C828818AB94EE98"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6FE3C1466BE6D749E93B1A1763C2A8DE2900",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "07EBF77773EC114E6C492901431BF3739C28"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 1,
                "uid": "7EE258501AFAA84F35699164C752E035E00A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "1E5849F142D37549D5086165A9B2986323A8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "35E727C13235A34BB2484CE15852F7648C48",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "A070720A4702684DAB283CD45460AAD27B23"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "35E727C13235A34BB2484CE15852F7648C48",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "1699A5EC4E0BB94EF5882CD7490BEB0C0FA0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "4B3B50AB6CD2D245529800D68179D4A169C1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AEE8BF946C156043D66841B30DA0B9EF16AA",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-ElegantLadyMagnolia_line4.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3F47E612123C0543F60B188897FCB5C9F8D0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1B8A2E7130A591446619FFA0C178D6BBBEF5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35E727C13235A34BB2484CE15852F7648C48",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7D58B8FD23115549E75AA79840C61405F866"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1A33DFBD00DB16451968D7D767536D7781A5",
                        "defaultText": "훌륭해! 이걸로 그녀를 위한 성대한 저녁 식사를 준비할 수 있겠어..."
                    },
                    "position": 0,
                    "characterId": "35E727C13235A34BB2484CE15852F7648C48",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "FCABF2BF5C82394AE78AC496BA29AFD5E9A0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E45900F183B7F7400B2807B1F739FB21082E"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1B1EDF94775CE04D4108E173BE22C3958ECF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "B270E10D9C2C744FE47A8C0171A13643445C"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of quest",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "F005C5AC835DB14EFC293F45943A49E4C19C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "044C0DC55BD8B94C966A00E813E6A779704B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8A9937803F62B24BAA79D8F234196BB46521",
                        "defaultText": "손님을 기다리는 건가? 하지만 식탁은 한 사람 몫만 차려져 있는데..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E875929A7C910148AE48054833382073A4F8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "66FC28A16BF4A94B7158BDC877C7E6DB0783"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35E727C13235A34BB2484CE15852F7648C48",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EF5D74F4683A2345491AC2174F0B0DD0BB44"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FE9E6E625752474C3998D294FF9A9626D1D0",
                        "defaultText": "이걸 받아 줘! 오호호호!"
                    },
                    "position": 0,
                    "characterId": "35E727C13235A34BB2484CE15852F7648C48",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FDBE05255B745747C839EF684B1191BDEF0A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "1AA50B9B6C6265462629F1C7EF9C4BB1DF11"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5AC855115C77B642225A94E6333D219E4A08"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "1730D1C30A07754E8439F466E1717E4FFC27"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "reward"
                },
                "indent": 0,
                "uid": "ADEEF04391F1B646970B6E32BA527B6E8EFA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "BB1C08930EA5014D2D6BE5D7FA7BDA4C43D8",
                    "parameters": {
                        "values": [
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "F7FC18DB28A4D24900085BD7D03A5BA7FD0B"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "F2AB7DC87AB5214599282572694F3375F6A1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F34876CA302F87445E49D932DA6788661CCE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "35E727C13235A34BB2484CE15852F7648C48",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6F80767F43CA71471B391C24A5577C51B9F9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "35E727C13235A34BB2484CE15852F7648C48",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "1EE97CAA7713F2460D7BA593B458F6175B48"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B805A90E40174848F919F2772F3C502C126B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1F25F70E3F94884DF76B0E25A9FFE299F018"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D9A4D47C6D6D9048D939FAB82F0B7560ADED",
                        "defaultText": "집 안에서 '그녀'의 사진을 몇 장 봤습니다, 부인."
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "605C1A223EBFC54B899884881DFEBCA32C91",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E6E63EA6692BD74A748B3E687A41FB9A804E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D26263AE9A3D9646197B19E177C60CDC30A2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C26927429673684C3A6A2D178EC9508C94B8",
                        "defaultText": "잠깐, 내가 본 건 이 부인의 사진뿐이었는데..."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C31F38DA9928A241FA38852694BA3F73529A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9873D0E34F1B0844533A1FC7710374F7CCFA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B41EE3D73E055848744AD914A8FF4CFC3164"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EEF14A386F7A0248C00ACF88C32F6DE7CC34",
                        "defaultText": "... ... ... 아."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "27B304646849514F1288B058B52FFA690E07",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "04C447977910334C99986C743AA304EA4C15"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "end of quest"
                },
                "indent": 0,
                "uid": "5879873614AAF940EA1820C06356462F7FF8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E920201C4F2E3145BB294516B8A90CB47DF2",
                        "defaultText": "'그녀'라고 말할 때... 자기 자신을 뜻한 건가!?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2B9BD4C94C78834FDA19F17273802F6C2C8F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FB7FC5F6514828472D8AE410EBD57E1DE867"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "00433BBE222683462E5BD1C7C0EEA5062092"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C8ADA673823E724138294D9477E1F64BCD22",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-ElegantLadyMagnolia_line6_3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5E6A98CF4BD14945AA5B41D45CBF29F14B81",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "D9A47E6C6244F14A806AEF6369DBC11CAF3B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35E727C13235A34BB2484CE15852F7648C48",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "18BE54A431D2A343B329733687D7745EE356"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6A5D36F211FE2644FF18DF12832B4CC78F4F",
                        "defaultText": "그녀는 이 요리로 아픔을 달래며 아주 행복해할 거야!\n내가 누구보다 그녀를 잘 알지!"
                    },
                    "position": 0,
                    "characterId": "35E727C13235A34BB2484CE15852F7648C48",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9F76C39D83E095417E08AB69BE9401305313",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "0669BDE760EC0543A82B1AE33DF92CAD47E3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F7BDB6B42455E840AF6B4C26E07C0878A3C5"
            }
        ],
        "localizableStrings": {
            "79CB007C8EDF8840705AA0D21000ED83779C": {
                "t": "Do you have the things I requested?",
                "d": {
                    "cid": "35E727C13235A34BB2484CE15852F7648C48",
                    "eid": "853D8A3C305C7840D1994A345D470BFE447F"
                }
            },
            "4E47A8EA72544143D588D3E72AEF5C74B2EF": {
                "t": "Here you go.",
                "d": {
                    "cid": 0,
                    "eid": "D34994CE8089E8427119A5037EB6FAA4A6C4"
                }
            },
            "1A33DFBD00DB16451968D7D767536D7781A5": {
                "t": "Excellent! With these, I'll be able to prepare a magnificent dinner for her...",
                "d": {
                    "cid": "35E727C13235A34BB2484CE15852F7648C48",
                    "eid": "FCABF2BF5C82394AE78AC496BA29AFD5E9A0"
                }
            },
            "8A9937803F62B24BAA79D8F234196BB46521": {
                "t": "Is she waiting for a guest? But the table is set for only one person...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "E875929A7C910148AE48054833382073A4F8"
                }
            },
            "FE9E6E625752474C3998D294FF9A9626D1D0": {
                "t": "Please accept this! Ohohoh!",
                "d": {
                    "cid": "35E727C13235A34BB2484CE15852F7648C48",
                    "eid": "FDBE05255B745747C839EF684B1191BDEF0A"
                }
            },
            "D9A4D47C6D6D9048D939FAB82F0B7560ADED": {
                "t": "I couldn't help but notice a few pictures of \"her\" in the house, madame.",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "605C1A223EBFC54B899884881DFEBCA32C91"
                }
            },
            "C26927429673684C3A6A2D178EC9508C94B8": {
                "t": "Wait, I've only seen pictures of this madame, though...",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "C31F38DA9928A241FA38852694BA3F73529A"
                }
            },
            "6A5D36F211FE2644FF18DF12832B4CC78F4F": {
                "t": "She will be very happy to soothe her pain with this dish! I know her better than anyone!",
                "d": {
                    "cid": "35E727C13235A34BB2484CE15852F7648C48",
                    "eid": "9F76C39D83E095417E08AB69BE9401305313"
                }
            },
            "EEF14A386F7A0248C00ACF88C32F6DE7CC34": {
                "t": "... ... ... Oh.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "27B304646849514F1288B058B52FFA690E07"
                }
            },
            "E920201C4F2E3145BB294516B8A90CB47DF2": {
                "t": "When she says \"her\", could she be referring to... herself!?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "2B9BD4C94C78834FDA19F17273802F6C2C8F"
                }
            },
            "AEE8BF946C156043D66841B30DA0B9EF16AA": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "3F47E612123C0543F60B188897FCB5C9F8D0"
                }
            },
            "C8ADA673823E724138294D9477E1F64BCD22": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "5E6A98CF4BD14945AA5B41D45CBF29F14B81"
                }
            }
        },
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}